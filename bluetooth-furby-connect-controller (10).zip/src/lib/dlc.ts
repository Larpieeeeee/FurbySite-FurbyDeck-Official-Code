/**
 * Furby Connect DLC container parser.
 * Layout reverse-engineered by Context IS (ctxis/Furby) and described in bluefluff's doc:
 *   40-byte magic ("F\0U\0R\0B\0Y" + padding + 78 56 34 12 02 00 08 00)
 *   header of 0x288 bytes: 16 entries × 38 bytes, each entry = "DLC_0000." prefix,
 *   3-char tag at +18 (every other byte), counter at +26, little-endian size at +30.
 *   Registered sections follow the header sequentially in header-field order.
 */
export interface DlcSection {
  tag: string;
  offset: number;
  size: number;
  /** derived content count, when cheap to compute */
  count?: number;
  countLabel?: [string, string];
}

export interface DlcInfo {
  ok: boolean;
  error?: string;
  total: number;
  sections: DlcSection[];
  head: string;
}

const HEADER_LEN = 0x288;
const ENTRY_LEN = 38;
const MAGIC_TAIL = [0x78, 0x56, 0x34, 0x12, 0x02, 0x00, 0x08, 0x00];
const FIELDS = ["???", "PAL", "SPR", "CEL", "XLS", "???", "???", "???", "???", "AMF", "APL", "LPS", "SEQ", "MTR", "???", "???"];

export const SECTION_NAMES: Record<string, [string, string]> = {
  PAL: ["Палитры цветов", "Colour palettes"],
  SPR: ["Плейлисты кадров", "Frame playlists"],
  CEL: ["Спрайты глаз", "Eye sprites"],
  XLS: ["Дерево действий", "Action tree"],
  AMF: ["Аудиодорожки", "Audio tracks"],
  APL: ["Аудиоплейлисты", "Audio playlists"],
  LPS: ["Артикуляция губ", "Lip movements"],
  SEQ: ["Последовательности", "Sequences"],
  MTR: ["Движения сервоприводов", "Servo movements"],
};

const COUNT_LABEL: Record<string, [string, string]> = {
  PAL: ["палитр по 64 цвета", "64-colour palettes"],
  CEL: ["кадров глаз", "eye frames"],
  AMF: ["аудиодорожек", "audio tracks"],
};

export const toHex = (bytes: Uint8Array, max = bytes.length) => {
  let out = "";
  for (let i = 0; i < Math.min(max, bytes.length); i++) out += bytes[i].toString(16).padStart(2, "0") + (i % 16 === 15 ? "\n" : " ");
  return out.trim();
};

export function parseDlc(data: Uint8Array): DlcInfo {
  const fail = (error: string): DlcInfo => ({ ok: false, error, total: data.length, sections: [], head: toHex(data, 64) });
  if (data.length < HEADER_LEN) return fail("файл слишком маленький для DLC");
  // magic: F\0U\0R\0B\0Y (9 bytes) + 23 zero bytes + 8 marker bytes
  for (let i = 0; i < 5; i++) if (data[i * 2] !== "FURBY".charCodeAt(i) || data[i * 2 + 1] !== 0) return fail("нет магии FURBY — это не DLC");
  for (let i = 0; i < MAGIC_TAIL.length; i++) if (data[32 + i] !== MAGIC_TAIL[i]) return fail("повреждённая сигнатура заголовка");

  const numEntries = Math.floor((HEADER_LEN - 40) / ENTRY_LEN);
  const sections: DlcSection[] = [];
  let cursor = HEADER_LEN;
  for (let i = 0; i < numEntries; i++) {
    const e = 40 + i * ENTRY_LEN;
    // "D\0L\0C\0_\00\00\00\0.\00" prefix (18 bytes)
    const prefix = [0x44, 0, 0x4c, 0, 0x43, 0, 0x5f, 0, 0x30, 0, 0x30, 0, 0x30, 0, 0x30, 0, 0x2e, 0];
    let ok = true;
    for (let k = 0; k < prefix.length; k++) if (data[e + k] !== prefix[k]) { ok = false; break; }
    if (!ok) continue;
    const tag = String.fromCharCode(data[e + 18], data[e + 20], data[e + 22]);
    const size = (data[e + 30] | (data[e + 31] << 8) | (data[e + 32] << 16) | (data[e + 33] << 24)) >>> 0;
    if (!FIELDS.includes(tag) || tag === "???" || size === 0) continue;
    const section: DlcSection = { tag, offset: cursor, size };
    if (tag === "PAL") {
      section.count = Math.floor(size / 0x80);
      section.countLabel = COUNT_LABEL.PAL;
    } else if (tag === "CEL") {
      section.count = Math.floor(size / 0xc00);
      section.countLabel = COUNT_LABEL.CEL;
    } else if (tag === "AMF" && size >= 4 && section.offset + 4 <= data.length) {
      section.count = (data[section.offset] | (data[section.offset + 1] << 8) | (data[section.offset + 2] << 16) | (data[section.offset + 3] << 24)) >>> 0;
      if (section.count > 10000) section.count = undefined;
      if (section.count !== undefined) section.countLabel = COUNT_LABEL.AMF;
    }
    sections.push(section);
    cursor += size;
  }
  if (sections.length === 0) return fail("в заголовке не найдено ни одной секции");
  return { ok: true, total: data.length, sections, head: toHex(data, 64) };
}

/** Best-effort extraction of a DLC from the toy (undocumented territory). */
export function guessFileSize(bytes: Uint8Array): number | undefined {
  // plausible DLC sizes: 4 KB … 16 MB
  const u32 = (o: number) => (bytes[o] | (bytes[o + 1] << 8) | (bytes[o + 2] << 16) | (bytes[o + 3] << 24)) >>> 0;
  for (let o = 0; o + 4 <= bytes.length; o += 4) {
    const v = u32(o);
    if (v >= 4096 && v <= 16 * 1024 * 1024 && v % 4 === 0) return v;
  }
  return undefined;
}
