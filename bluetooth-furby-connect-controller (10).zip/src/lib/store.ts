import { useSyncExternalStore } from "react";

export interface Store<T> {
  get(): T;
  set(patch: Partial<T> | ((state: T) => Partial<T>)): void;
  reset(): void;
  subscribe(listener: () => void): () => void;
  /** React hook. Selectors must return primitives or stable references. */
  use<U>(selector: (state: T) => U): U;
}

function load(key: string): Record<string, unknown> {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

/**
 * Tiny external store. With a `key` the state is saved to localStorage
 * and merged with the defaults on load, so new fields always get a value.
 */
export function createStore<T extends object>(
  defaults: T,
  key?: string,
  merge: (defaults: T, saved: Record<string, unknown>) => T = (d, s) => ({ ...d, ...s }) as T,
): Store<T> {
  let state: T = key ? merge(defaults, load(key)) : { ...defaults };
  const listeners = new Set<() => void>();
  let timer: ReturnType<typeof setTimeout> | undefined;

  const save = () => {
    if (!key) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      try {
        localStorage.setItem(key, JSON.stringify(state));
      } catch {
        /* storage full or blocked */
      }
    }, 150);
  };

  const emit = () => listeners.forEach((listener) => listener());

  const store: Store<T> = {
    get: () => state,
    set(patch) {
      const next = typeof patch === "function" ? patch(state) : patch;
      state = { ...state, ...next };
      save();
      emit();
    },
    reset() {
      state = { ...defaults };
      save();
      emit();
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    use: (selector) => useSyncExternalStore(store.subscribe, () => selector(state)),
  };
  return store;
}
