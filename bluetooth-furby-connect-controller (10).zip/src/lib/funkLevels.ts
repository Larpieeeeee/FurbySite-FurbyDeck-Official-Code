import type { SongSpec } from "./audio/synth";
import { createStore } from "./store";

/** 32 sixteenth steps; -1 = empty, 0..10 = scale degree (lane = degree % 4) */
export interface FunkChart {
  opp: number[];
  player: number[];
}

export interface CustomLevel {
  id: string;
  name: string;
  scene: string;
  /** index into FUNK_CHARS */
  opponent: number;
  /** index into LOOKS (5 = default player) */
  playerKind: number;
  spec: SongSpec;
  chart: FunkChart;
  updated: number;
}

export const emptyChart = (): FunkChart => ({ opp: Array(32).fill(-1), player: Array(32).fill(-1) });

export const newLevel = (): CustomLevel => ({
  id: Math.random().toString(36).slice(2, 10),
  name: "Мой уровень",
  scene: "theater",
  opponent: 0,
  playerKind: 5,
  spec: { seed: Math.floor(Math.random() * 99999), bpm: 120, scale: "minor", root: 57, style: 0, density: 0.5 },
  chart: emptyChart(),
  updated: Date.now(),
});

export const funkLevels = createStore<{ list: CustomLevel[] }>({ list: [] }, "furby.funklevels.v1");

export const levelOps = {
  upsert(level: CustomLevel) {
    funkLevels.set((s) => {
      const list = s.list.some((l) => l.id === level.id) ? s.list.map((l) => (l.id === level.id ? level : l)) : [...s.list, level];
      return { list };
    });
  },
  remove(id: string) {
    funkLevels.set((s) => ({ list: s.list.filter((l) => l.id !== id) }));
  },
};
