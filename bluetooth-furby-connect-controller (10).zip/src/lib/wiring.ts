/** Connects the independent modules (stats, XP, achievements, lights, automation) without import cycles. */
import { CircleCheck, ListChecks, Trophy } from "lucide-react";
import { refreshFiles } from "./audio/music";
import { sfx } from "./audio/synth";
import { startAutomation } from "./automation";
import { broadcast, furby, furby2 } from "./furby/controller";
import { startLight } from "./furby/lighting";
import { pick, tr } from "./i18n";
import { onLevel, onQuest, onUnlock, progress, rankOf } from "./progress";
import { settings } from "./settings";
import { quietToasts, toast } from "./toast";

let prevStatus = furby.getState().status;

furby.onCommand = () => {
  progress.bump("commands");
  progress.count("cmd");
  progress.addXp(1);
};
furby.onPhrase = () => {
  progress.bump("phrases");
  progress.count("talk");
  progress.addXp(2);
};

const watchConnect = (get: () => typeof furby) => () => {
  const st = get().getState();
  if (st.status === prevStatus) return;
  if (st.status === "ready") {
    const other = get() === furby ? furby2 : furby;
    const otherUp = other.getState().status === "ready" || other.getState().status === "confirming" || other.getState().status === "connecting";
    if (otherUp) {
      // adding a second toy is routine: no toast flood from achievements and level-ups
      quietToasts(2600);
      progress.bump("connects");
      if (st.demo) progress.bump("demos");
    } else {
      progress.bump("connects");
      if (st.demo) progress.bump("demos");
      toast(tr("Ферби на связи", "Furby is connected"), tr("Комбинация принята, можно управлять", "Combination accepted, you're in control"), CircleCheck);
    }
    const s = settings.get();
    const effect = s.connectEffect || (s.restoreLight ? s.lightMode : "");
    if (effect) window.setTimeout(() => startLight(effect), 700);
  }
  prevStatus = st.status;
};
furby.subscribe(watchConnect(() => furby));
furby2.subscribe(watchConnect(() => furby2));

furby2.onCommand = furby.onCommand;
furby2.onPhrase = furby.onPhrase;

for (const f of [furby, furby2]) {
  f.onInput((e) => {
    if (e.type === "shake") progress.count("shake");
  });
}

onUnlock((a) => {
  toast(`${tr("Ачивка", "Achievement")}: ${pick(a.name)}`, pick(a.desc), a.icon);
  sfx("level");
  broadcast((f) => f.say("achievement"));
});
onLevel((level) => {
  toast(tr(`Уровень ${level}!`, `Level ${level}!`), `${tr("Новый ранг", "Rank")}: ${pick(rankOf(level).name)}`, Trophy);
  sfx("win");
});
onQuest((q) => toast(tr("Задание выполнено", "Quest complete"), `${pick(q.text)} · +${q.reward} XP`, ListChecks));

// Demo mode: arrow keys move the virtual antenna (outside of games)
const key = (down: boolean) => (e: KeyboardEvent) => {
  const el = e.target as HTMLElement | null;
  if (el && /INPUT|TEXTAREA|SELECT/.test(el.tagName)) return;
  // keys go to the toy that needs them most: handshake first, then a game, then any demo
  const toys = [furby, furby2];
  const active =
    toys.find((t) => t.getState().status === "confirming") ??
    toys.find((t) => t.getState().inGame) ??
    toys.find((t) => t.isDemo);
  if (active?.demoKey(e.code, down)) e.preventDefault();
};
window.addEventListener("keydown", key(true));
window.addEventListener("keyup", key(false));

startAutomation();
void refreshFiles();
