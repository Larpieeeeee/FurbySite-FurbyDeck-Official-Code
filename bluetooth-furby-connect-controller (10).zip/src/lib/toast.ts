import type { LucideIcon } from "lucide-react";
import { settings } from "./settings";
import { createStore } from "./store";

export type ToastTone = "ok" | "warn" | "err";

export interface Toast {
  id: number;
  title: string;
  text?: string;
  icon?: LucideIcon;
  tone: ToastTone;
}

export const toasts = createStore<{ items: Toast[] }>({ items: [] });

let counter = 0;
let quietUntil = 0;

/** Suppresses informational toasts for a moment (e.g. while a second toy connects). */
export function quietToasts(ms: number) {
  quietUntil = Date.now() + ms;
}

export function dismissToast(id: number) {
  toasts.set((s) => ({ items: s.items.filter((t) => t.id !== id) }));
}

export function toast(title: string, text?: string, icon?: LucideIcon, tone: ToastTone = "ok") {
  if (tone !== "err" && (Date.now() < quietUntil || !settings.get().toasts)) return;
  const id = ++counter;
  toasts.set((s) => ({ items: [...s.items, { id, title, text, icon, tone }].slice(-4) }));
  setTimeout(() => dismissToast(id), 4200);
}
