/** IndexedDB storage for user-uploaded music, so tracks survive page reloads. */
export interface StoredTrack {
  id: string;
  name: string;
  type: string;
  size: number;
  added: number;
  blob: Blob;
}

export type TrackMeta = Omit<StoredTrack, "blob">;

const DB_NAME = "furby-connect";
const STORE = "tracks";
let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: "id" });
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  return dbPromise;
}

function run<T>(mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const request = fn(db.transaction(STORE, mode).objectStore(STORE));
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      }),
  );
}

export const idbAll = () => run<StoredTrack[]>("readonly", (s) => s.getAll());
export const idbGet = (id: string) => run<StoredTrack | undefined>("readonly", (s) => s.get(id));
export const idbPut = (track: StoredTrack) => run("readwrite", (s) => s.put(track));
export const idbDelete = (id: string) => run("readwrite", (s) => s.delete(id));
export const idbClear = () => run("readwrite", (s) => s.clear());
