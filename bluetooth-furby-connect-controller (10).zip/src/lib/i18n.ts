import { useCallback } from "react";
import { settings, useSettings, type Lang } from "./settings";

export type { Lang };

/** A translated string: [Russian, English]. Both are required, so nothing stays untranslated. */
export type Text = readonly [string, string];
export type T = (ru: string, en: string) => string;

export const LANGS: Array<{ id: Lang; name: string }> = [
  { id: "ru", name: "Русский" },
  { id: "en", name: "English" },
];

export const pick = (text: Text, lang: Lang = settings.get().lang): string => (lang === "en" ? text[1] : text[0]);

/** For code outside React (logs, toasts, games). */
export const tr: T = (ru, en) => (settings.get().lang === "en" ? en : ru);

export function useLang(): Lang {
  return useSettings((s) => s.lang);
}

export function useT(): T {
  const lang = useLang();
  return useCallback((ru: string, en: string) => (lang === "en" ? en : ru), [lang]);
}

export function formatNumber(value: number, lang: Lang = settings.get().lang): string {
  const abs = Math.abs(value);
  const units = lang === "en" ? ["", "K", "M", "B", "T", "Qa"] : ["", " тыс.", " млн", " млрд", " трлн", " квдр"];
  if (abs < 1000) return String(Math.floor(value));
  const tier = Math.min(units.length - 1, Math.floor(Math.log10(abs) / 3));
  const scaled = value / 10 ** (tier * 3);
  return `${scaled.toFixed(scaled < 10 ? 2 : scaled < 100 ? 1 : 0)}${units[tier]}`;
}
