import { broadcast, furby, furby2 } from "../furby/controller";
import type { Text } from "../i18n";
import { idbAll, idbClear, idbDelete, idbGet, idbPut, type TrackMeta } from "../idb";
import { progress } from "../progress";
import { settings } from "../settings";
import { createStore } from "../store";
import { audio, compose, scheduleBar, type Composition, type ScaleName, type SongSpec } from "./synth";

export interface BuiltinTrack {
  id: string;
  name: Text;
  spec: SongSpec;
  lead: OscillatorType;
}

const track = (id: string, ru: string, en: string, seed: number, bpm: number, scale: ScaleName, style: number, density: number, lead: OscillatorType, root = 57): BuiltinTrack => ({
  id,
  name: [ru, en],
  spec: { seed, bpm, scale, root, style, density },
  lead,
});

export const BUILTIN: BuiltinTrack[] = [
  track("disco", "Пушистое диско", "Fluffy Disco", 11, 118, "major", 0, 0.5, "square"),
  track("city", "Ночной город", "Night City", 23, 100, "minor", 1, 0.45, "sawtooth"),
  track("lofi", "Облака лоу-фай", "Lo-fi Clouds", 37, 82, "dorian", 3, 0.35, "triangle"),
  track("quest", "Пиксельный квест", "Pixel Quest", 41, 140, "major", 2, 0.6, "square", 60),
  track("cosmo", "Космо-хаус", "Cosmo House", 53, 124, "minor", 0, 0.5, "sawtooth"),
  track("beach", "Солнечный пляж", "Sunny Beach", 67, 96, "mixo", 1, 0.4, "triangle"),
  track("rock", "Пуховый рок", "Fluff Rock", 71, 132, "minor", 2, 0.55, "sawtooth", 52),
  track("robots", "Танец роботов", "Robot Dance", 83, 112, "penta", 0, 0.5, "square"),
  track("garden", "Весенний сад", "Spring Garden", 97, 104, "major", 3, 0.4, "triangle", 60),
  track("neon", "Неоновая гонка", "Neon Race", 101, 150, "minor", 2, 0.65, "square"),
  track("lullaby", "Колыбельная", "Lullaby", 113, 72, "major", 3, 0.3, "sine", 60),
  track("party", "Вечеринка", "Party Time", 127, 128, "mixo", 0, 0.6, "sawtooth"),
];

export interface MusicState {
  current: { kind: "builtin" | "file"; id: string; name: Text } | null;
  playing: boolean;
  level: number;
  beat: number;
  position: number;
  duration: number;
  files: TrackMeta[];
}

export const music = createStore<MusicState>({ current: null, playing: false, level: 0, beat: 0, position: 0, duration: 0, files: [] });

let comp: Composition | null = null;
let lead: OscillatorType = "square";
let bar = 0;
let nextBar = 0;
let schedTimer: number | undefined;
let trackGain: GainNode | null = null;
let el: HTMLAudioElement | null = null;
let objectUrl: string | null = null;
let meterTimer: number | undefined;

function ensureElement(): HTMLAudioElement {
  if (!el) {
    el = new Audio();
    const { ac, music: bus } = audio();
    ac.createMediaElementSource(el).connect(bus);
    el.addEventListener("ended", () => {
      if (!el?.loop) stopMusic();
    });
  }
  return el;
}

function schedule() {
  if (!comp || !trackGain) return;
  const { ac } = audio();
  while (nextBar < ac.currentTime + 0.25) {
    const b = bar % 8;
    const phrase = comp.phrases[[0, 0, 1, 1, 0, 0, 2, 2][b]];
    scheduleBar(comp, b, nextBar, trackGain, { lead, phrase, half: b % 2 });
    nextBar += comp.barDur;
    bar++;
  }
}

export function playBuiltin(id: string) {
  const t = BUILTIN.find((x) => x.id === id);
  if (!t) return;
  stopMusic(true);
  const { ac, music: bus } = audio();
  trackGain = ac.createGain();
  trackGain.connect(bus);
  comp = compose(t.spec);
  lead = t.lead;
  bar = 0;
  nextBar = ac.currentTime + 0.12;
  schedule();
  schedTimer = window.setInterval(schedule, 25);
  start({ kind: "builtin", id, name: t.name });
}

export async function playFile(id: string) {
  const rec = await idbGet(id);
  if (!rec) return;
  stopMusic(true);
  const a = ensureElement();
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = URL.createObjectURL(rec.blob);
  a.src = objectUrl;
  a.loop = settings.get().musicLoop;
  try {
    await a.play();
  } catch {
    return;
  }
  start({ kind: "file", id, name: [rec.name, rec.name] });
}

function start(current: NonNullable<MusicState["current"]>) {
  music.set({ current, playing: true });
  if (settings.get().dance) broadcast((f) => f.startDance());
  progress.bump("dances");
  startMeter();
}

/** Stops playback. `keepDance` is used when switching tracks so Furby keeps dancing. */
export function stopMusic(keepDance = false) {
  window.clearInterval(schedTimer);
  schedTimer = undefined;
  comp = null;
  if (trackGain) {
    const { ac } = audio();
    const g = trackGain;
    g.gain.setTargetAtTime(0, ac.currentTime, 0.02);
    window.setTimeout(() => g.disconnect(), 400);
    trackGain = null;
  }
  el?.pause();
  window.clearInterval(meterTimer);
  music.set({ playing: false, current: null, level: 0, beat: 0, position: 0, duration: 0 });
  if (!keepDance) broadcast((f) => f.stopDance());
}

export function setDance(on: boolean) {
  settings.set({ dance: on });
  if (on && music.get().playing) broadcast((f) => f.startDance());
  if (!on) broadcast((f) => f.stopDance());
}

export function seek(seconds: number) {
  if (el && music.get().current?.kind === "file") el.currentTime = seconds;
}

function startMeter() {
  window.clearInterval(meterTimer);
  const { analyser } = audio();
  const data = new Uint8Array(analyser.frequencyBinCount);
  let avg = 0;
  let beat = 0;
  let acc = 0;
  meterTimer = window.setInterval(() => {
    analyser.getByteFrequencyData(data);
    let sum = 0;
    let bass = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i];
      if (i < 8) bass += data[i];
    }
    const b = bass / 8 / 255;
    avg = avg * 0.92 + b * 0.08;
    beat = b > avg * 1.25 && b > 0.3 ? 1 : beat * 0.8;
    const isFile = music.get().current?.kind === "file" && el;
    music.set({ level: sum / data.length / 255, beat, position: isFile ? el!.currentTime : 0, duration: isFile ? el!.duration || 0 : 0 });
    if (beat === 1 && settings.get().beatLight) {
      const accent = settings.get().accent.replace("#", "");
      const v = parseInt(accent, 16);
      broadcast((f) => f.setLedFrame([(v >> 16) & 255, (v >> 8) & 255, v & 255], true));
    }
    acc += 0.05;
    if (acc >= 1) {
      acc = 0;
      if (furby.getState().dancing || furby2.getState().dancing) {
        progress.bump("danceSeconds");
        progress.count("dance");
      }
    }
  }, 50);
}

export async function refreshFiles() {
  try {
    const all = await idbAll();
    music.set({
      files: all.map((t) => ({ id: t.id, name: t.name, type: t.type, size: t.size, added: t.added })).sort((a, b) => b.added - a.added),
    });
  } catch {
    /* IndexedDB unavailable (private mode) */
  }
}

export async function addFiles(list: FileList | File[]) {
  for (const f of Array.from(list)) {
    if (!f.type.startsWith("audio/") && !/\.(mp3|wav|ogg|m4a|aac|flac|webm|opus)$/i.test(f.name)) continue;
    await idbPut({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name: f.name.replace(/\.[^.]+$/, ""),
      type: f.type,
      size: f.size,
      added: Date.now(),
      blob: f,
    });
    progress.bump("musicTracks");
  }
  try {
    await navigator.storage?.persist?.();
  } catch {
    /* not supported */
  }
  await refreshFiles();
}

export async function removeFile(id: string) {
  if (music.get().current?.id === id) stopMusic();
  await idbDelete(id);
  await refreshFiles();
}

export async function clearFiles() {
  if (music.get().current?.kind === "file") stopMusic();
  await idbClear();
  await refreshFiles();
}
