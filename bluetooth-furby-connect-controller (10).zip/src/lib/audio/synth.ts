/** Web Audio engine: drums, synths, "singing" voices, sound effects and a tiny song composer. */
import { settings } from "../settings";

export type SfxKind =
  | "click" | "coin" | "jump" | "hit" | "lose" | "win" | "tick" | "pop" | "level" | "error" | "shoot" | "boom" | "good" | "whoosh";

interface Engine {
  ac: AudioContext;
  music: GainNode;
  sfx: GainNode;
  analyser: AnalyserNode;
  noise: AudioBuffer;
}

let engine: Engine | null = null;

export function audio(): Engine {
  if (!engine) {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ac = new Ctor();
    const comp = ac.createDynamicsCompressor();
    comp.connect(ac.destination);
    const analyser = ac.createAnalyser();
    analyser.fftSize = 512;
    analyser.smoothingTimeConstant = 0.7;
    const music = ac.createGain();
    music.connect(analyser);
    analyser.connect(comp);
    const sfx = ac.createGain();
    sfx.connect(comp);
    const noise = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const data = noise.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    engine = { ac, music, sfx, analyser, noise };
    const apply = () => {
      const s = settings.get();
      music.gain.value = s.musicVolume;
      sfx.gain.value = s.sfx ? s.sfxVolume : 0;
    };
    apply();
    settings.subscribe(apply);
  }
  if (engine.ac.state === "suspended") void engine.ac.resume();
  return engine;
}

export const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

function envGain(ac: AudioContext, t: number, attack: number, peak: number, decay: number) {
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  return g;
}

function noiseBurst(t: number, out: AudioNode, type: BiquadFilterType, freq: number, peak: number, decay: number) {
  const { ac, noise } = audio();
  const src = ac.createBufferSource();
  src.buffer = noise;
  const f = ac.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  src.connect(f).connect(envGain(ac, t, 0.002, peak, decay)).connect(out);
  src.start(t, Math.random() * 0.5);
  src.stop(t + decay + 0.05);
}

export function kick(t: number, out: AudioNode) {
  const { ac } = audio();
  const o = ac.createOscillator();
  o.frequency.setValueAtTime(150, t);
  o.frequency.exponentialRampToValueAtTime(42, t + 0.13);
  o.connect(envGain(ac, t, 0.003, 0.85, 0.28)).connect(out);
  o.start(t);
  o.stop(t + 0.33);
}

export function snare(t: number, out: AudioNode) {
  const { ac } = audio();
  noiseBurst(t, out, "highpass", 1400, 0.4, 0.16);
  const o = ac.createOscillator();
  o.type = "triangle";
  o.frequency.setValueAtTime(220, t);
  o.frequency.exponentialRampToValueAtTime(140, t + 0.08);
  o.connect(envGain(ac, t, 0.002, 0.3, 0.09)).connect(out);
  o.start(t);
  o.stop(t + 0.13);
}

export function hat(t: number, out: AudioNode, open = false) {
  noiseBurst(t, out, "highpass", 7500, 0.16, open ? 0.2 : 0.035);
}

export interface ToneOpts {
  type?: OscillatorType;
  gain?: number;
  attack?: number;
  release?: number;
  cutoff?: number;
  detune?: number;
}

export function tone(t: number, freq: number, dur: number, out: AudioNode, o: ToneOpts = {}) {
  const { ac } = audio();
  const attack = o.attack ?? 0.005;
  const release = o.release ?? 0.06;
  const d = Math.max(dur, attack + 0.03);
  const peak = o.gain ?? 0.12;
  const osc = ac.createOscillator();
  osc.type = o.type ?? "square";
  osc.frequency.setValueAtTime(freq, t);
  if (o.detune) osc.detune.value = o.detune;
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + attack);
  g.gain.setValueAtTime(peak, Math.max(t + attack, t + d - release));
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  let node: AudioNode = osc;
  if (o.cutoff) {
    const f = ac.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = o.cutoff;
    osc.connect(f);
    node = f;
  }
  node.connect(g).connect(out);
  osc.start(t);
  osc.stop(t + d + 0.05);
}

export interface Timbre {
  formants: [number, number];
  type?: OscillatorType;
  vib?: number;
  gain?: number;
}

/** A synthetic "singing" voice: saw wave through two vowel formants with vibrato. */
export function voice(t: number, freq: number, dur: number, out: AudioNode, tb: Timbre) {
  const { ac } = audio();
  const d = Math.max(0.09, dur);
  const o = ac.createOscillator();
  o.type = tb.type ?? "sawtooth";
  o.frequency.setValueAtTime(freq * 0.94, t);
  o.frequency.exponentialRampToValueAtTime(freq, t + 0.04);
  const lfo = ac.createOscillator();
  lfo.frequency.value = 5.6;
  const lg = ac.createGain();
  lg.gain.setValueAtTime(0, t);
  lg.gain.linearRampToValueAtTime(freq * 0.016 * (tb.vib ?? 1), t + d * 0.6);
  lfo.connect(lg).connect(o.frequency);
  const g = ac.createGain();
  const peak = tb.gain ?? 0.5;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + 0.02);
  g.gain.setValueAtTime(peak, t + d * 0.75);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  for (const [f, q] of [
    [tb.formants[0], 6],
    [tb.formants[1], 8],
  ]) {
    const bp = ac.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = f;
    bp.Q.value = q;
    o.connect(bp).connect(g);
  }
  const lp = ac.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 900;
  const body = ac.createGain();
  body.gain.value = 0.18;
  o.connect(lp).connect(body).connect(g);
  g.connect(out);
  o.start(t);
  lfo.start(t);
  o.stop(t + d + 0.05);
  lfo.stop(t + d + 0.05);
}

export function sfx(kind: SfxKind) {
  if (!settings.get().sfx) return;
  const { ac, sfx: out } = audio();
  const t = ac.currentTime + 0.005;
  const seq = (notes: number[], step: number, type: OscillatorType, gain: number) =>
    notes.forEach((m, i) => tone(t + i * step, mtof(m), step * 0.95, out, { type, gain }));
  const sweep = (from: number, to: number, dur: number, type: OscillatorType, gain: number) => {
    const o = ac.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(from, t);
    o.frequency.exponentialRampToValueAtTime(to, t + dur);
    o.connect(envGain(ac, t, 0.004, gain, dur)).connect(out);
    o.start(t);
    o.stop(t + dur + 0.05);
  };
  switch (kind) {
    case "click": tone(t, 1300, 0.03, out, { type: "square", gain: 0.05 }); break;
    case "tick": tone(t, 900, 0.04, out, { type: "sine", gain: 0.12 }); break;
    case "pop": sweep(500, 900, 0.07, "sine", 0.18); break;
    case "coin": seq([83, 88], 0.07, "square", 0.07); break;
    case "jump": sweep(300, 720, 0.12, "square", 0.07); break;
    case "shoot": sweep(1000, 220, 0.1, "sawtooth", 0.05); break;
    case "hit": noiseBurst(t, out, "lowpass", 900, 0.5, 0.15); sweep(220, 70, 0.15, "square", 0.08); break;
    case "boom": noiseBurst(t, out, "lowpass", 420, 0.8, 0.45); break;
    case "good": seq([76, 79, 84], 0.06, "triangle", 0.12); break;
    case "win": seq([72, 76, 79, 84, 88], 0.09, "square", 0.07); break;
    case "lose": seq([67, 63, 60, 55], 0.14, "triangle", 0.14); break;
    case "level": seq([79, 83, 86, 91], 0.07, "triangle", 0.12); break;
    case "error": seq([50, 46], 0.1, "square", 0.07); break;
    case "whoosh": noiseBurst(t, out, "bandpass", 1200, 0.3, 0.25); break;
  }
}

// ---------------------------------------------------------------------------
// Composer: deterministic songs from a seed (used by the music tab and Furby Funk)
// ---------------------------------------------------------------------------
export type ScaleName = "major" | "minor" | "dorian" | "mixo" | "penta";
export const SCALES: Record<ScaleName, number[]> = {
  major: [0, 2, 4, 5, 7, 9, 11],
  minor: [0, 2, 3, 5, 7, 8, 10],
  dorian: [0, 2, 3, 5, 7, 9, 10],
  mixo: [0, 2, 4, 5, 7, 9, 10],
  penta: [0, 2, 4, 7, 9],
};

export interface SongSpec {
  seed: number;
  bpm: number;
  scale: ScaleName;
  root: number;
  style: number;
  density: number;
}

/** step = 16th note inside a 2-bar phrase (0..31), deg = scale degree */
export interface MNote {
  step: number;
  deg: number;
  len: number;
}

export interface Composition {
  spec: SongSpec;
  stepDur: number;
  barDur: number;
  prog: number[];
  phrases: MNote[][];
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PROGS = [
  [0, 4, 5, 3],
  [5, 3, 0, 4],
  [0, 5, 3, 4],
  [0, 3, 4, 3],
  [0, 6, 5, 4],
  [0, 2, 3, 4],
];

const clampN = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

const MOTIFS: number[][] = [
  [0, 2, 4, 2, 0, 2, 4, 7],
  [4, 3, 2, 0, 2, 3, 4, 4],
  [0, 4, 2, 4, 5, 4, 2, 0],
  [7, 5, 4, 5, 4, 2, 0, 2],
  [0, 1, 2, 4, 5, 4, 2, 1],
  [2, 4, 7, 4, 2, 4, 7, 9],
  [4, 4, 5, 7, 5, 4, 2, 0],
];
const RHYTHMS: number[][] = [
  [0, 2, 4, 6, 8, 10, 12, 14],
  [0, 3, 6, 8, 11, 14],
  [0, 2, 4, 8, 10, 14],
  [0, 4, 6, 8, 12, 14],
  [2, 4, 6, 8, 10, 12, 14],
];

/** A phrase is a repeatable melodic hook on a rhythmic template — like a real song, not a random walk. */
function makePhrase(r: () => number, density: number, prog: number[], index: number): MNote[] {
  const motif = MOTIFS[Math.floor(r() * MOTIFS.length)];
  const rhythm = RHYTHMS[Math.floor(r() * RHYTHMS.length)];
  const chord = prog[(index * 2) % 4];
  const notes: MNote[] = [];
  let k = 0;
  for (const step of rhythm) {
    if (step < 2 && r() < 0.35) continue;
    if (step >= 28 && r() < 0.5) continue;
    if (r() > 0.5 + density * 0.5) continue;
    const deg = clampN(motif[k % motif.length] + chord, 0, 10);
    k++;
    notes.push({ step, deg, len: 2 });
  }
  // two identical lanes in a row are hard to play — nudge the second one
  for (let i = 1; i < notes.length; i++) {
    if (notes[i].deg % 4 === notes[i - 1].deg % 4 && notes[i].step - notes[i - 1].step < 4) {
      notes[i].deg = clampN(notes[i].deg + 1, 0, 10);
    }
  }
  for (let i = 0; i < notes.length; i++) notes[i].len = Math.min(4, (notes[i + 1]?.step ?? 32) - notes[i].step);
  return notes;
}

export function compose(spec: SongSpec): Composition {
  const r = mulberry32(spec.seed);
  const stepDur = 60 / spec.bpm / 4;
  const prog = PROGS[Math.floor(r() * PROGS.length)];
  const phrases = [0, 1, 2, 3].map((i) => makePhrase(r, spec.density, prog, i));
  return { spec, stepDur, barDur: stepDur * 16, prog, phrases };
}

export function degMidi(spec: SongSpec, deg: number): number {
  const sc = SCALES[spec.scale];
  const n = sc.length;
  return spec.root + sc[((deg % n) + n) % n] + 12 * Math.floor(deg / n);
}

const KICK = ["x...x...x...x...", "x.....x...x.....", "x.......x.x.....", "x.........x....."];
const SNARE = ["....x.......x...", "....x.......x...", "....x.......x..x", "........x......."];
const HAT = ["..o...o...o...o.", "x.x.x.x.x.x.x.x.", "x.x.x.x.x.x.x.x.", "x.x.x.x.x.xox.x."];
const BASS = ["11111111", "1..21.1.", "11.11.21", "1...1.2."];

export interface BarOpts {
  lead?: OscillatorType | null;
  phrase?: MNote[] | null;
  half?: number;
  drums?: number;
  bass?: boolean;
  pad?: boolean;
}

export function scheduleBar(c: Composition, bar: number, t0: number, out: AudioNode, o: BarOpts = {}) {
  const { stepDur, spec } = c;
  const st = spec.style % 4;
  const chord = c.prog[bar % 4];
  const drums = o.drums ?? 1;
  for (let s = 0; s < 16; s++) {
    const t = t0 + s * stepDur + (st === 3 && s % 2 === 1 ? stepDur * 0.2 : 0);
    if (drums > 0) {
      if (KICK[st][s] === "x") kick(t, out);
      if (drums > 0.5 && SNARE[st][s] === "x") snare(t, out);
      if (HAT[st][s] !== ".") hat(t, out, HAT[st][s] === "o");
    }
    if (o.bass !== false && s % 2 === 0) {
      const b = BASS[st][s / 2];
      if (b !== ".") tone(t, mtof(degMidi(spec, chord + (b === "2" ? 4 : 0)) - 24), stepDur * 1.7, out, { type: "sawtooth", gain: 0.12, cutoff: 600 });
    }
  }
  if (o.pad !== false) {
    for (const d of [chord, chord + 2, chord + 4]) {
      tone(t0, mtof(degMidi(spec, d) - 12), c.barDur * 0.95, out, { type: "triangle", gain: 0.03, attack: 0.1, release: 0.3 });
    }
  }
  if (o.lead && o.phrase) {
    for (const n of o.phrase) {
      if (Math.floor(n.step / 16) !== (o.half ?? 0)) continue;
      tone(t0 + (n.step % 16) * stepDur, mtof(degMidi(spec, n.deg) + 12), n.len * stepDur * 0.85, out, { type: o.lead, gain: 0.06, cutoff: 3500 });
    }
  }
}
