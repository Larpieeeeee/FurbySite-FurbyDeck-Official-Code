/// <reference types="web-bluetooth" />
import { LIBRARY, type LibRow } from "../actions/library";
import { tr } from "../i18n";
import { guessFileSize, parseDlc, toHex as hexHead } from "../dlc";
import { settings } from "../settings";
import { createStore } from "../store";
import {
  DEBUG_SCREENS, DIRS, FILE_WRITE, FLUFF_SERVICE, GP_LISTEN, GP_WRITE, NAME_PREFIX, NORDIC_LISTEN, TOUCH_IDS, cmd, decodeSensors, describePacket, toHex,
  type Bytes, type Dir, type MoodType, type Orientation, type Rgb, type SensorState, type Touch,
} from "./protocol";

export type FurbyStatus = "idle" | "connecting" | "confirming" | "ready";
export type LogKind = "tx" | "rx" | "sys" | "err";
export interface LogEntry {
  id: number;
  time: string;
  kind: LogKind;
  text: string;
  /** English version, when the entry has one */
  en?: string;
  /** set when journals of two toys are merged */
  key?: string;
}
export type InputType =
  | "antL" | "antR" | "antF" | "antB" | "antPress" | Touch
  | "shake" | "shakeHard" | "still" | "flip" | "lieL" | "lieR" | "tiltL" | "tiltR";
export interface InputEvent {
  type: InputType;
  t: number;
  src: "furby" | "key" | "touch";
}
export interface ConfirmState {
  seq: Dir[];
  step: number;
  deadline: number;
  errors: number;
  errorAt: number;
  attempt: number;
}
export interface DeviceInfo {
  manufacturer?: string;
  model?: string;
  firmware?: string;
  hardware?: string;
  software?: string;
}
export interface MotionState {
  intensity: number;
  peak: number;
  shakes: number;
  label: "calm" | "move" | "shake";
  history: number[];
  stillFor: number;
}
export interface Stats {
  tx: number;
  rx: number;
  actions: number;
  txHist: number[];
  rxHist: number[];
  cmds: Record<string, number>;
  pings: number[];
  rulesFired: number;
}
export type SayKind = "hello" | "start" | "win" | "lose" | "good" | "achievement" | "bye" | "tap";

export interface FurbyState {
  supported: boolean;
  status: FurbyStatus;
  step: number;
  demo: boolean;
  deviceName: string | null;
  sensors: SensorState | null;
  error: string | null;
  debugStep: number;
  firmware: string | null;
  info: DeviceInfo;
  logs: LogEntry[];
  busy: boolean;
  dancing: boolean;
  inGame: boolean;
  scene: string | null;
  confirm: ConfirmState | null;
  lastShake: number;
  eyes: boolean;
  telemetry: boolean;
  color: Rgb;
  lastPhrase: string | null;
  phrases: number;
  nextChatterIn: number;
  motion: MotionState;
  /** per-toy chatter switch (the global setting is still the master switch) */
  chatterOn: boolean;
  deviceId: string | null;
  /** DLC slot currently activated (tracked locally; the protocol has no query for it) */
  activeSlot: number | null;
  imHere: string | null;
  connectedAt: number;
  stats: Stats;
}

export const CONNECT_STEPS = 6;
export const CONFIRM_LENGTH = 6;
export const CONFIRM_MS = 20000;
const MAX_LOGS = 400;
const HIST = 45;

type Quad = [number, number, number, number];
const SAY: Record<SayKind, Quad[]> = {
  hello: [[40, 0, 0, 0], [29, 0, 0, 0], [29, 0, 0, 1]],
  start: [[66, 0, 0, 2], [66, 0, 0, 0], [66, 0, 0, 3]],
  win: [[41, 0, 0, 0], [55, 2, 15, 0], [55, 2, 15, 4], [41, 0, 0, 3]],
  lose: [[21, 0, 0, 3], [21, 0, 0, 8], [21, 0, 0, 9]],
  good: [[64, 0, 0, 0], [64, 0, 0, 3], [39, 1, 9, 0]],
  achievement: [[60, 0, 0, 0], [60, 0, 0, 1], [41, 0, 1, 1]],
  bye: [[28, 0, 0, 0], [28, 0, 0, 1]],
  tap: [[1, 0, 0, 3], [1, 2, 1, 2]],
};
const TALK_INPUTS = [8, 40, 41, 43, 45, 53, 63, 66, 69, 39, 1, 12];
const REACTION_INPUT = { tummy: 2, head: 1, tongue: 14, shake: 9, flip: 10 } as const;
type ReactionKind = keyof typeof REACTION_INPUT;

const byte = (v: number) => Math.max(0, Math.min(255, Math.round(v) || 0));
const errorText = (e: unknown) => (e instanceof Error ? e.message : String(e));
const pickOne = <T,>(list: T[]) => list[Math.floor(Math.random() * list.length)];
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const rowsOf = (inputs: number[]) => LIBRARY.filter((r) => inputs.includes(r[0]));
export const rowLabel = (r: LibRow) => (settings.get().lang === "en" ? r[5] : r[4]);
export function actionName(i: number, x: number, s: number, p: number): string {
  const r = LIBRARY.find((q) => q[0] === i && q[1] === x && q[2] === s && q[3] === p);
  return r ? rowLabel(r) : `${i}/${x}/${s}/${p}`;
}

function makeSequence(): Dir[] {
  const seq: Dir[] = [];
  while (seq.length < CONFIRM_LENGTH) {
    const d = pickOne(DIRS);
    if (d !== seq[seq.length - 1]) seq.push(d);
  }
  return seq;
}
const isLeft = (o: Orientation) => o === "tilted-left" || o === "left-side";
const isRight = (o: Orientation) => o === "tilted-right" || o === "right-side";
const emptyMotion = (): MotionState => ({ intensity: 0, peak: 0, shakes: 0, label: "calm", history: [], stillFor: 0 });
const emptyStats = (): Stats => ({ tx: 0, rx: 0, actions: 0, txHist: Array(HIST).fill(0), rxHist: Array(HIST).fill(0), cmds: {}, pings: [], rulesFired: 0 });

/** Tolerant 0x73 parser: finds "TU002949"-style filename wherever it starts. */
function parseSlotPacket(d: Uint8Array): { name: string; size: number; checksum: string; raw: string } | null {
  if (d.length < 8) return null;
  // an all-zero payload means the slot is empty
  let hasData = false;
  for (let i = 2; i < d.length; i++)
    if (d[i] !== 0) {
      hasData = true;
      break;
    }
  if (!hasData) return null;
  const raw = hexHead(d, Math.min(d.length, 24));
  // find a printable-ASCII run of 4..16 chars wherever it starts, then read
  // size (3 bytes BE) and adler32 (4 bytes) right after it; reject absurd sizes
  let name = "";
  let size = 0;
  let checksum = 0;
  for (let off = 1; off <= Math.min(8, Math.max(1, d.length - 8)); off++) {
    let end = off;
    while (end < d.length && d[end] >= 0x21 && d[end] <= 0x7e) end++;
    const len = end - off;
    if (len < 4 || len > 16 || end + 7 > d.length) continue;
    const candSize = (d[end] << 16) | (d[end + 1] << 8) | d[end + 2];
    if (candSize < 256 || candSize > 16 * 1024 * 1024) continue;
    name = String.fromCharCode(...d.subarray(off, end));
    size = candSize;
    checksum = ((d[end + 3] << 24) | (d[end + 4] << 16) | (d[end + 5] << 8) | d[end + 6]) >>> 0;
    break;
  }
  return { name, size, checksum: checksum ? "0x" + checksum.toString(16) : "", raw };
}

interface Pending {
  bytes: Bytes;
  silent?: boolean;
  tag?: string;
  label?: string;
}

/** Target for user-initiated commands: both furbies, or one of them. */
export const commandTarget = createStore<{ target: "all" | "1" | "2" }>({ target: "all" });

export class FurbyController {
  readonly slot: "1" | "2";
  private state: FurbyState = {
    supported: typeof navigator !== "undefined" && "bluetooth" in navigator,
    status: "idle",
    step: 0,
    demo: false,
    deviceName: null,
    sensors: null,
    error: null,
    debugStep: 0,
    firmware: null,
    info: {},
    logs: [],
    busy: false,
    dancing: false,
    inGame: false,
    scene: null,
    confirm: null,
    lastShake: 0,
    eyes: true,
    telemetry: false,
    color: [0, 0, 0],
    lastPhrase: null,
    phrases: 0,
    nextChatterIn: 0,
    motion: emptyMotion(),
    imHere: null,
    connectedAt: 0,
    stats: emptyStats(),
    chatterOn: true,
    deviceId: null,
    activeSlot: null,
  };

  private listeners = new Set<() => void>();
  private inputListeners = new Set<(e: InputEvent) => void>();
  private device: BluetoothDevice | null = null;
  private writeChar: BluetoothRemoteGATTCharacteristic | null = null;
  private fileChar: BluetoothRemoteGATTCharacteristic | null = null;
  private demo = false;
  private pending: Pending[] = [];
  private ledPending: Rgb | null = null;
  private pumping = false;
  private lastTx = 0;
  private ticker: number | null = null;
  private demoTimer: number | null = null;
  private tickCount = 0;
  private logCounter = 0;
  private lastDir: SensorState["dir"] = null;
  private confirmTimer: number | undefined;
  private lastTouches: Touch[] = [];
  private touchSince: Partial<Record<Touch, number>> = {};
  private touchFired = new Set<Touch>();
  private touchReacted = new Set<Touch>();
  private touchTimer: number | undefined;
  private playing = false;
  private playingSince = 0;
  private busyUntil = 0;
  private lastReact = 0;
  private lastSay = 0;
  private nextChatter = 0;
  private lastDance = 0;
  private txSec = 0;
  private rxSec = 0;
  private stats: Stats = emptyStats();
  private impulses: Array<[number, number]> = [];
  private lastShakeAt = 0;
  private lastMoveAt = 0;
  private stillFired = false;
  private motion: MotionState = emptyMotion();
  private waiters: Array<{ match: (d: Uint8Array) => boolean; resolve: (v: Uint8Array | null) => void; timer: number }> = [];
  private counters: Array<{ match: (d: Uint8Array) => boolean; count: number }> = [];
  constructor(slot: "1" | "2" = "1") {
    this.slot = slot;
  }

  private dz = { x: 0 as -1 | 0 | 1, y: 0 as -1 | 0 | 1, pressed: false, touches: new Set<Touch>(), orient: 0x01, b3: 7, b5: 0x27, b6: 0x0e, shakeUntil: 0, hard: false };

  ledOverrideUntil = 0;
  onCommand: (() => void) | null = null;
  onPhrase: (() => void) | null = null;

  // ---- store ---------------------------------------------------------------
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  getState = () => this.state;

  private patch(partial: Partial<FurbyState>) {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((l) => l());
  }

  get connected() {
    return (this.writeChar !== null || this.demo) && this.state.status === "ready";
  }

  get isDemo() {
    return this.demo;
  }

  onInput(listener: (e: InputEvent) => void) {
    this.inputListeners.add(listener);
    return () => {
      this.inputListeners.delete(listener);
    };
  }

  private emit(type: InputType, t: number) {
    const event: InputEvent = { type, t, src: "furby" };
    this.inputListeners.forEach((l) => l(event));
  }

  log(kind: LogKind, text: string, en?: string) {
    const entry: LogEntry = {
      id: ++this.logCounter,
      time: new Date().toLocaleTimeString(settings.get().lang === "en" ? "en-GB" : "ru-RU", { hour12: false }),
      kind,
      text,
      en,
    };
    const logs = this.state.logs.length >= MAX_LOGS ? this.state.logs.slice(-MAX_LOGS + 1) : this.state.logs;
    this.patch({ logs: [...logs, entry] });
  }

  clearLogs() {
    this.patch({ logs: [] });
  }

  // ---- connection ----------------------------------------------------------
  async connect() {
    if (!this.state.supported) {
      this.patch({ error: tr("Браузер не поддерживает Web Bluetooth. На iPhone открой сайт в Bluefy, на Android — в Chrome. Или включи демо-режим.", "This browser doesn't support Web Bluetooth. On iPhone open the site in Bluefy, on Android use Chrome. Or turn on demo mode.") });
      return;
    }
    if (this.state.status !== "idle") return;
    this.patch({ status: "connecting", step: 1, error: null, demo: false });
    try {
      const device = await navigator.bluetooth.requestDevice({ filters: [{ namePrefix: NAME_PREFIX }], optionalServices: [FLUFF_SERVICE, "device_information"] });
      this.device = device;
      device.addEventListener("gattserverdisconnected", this.handleDisconnect);
      if (!device.gatt) throw new Error("GATT unavailable");
      this.patch({ step: 2 });
      const server = await device.gatt.connect();
      this.patch({ step: 3 });
      const service = await server.getPrimaryService(FLUFF_SERVICE);
      this.patch({ step: 4 });
      const write = await service.getCharacteristic(GP_WRITE);
      const listen = await service.getCharacteristic(GP_LISTEN);
      const nordic = await service.getCharacteristic(NORDIC_LISTEN);
      const fileWrite = await service.getCharacteristic(FILE_WRITE);
      const info = await this.readInfo(server);
      this.patch({ step: 5 });
      listen.addEventListener("characteristicvaluechanged", this.handleGp);
      nordic.addEventListener("characteristicvaluechanged", this.handleNordic);
      await listen.startNotifications();
      await nordic.startNotifications();
      this.writeChar = write;
      this.fileChar = fileWrite;
      this.patch({ step: 6 });
      this.begin(device.name ?? NAME_PREFIX, info, device.id ?? NAME_PREFIX);
    } catch (error) {
      const failed = this.teardown();
      if (failed?.gatt?.connected) failed.gatt.disconnect();
      if ((error as DOMException)?.name === "NotFoundError") {
        this.patch({ status: "idle", step: 0 });
        return;
      }
      this.patch({ status: "idle", step: 0, error: tr("Не удалось подключиться: ", "Could not connect: ") + errorText(error) });
      this.log("err", errorText(error));
    }
  }

  /** Virtual Furby: answers like the real one, controlled with the keyboard and on-screen sensors */
  async connectDemo() {
    if (this.state.status !== "idle") return;
    this.demo = true;
    this.patch({ status: "connecting", step: 1, error: null, demo: true });
    for (let s = 2; s <= CONNECT_STEPS; s++) {
      await sleep(160);
      this.patch({ step: s });
    }
    this.log("sys", "Демо-режим: виртуальный Ферби отвечает как настоящий", "Demo mode: the virtual Furby answers like a real one");
    this.begin(tr("Furby (демо)", "Furby (demo)"), { manufacturer: "Hasbro (sim)", model: "Furby Connect", firmware: "sim" }, "demo");
    this.demoTimer = window.setInterval(() => this.demoTick(), 200);
  }

  private begin(name: string, info: DeviceInfo, deviceId?: string) {
    const id = deviceId ?? name;
    const savedColour = settings.get().deviceColors[id];
    this.resetInput();
    this.stats = emptyStats();
    this.motion = emptyMotion();
    this.lastMoveAt = performance.now();
    this.startTicker();
    if (settings.get().telemetryOnConnect) this.setSensorStream(true, true);
    this.patch({
      status: "confirming",
      deviceName: name,
      info,
      sensors: null,
      phrases: 0,
      lastPhrase: null,
      stats: this.stats,
      motion: this.motion,
      confirm: { seq: makeSequence(), step: 0, deadline: Date.now() + CONFIRM_MS, errors: 0, errorAt: 0, attempt: 1 },
      deviceId: id,
      chatterOn: true,
      activeSlot: null,
    });
    if (savedColour !== undefined) {
      this.setLedFrame([(savedColour >> 16) & 255, (savedColour >> 8) & 255, savedColour & 255], true);
      this.log("sys", "Цвет этой игрушки восстановлен", "Restored this toy's colour");
    }
    this.log("sys", "Рукопожатие: 6 поворотов антенны, 20 секунд (нажатия не учитываются)", "Handshake: 6 antenna turns, 20 seconds (presses are ignored)");
  }

  private async readInfo(server: BluetoothRemoteGATTServer): Promise<DeviceInfo> {
    try {
      const dis = await server.getPrimaryService("device_information");
      const read = async (id: string) => {
        try {
          const value = await (await dis.getCharacteristic(id)).readValue();
          return new TextDecoder().decode(value).replace(/\0/g, "").trim() || undefined;
        } catch {
          return undefined;
        }
      };
      return { manufacturer: await read("manufacturer_name_string"), model: await read("model_number_string"), firmware: await read("firmware_revision_string"), hardware: await read("hardware_revision_string"), software: await read("software_revision_string") };
    } catch {
      return {};
    }
  }

  disconnect() {
    if (settings.get().antennaOffOnDisconnect && this.writeChar) void this.writeChar.writeValue(new Uint8Array(cmd.antennaColor(0, 0, 0))).catch(() => undefined);
    const device = this.teardown();
    window.setTimeout(() => {
      if (device?.gatt?.connected) device.gatt.disconnect();
    }, 150);
    this.patch({ ...this.idleState(), error: null });
    this.log("sys", "Отключено", "Disconnected");
  }

  private idleState(): Partial<FurbyState> {
    return { status: "idle", step: 0, demo: false, deviceName: null, sensors: null, debugStep: 0, firmware: null, confirm: null, dancing: false, busy: false, scene: null, connectedAt: 0, telemetry: false, imHere: null };
  }

  private handleDisconnect = (event: Event) => {
    if ((event.target as BluetoothDevice) !== this.device) return;
    this.teardown();
    this.patch({ ...this.idleState(), error: tr("Связь с Ферби пропала. Включи игрушку и подключись снова.", "Lost connection to Furby. Turn it on and connect again.") });
    this.log("err", "Соединение разорвано", "Connection lost");
  };

  private teardown(): BluetoothDevice | null {
    const device = this.device;
    if (this.ticker !== null) window.clearInterval(this.ticker);
    if (this.demoTimer !== null) window.clearInterval(this.demoTimer);
    window.clearTimeout(this.confirmTimer);
    window.clearTimeout(this.touchTimer);
    this.ticker = null;
    this.demoTimer = null;
    this.writeChar = null;
    this.fileChar = null;
    this.demo = false;
    this.pending = [];
    this.ledPending = null;
    this.device = null;
    device?.removeEventListener("gattserverdisconnected", this.handleDisconnect);
    return device;
  }

  private resetInput() {
    this.lastDir = null;
    this.lastTouches = [];
    this.touchSince = {};
    this.touchFired.clear();
    this.touchReacted.clear();
    this.impulses = [];
    this.playing = false;
    this.busyUntil = 0;
    this.dz = { x: 0, y: 0, pressed: false, touches: new Set(), orient: 0x01, b3: 7, b5: 0x27, b6: 0x0e, shakeUntil: 0, hard: false };
  }

  private startTicker() {
    if (this.ticker !== null) window.clearInterval(this.ticker);
    this.tickCount = 0;
    this.ticker = window.setInterval(this.tick, 500);
  }

  private tick = () => {
    const now = performance.now();
    const s = settings.get();
    this.tickCount++;
    if (now - this.lastTx > 3000 && this.pending.length === 0) this.send(cmd.keepAlive(), { silent: true, verbose: true });

    const busy = this.isBusy();
    const patch: Partial<FurbyState> = {};
    if (busy !== this.state.busy) patch.busy = busy;

    if (this.tickCount % 2 === 0) {
      this.stats = {
        ...this.stats,
        txHist: [...this.stats.txHist.slice(1), this.txSec],
        rxHist: [...this.stats.rxHist.slice(1), this.rxSec],
      };
      this.txSec = 0;
      this.rxSec = 0;
      patch.stats = this.stats;
    }

    // motion: decay, history, "still" detection
    this.motion = {
      ...this.motion,
      intensity: this.motionIntensity(now),
      history: [...this.motion.history.slice(-59), this.motionIntensity(now)],
      stillFor: Math.floor((now - this.lastMoveAt) / 1000),
    };
    this.motion.label = this.motion.intensity >= s.motionThreshold ? "shake" : this.motion.intensity > 8 ? "move" : "calm";
    patch.motion = this.motion;
    if (this.state.status === "ready" && !this.stillFired && now - this.lastMoveAt > 30000) {
      this.stillFired = true;
      this.emit("still", now);
    }

    if (this.state.status === "confirming" && this.state.confirm && Date.now() > this.state.confirm.deadline) {
      this.log("err", "Время вышло — отключение", "Time is up — disconnecting");
      this.disconnect();
      this.patch({ error: tr("Комбинация не повторена за 20 секунд — Фёрби отключён.", "The combination wasn't repeated within 20 seconds — Furby disconnected.") });
      return;
    }

    if (this.state.dancing && now - this.lastDance > s.danceEvery * 1000) this.sendDance();

    const quiet = s.quietUntil > Date.now();
    const chatterAllowed = s.chatter && this.state.chatterOn && !quiet && this.state.status === "ready" && !this.state.dancing && !this.state.scene && (!this.state.inGame || s.chatterInGames);
    if (chatterAllowed) {
      if (!this.nextChatter) this.nextChatter = now + s.chatterEvery * 1000;
      if (now >= this.nextChatter && !busy) this.sayRandom(true);
      patch.nextChatterIn = Math.max(0, Math.round((this.nextChatter - now) / 1000));
    } else if (this.state.nextChatterIn !== 0) patch.nextChatterIn = 0;
    this.patch(patch);
  };

  isBusy(): boolean {
    const now = performance.now();
    return (this.playing && now - this.playingSince < 12000) || now < this.busyUntil;
  }

  // ---- writing -------------------------------------------------------------
  private send(bytes: Bytes, opts: { silent?: boolean; tag?: string; auto?: boolean; label?: string; verbose?: boolean } = {}) {
    if (!this.writeChar && !this.demo) {
      if (!opts.silent && !opts.auto) this.log("err", "Ферби не подключён", "Furby is not connected");
      return;
    }
    // user commands are routed: "all" fans out to the other toy, a slot forwards there
    const target = commandTarget.get().target;
    if (!opts.silent && !opts.auto) {
      const other = this === furby ? furby2 : furby;
      if (other.connected && (target === "all" || target === other.slot)) {
        other.send(bytes, { ...opts, auto: true });
      }
      if (target !== "all" && target !== this.slot) return;
    }

    if (bytes[0] >= 0x10 && bytes[0] <= 0x13) {
      this.busyUntil = Math.max(this.busyUntil, performance.now() + 2200);
      this.stats.actions++;
      // pause the site's light engine while the toy runs an action —
      // otherwise firmware and site fight over the LED and it flickers
      this.ledOverrideUntil = Math.max(this.ledOverrideUntil, performance.now() + 3500);
    }
    if (!opts.silent && !opts.auto) {
      this.onCommand?.();
      this.nextChatter = performance.now() + settings.get().chatterEvery * 1000;
    }
    if (opts.label && !opts.silent) this.stats.cmds[opts.label] = (this.stats.cmds[opts.label] ?? 0) + 1;
    const silent = opts.silent && !(opts.verbose && settings.get().verboseLog);
    this.pending.push({ bytes, silent, tag: opts.tag, label: opts.label });
    if (this.pending.length > 40) this.pending.splice(0, this.pending.length - 40);
    void this.pump();
  }

  private async pump() {
    if (this.pumping || (!this.writeChar && !this.demo)) return;
    this.pumping = true;
    try {
      while (this.writeChar || this.demo) {
        let item = this.pending.shift();
        if (!item && this.ledPending) {
          item = { bytes: cmd.antennaColor(...this.ledPending), silent: true };
          this.ledPending = null;
        }
        if (!item) break;
        try {
          if (this.demo) {
            await sleep(12);
            this.simulate(item.bytes);
          } else await this.writeChar!.writeValue(new Uint8Array(item.bytes));
          this.lastTx = performance.now();
          this.txSec++;
          this.stats.tx++;
          if (!item.silent) this.log("tx", item.label ? `${toHex(item.bytes)} · ${item.label}` : toHex(item.bytes));
        } catch (error) {
          this.log("err", `Не отправлено ${toHex(item.bytes)}: ${errorText(error)}`, `Not sent ${toHex(item.bytes)}: ${errorText(error)}`);
        }
      }
    } finally {
      this.pumping = false;
    }
  }

  // ---- reading -------------------------------------------------------------
  private handleGp = (event: Event) => {
    const value = (event.target as BluetoothRemoteGATTCharacteristic).value;
    if (value) this.handleData(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
  };

  private handleNordic = (event: Event) => {
    const value = (event.target as BluetoothRemoteGATTCharacteristic).value;
    if (!value) return;
    const data = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    if (data[0] !== 0x09) this.log("rx", `Nordic ${toHex(data)}`);
  };

  private handleData(data: Uint8Array) {
    if (data.length === 0) return;
    for (const w of [...this.waiters]) {
      if (w.match(data)) {
        window.clearTimeout(w.timer);
        this.waiters = this.waiters.filter((x) => x !== w);
        w.resolve(data);
      }
    }
    for (const c of this.counters) if (c.match(data)) c.count++;
    this.rxSec++;
    this.stats.rx++;
    const verbose = settings.get().verboseLog;
    if (data[0] === 0x21) {
      if (verbose) {
        const d = describePacket(data);
        this.log("rx", d.ru, d.en);
      }
      this.handleSensors(data);
      return;
    }
    if (data[0] === 0x22) {
      this.patch({ imHere: toHex(data) });
      if (verbose) {
        const d = describePacket(data);
        this.log("rx", d.ru, d.en);
      }
      return;
    }
    if (data[0] === 0x20) this.handleMessage(data[1]);
    if (data[0] === 0xfe && data.length > 1) this.patch({ firmware: "0x" + toHex([data[1]]) });
    const described = describePacket(data);
    this.log("rx", described.ru, described.en);
  }

  private handleMessage(code: number) {
    const now = performance.now();
    if (code === 0x0c || code === 0x07) {
      this.playing = true;
      this.playingSince = now;
    }
    if (code === 0x0e || code === 0x06 || code === 0x0d) {
      this.playing = false;
      this.busyUntil = Math.max(this.busyUntil, now + 600);
      if (code === 0x0e && this.state.dancing && now - this.lastDance > 800) {
        window.setTimeout(() => {
          if (this.state.dancing) this.sendDance();
        }, 120);
      }
    }
    if (code === 0x17) this.patch({ eyes: true });
    if (code === 0x18) this.patch({ eyes: false });
  }

  private handleSensors(data: Uint8Array) {
    const s = settings.get();
    const sensors = decodeSensors(data, s.invertX, s.invertY, s.tiltInvertX);
    if (!sensors) return;
    const now = performance.now();
    const prev = this.state.sensors;
    const gated = s.gateWhileMoving && this.isBusy();

    if (sensors.dir !== this.lastDir) {
      this.lastDir = sensors.dir;
      if (sensors.dir) {
        this.emit(sensors.dir === "P" ? "antPress" : (`ant${sensors.dir}` as InputType), now);
        if (sensors.dir !== "P" && this.state.status === "confirming") this.queueConfirm(sensors.dir);
      }
    }
    this.lastTouches = sensors.touches;
    this.processTouches(now);
    if (prev && prev.orientation !== sensors.orientation) this.onOrientation(prev.orientation, sensors.orientation, now, gated);
    this.motionUpdate(prev, sensors, now, gated);
    this.patch({ sensors });
  }

  private processTouches(now: number) {
    const s = settings.get();
    const gated = s.gateWhileMoving && this.isBusy();
    let pending = false;
    for (const t of TOUCH_IDS) {
      if (!this.lastTouches.includes(t)) {
        delete this.touchSince[t];
        this.touchFired.delete(t);
        this.touchReacted.delete(t);
        continue;
      }
      const instant = t === "tongue" || t === "tail";
      if (gated && !instant) {
        this.touchSince[t] = now;
        pending = true;
        continue;
      }
      const since = (this.touchSince[t] ??= now);
      if (!this.touchFired.has(t)) {
        if (instant || now - since >= 60) {
          this.touchFired.add(t);
          this.emit(t, now);
        } else pending = true;
      }
      if (!this.touchReacted.has(t)) {
        if (now - since >= s.touchHoldMs) {
          this.touchReacted.add(t);
          if (t === "tummy" || t === "head" || t === "tongue") this.react(t);
        } else pending = true;
      }
    }
    window.clearTimeout(this.touchTimer);
    if (pending) this.touchTimer = window.setTimeout(() => this.processTouches(performance.now()), 70);
  }

  private onOrientation(from: Orientation, to: Orientation, now: number, gated: boolean) {
    if (gated) return;
    if (isLeft(to) && !isLeft(from)) this.emit("tiltL", now);
    if (isRight(to) && !isRight(from)) this.emit("tiltR", now);
    if (to === "left-side") this.emit("lieL", now);
    if (to === "right-side") this.emit("lieR", now);
    if (to === "upside-down") {
      this.emit("flip", now);
      this.react("flip");
    }
  }

  /** Motion intensity 0..100 from orientation changes, antenna jerks and accelerometer spread over 1.4 s */
  private motionUpdate(prev: SensorState | null, s: SensorState, now: number, gated: boolean) {
    if (!prev || gated) return;
    let imp = 0;
    if (prev.orientation !== s.orientation) {
      // A light tilt is cheap, a real flip or lying on a side is a strong impulse
      const strong =
        s.orientation === "upside-down" || prev.orientation === "upside-down" ||
        isLeft(s.orientation) || isRight(s.orientation) || isLeft(prev.orientation) || isRight(prev.orientation);
      imp += strong ? 28 : 8;
    }
    if (prev.dir !== s.dir && s.dir) imp += 6;
    const a = s.bytes;
    const b = prev.bytes;
    imp += Math.min(15, (Math.abs((a[3] ?? 0) - (b[3] ?? 0)) + Math.abs((a[5] ?? 0) - (b[5] ?? 0)) + Math.abs((a[6] ?? 0) - (b[6] ?? 0))) * 0.5);
    if (imp <= 0) return;
    if (imp > 5) {
      this.lastMoveAt = now;
      this.stillFired = false;
    }
    this.impulses.push([now, imp]);
    const set = settings.get();
    const intensity = this.motionIntensity(now);
    if (intensity > this.motion.peak) this.motion = { ...this.motion, peak: Math.round(intensity) };
    if (intensity >= set.motionThreshold && now - this.lastShakeAt > set.motionCooldown * 1000) {
      this.lastShakeAt = now;
      const hard = intensity >= Math.min(95, set.motionThreshold + 30);
      this.motion = { ...this.motion, shakes: this.motion.shakes + 1 };
      this.patch({ lastShake: now, motion: this.motion });
      this.emit(hard ? "shakeHard" : "shake", now);
      // Only a hard shake is worth yelling about — light tilts stay silent
      if (hard) {
        this.emit("shake", now);
        this.react("shake");
      }
    }
  }

  private motionIntensity(now: number) {
    this.impulses = this.impulses.filter(([t]) => now - t < 1400);
    const sum = this.impulses.reduce((n, [, v]) => n + v, 0);
    return Math.round(Math.min(100, sum * (settings.get().motionSensitivity / 55)));
  }

  resetMotion() {
    this.motion = emptyMotion();
    this.impulses = [];
    this.patch({ motion: this.motion });
  }

  private react(kind: ReactionKind) {
    const s = settings.get();
    const allowed = { tummy: s.reactTummy, head: s.reactHead, tongue: s.reactTongue, shake: s.reactShake, flip: s.reactFlip }[kind];
    if (!s.reactions || !allowed || this.state.status !== "ready" || this.state.inGame || this.state.dancing || this.state.scene) return;
    const now = performance.now();
    if (this.isBusy() || now - this.lastReact < 4000) return;
    this.lastReact = now;
    const rows = rowsOf([REACTION_INPUT[kind]]);
    if (rows.length) this.phrase(pickOne(rows));
    else this.randomInput(REACTION_INPUT[kind], true);
  }

  // ---- handshake -------------------------------------------------------------
  private queueConfirm(dir: Dir) {
    window.clearTimeout(this.confirmTimer);
    this.confirmTimer = window.setTimeout(() => {
      if (this.lastDir === dir) this.checkConfirm(dir);
    }, 70);
  }

  private checkConfirm(dir: Dir) {
    const c = this.state.confirm;
    if (!c || this.state.status !== "confirming") return;
    if (dir === c.seq[c.step]) {
      const step = c.step + 1;
      if (step >= c.seq.length) {
        this.patch({ status: "ready", confirm: null, connectedAt: Date.now() });
        this.flash([0, 255, 0]);
        this.log("sys", "Комбинация принята — Ферби на связи", "Combination accepted — Furby is connected");
        window.setTimeout(() => this.say("hello", true), 500);
        return;
      }
      this.patch({ confirm: { ...c, step } });
      this.flash([0, 120, 255]);
    } else {
      // a mistake does NOT restart the timer — only the deadline counts
      this.patch({ confirm: { ...c, step: 0, errors: c.errors + 1, errorAt: Date.now() } });
      this.flash([255, 0, 0]);
    }
  }

  newCombination() {
    const c = this.state.confirm;
    if (!c) return;
    this.patch({ confirm: { ...c, seq: makeSequence(), step: 0, deadline: Date.now() + CONFIRM_MS, attempt: c.attempt + 1 } });
  }

  private flash(rgb: Rgb) {
    this.setLedFrame(rgb, true);
    window.setTimeout(() => this.setLedFrame([0, 0, 0], true), 350);
  }

  // ---- commands ------------------------------------------------------------
  action(input: number, index: number, sub: number, specific: number, auto = false) {
    const label = `${actionName(input, index, sub, specific)}`;
    this.send(cmd.action(byte(input), byte(index), byte(sub), byte(specific)), { auto, label });
  }

  randomInput(input: number, auto = false) {
    this.send(cmd.randomInput(byte(input)), { auto, label: `input ${input}` });
  }

  /** Plays a library phrase and remembers its name for the voice card */
  phrase(row: LibRow, auto = false) {
    this.send(cmd.action(row[0], row[1], row[2], row[3]), { auto, label: rowLabel(row) });
    this.lastSay = performance.now();
    this.nextChatter = performance.now() + settings.get().chatterEvery * 1000;
    this.patch({ lastPhrase: rowLabel(row), phrases: this.state.phrases + 1 });
    this.onPhrase?.();
  }

  setChatterOn(on: boolean) {
    this.patch({ chatterOn: on });
  }

  sayRandom(auto = false) {
    const s = settings.get();
    this.phrase(pickOne(rowsOf(s.chatterSilly ? [...TALK_INPUTS, 7] : TALK_INPUTS)), auto);
  }

  say(kind: SayKind, force = false) {
    if (this.state.status !== "ready") return;
    if (!force && !settings.get().talkOnEvents) return;
    const now = performance.now();
    if (!force && (this.isBusy() || now - this.lastSay < 3000)) return;
    this.lastSay = now;
    const [i, x, s, p] = pickOne(SAY[kind]);
    this.send(cmd.action(i, x, s, p), { auto: true, label: actionName(i, x, s, p) });
  }

  setLedFrame(rgb: Rgb, override = false) {
    if (override) this.ledOverrideUntil = performance.now() + 400;
    const c: Rgb = [byte(rgb[0]), byte(rgb[1]), byte(rgb[2])];
    this.ledPending = c;
    const prev = this.state.color;
    if (prev[0] !== c[0] || prev[1] !== c[1] || prev[2] !== c[2]) this.patch({ color: c });
    void this.pump();
  }

  /** Static antenna colour for this toy; `remember` is what gets stored (raw, pre-gamma). */
  setColor(rgb: Rgb, remember: Rgb = rgb) {
    this.setLedFrame(rgb, true);
    if (this.state.deviceId) {
      const value = (remember[0] << 16) | (remember[1] << 8) | remember[2];
      settings.set({ deviceColors: { ...settings.get().deviceColors, [this.state.deviceId]: value } });
    }
  }

  setEyes(on: boolean) {
    this.send(cmd.eyes(on), { label: on ? "LCD on" : "LCD off" });
    this.patch({ eyes: on });
  }

  setMood(type: MoodType, value: number) {
    this.send(cmd.mood(type, byte(value)), { label: `mood ${type} → ${byte(value)}` });
  }

  setSensorStream(on: boolean, silent = false) {
    this.send(cmd.sensorStream(on), { silent, label: on ? "telemetry on" : "telemetry off" });
    this.patch({ telemetry: on });
  }

  readFirmware() {
    this.send(cmd.firmware(), { label: tr("версия прошивки", "firmware version"), auto: true });
  }

  wake() {
    this.setEyes(true);
    this.randomInput(27);
  }

  sleep() {
    this.randomInput(28);
    window.setTimeout(() => {
      if (this.connected) this.setEyes(false);
    }, 4000);
  }

  sendRaw(bytes: Bytes): boolean {
    if (settings.get().safeMode && [0x50, 0x53, 0x60, 0x61, 0x62, 0x74].includes(bytes[0])) {
      this.log("err", "Безопасный режим: команды DLC заблокированы", "Safe mode: DLC commands are blocked");
      return false;
    }
    this.send(bytes.map(byte), { label: "raw" });
    return true;
  }

  sayName(name: number) {
    this.action(33, 0, 0, name);
  }

  setName(name: number) {
    this.send(cmd.setName(byte(name)), { label: `name ${name}` });
    this.action(33, 0, 0, name);
  }

  /** Waits for the next packet matching a predicate (used by diagnostics). */
  waitForPacket(match: (d: Uint8Array) => boolean, timeoutMs = 2500): Promise<Uint8Array | null> {
    if (!this.connected) return Promise.resolve(null);
    return new Promise((resolve) => {
      const entry = { match, resolve, timer: 0 };
      entry.timer = window.setTimeout(() => {
        this.waiters = this.waiters.filter((x) => x !== entry);
        resolve(null);
      }, timeoutMs);
      this.waiters.push(entry);
    });
  }

  /** Counts matching packets arriving during a time window. */
  countPackets(match: (d: Uint8Array) => boolean, durationMs: number): Promise<number> {
    return new Promise((resolve) => {
      const entry = { match, count: 0 };
      this.counters.push(entry);
      window.setTimeout(() => {
        this.counters = this.counters.filter((x) => x !== entry);
        resolve(entry.count);
      }, durationMs);
    });
  }

  /** ImHere round trip: 20 06 → 22, returns latency in ms */
  ping(): Promise<number | null> {
    if (!this.connected) return Promise.resolve(null);
    const t0 = performance.now();
    return this.waitForPacket((d) => d[0] === 0x22, 2000).then((d) => {
      if (!d) return null;
      const ms = Math.round(performance.now() - t0);
      this.stats = { ...this.stats, pings: [...this.stats.pings.slice(-9), ms] };
      this.patch({ stats: this.stats });
      return ms;
    });
  }

  ruleFired() {
    this.stats = { ...this.stats, rulesFired: this.stats.rulesFired + 1 };
    this.patch({ stats: this.stats });
  }

  // ---- dance (input 18/0/0/1 non-stop) ---------------------------------------
  startDance() {
    if (this.state.dancing) return;
    this.patch({ dancing: true });
    this.sendDance();
  }

  private sendDance() {
    this.lastDance = performance.now();
    this.send(cmd.action(18, 0, 0, 1), { tag: "dance", auto: true, label: "18/0/0/1" });
  }

  stopDance() {
    if (!this.state.dancing) return;
    this.patch({ dancing: false });
    this.pending = this.pending.filter((p) => p.tag !== "dance");
    if (this.connected) {
      this.send(cmd.cancel(), { silent: true });
      this.send(cmd.action(1, 1, 0, 1), { auto: true });
    }
  }

  gameStart() {
    this.patch({ inGame: true });
  }

  gameEnd() {
    this.patch({ inGame: false });
    this.nextChatter = performance.now() + settings.get().chatterEvery * 1000;
  }

  setScene(scene: string | null) {
    this.patch({ scene });
  }

  // ---- LCD debug menu --------------------------------------------------------
  debugOpen() {
    if (this.state.debugStep > 0) return;
    this.send(cmd.eyes(true), { label: "LCD on", auto: true });
    this.send(cmd.debugCycle(), { label: "debug", auto: true });
    this.patch({ debugStep: 1, eyes: true });
  }

  debugNext(total: number) {
    if (this.state.debugStep === 0) {
      this.debugOpen();
      return;
    }
    this.send(cmd.debugCycle(), { label: "debug", auto: true });
    this.patch({ debugStep: (this.state.debugStep % (total + 1)) + 1 > total ? 0 : this.state.debugStep + 1 });
  }

  /** Cycles back to the normal eyes instead of switching the display off. */
  debugClose(total = DEBUG_SCREENS.length) {
    const step = this.state.debugStep;
    const presses = step > 0 ? Math.max(0, total + 1 - step) : 0;
    this.patch({ debugStep: 0, eyes: true });
    if (presses === 0) {
      this.send(cmd.eyes(true), { label: "LCD on", auto: true });
      return;
    }
    // spaced packets: the toy registers every cycle and really returns to normal eyes
    for (let i = 0; i < presses; i++) {
      window.setTimeout(() => {
        if (this.connected) this.send(cmd.debugCycle(), { silent: true, label: "debug" });
      }, i * 150);
    }
    window.setTimeout(() => {
      if (this.connected) this.send(cmd.eyes(true), { label: "LCD on", auto: true });
    }, presses * 150 + 120);
  }

  // ---- DLC slots (bluefluff: 0x50 / 0x60 / 0x61 / 0x62 / 0x73 / 0x74) ----

  private assertDlcAllowed() {
    if (settings.get().safeMode) {
      throw new Error(tr("Безопасный режим: операции с DLC отключены. Отключи его в настройках.", "Safe mode: DLC operations are off. Turn it off in Settings."));
    }
  }

  /** Queries the 14 slots one by one (0x73). The reply layout is not fully
   *  documented, so the filename is found by scanning for an ASCII run and the
   *  slot is correlated by query order instead of trusting a byte position. */
  async dlcSlots(onSlot?: (checked: number) => void): Promise<Array<{ slot: number; name: string; size: number; checksum: string; raw: string } | null>> {
    if (!this.writeChar && !this.demo) throw new Error(tr("Фёрби не подключён", "Furby is not connected"));
    const out: Array<{ slot: number; name: string; size: number; checksum: string; raw: string } | null> = Array(14).fill(null);
    for (let slot = 0; slot < 14; slot++) {
      const waiter = this.waitForPacket((d) => d[0] === 0x73, 1500);
      this.send([0x73, slot], { auto: true, label: `dlc slot ${slot}` });
      const d = await waiter;
      const parsed = d ? parseSlotPacket(d) : null;
      if (parsed) out[slot] = { slot, ...parsed };
      onSlot?.(slot + 1);
    }
    return out;
  }

  async dlcUpload(file: File, slot: number, onProgress?: (frac: number) => void): Promise<void> {
    this.assertDlcAllowed();
    if (slot < 0 || slot > 13) throw new Error(tr("Слот должен быть от 0 до 13", "Slot must be 0 to 13"));
    const data = new Uint8Array(await file.arrayBuffer());
    if (data.length < 4) throw new Error(tr("Файл пустой", "The file is empty"));
    if (this.demo && !this.fileChar) {
      // demo: fake a fast transfer so the UI can be tested
      for (let i = 1; i <= 20; i++) {
        await new Promise((r) => setTimeout(r, 60));
        onProgress?.(i / 20);
      }
      return;
    }
    if (!this.fileChar) throw new Error(tr("Нет канала для загрузки файлов", "No file transfer channel"));
    const ascii = (file.name.toUpperCase().replace(/[^A-Z0-9.]/g, "_") + "____________").slice(0, 12);
    const nameBytes = Array.from(ascii, (c) => c.charCodeAt(0));
    const announce = [
      0x50, 0x00,
      (data.length >> 16) & 255, (data.length >> 8) & 0x255, data.length & 0xff,
      slot,
      ...nameBytes, 0x00, 0x00,
    ];
    announce[3] = (data.length >> 8) & 0xff;
    const ready = this.waitForPacket((d) => d[0] === 0x24 && d[1] === 0x02, 8000);
    this.send(announce, { auto: true, label: "dlc announce" });
    const r = await ready;
    if (!r) throw new Error(tr("Игрушка не готова принимать файл", "The toy is not ready to receive the file"));
    const done = this.waitForPacket((d) => d[0] === 0x24 && (d[1] === 0x05 || d[1] === 0x06 || d[1] === 0x03), Math.max(30000, data.length * 12));
    for (let off = 0; off < data.length; off += 20) {
      await this.fileChar!.writeValue(data.subarray(off, Math.min(off + 20, data.length)));
      onProgress?.(Math.min(1, (off + 20) / data.length));
    }
    const fin = await done;
    if (!fin) throw new Error(tr("Нет подтверждения получения файла", "No file-received confirmation"));
    if (fin[1] === 0x06) throw new Error(tr("Игрушка отклонила файл", "The toy rejected the file"));
    if (fin[1] === 0x03) throw new Error(tr("Передача прервалась по таймауту", "The transfer timed out"));
  }

  dlcLoad(slot: number) {
    this.send([0x60, byte(slot)], { auto: true, label: "dlc load" });
    this.patch({ activeSlot: slot });
  }

  dlcActivate(slot: number) {
    this.send([0x60, byte(slot)], { auto: true, label: "dlc load" });
    window.setTimeout(() => this.send([0x61], { auto: true, label: "dlc activate" }), 350);
    this.patch({ activeSlot: slot });
  }

  dlcDeactivate(slot: number) {
    this.send([0x62, byte(slot)], { auto: true, label: "dlc deactivate" });
    if (this.state.activeSlot === slot) this.patch({ activeSlot: null });
  }

  dlcDelete(slot: number) {
    this.assertDlcAllowed();
    this.send([0x74, byte(slot)], { auto: true, label: "dlc delete" });
    if (this.state.activeSlot === slot) this.patch({ activeSlot: null });
  }

  async dlcSlotInfo(slot: number): Promise<{ name: string; size: number; checksum: string; raw: string } | null> {
    const d = await this.waitForPacket((x) => x[0] === 0x73, 1500);
    this.send([0x73, slot], { auto: true, label: `dlc slot ${slot}` });
    return d ? parseSlotPacket(d) : null;
  }

  /** Best-effort extraction of a slot's file onto the device.
   *  The protocol documents no file-read command, so this probes 0x54/0x55
   *  (size / checksum) and then polls the FileWrite characteristic. Failures
   *  return a diagnostic log instead of pretending it worked. */
  async dlcReadFromToy(
    slot: number,
    onProgress?: (got: number) => void,
  ): Promise<{ ok: boolean; file?: File; error?: string; log: string[] }> {
    const log: string[] = [];
    const say = (line: string) => log.push(line);
    if (this.demo) return { ok: false, error: tr("В демо-режиме выгрузка недоступна", "Extraction is not available in demo mode"), log };
    if (!this.writeChar || !this.fileChar) return { ok: false, error: tr("Фёрби не подключён", "Furby is not connected"), log };
    try {
      say(`слот ${slot}: запрос размера (0x54)`);
      let w = this.waitForPacket((d) => d[0] === 0x54, 2000);
      this.send([0x54, byte(slot)], { auto: true, label: "dlc size" });
      let sizeD = await w;
      if (!sizeD) {
        say("ответа нет, повторяю без слота");
        w = this.waitForPacket((d) => d[0] === 0x54, 1500);
        this.send([0x54], { auto: true, label: "dlc size" });
        sizeD = await w;
      }
      let sizeHint: number | undefined;
      if (sizeD) {
        say(`0x54: ${toHex(sizeD)}`);
        sizeHint = guessFileSize(sizeD);
        if (sizeHint) say(`размер ≈ ${sizeHint} байт`);
      } else say("0x54: игрушка не ответила");

      w = this.waitForPacket((d) => d[0] === 0x55, 1500);
      this.send([0x55, byte(slot)], { auto: true, label: "dlc checksum" });
      const sumD = await w;
      say(sumD ? `0x55: ${toHex(sumD)}` : "0x55: игрушка не ответила");

      if (!this.fileChar!.properties.read) {
        return { ok: false, error: tr("Характеристика файлов не поддерживает чтение", "The file characteristic does not support reading"), log };
      }
      say("чтение FileWrite…");
      const chunks: Uint8Array[] = [];
      let total = 0;
      let stalls = 0;
      let prevHex = "";
      const started = performance.now();
      for (let i = 0; i < 400 && stalls < 4 && performance.now() - started < 60000; i++) {
        let bytes: Uint8Array = new Uint8Array();
        try {
          const v = await this.fileChar!.readValue();
          if (v) bytes = new Uint8Array(v.buffer.slice(v.byteOffset, v.byteOffset + v.byteLength));
        } catch (e) {
          say(`чтение не удалось: ${errorText(e)}`);
          break;
        }
        const hx = hexHead(bytes, 12);
        if (bytes.length === 0 || hx === prevHex) {
          if (i < 3) say(`чтение #${i + 1}: ${bytes.length} байт${bytes.length ? ` (${hx}…)` : ""}`);
          stalls++;
          continue;
        }
        prevHex = hx;
        stalls = 0;
        if (i < 3) say(`чтение #${i + 1}: ${bytes.length} байт (${hx}…)`);
        chunks.push(bytes);
        total += bytes.length;
        onProgress?.(total);
        if (sizeHint && total >= sizeHint) break;
        await new Promise((r) => setTimeout(r, 40));
      }
      say(`собрано ${total} байт`);
      if (total === 0) {
        return {
          ok: false,
          error: tr(
            "Игрушка не отдала ни байта содержимого. Чтение файла не документировано в протоколе — лог ниже, пришли его, и я доработаю.",
            "The toy returned no content bytes. File reading isn't documented in the protocol — send me the log and I'll adapt it.",
          ),
          log,
        };
      }
      const all = new Uint8Array(total);
      let off = 0;
      for (const c of chunks) {
        all.set(c, off);
        off += c.length;
      }
      const info = parseDlc(all);
      if (!info.ok) return { ok: false, error: tr("Собранные данные не похожи на DLC: ", "The assembled data is not a DLC: ") + (info.error ?? ""), log };
      let name = `slot${slot}.dlc`;
      const slotInfo = await this.dlcSlotInfo(slot);
      if (slotInfo?.name) name = /\.dlc$/i.test(slotInfo.name) ? slotInfo.name : `${slotInfo.name}.DLC`;
      say(`готово: ${name}`);
      return { ok: true, file: new File([all], name, { type: "application/octet-stream" }), log };
    } catch (e) {
      return { ok: false, error: errorText(e), log };
    }
  }

  // ---- demo (virtual Furby) ---------------------------------------------------
  demoAntenna(dir: Dir | "P" | null) {
    if (!this.demo) return;
    this.dz.x = dir === "L" ? -1 : dir === "R" ? 1 : 0;
    this.dz.y = dir === "F" ? 1 : dir === "B" ? -1 : 0;
    this.dz.pressed = dir === "P";
    this.demoTick(true);
  }

  demoTouch(t: Touch, on: boolean) {
    if (!this.demo) return;
    if (on) this.dz.touches.add(t);
    else this.dz.touches.delete(t);
    this.demoTick(true);
  }

  demoShake(hard = false) {
    if (!this.demo) return;
    this.dz.shakeUntil = performance.now() + (hard ? 1300 : 900);
    this.dz.hard = hard;
  }

  demoKey(code: string, down: boolean) {
    if (!this.demo || (this.state.inGame && this.state.status === "ready")) return false;
    const map: Record<string, Dir> = { ArrowUp: "F", ArrowDown: "B", ArrowLeft: "L", ArrowRight: "R" };
    const d = map[code];
    if (!d) return false;
    this.demoAntenna(down ? d : null);
    return true;
  }

  private demoTick(force = false) {
    if (!this.demo) return;
    if (!this.state.telemetry && !force && this.state.status === "ready") return;
    const z = this.dz;
    const now = performance.now();
    if (now < z.shakeUntil) {
      z.orient = [0x01, 0x40, 0x80, 0x20, 0x01, 0x04, 0x08][Math.floor(Math.random() * (z.hard ? 7 : 4))];
      z.b5 = 0x27 + Math.floor((Math.random() - 0.5) * (z.hard ? 40 : 20));
      z.b6 = 0x0e + Math.floor((Math.random() - 0.5) * (z.hard ? 40 : 20));
    } else {
      z.orient = 0x01;
      z.b5 = 0x27;
      z.b6 = 0x0e;
    }
    const tb: Record<Touch, number> = { head: 0x01, tummy: 0x02, sideR: 0x04, sideL: 0x08, tail: 0x10, tongue: 0x20 };
    let b2 = z.pressed ? 0xc0 : z.y > 0 ? 0x80 : z.y < 0 ? 0x40 : 0;
    z.touches.forEach((t) => (b2 |= tb[t]));
    const b1 = z.x < 0 ? 0x02 : z.x > 0 ? 0x01 : 0;
    this.handleData(Uint8Array.from([0x21, b1, b2, z.b3, z.orient, byte(z.b5), byte(z.b6), 0]));
  }

  private inject(bytes: number[], delay: number) {
    window.setTimeout(() => {
      if (this.demo) this.handleData(Uint8Array.from(bytes));
    }, delay);
  }

  private simulate(b: Bytes) {
    const op = b[0];
    if (op >= 0x10 && op <= 0x13) {
      this.inject([0x20, 0x0c], 60);
      this.inject([0x20, 0x0e], 1200 + Math.random() * 1300);
    } else if (op === 0x20 && b[1] === 0x06) {
      this.inject([0x22, ...Array.from({ length: 17 }, (_, i) => i + 1)], 40 + Math.random() * 60);
    } else if (op === 0xfe) this.inject([0xfe, 0x04], 80);
    else if (op === 0xcd) this.inject([0x20, b[1] ? 0x17 : 0x18], 60);
    else if (op === 0x72) this.inject([0x72, 0x00, 0x0e, 0x00, 0x00], 90);
    else if (op === 0x20 && (b[1] === 0x0d || b[1] === 0x0e)) this.patch({ telemetry: b[1] === 0x0d });
    else if (op === 0x73) {
      const slot = b[1] ?? 0;
      if (slot === 2) {
        const name = Array.from("TU003410", (c) => c.charCodeAt(0));
        this.inject([0x73, slot, ...name, 17, 61, 214, 117, 4, 96, 46], 90);
      } else {
        this.inject([0x73, slot, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 90);
      }
    } else if (op === 0x60 || op === 0x61 || op === 0x62 || op === 0x74) {
      this.inject([0xdc, b[1] ?? 0], 80);
    } else if (op === 0x50) {
      this.inject([0x24, 0x02], 120);
    }
  }
}

export const furby = new FurbyController();

/** Two toys are supported: the primary one and an optional second one. */
export const furby2 = new FurbyController("2");

export const bothFurbies = (): FurbyController[] => [furby, furby2];
export const connectedFurbies = (): FurbyController[] => bothFurbies().filter((f) => f.connected);
/** Runs an action on every connected toy (game feedback, lights, dance). */
export function broadcast(fn: (f: FurbyController) => void) {
  for (const f of connectedFurbies()) fn(f);
}
export function useConfirmingController(): FurbyController | null {
  return furby.getState().status === "confirming" ? furby : furby2.getState().status === "confirming" ? furby2 : null;
}
