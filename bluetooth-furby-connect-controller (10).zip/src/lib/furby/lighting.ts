/** Antenna light engine: 100 pattern×palette modes + special/reactive modes, gamma-corrected for the LED. */
import { music } from "../audio/music";
import type { Text } from "../i18n";
import { progress } from "../progress";
import { settings } from "../settings";
import { createStore } from "../store";
import { broadcast, furby, furby2 } from "./controller";
import { hsv, mix, scale, type MoodType, type Rgb } from "./protocol";

export type LightCat = "smooth" | "rhythm" | "react" | "special";
interface Env {
  level: number;
  beat: number;
  ax: number;
  ay: number;
  touch: boolean;
  tiltX: number;
}
type Fn = (t: number, e: Env) => Rgb;
export interface LightMode {
  id: string;
  name: Text;
  desc: Text;
  group: string;
  cat: LightCat;
  danger?: boolean;
  fn: Fn;
}

const hash = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const noise1 = (x: number) => {
  const i = Math.floor(x);
  const f = x - i;
  return hash(i) + (hash(i + 1) - hash(i)) * f * f * (3 - 2 * f);
};
const OFF: Rgb = [0, 0, 0];
const hexRgb = (h: string): Rgb => {
  const v = parseInt(h.replace("#", ""), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
};

// ---- mood values (sidebar sliders, macros, "by mood" light) -------------------------
export const moods = createStore<{ values: number[] }>({ values: [50, 10, 20, 60, 90] }, "furby.moods.v1");
export function setMoodValue(type: MoodType, value: number, send = true) {
  const values = [...moods.get().values];
  values[type] = value;
  moods.set({ values });
  if (send) broadcast((f) => f.setMood(type, value));
}

// ---- sequencer ------------------------------------------------------------------------
export const sequencer = createStore<{ frames: Array<{ hex: string; ms: number }> }>(
  { frames: [{ hex: "#ff3b6b", ms: 300 }, { hex: "#ffd166", ms: 240 }, { hex: "#7ff2d8", ms: 240 }, { hex: "#6ec1ff", ms: 240 }, { hex: "#c084fc", ms: 240 }] },
  "furby.sequencer.v1",
);

// ---- microphone -----------------------------------------------------------------------
let mic: { stream: MediaStream; analyser: AnalyserNode; data: Uint8Array<ArrayBuffer>; ac: AudioContext } | null = null;
async function startMic() {
  if (mic) return;
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const ac = new AudioContext();
  const analyser = ac.createAnalyser();
  analyser.fftSize = 256;
  ac.createMediaStreamSource(stream).connect(analyser);
  mic = { stream, analyser, ac, data: new Uint8Array(analyser.frequencyBinCount) };
}
function stopMic() {
  if (!mic) return;
  mic.stream.getTracks().forEach((t) => t.stop());
  void mic.ac.close();
  mic = null;
}
function micLevel() {
  if (!mic) return 0;
  mic.analyser.getByteFrequencyData(mic.data);
  let sum = 0;
  for (const v of mic.data) sum += v;
  return Math.min(1, (sum / mic.data.length / 255) * 2.4);
}

// ---- Morse ----------------------------------------------------------------------------
const MORSE: Record<string, string> = {
  a: ".-", b: "-...", c: "-.-.", d: "-..", e: ".", f: "..-.", g: "--.", h: "....", i: "..", j: ".---", k: "-.-", l: ".-..", m: "--", n: "-.", o: "---", p: ".--.", q: "--.-", r: ".-.", s: "...", t: "-", u: "..-", v: "...-", w: ".--", x: "-..-", y: "-.--", z: "--..",
  а: ".-", б: "-...", в: ".--", г: "--.", д: "-..", е: ".", ж: "...-", з: "--..", и: "..", й: ".---", к: "-.-", л: ".-..", м: "--", н: "-.", о: "---", п: ".--.", р: ".-.", с: "...", т: "-", у: "..-", ф: "..-.", х: "....", ц: "-.-.", ч: "---.", ш: "----", щ: "--.-", ъ: "--.--", ы: "-.--", ь: "-..-", э: "..-..", ю: "..--", я: ".-.-",
  "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-", "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
};
let morseCache = { text: "", bits: "" };
function morseBits() {
  const text = settings.get().morseText.toLowerCase();
  if (morseCache.text === text) return morseCache.bits;
  let bits = "";
  for (const word of text.split(/\s+/).filter(Boolean)) {
    for (const ch of word) {
      const code = MORSE[ch];
      if (!code) continue;
      bits += [...code].map((c) => (c === "." ? "1" : "111")).join("0") + "000";
    }
    bits += "0000";
  }
  morseCache = { text, bits: bits || "0" };
  return morseCache.bits;
}

// ---- palettes & patterns ------------------------------------------------------------------
type Sampler = (x: number) => Rgb;
const PALETTES: Array<{ id: string; name: Text; colors: Rgb[] | null }> = [
  { id: "rainbow", name: ["Радуга", "Rainbow"], colors: null },
  { id: "fire", name: ["Огонь", "Fire"], colors: [[255, 24, 0], [255, 90, 0], [255, 170, 0], [255, 50, 0]] },
  { id: "ocean", name: ["Океан", "Ocean"], colors: [[0, 50, 255], [0, 150, 255], [0, 255, 200], [0, 90, 170]] },
  { id: "forest", name: ["Лес", "Forest"], colors: [[0, 255, 60], [90, 255, 0], [0, 150, 40], [170, 255, 60]] },
  { id: "sunset", name: ["Закат", "Sunset"], colors: [[255, 70, 0], [255, 0, 90], [170, 0, 255], [255, 140, 0]] },
  { id: "police", name: ["Полиция", "Police"], colors: [[255, 0, 0], [0, 0, 255]] },
  { id: "candy", name: ["Конфета", "Candy"], colors: [[255, 60, 170], [60, 255, 190], [190, 120, 255], [255, 170, 210]] },
  { id: "ice", name: ["Лёд", "Ice"], colors: [[255, 255, 255], [120, 220, 255], [0, 120, 255]] },
  { id: "neon", name: ["Неон", "Neon"], colors: [[255, 0, 255], [0, 255, 255], [120, 255, 0]] },
  { id: "gold", name: ["Золото", "Gold"], colors: [[255, 170, 0], [255, 210, 60], [255, 255, 200], [255, 120, 0]] },
];
function sampler(colors: Rgb[] | null): Sampler {
  if (!colors) return (x) => hsv(x, 1, 1);
  return (x) => {
    const n = colors.length;
    const f = (((x % 1) + 1) % 1) * n;
    const i = Math.floor(f);
    return mix(colors[i % n], colors[(i + 1) % n], f - i);
  };
}
const PATTERNS: Array<{ id: string; name: Text; desc: Text; cat: LightCat; danger?: boolean; fn: (t: number, p: Sampler, n: number) => Rgb }> = [
  { id: "smooth", name: ["Плавно", "Smooth"], desc: ["Медленный перелив по палитре", "Slow flow through the palette"], cat: "smooth", fn: (t, p) => p(t * 0.08) },
  { id: "breathe", name: ["Дыхание", "Breathe"], desc: ["Синусоидальное затухание", "Sine fade in and out"], cat: "smooth", fn: (t, p, n) => scale(p(Math.floor(t / 4) / n), 0.06 + 0.94 * (0.5 - 0.5 * Math.cos((t * Math.PI) / 2))) },
  { id: "fade", name: ["Переливы", "Crossfade"], desc: ["Мягкая смена цветов", "Soft colour changes"], cat: "smooth", fn: (t, p, n) => p(t / 1.6 / n) },
  { id: "wave", name: ["Волна", "Wave"], desc: ["Туда и обратно по палитре", "Back and forth through the palette"], cat: "smooth", fn: (t, p) => p((0.5 + 0.5 * Math.sin(t * 1.2)) * 0.999) },
  { id: "candle", name: ["Свеча", "Candle"], desc: ["Живое мерцание", "Living flicker"], cat: "smooth", fn: (t, p) => scale(p(t * 0.03), 0.45 + 0.55 * noise1(t * 9)) },
  {
    id: "pulse", name: ["Пульс", "Heartbeat"], desc: ["Двойной удар как на ЭКГ", "Double beat like an ECG"], cat: "rhythm",
    fn: (t, p, n) => {
      const ph = t % 1.1;
      const e = Math.max(Math.exp(-ph * 14), ph > 0.25 ? 0.8 * Math.exp(-(ph - 0.25) * 14) : 0);
      return scale(p(Math.floor(t / 1.1) / n), 0.05 + 0.95 * e);
    },
  },
  { id: "strobe", name: ["Стробоскоп", "Strobe"], desc: ["Резкие вспышки", "Sharp flashes"], cat: "rhythm", danger: true, fn: (t, p, n) => (t % 0.5 < 0.14 ? p(Math.floor(t / 0.5) / n) : OFF) },
  { id: "blink", name: ["Мигание", "Blink"], desc: ["Раз в секунду", "Once a second"], cat: "rhythm", fn: (t, p, n) => (t % 1 < 0.5 ? p(Math.floor(t) / n) : OFF) },
  { id: "jump", name: ["Скачки", "Jump"], desc: ["Резкая смена цветов", "Hard colour jumps"], cat: "rhythm", fn: (t, p, n) => p(Math.floor(t / 0.45) / n) },
  {
    id: "sparkle", name: ["Искры", "Sparkle"], desc: ["Случайные блёстки", "Random glitter"], cat: "rhythm",
    fn: (t, p) => {
      const k = Math.floor(t * 12);
      return hash(k) > 0.8 ? p(hash(k + 7)) : scale(p(t * 0.05), 0.12);
    },
  },
  {
    id: "run",
    name: ["Пробег", "Run"],
    desc: ["Бегущая вспышка по палитре", "A running flash across the palette"],
    cat: "rhythm",
    fn: (t, p) => scale(p((t * 0.5) % 1), ((t * 4) % 1) < 0.3 ? 1 : 0.22),
  },
  {
    id: "stairs",
    name: ["Лесенка", "Stairs"],
    desc: ["Ступеньки яркости", "Brightness steps"],
    cat: "rhythm",
    fn: (t, p) => scale(p(Math.floor(((t * 0.5) % 1) * 6) / 6), [0.25, 0.6, 1][Math.floor(t * 3) % 3]),
  },
  {
    id: "dblpulse",
    name: ["Двойной пульс", "Double pulse"],
    desc: ["Два удара за такт", "Two beats per bar"],
    cat: "rhythm",
    fn: (t, p, n) => {
      const ph = (t * 2) % 1;
      const e = Math.max(Math.exp(-ph * 18), Math.exp(-((ph + 0.5) % 1) * 18));
      return scale(p(Math.floor(t) / n), 0.05 + 0.95 * e);
    },
  },
  {
    id: "rain",
    name: ["Дождь", "Rain"],
    desc: ["Капли по палитре", "Drops across the palette"],
    cat: "rhythm",
    fn: (t, p) => {
      const k = Math.floor(t * 7);
      return scale(p(hash(k + 3)), hash(k) > 0.45 ? 1 : 0.14);
    },
  },
  {
    id: "zigzag",
    name: ["Зигзаг", "Zigzag"],
    desc: ["Треугольная волна", "Triangle wave"],
    cat: "smooth",
    fn: (t, p) => {
      const tri = Math.abs(((t * 1.2) % 2) - 1);
      return scale(p((Math.floor(t * 1.2) % 2) / 2), 0.2 + 0.8 * tri);
    },
  },
  {
    id: "blob",
    name: ["Клякса", "Blob"],
    desc: ["Органическое переливание", "Organic blobbing"],
    cat: "smooth",
    fn: (t, p) => scale(p(noise1(t * 1.4)), 0.3 + 0.7 * noise1(t * 4 + 9)),
  },
  { id: "breathe2", name: ["Дыхание-2", "Breathe 2"], desc: ["Вдох с новым цветом каждый цикл", "Breath with a new colour each cycle"], cat: "smooth", fn: (t, p, n) => scale(p((Math.floor(t / 2) + 0.5) / n), 0.2 + 0.8 * Math.abs(Math.sin(t * 0.9))) },
  { id: "heartbeat2", name: ["Пульс-2", "Heartbeat 2"], desc: ["Один резкий удар", "One sharp beat"], cat: "rhythm", fn: (t, p, n) => { const ph = t % 0.9; return scale(p(Math.floor(t / 0.9) / n), 0.06 + 0.94 * Math.exp(-ph * 22)); } },
  { id: "softflash", name: ["Мягкая вспышка", "Soft flash"], desc: ["Плавное проявление", "Soft appearance"], cat: "smooth", fn: (t, p, n) => { const ph = t % 1.2; const e = ph < 0.3 ? Math.sin((ph / 0.3) * Math.PI) : 0; return scale(p(Math.floor(t / 1.2) / n), 0.12 + 0.88 * e); } },
  { id: "disco2", name: ["Диско-2", "Disco 2"], desc: ["Белая вспышка между цветами", "White flash between colours"], cat: "rhythm", fn: (t, p) => (t % 0.5 < 0.12 ? [255, 255, 255] : p((Math.floor(t * 2) % 20) / 20)) },
  { id: "colorbounce", name: ["Цвет-прыжок", "Colour bounce"], desc: ["Цвет идёт, яркость прыгает", "Colour flows, brightness bounces"], cat: "rhythm", fn: (t, p) => scale(p((t * 0.4) % 1), 0.15 + 0.85 * Math.abs(((t * 1.6) % 2) - 1)) },
  { id: "meteor2", name: ["Метеор-2", "Meteor 2"], desc: ["Вспышка и долгий след", "Flash with a long tail"], cat: "smooth", fn: (t, p) => { const ph = (t % 1.6) / 1.6; return scale(p(hash(Math.floor(t / 1.6))), Math.exp(-ph * 3.5)); } },
  { id: "candle2", name: ["Камин-2", "Fireplace 2"], desc: ["Живое тёплое пламя", "Living warm flame"], cat: "smooth", fn: (t) => scale([255, Math.round(120 + noise1(t * 6) * 110), 40], 0.35 + 0.55 * noise1(t * 8 + 3)) },
  { id: "randomjump", name: ["Случайные прыжки", "Random jumps"], desc: ["Цвет меняется скачком", "Colour jumps at random"], cat: "rhythm", fn: (t, p) => scale(p(hash(Math.floor(t * 1.7) % 97)), 0.9) },
  { id: "mixwave", name: ["Смесь-волна", "Mix wave"], desc: ["Две точки палитры смешиваются", "Two palette points blend"], cat: "smooth", fn: (t, p) => mix(p((t / 3) % 1), p(((t / 3) + 0.5) % 1), 0.5 + 0.5 * Math.sin(t * 1.7)) },
  { id: "spiral2", name: ["Вихрь-2", "Spiral 2"], desc: ["Цветовой вихрь с пульсом", "Colour whirl with a pulse"], cat: "smooth", fn: (t) => scale(hsv(t * 0.2, 1, 1), 0.5 + 0.5 * Math.sin(t * 0.9)) },
  { id: "reveal", name: ["Проявление", "Reveal"], desc: ["Медленное проявление цвета", "Colour slowly revealed"], cat: "smooth", fn: (t, p, n) => scale(p(Math.floor(t / 6) / n), 0.05 + 0.95 * Math.pow(0.5 + 0.5 * Math.sin(t * 0.5), 2)) },
  { id: "dots2", name: ["Искры-3", "Sparks 3"], desc: ["Короткие щелчки цвета", "Short colour clicks"], cat: "rhythm", fn: (t, p) => scale(p(hash(Math.floor(t * 4))), t % 0.25 < 0.1 ? 1 : 0.15) },
  { id: "elevator", name: ["Лифт", "Elevator"], desc: ["Яркость поднимается ступенями", "Brightness rises in steps"], cat: "rhythm", fn: (t, p, n) => { const ph = (t % 6) / 6; const b = ph < 0.5 ? ph * 2 : (1 - ph) * 2; return scale(p(Math.floor(t / 6) / n), 0.1 + 0.9 * (Math.floor(b * 6) / 6)); } },
  { id: "ocean2", name: ["Прилив-2", "Tide 2"], desc: ["Большая медленная волна", "Big slow swell"], cat: "smooth", fn: (t) => scale(hsv(0.5 + 0.12 * Math.sin(t * 0.18), 0.85, 1), 0.22 + 0.78 * (0.5 + 0.5 * Math.sin(t * 0.45))) },
  { id: "sparkle3", name: ["Блёстки-2", "Glitter 2"], desc: ["Редкие белые вспышки", "Rare white flashes"], cat: "rhythm", fn: (t, p) => (hash(Math.floor(t * 3)) > 0.85 ? [255, 255, 255] : scale(p(t / 12), 0.2)) },
  { id: "breathbeat", name: ["Дыхание-бит", "Breath beat"], desc: ["Дыхание с ударом на каждый такт", "Breath with a beat"], cat: "smooth", fn: (t, p) => { const base = 0.15 + 0.55 * (0.5 - 0.5 * Math.cos(t * 1.6)); const beat = 0.3 * Math.exp(-((t % 1) * 8)); return scale(p((t / 8) % 1), Math.min(1, base + beat)); } },
  { id: "nightglow", name: ["Ночной огонёк", "Night glow"], desc: ["Тёплое мерцание", "Warm flicker"], cat: "smooth", fn: (t) => scale([255, 170, 60], 0.3 + 0.3 * noise1(t * 5) + 0.12 * Math.sin(t * 9)) },
  { id: "chromespin", name: ["Цвет-вихрь", "Chrome spin"], desc: ["Хромированный вихрь", "Chromatic whirl"], cat: "smooth", fn: (t) => scale(hsv(t * 0.35 + noise1(t) * 0.2, 1, 1), 0.55 + 0.45 * Math.sin(t * 2.2)) },
  { id: "dimhold", name: ["Полутьма", "Half-light"], desc: ["Спокойный приглушённый свет", "Calm dim light"], cat: "smooth", fn: (t, p, n) => scale(p(Math.floor(t / 10) / n), 0.22 + 0.12 * Math.sin(t * 0.6)) },
  { id: "squarewave", name: ["Квадрат", "Square"], desc: ["Два цвета, две яркости", "Two colours, two levels"], cat: "rhythm", fn: (t, p) => { const ph = (t * 2) % 2; return scale(p(ph < 1 ? 0.15 : 0.65), ph % 1 < 0.5 ? 1 : 0.55); } },
];

const SOS = "1010100011101110111000101010000000";
let lastRx = 0;
let rxFlash = 0;
const S = (id: string, cat: LightCat, name: Text, desc: Text, fn: Fn, danger = false): LightMode => ({ id, group: "special", cat, name, desc, fn, danger });

const SPECIALS: LightMode[] = [
  S("rainbow", "smooth", ["Радуга", "Rainbow"], ["Ровный круг по спектру", "Even sweep through the spectrum"], (t) => hsv(t * 0.1, 1, 1)),
  S("aurora", "smooth", ["Северное сияние", "Aurora"], ["Изумруд и фиолет", "Emerald and violet"], (t) => mix(mix([0, 255, 120], [0, 140, 255], 0.5 + 0.5 * Math.sin(t * 0.7)), [150, 0, 255], 0.5 + 0.5 * Math.sin(t * 0.31))),
  S("sunrise", "smooth", ["Рассвет", "Sunrise"], ["От тёмно-красного к тёплому белому", "From deep red to warm white"], (t) => {
    const k = (t % 30) / 30;
    return k < 0.5 ? mix([40, 0, 0], [255, 80, 0], k * 2) : mix([255, 80, 0], [255, 230, 180], (k - 0.5) * 2);
  }),
  S("rainbow-fast", "rhythm", ["Быстрая радуга", "Fast rainbow"], ["Быстрая спираль оттенков", "A fast spiral of hues"], (t) => hsv(t * 0.45, 1, 1)),
  S("siren", "rhythm", ["Мигалка", "Siren"], ["Красный / синий патруль", "Red / blue patrol"], (t) => {
    const ph = t % 0.8;
    return ph % 0.1 < 0.06 ? (ph < 0.4 ? [255, 0, 0] : [0, 0, 255]) : OFF;
  }, true),
  S("storm", "rhythm", ["Гроза", "Thunderstorm"], ["Тёмное небо и молнии", "Dark sky and lightning"], (t) => (hash(Math.floor(t * 10)) > 0.95 ? [255, 255, 255] : [8, 18, 70]), true),
  S("matrix", "rhythm", ["Матрица", "Matrix"], ["Зелёные капли кода", "Green drops of code"], (t) => scale([0, 255, 60], 0.15 + 0.85 * (hash(Math.floor(t * 9)) > 0.6 ? 1 : 0.2))),
  S("holiday", "rhythm", ["Новый год", "Holidays"], ["Красно-зелёная гирлянда", "Red and green garland"], (t) => scale(Math.floor(t * 1.5) % 2 ? [255, 0, 0] : [0, 255, 40], 0.5 + 0.5 * noise1(t * 6))),
  S("halloween", "rhythm", ["Хэллоуин", "Halloween"], ["Тыква и фиолетовый туман", "Pumpkin and violet fog"], (t) => scale(noise1(t * 2) > 0.5 ? [255, 90, 0] : [140, 0, 255], 0.35 + 0.65 * noise1(t * 11))),
  S("music", "react", ["Под музыку сайта", "Site music"], ["Пляшет под музыку из вкладки «Музыка»", "Dances to the music tab"], (t, e) => scale(hsv(t * 0.05 + e.beat * 0.2, 1, 1), 0.12 + 0.88 * Math.min(1, e.level * 1.8 + e.beat * 0.4))),
  S("mic", "react", ["Музыка (микрофон)", "Music (microphone)"], ["Антенна пляшет под звук в комнате", "Dances to the sound in the room"], (t) => scale(hsv(t * 0.07, 1, 1), 0.08 + 0.92 * micLevel())),
  S("sensors", "react", ["Реакция на датчики", "Sensor reaction"], ["Цвет по типу прикосновения", "Colour by type of touch"], (_t, e) => (e.touch ? [255, 60, 170] : e.ax < 0 ? [160, 0, 255] : e.ax > 0 ? [255, 30, 30] : e.ay > 0 ? [0, 255, 80] : e.ay < 0 ? [0, 200, 255] : [40, 40, 40])),
  S("tilt", "react", ["Наклон", "Tilt"], ["Цвет зависит от наклона", "Colour follows the tilt"], (_t, e) => hsv(0.55 + e.tiltX * 0.3, 1, 1)),
  S("link", "react", ["Пульс связи", "Link pulse"], ["Вспышка на каждый пакет Ферби", "A flash on every Furby packet"], () => {
    const rx = furby.getState().stats.rx;
    if (rx !== lastRx) {
      lastRx = rx;
      rxFlash = 1;
    }
    rxFlash *= 0.7;
    return scale([0, 200, 180], 0.08 + 0.92 * rxFlash);
  }),
  S("mood", "react", ["По настроению", "By mood"], ["Цвет отражает moodmeter", "Colour reflects the moodmeter"], (t) => {
    const [ex, dis, tired, , well] = moods.get().values.map((v) => v / 100);
    const base = mix(mix([0, 200, 120], [255, 40, 0], dis), [60, 60, 255], tired * 0.6);
    return scale(mix(base, [255, 200, 0], ex * 0.4), (0.35 + 0.65 * well) * (0.75 + 0.25 * Math.sin(t * (1 + ex * 4))));
  }),
  S("white", "special", ["Белый свет", "White light"], ["Ровный белый", "Plain white"], () => [255, 255, 255]),
  S("traffic", "special", ["Светофор", "Traffic light"], ["Зелёный → жёлтый → красный", "Green → yellow → red"], (t) => {
    const ph = t % 8;
    return ph < 3.5 ? [0, 255, 0] : ph < 4.5 ? [255, 170, 0] : [255, 0, 0];
  }),
  S("sos", "special", ["SOS морзянкой", "SOS in Morse"], ["Сигнал бедствия", "Distress signal"], (t) => (SOS[Math.floor(t / 0.2) % SOS.length] === "1" ? [255, 255, 255] : OFF)),
  S("morse", "special", ["Морзянка", "Morse code"], ["Антенна выстукивает твой текст", "The antenna taps out your text"], (t) => {
    const bits = morseBits();
    return bits[Math.floor(t / 0.18) % bits.length] === "1" ? [255, 255, 255] : OFF;
  }),
  S("sequencer", "special", ["Мой секвенсор", "My sequencer"], ["Твоя покадровая последовательность", "Your frame-by-frame sequence"], (t) => {
    const frames = sequencer.get().frames;
    const total = frames.reduce((n, f) => n + f.ms, 0) || 1;
    let at = (t * 1000) % total;
    for (const f of frames) {
      if (at < f.ms) return hexRgb(f.hex);
      at -= f.ms;
    }
    return OFF;
  }),
  S("rgbtest", "special", ["Тест RGB", "RGB test"], ["Красный, зелёный, синий, белый — проверка диода", "Red, green, blue, white — LED check"], (t) => ([[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 255]] as Rgb[])[Math.floor(t / 0.8) % 4]),
    S("radar", "react", ["Радар", "Radar"], ["Вспышка развёртки", "Sweep flash"], (t) => (((t * 1.2) % 1) < 0.1 ? [0, 255, 140] : [0, 45, 30])),
  S("scanner", "smooth", ["Сканер", "Scanner"], ["Белый луч по кругу", "White beam sweep"], (t) => {
    const b = (t * 0.7) % 1;
    return scale([255, 255, 255], 0.08 + 0.92 * Math.exp(-Math.pow((b - 0.5) * 5, 2)));
  }),
  S("stars", "rhythm", ["Звёзды", "Stars"], ["Мерцание звёзд", "Twinkling stars"], (t) => {
    const k = Math.floor(t * 5);
    return hash(k) > 0.65 ? [255, 255, 255] : scale([50, 70, 140], 0.5);
  }),
  S("daynight", "smooth", ["День-ночь", "Day & night"], ["Медленный переход", "Slow transition"], (t) => mix([255, 190, 120], [25, 35, 90], 0.5 + 0.5 * Math.sin(t * 0.15))),
  S("counter", "rhythm", ["Счётчик", "Counter"], ["Ступенчатая яркость", "Stepped brightness"], (t) => scale([255, 255, 255], ((Math.floor(t * 3) % 8) + 1) / 8)),
  S("fog", "smooth", ["Туман", "Fog"], ["Приглушённые оттенки", "Muted tones"], (t) => mix(hsv(t * 0.05, 0.35, 0.85), [175, 180, 190], 0.4)),
];

const GRID: LightMode[] = PATTERNS.flatMap((p) =>
  PALETTES.map((pal) => {
    const s = sampler(pal.colors);
    const n = pal.colors?.length ?? 6;
    return {
      id: `${p.id}-${pal.id}`,
      group: p.id,
      cat: p.cat,
      danger: p.danger,
      name: [`${p.name[0]} · ${pal.name[0]}`, `${p.name[1]} · ${pal.name[1]}`] as Text,
      desc: p.desc,
      fn: (t: number) => p.fn(t, s, n),
    };
  }),
);

const SHUFFLE = S("shuffle", "special", ["Случайные режимы", "Shuffle modes"], ["Новый режим каждые 8 секунд", "A new mode every 8 seconds"], (t, e) => GRID[Math.floor(hash(Math.floor(t / 8)) * GRID.length)].fn(t, e));

export const LIGHT_MODES: LightMode[] = [...SPECIALS, SHUFFLE, ...GRID];
export const LIGHT_SPECIALS: LightMode[] = [...SPECIALS, SHUFFLE];
export const LIGHT_PATTERNS = PATTERNS.map(({ id, name, desc, cat, danger }) => ({ id, name, desc, cat, danger }));
export const LIGHT_PALETTES = PALETTES.map(({ id, name, colors }) => ({ id, name, preview: colors ? colors[0] : ([255, 0, 0] as Rgb), colors }));

export const lighting = createStore<{ mode: string | null; color: Rgb; micError: string | null }>({ mode: null, color: OFF, micError: null });

let timer: number | undefined;
let started = 0;
let current: LightMode | null = null;

function ledOutput(c: Rgb): Rgb {
  const s = settings.get();
  const k = s.ledBrightness / 100;
  const f = (v: number) => Math.round(255 * Math.pow(Math.max(0, Math.min(255, v)) / 255, s.ledGamma ? 2.2 : 1) * k);
  return [f(c[0]), f(c[1]), f(c[2])];
}

function tick() {
  if (!current) return;
  const s = settings.get();
  const st = furby.getState().sensors;
  const m = music.get();
  const t = ((performance.now() - started) / 1000) * s.ledSpeed;
  const env: Env = { level: m.level, beat: m.beat, ax: st?.x ?? 0, ay: st?.y ?? 0, touch: (st?.touches.length ?? 0) > 0, tiltX: st?.tiltX ?? 0 };
  const color = current.fn(t, env);
  const preview = scale(color, s.ledBrightness / 100);
  const prev = lighting.get().color;
  if (preview[0] !== prev[0] || preview[1] !== prev[1] || preview[2] !== prev[2]) lighting.set({ color: preview });
  if (performance.now() > Math.max(furby.ledOverrideUntil, furby2.ledOverrideUntil)) broadcast((f) => f.setLedFrame(ledOutput(color)));
  timer = window.setTimeout(tick, 1000 / Math.max(2, Math.min(30, s.ledFps)));
}

export function startLight(id: string) {
  const mode = LIGHT_MODES.find((m) => m.id === id);
  if (!mode) return;
  window.clearTimeout(timer);
  if (id === "mic") {
    startMic().then(
      () => lighting.set({ micError: null }),
      (e) => lighting.set({ micError: e instanceof Error ? e.message : String(e) }),
    );
  } else stopMic();
  current = mode;
  started = performance.now();
  lighting.set({ mode: id });
  settings.set({ lightMode: id });
  progress.markLight(id);
  tick();
}

export function stopLight(turnOff = true) {
  window.clearTimeout(timer);
  stopMic();
  current = null;
  lighting.set({ mode: null, color: OFF });
  settings.set({ lightMode: "" });
  if (turnOff) broadcast((f) => f.setLedFrame(OFF));
}

export function setStaticColor(c: Rgb) {
  window.clearTimeout(timer);
  stopMic();
  current = null;
  lighting.set({ mode: null, color: scale(c, settings.get().ledBrightness / 100) });
  settings.set({ lightMode: "" });
  // remember the raw colour on every connected toy, send the gamma-corrected one
  broadcast((f) => f.setColor(ledOutput(c), c));
}
