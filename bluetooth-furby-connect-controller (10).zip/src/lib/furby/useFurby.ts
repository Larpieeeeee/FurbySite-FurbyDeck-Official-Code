import { useSyncExternalStore } from "react";
import { furby, furby2, useConfirmingController, type FurbyController, type FurbyState } from "./controller";

/**
 * Subscribe to a slice of a Furby store.
 * Selectors must return primitives or stable references, otherwise React re-renders forever.
 */
export function useFurby<T>(selector: (state: FurbyState) => T): T {
  return useCtl(furby, selector);
}

export function useCtl<T>(ctl: FurbyController, selector: (state: FurbyState) => T): T {
  return useSyncExternalStore(ctl.subscribe, () => selector(ctl.getState()));
}

export function useFurby2<T>(selector: (state: FurbyState) => T): T {
  return useCtl(furby2, selector);
}

/** The toy currently waiting for antenna confirmation (either slot). */
export function useConfirming(): FurbyController | null {
  return useSyncExternalStore(
    (cb) => {
      const u1 = furby.subscribe(cb);
      const u2 = furby2.subscribe(cb);
      return () => {
        u1();
        u2();
      };
    },
    () => useConfirmingController(),
  );
}
