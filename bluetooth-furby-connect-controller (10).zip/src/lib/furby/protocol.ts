/**
 * Furby Connect Bluetooth LE protocol (reverse-engineered by Jeija/bluefluff and pdjstone/FurBLE).
 * Commands are byte arrays (max 20) written to GeneralPlusWrite; replies arrive on GeneralPlusListen.
 */
import type { Text } from "../i18n";

export const FLUFF_SERVICE = "dab91435-b5a1-e29c-b041-bcd562613bde";
export const GP_WRITE = "dab91383-b5a1-e29c-b041-bcd562613bde";
export const GP_LISTEN = "dab91382-b5a1-e29c-b041-bcd562613bde";
export const NORDIC_LISTEN = "dab90756-b5a1-e29c-b041-bcd562613bde";
export const FILE_WRITE = "dab90758-b5a1-e29c-b041-bcd562613bde";
export const NAME_PREFIX = "Furby";
export const MAX_PACKET = 20;

export type Bytes = number[];
export type Rgb = [number, number, number];
export type Dir = "L" | "R" | "F" | "B";
export const DIRS: Dir[] = ["L", "R", "F", "B"];

export const DIR_LABELS: Record<Dir, Text> = {
  L: ["Влево", "Left"],
  R: ["Вправо", "Right"],
  F: ["Вперёд", "Forward"],
  B: ["Назад", "Back"],
};

export type MoodType = 0 | 1 | 2 | 3 | 4;
export const MOODS: Array<{ type: MoodType; label: Text }> = [
  { type: 0, label: ["Возбуждение", "Excitement"] },
  { type: 1, label: ["Недовольство", "Displeasure"] },
  { type: 2, label: ["Усталость", "Tiredness"] },
  { type: 3, label: ["Сытость", "Fullness"] },
  { type: 4, label: ["Самочувствие", "Wellness"] },
];

export const DEBUG_SCREENS: Text[] = [
  ["Настроение и личность", "Mood and personality"],
  ["Часы (RTC) и BLE", "Clock (RTC) and BLE"],
  ["Акселерометр", "Accelerometer"],
  ["Микрофон", "Microphone"],
  ["Furby-to-Furby (F2F)", "Furby-to-Furby (F2F)"],
  ["Слоты DLC", "DLC slots"],
  ["Тайминги уведомлений", "Notification timings"],
];

export type Orientation =
  | "upright"
  | "upside-down"
  | "right-side"
  | "left-side"
  | "tilted-right"
  | "tilted-left"
  | "leaning-back"
  | "leaning-forward"
  | "unknown";

export const ORIENTATION_LABELS: Record<Orientation, Text> = {
  upright: ["Стоит прямо", "Upright"],
  "upside-down": ["Вверх ногами", "Upside down"],
  "right-side": ["Лежит на правом боку", "Lying on the right side"],
  "left-side": ["Лежит на левом боку", "Lying on the left side"],
  "tilted-right": ["Наклон вправо", "Tilted right"],
  "tilted-left": ["Наклон влево", "Tilted left"],
  "leaning-back": ["Откинут назад", "Leaning back"],
  "leaning-forward": ["Наклон вперёд", "Leaning forward"],
  unknown: ["Не определено", "Unknown"],
};

export type Touch = "head" | "tummy" | "sideL" | "sideR" | "tail" | "tongue";
export const TOUCH_IDS: Touch[] = ["head", "tummy", "sideL", "sideR", "tail", "tongue"];
export const TOUCH_LABELS: Record<Touch, Text> = {
  head: ["Голова", "Head"],
  tummy: ["Живот", "Tummy"],
  sideL: ["Левый бок", "Left side"],
  sideR: ["Правый бок", "Right side"],
  tail: ["Хвост", "Tail"],
  tongue: ["Язык", "Tongue"],
};

export interface SensorState {
  raw: string;
  bytes: number[];
  /** Antenna joystick: -1 left, 1 right */
  x: -1 | 0 | 1;
  /** Antenna joystick: 1 forward, -1 back */
  y: -1 | 0 | 1;
  /** Antenna pushed down (pressed) */
  pressed: boolean;
  dir: Dir | "P" | null;
  touches: Touch[];
  orientation: Orientation;
  /** Approximate tilt from the orientation flags, -1..1 */
  tiltX: number;
  tiltY: number;
}

const TOUCH_BITS: Array<[number, Touch]> = [
  [0x01, "head"],
  [0x02, "tummy"],
  [0x04, "sideR"],
  [0x08, "sideL"],
  [0x10, "tail"],
  [0x20, "tongue"],
];

function orientationOf(b: number): Orientation {
  if (b & 0x02) return "upside-down";
  if (b & 0x04) return "right-side";
  if (b & 0x08) return "left-side";
  if (b & 0x40) return "tilted-right";
  if (b & 0x80) return "tilted-left";
  if (b & 0x20) return "leaning-back";
  if (b & 0x10) return "leaning-forward";
  if (b & 0x01) return "upright";
  return "unknown";
}

export function decodeSensors(data: Uint8Array, invertX = false, invertY = false, invertTilt = false): SensorState | null {
  if (data.length < 5 || data[0] !== 0x21) return null;
  const b1 = data[1];
  const b2 = data[2];
  const b4 = data[4];

  // Byte 2: both 0x40 and 0x80 set = antenna pushed down. 0x80 alone = forward, 0x40 alone = back.
  const pressed = (b2 & 0xc0) === 0xc0;
  let x: -1 | 0 | 1 = b1 & 0x02 ? -1 : b1 & 0x01 ? 1 : 0;
  let y: -1 | 0 | 1 = pressed ? 0 : b2 & 0x80 ? 1 : b2 & 0x40 ? -1 : 0;
  if (invertX) x = (-x || 0) as -1 | 0 | 1;
  if (invertY) y = (-y || 0) as -1 | 0 | 1;
  const dir: SensorState["dir"] = pressed ? "P" : x < 0 ? "L" : x > 0 ? "R" : y > 0 ? "F" : y < 0 ? "B" : null;

  // Tilt: "tilted" = light tilt (0.5), "lying on side" = full tilt (1)
  let tiltX = b4 & 0x04 ? 1 : b4 & 0x08 ? -1 : b4 & 0x40 ? 0.5 : b4 & 0x80 ? -0.5 : 0;
  let tiltY = b4 & 0x20 ? -0.7 : b4 & 0x10 ? 0.7 : 0;
  if (invertTilt) tiltX = -tiltX || 0;

  return {
    raw: toHex(data),
    bytes: Array.from(data),
    x,
    y,
    pressed,
    dir,
    touches: TOUCH_BITS.filter(([bit]) => b2 & bit).map(([, touch]) => touch),
    orientation: orientationOf(b4),
    tiltX,
    tiltY,
  };
}

// ---------------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------------
export const cmd = {
  action: (input: number, index: number, sub: number, specific: number): Bytes => [0x13, 0x00, input, index, sub, specific],
  /** 0x10 00 input: random action from a category */
  randomInput: (input: number): Bytes => [0x10, 0x00, input],
  antennaColor: (r: number, g: number, b: number): Bytes => [0x14, r, g, b],
  eyes: (on: boolean): Bytes => [0xcd, on ? 1 : 0],
  debugCycle: (): Bytes => [0xdb],
  mood: (type: MoodType, value: number): Bytes => [0x23, 0x01, type, value],
  keepAlive: (): Bytes => [0x20, 0x06],
  sensorStream: (on: boolean): Bytes => [0x20, on ? 0x0d : 0x0e],
  firmware: (): Bytes => [0xfe],
  cancel: (): Bytes => [0x46],
  setName: (name: number): Bytes => [0x21, name],
};

// ---------------------------------------------------------------------------
// Log helpers
// ---------------------------------------------------------------------------
const MESSAGES: Record<number, Text> = {
  0x01: ["режим имени", "naming mode"],
  0x04: ["режим приложения", "app mode"],
  0x06: ["ответ проигран", "response played"],
  0x07: ["речь", "speech playing"],
  0x0c: ["действие играет", "sequence playing"],
  0x0d: ["действие отменено", "sequence cancelled"],
  0x0e: ["действие завершено", "sequence ended"],
  0x0f: ["input вне диапазона", "input out of range"],
  0x10: ["index вне диапазона", "index out of range"],
  0x11: ["subindex вне диапазона", "subindex out of range"],
  0x12: ["specific вне диапазона", "specific out of range"],
  0x13: ["маска сна надета", "sleep mask on"],
  0x14: ["маска сна снята", "sleep mask off"],
  0x17: ["подсветка глаз вкл", "eyes on"],
  0x18: ["подсветка глаз выкл", "eyes off"],
};

const PACKETS: Record<number, Text> = {
  0x21: ["датчики", "sensors"],
  0x22: ["ImHere", "ImHere"],
  0x23: ["режим", "mode"],
  0x24: ["передача файла", "file transfer"],
  0x25: ["язык", "language"],
  0x72: ["слоты DLC", "DLC slots"],
  0xdc: ["DLC", "DLC"],
  0xfe: ["прошивка GeneralPlus", "GeneralPlus firmware"],
};

export function describePacket(data: Uint8Array): { ru: string; en: string } {
  const name = data[0] === 0x20 ? MESSAGES[data[1]] : PACKETS[data[0]];
  return name
    ? { ru: `${toHex(data)}  (${name[0]})`, en: `${toHex(data)}  (${name[1]})` }
    : { ru: toHex(data), en: toHex(data) };
}

export function toHex(bytes: ArrayLike<number>): string {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join(" ");
}

/** Accepts "13 00 4b", "0x13,0x00" or "13004b". */
export function parseHex(text: string): Bytes | null {
  const tokens = text.toLowerCase().replace(/0x/g, " ").split(/[^0-9a-f]+/).filter(Boolean);
  const bytes: Bytes = [];
  for (const token of tokens) {
    if (token.length % 2 !== 0) return null;
    for (let i = 0; i < token.length; i += 2) bytes.push(parseInt(token.slice(i, i + 2), 16));
  }
  return bytes.length > 0 && bytes.length <= MAX_PACKET ? bytes : null;
}

export function hexToRgb(hex: string): Rgb {
  const v = parseInt(hex.replace("#", ""), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

export function rgbToHex([r, g, b]: Rgb): string {
  return "#" + [r, g, b].map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");
}

export function hsv(h: number, s: number, v: number): Rgb {
  const hh = (((h % 1) + 1) % 1) * 6;
  const i = Math.floor(hh);
  const f = hh - i;
  const p = v * (1 - s);
  const q = v * (1 - s * f);
  const t = v * (1 - s * (1 - f));
  const [r, g, b] = [
    [v, t, p],
    [q, v, p],
    [p, v, t],
    [p, q, v],
    [t, p, v],
    [v, p, q],
  ][i % 6];
  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

export const mix = (a: Rgb, b: Rgb, k: number): Rgb => [
  Math.round(a[0] + (b[0] - a[0]) * k),
  Math.round(a[1] + (b[1] - a[1]) * k),
  Math.round(a[2] + (b[2] - a[2]) * k),
];

export const scale = (c: Rgb, k: number): Rgb => [Math.round(c[0] * k), Math.round(c[1] * k), Math.round(c[2] * k)];
