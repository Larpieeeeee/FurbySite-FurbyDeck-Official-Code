import type { LucideIcon } from "lucide-react";
import {
  Award, Blocks, Bluetooth, Brain, CalendarDays, Clock, Coins, Crown, Disc, Disc3, Droplets, Egg, FlaskConical, Gamepad2, GraduationCap,
  LayoutGrid, Library, Lightbulb, ListChecks, Medal, Megaphone, Mic, MousePointerClick, Music, Music2, Orbit, Piano, Radio, RefreshCw,
  Rocket, Search, ShieldCheck, Signal, Sparkles, Sun, Tent, Terminal, Timer, TrainFront, Trophy, Upload, Workflow, Worm, Wrench, Zap,
} from "lucide-react";
import type { Text } from "./i18n";
import { createStore } from "./store";

export interface Stats {
  connects: number;
  commands: number;
  gamesPlayed: number;
  gamesWon: number;
  playSeconds: number;
  dances: number;
  danceSeconds: number;
  washed: number;
  musicTracks: number;
  phrases: number;
  macros: number;
  notes: number;
  rules: number;
  searches: number;
  pings: number;
  demos: number;
  quests: number;
}

export interface ClickerSave {
  fluffs: number;
  total: number;
  clicks: number;
  levels: Record<string, number>;
  stardust: number;
  prestiges: number;
  lastSeen: number;
}

export interface Daily {
  date: string;
  counts: Record<string, number>;
  done: string[];
}

export interface ProgressData {
  stats: Stats;
  bests: Record<string, number>;
  played: string[];
  plays: Record<string, number>;
  lights: string[];
  unlocked: Record<string, number>;
  levels: Record<string, number>;
  clicker: ClickerSave | null;
  xp: number;
  xpDays: Record<string, number>;
  streak: number;
  lastDay: string;
  daily: Daily;
}

const today = () => new Date().toISOString().slice(0, 10);
const DEFAULT_STATS: Stats = {
  connects: 0, commands: 0, gamesPlayed: 0, gamesWon: 0, playSeconds: 0, dances: 0, danceSeconds: 0, washed: 0, musicTracks: 0,
  phrases: 0, macros: 0, notes: 0, rules: 0, searches: 0, pings: 0, demos: 0, quests: 0,
};
const DEFAULTS: ProgressData = {
  stats: DEFAULT_STATS, bests: {}, played: [], plays: {}, lights: [], unlocked: {}, levels: {}, clicker: null,
  xp: 0, xpDays: {}, streak: 0, lastDay: "", daily: { date: today(), counts: {}, done: [] },
};

export const progressStore = createStore<ProgressData>(DEFAULTS, "furby.progress.v1", (d, s) => ({
  ...d,
  ...(s as Partial<ProgressData>),
  stats: { ...d.stats, ...((s.stats as Partial<Stats>) ?? {}) },
  daily: (s.daily as Daily | undefined)?.date === today() ? (s.daily as Daily) : { date: today(), counts: {}, done: [] },
}));

// ---- XP, levels and ranks ----------------------------------------------------
export const levelOf = (xp: number) => Math.floor(Math.sqrt(xp / 60)) + 1;
export const xpFor = (level: number) => Math.pow(level - 1, 2) * 60;
export const RANKS: Array<{ min: number; name: Text; icon: LucideIcon }> = [
  { min: 1, name: ["Новичок", "Rookie"], icon: Egg },
  { min: 4, name: ["Дрессировщик", "Trainer"], icon: GraduationCap },
  { min: 8, name: ["Укротитель", "Tamer"], icon: Tent },
  { min: 13, name: ["Инженер", "Engineer"], icon: Wrench },
  { min: 19, name: ["Маэстро", "Maestro"], icon: Music },
  { min: 26, name: ["Легенда Ферби", "Furby Legend"], icon: Crown },
];
export const rankOf = (level: number) => [...RANKS].reverse().find((r) => level >= r.min) ?? RANKS[0];

// ---- daily quests ---------------------------------------------------------------
export type Counter = "games" | "cmd" | "talk" | "score" | "macro" | "shake" | "notes" | "light" | "dance";
export const QUESTS: Array<{ id: string; text: Text; goal: number; reward: number; counter: Counter }> = [
  { id: "games3", text: ["Сыграй 3 партии в любые игры", "Play 3 rounds of any games"], goal: 3, reward: 120, counter: "games" },
  { id: "cmd40", text: ["Отправь 40 команд Ферби", "Send 40 commands to Furby"], goal: 40, reward: 100, counter: "cmd" },
  { id: "talk15", text: ["Пусть Ферби скажет 15 реплик", "Let Furby say 15 phrases"], goal: 15, reward: 110, counter: "talk" },
  { id: "score800", text: ["Набери 800 очков в одной игре", "Score 800 in a single game"], goal: 800, reward: 160, counter: "score" },
  { id: "macro2", text: ["Запусти 2 макроса или сценария", "Run 2 macros or scenarios"], goal: 2, reward: 90, counter: "macro" },
  { id: "shake5", text: ["Поймай тряску 5 раз", "Catch a shake 5 times"], goal: 5, reward: 90, counter: "shake" },
  { id: "notes20", text: ["Сыграй 20 нот на пианино", "Play 20 notes on the piano"], goal: 20, reward: 100, counter: "notes" },
  { id: "light3", text: ["Включи 3 световых эффекта", "Turn on 3 light effects"], goal: 3, reward: 80, counter: "light" },
  { id: "dance2", text: ["Потанцуй с Ферби 2 минуты", "Dance with Furby for 2 minutes"], goal: 120, reward: 100, counter: "dance" },
];
export function todayQuests(date = today()) {
  const seed = [...date].reduce((n, c) => n + c.charCodeAt(0), 0);
  const pool = [...QUESTS];
  const out: typeof QUESTS = [];
  for (let i = 0; i < 3; i++) out.push(pool.splice((seed * (i + 7)) % pool.length, 1)[0]);
  return out;
}

// ---- achievements -----------------------------------------------------------------
export interface Achievement {
  id: string;
  icon: LucideIcon;
  name: Text;
  desc: Text;
  test: (p: ProgressData) => boolean;
}
const count = (p: ProgressData, prefix: string, min = 1) => Object.entries(p.levels).filter(([k, v]) => k.startsWith(prefix) && v >= min).length;

export const ACHIEVEMENTS: Achievement[] = [
  { id: "connect", icon: Bluetooth, name: ["Первый контакт", "First contact"], desc: ["Подключиться к Ферби", "Connect to Furby"], test: (p) => p.stats.connects >= 1 },
  { id: "connect10", icon: ShieldCheck, name: ["Старые друзья", "Old friends"], desc: ["10 подключений", "10 connections"], test: (p) => p.stats.connects >= 10 },
  { id: "demo", icon: FlaskConical, name: ["Тест-драйв", "Test drive"], desc: ["Попробовать демо-режим", "Try demo mode"], test: (p) => p.stats.demos >= 1 },
  { id: "cmd100", icon: Terminal, name: ["Командир", "Commander"], desc: ["100 команд", "100 commands"], test: (p) => p.stats.commands >= 100 },
  { id: "cmd1000", icon: Radio, name: ["Главнокомандующий", "Commander-in-chief"], desc: ["1000 команд", "1000 commands"], test: (p) => p.stats.commands >= 1000 },
  { id: "talk50", icon: Megaphone, name: ["Болтушка", "Chatterbox"], desc: ["Ферби сказал 50 реплик", "Furby said 50 phrases"], test: (p) => p.stats.phrases >= 50 },
  { id: "macro5", icon: Workflow, name: ["Режиссёр", "Director"], desc: ["Запустить 5 макросов", "Run 5 macros"], test: (p) => p.stats.macros >= 5 },
  { id: "piano50", icon: Piano, name: ["Пианист", "Pianist"], desc: ["Сыграть 50 нот", "Play 50 notes"], test: (p) => p.stats.notes >= 50 },
  { id: "rule", icon: Zap, name: ["Автоматизатор", "Automator"], desc: ["Сработало правило автоматики", "An automation rule fired"], test: (p) => p.stats.rules >= 1 },
  { id: "search10", icon: Search, name: ["Сыщик", "Detective"], desc: ["10 поисков по смыслу", "10 smart searches"], test: (p) => p.stats.searches >= 10 },
  { id: "ping", icon: Signal, name: ["Связист", "Signalman"], desc: ["Проверить связь пингом", "Run a ping test"], test: (p) => p.stats.pings >= 1 },
  { id: "game1", icon: Gamepad2, name: ["Игрок", "Player"], desc: ["Сыграть в любую игру", "Play any game"], test: (p) => p.stats.gamesPlayed >= 1 },
  { id: "games10", icon: LayoutGrid, name: ["Коллекционер", "Collector"], desc: ["10 разных игр", "10 different games"], test: (p) => p.played.length >= 10 },
  { id: "games30", icon: Library, name: ["Знаток игр", "Game expert"], desc: ["30 разных игр", "30 different games"], test: (p) => p.played.length >= 30 },
  { id: "win25", icon: Trophy, name: ["Победитель", "Winner"], desc: ["25 побед", "25 wins"], test: (p) => p.stats.gamesWon >= 25 },
  { id: "hour", icon: Clock, name: ["Целый час", "A whole hour"], desc: ["Час в играх", "An hour in games"], test: (p) => p.stats.playSeconds >= 3600 },
  { id: "dash1", icon: Zap, name: ["Первый прыжок", "First jump"], desc: ["Пройти уровень Furby Dash", "Beat a Furby Dash level"], test: (p) => count(p, "dash:", 100) >= 1 },
  { id: "dashAll", icon: Rocket, name: ["Мастер Dash", "Dash master"], desc: ["Все уровни Furby Dash", "Every Furby Dash level"], test: (p) => count(p, "dash:", 100) >= 12 },
  { id: "funk1", icon: Mic, name: ["Первая песня", "First song"], desc: ["Пройти песню в Furby Funk", "Clear a Furby Funk song"], test: (p) => count(p, "funkclear:") >= 1 },
  { id: "funkFc", icon: Medal, name: ["Без промаха", "Full combo"], desc: ["Песня без промахов", "A song without misses"], test: (p) => (p.levels.funkfc ?? 0) >= 1 },
  { id: "funkAll", icon: Disc3, name: ["Звезда сцены", "Stage star"], desc: ["Все 15 песен", "All 15 songs"], test: (p) => count(p, "funkclear:") >= 15 },
  { id: "wash1", icon: Droplets, name: ["Чистюля", "Neat freak"], desc: ["Вымыть животное", "Wash an animal"], test: (p) => p.stats.washed >= 1 },
  { id: "wash10", icon: Sparkles, name: ["Мойщик года", "Groomer of the year"], desc: ["Вымыть 10 животных", "Wash 10 animals"], test: (p) => p.stats.washed >= 10 },
  { id: "space", icon: Orbit, name: ["Пилот", "Pilot"], desc: ["5000 очков в космосе", "5000 in Space"], test: (p) => (p.bests.space ?? 0) >= 5000 },
  { id: "surf", icon: TrainFront, name: ["Бегун", "Runner"], desc: ["2000 в метро-раннере", "2000 in Subway Run"], test: (p) => (p.bests.surf ?? 0) >= 2000 },
  { id: "orders", icon: Megaphone, name: ["Исполнительный", "Obedient"], desc: ["5000 в «Приказах»", "5000 in Orders"], test: (p) => (p.bests.orders ?? 0) >= 5000 },
  { id: "click1k", icon: MousePointerClick, name: ["Кликер", "Clicker"], desc: ["1000 пушинок", "1000 fluffs"], test: (p) => (p.clicker?.total ?? 0) >= 1000 },
  { id: "click1m", icon: Coins, name: ["Пуховый миллионер", "Fluff millionaire"], desc: ["Миллион пушинок", "A million fluffs"], test: (p) => (p.clicker?.total ?? 0) >= 1e6 },
  { id: "prestige", icon: RefreshCw, name: ["Перерождение", "Rebirth"], desc: ["Переродиться в кликере", "Rebirth in the clicker"], test: (p) => (p.clicker?.prestiges ?? 0) >= 1 },
  { id: "dance10", icon: Music2, name: ["Танцор", "Dancer"], desc: ["Включить музыку 10 раз", "Play music 10 times"], test: (p) => p.stats.dances >= 10 },
  { id: "disco", icon: Disc, name: ["Дискотека", "Disco"], desc: ["10 минут танцев", "10 minutes of dancing"], test: (p) => p.stats.danceSeconds >= 600 },
  { id: "light10", icon: Lightbulb, name: ["Светлячок", "Firefly"], desc: ["10 режимов подсветки", "10 light modes"], test: (p) => p.lights.length >= 10 },
  { id: "light50", icon: Sun, name: ["Светомастер", "Light master"], desc: ["50 режимов подсветки", "50 light modes"], test: (p) => p.lights.length >= 50 },
  { id: "upload", icon: Upload, name: ["Своя музыка", "My music"], desc: ["Загрузить свой трек", "Upload your own track"], test: (p) => p.stats.musicTracks >= 1 },
  { id: "reaction", icon: Timer, name: ["Молния", "Lightning"], desc: ["Реакция быстрее 250 мс", "Reaction under 250 ms"], test: (p) => (p.bests.reaction ?? 0) >= 750 },
  { id: "snake", icon: Worm, name: ["Удав", "Boa"], desc: ["300 в «Змейке»", "300 in Snake"], test: (p) => (p.bests.snake ?? 0) >= 300 },
  { id: "tetris", icon: Blocks, name: ["Архитектор", "Architect"], desc: ["1000 в «Тетрисе»", "1000 in Tetris"], test: (p) => (p.bests.tetris ?? 0) >= 1000 },
  { id: "simon", icon: Brain, name: ["Слон", "Elephant memory"], desc: ["200 в «Повторяй за мной»", "200 in Simon Says"], test: (p) => (p.bests.simon ?? 0) >= 200 },
  { id: "lvl5", icon: Award, name: ["Опытный", "Experienced"], desc: ["Достичь 5 уровня", "Reach level 5"], test: (p) => levelOf(p.xp) >= 5 },
  { id: "lvl13", icon: Crown, name: ["Ветеран", "Veteran"], desc: ["Достичь 13 уровня", "Reach level 13"], test: (p) => levelOf(p.xp) >= 13 },
  { id: "streak3", icon: CalendarDays, name: ["Постоянство", "Consistency"], desc: ["3 дня подряд", "3 days in a row"], test: (p) => p.streak >= 3 },
  { id: "quests5", icon: ListChecks, name: ["Исполнитель", "Quest doer"], desc: ["5 заданий дня", "5 daily quests"], test: (p) => p.stats.quests >= 5 },
];

type Listener<T> = (v: T) => void;
const unlockL = new Set<Listener<Achievement>>();
const levelL = new Set<Listener<number>>();
const questL = new Set<Listener<(typeof QUESTS)[number]>>();
const sub = <T,>(set: Set<Listener<T>>) => (l: Listener<T>) => {
  set.add(l);
  return () => {
    set.delete(l);
  };
};
export const onUnlock = sub(unlockL);
export const onLevel = sub(levelL);
export const onQuest = sub(questL);

function check() {
  const p = progressStore.get();
  const fresh = ACHIEVEMENTS.filter((a) => !p.unlocked[a.id] && a.test(p));
  if (fresh.length === 0) return;
  const unlocked = { ...p.unlocked };
  for (const a of fresh) unlocked[a.id] = Date.now();
  progressStore.set({ unlocked });
  fresh.forEach((a) => {
    unlockL.forEach((l) => l(a));
    progress.addXp(50);
  });
}

export const progress = {
  addXp(n: number) {
    if (n <= 0) return;
    const p = progressStore.get();
    const d = today();
    const yest = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
    const before = levelOf(p.xp);
    const days = { ...p.xpDays, [d]: (p.xpDays[d] ?? 0) + n };
    for (const k of Object.keys(days).sort().slice(0, -30)) delete days[k];
    const streak = p.lastDay === d ? p.streak : p.lastDay === yest ? p.streak + 1 : 1;
    progressStore.set({ xp: p.xp + n, xpDays: days, streak, lastDay: d });
    const after = levelOf(p.xp + n);
    if (after > before) levelL.forEach((l) => l(after));
    check();
  },
  count(counter: Counter, n = 1) {
    const p = progressStore.get();
    const daily = p.daily.date === today() ? p.daily : { date: today(), counts: {}, done: [] };
    const prev = daily.counts[counter] ?? 0;
    const value = counter === "score" ? Math.max(prev, n) : prev + n;
    const next: Daily = { ...daily, counts: { ...daily.counts, [counter]: value } };
    const finished = todayQuests().filter((q) => q.counter === counter && value >= q.goal && !next.done.includes(q.id));
    next.done = [...next.done, ...finished.map((q) => q.id)];
    progressStore.set({ daily: next });
    for (const q of finished) {
      progressStore.set((s) => ({ stats: { ...s.stats, quests: s.stats.quests + 1 } }));
      questL.forEach((l) => l(q));
      progress.addXp(q.reward);
    }
  },
  bump(stat: keyof Stats, n = 1) {
    progressStore.set((p) => ({ stats: { ...p.stats, [stat]: p.stats[stat] + n } }));
    check();
  },
  recordGame(id: string, score: number, o: { win?: boolean; seconds?: number } = {}) {
    const p = progressStore.get();
    const prev = p.bests[id] ?? 0;
    const better = score > prev;
    progressStore.set({
      bests: better ? { ...p.bests, [id]: Math.round(score) } : p.bests,
      played: p.played.includes(id) ? p.played : [...p.played, id],
      plays: { ...p.plays, [id]: (p.plays[id] ?? 0) + 1 },
      stats: { ...p.stats, gamesPlayed: p.stats.gamesPlayed + 1, gamesWon: p.stats.gamesWon + (o.win ? 1 : 0), playSeconds: p.stats.playSeconds + Math.round(o.seconds ?? 0) },
    });
    progress.count("games");
    progress.count("score", Math.round(score));
    progress.addXp(10 + Math.min(50, Math.floor(score / 40)) + (o.win ? 20 : 0));
    check();
    return { best: Math.max(prev, score), isRecord: better && prev > 0 };
  },
  best: (id: string) => progressStore.get().bests[id] ?? 0,
  level: (key: string) => progressStore.get().levels[key] ?? 0,
  setLevel(key: string, value: number, mode: "max" | "set" = "max") {
    const levels = progressStore.get().levels;
    const next = mode === "max" ? Math.max(levels[key] ?? 0, value) : value;
    if (next === levels[key]) return;
    progressStore.set({ levels: { ...levels, [key]: next } });
    check();
  },
  markLight(id: string) {
    progress.count("light");
    const lights = progressStore.get().lights;
    if (lights.includes(id)) return;
    progressStore.set({ lights: [...lights, id] });
    check();
  },
  saveClicker(save: ClickerSave) {
    progressStore.set({ clicker: save });
    check();
  },
  reset() {
    progressStore.reset();
  },
};
