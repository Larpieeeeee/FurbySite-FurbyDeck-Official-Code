/** Built-in command list, downloadable full list (bluefluff actionlist.md) and smart search. */
import { Download, TriangleAlert } from "lucide-react";
import type { Text } from "../i18n";
import { tr } from "../i18n";
import { toast } from "../toast";
import { createStore } from "../store";

export type ActionRow = [input: number, index: number, sub: number, specific: number, text: string];
export interface ActionSection {
  range: string;
  title: Text;
  rows: ActionRow[];
}
export type BasicRow = [number, number, number, number, string, string];

export const ACTIONS_URL = "https://raw.githubusercontent.com/Jeija/bluefluff/master/doc/actionlist.md";
/** Measured size of actionlist.md: raw and gzip-compressed transfer */
export const RAW_BYTES = 63227;
export const GZIP_BYTES = 20320;
export const FULL_COUNT_APPROX = 1770;
const STORAGE_KEY = "furby.actions.v1";

export const BASIC: Array<{ title: Text; rows: BasicRow[] }> = [
  {
    title: ["Реакции", "Reactions"],
    rows: [
      [55, 2, 14, 0, "Хихиканье", "Giggle"],
      [2, 0, 0, 0, "Безумный смех", "Frantic laughter"],
      [2, 0, 0, 3, "Смех и пук", "Laugh and fart"],
      [1, 0, 0, 3, "«Как же хорошо!»", "“Feels so good!”"],
      [1, 0, 0, 5, "«Чешется!»", "“Itchy scratchy!”"],
      [1, 3, 0, 6, "«Люблю тебя!»", "“Kah luurve you!”"],
      [1, 3, 0, 10, "Мяуканье", "Meowing"],
      [1, 1, 0, 3, "Зевок вуки", "Wookie yawn"],
      [39, 1, 9, 0, "«Молодец!»", "“Good job!”"],
      [55, 2, 15, 0, "«У нас получилось!»", "“We did it!”"],
      [55, 2, 15, 3, "«Дай пять!»", "“High five!”"],
      [66, 0, 0, 1, "«Я готов!»", "“Kah ready to go!”"],
      [69, 0, 0, 0, "«Мой мозг растёт!»", "“Kah brain getting bigger!”"],
      [64, 0, 0, 3, "«Мне нравится!»", "“Kah love it!”"],
    ],
  },
  {
    title: ["Еда и тело", "Food and body"],
    rows: [
      [56, 3, 15, 1, "Тошнит", "Puke"],
      [56, 3, 1, 1, "«Вкуснятина»", "“Yummy in kah tummy”"],
      [56, 0, 2, 0, "«Я голоден»", "“Kah hungry”"],
      [56, 1, 1, 2, "Свист", "Whistle"],
      [56, 1, 3, 0, "«Холодно»", "“Too cold”"],
      [56, 1, 2, 0, "«Горячо!»", "“Too hot!”"],
      [56, 3, 14, 0, "Плевок", "Spit"],
    ],
  },
  {
    title: ["Сон и пробуждение", "Sleep and wake up"],
    rows: [
      [28, 0, 0, 1, "«Спокойной ночи»", "“Good night bestie”"],
      [28, 0, 0, 2, "«Тихий час!»", "“Power nap!”"],
      [27, 0, 0, 1, "Потягивается", "Stretches, “hi!”"],
      [29, 0, 0, 0, "«Привет, я вернулся!»", "“Hello! Kah back!”"],
      [74, 0, 0, 1, "Битбокс во сне", "Beatbox snore"],
      [74, 0, 2, 0, "«Хай-я!» во сне", "“Hai yah!” dream"],
      [74, 0, 3, 2, "Пиратская песня во сне", "Pirate song dream"],
      [74, 0, 5, 0, "«Мяу» во сне", "Meow dream"],
    ],
  },
  {
    title: ["Музыка и танцы", "Music and dance"],
    rows: [
      [18, 0, 0, 1, "Танец", "Dance"],
      [17, 1, 0, 4, "«Я Фёрби или танцор?»", "“Is kah furby or dancer?”"],
      [17, 3, 0, 1, "«Потанцуешь со мной?»", "“Wanna dance?”"],
      [9, 0, 1, 0, "«Трясись!»", "“Shakers gonna shake”"],
      [10, 0, 1, 4, "«Это происходит!»", "“This is happening!”"],
    ],
  },
  {
    title: ["Ноты", "Notes"],
    rows: [
      [70, 0, 0, 0, "До", "Do"],
      [70, 0, 0, 1, "Ре", "Re"],
      [70, 0, 0, 2, "Ми", "Mi"],
      [70, 0, 0, 3, "Фа", "Fa"],
      [70, 0, 0, 4, "Соль", "Sol"],
      [70, 0, 0, 5, "Ля", "La"],
      [70, 0, 0, 6, "Си", "Ti"],
      [70, 0, 0, 7, "До (верхняя)", "Do (high)"],
    ],
  },
];

/** Categories for "random action from input" (command 10 00 input) */
export const RANDOM_CATEGORIES: Array<{ input: number; name: Text }> = [
  { input: 1, name: ["Ласка", "Petting"] },
  { input: 2, name: ["Щекотка", "Tickling"] },
  { input: 7, name: ["Пуки и отрыжка", "Farts and burps"] },
  { input: 8, name: ["Болтовня", "Chatter"] },
  { input: 9, name: ["Движения", "Movement"] },
  { input: 12, name: ["Сонный", "Sleepy"] },
  { input: 14, name: ["Звуки еды", "Eating noises"] },
  { input: 16, name: ["Икота", "Hiccup"] },
  { input: 17, name: ["Пение", "Singing"] },
  { input: 18, name: ["Музыка", "Hearing music"] },
  { input: 19, name: ["Пуки", "Farts"] },
  { input: 20, name: ["Громкий звук", "Loud noise"] },
  { input: 21, name: ["Упал", "Dropped"] },
  { input: 22, name: ["Болеет", "Sick"] },
  { input: 23, name: ["Голоден", "Hungry"] },
  { input: 24, name: ["Скучает", "Bored"] },
  { input: 27, name: ["Просыпается", "Waking up"] },
  { input: 28, name: ["Засыпает", "Falling asleep"] },
  { input: 29, name: ["Вернулся", "Coming back"] },
  { input: 30, name: ["Игра с другом", "Playing with a friend"] },
  { input: 33, name: ["Имена", "Names"] },
];

const SECTION_RU: Record<string, string> = {
  "Generic reactions": "Общие реакции",
  "Farts poop and burps": "Пуки, какашки и отрыжка",
  "Conversation parts": "Фрагменты разговоров",
  "Movement related": "Движения",
  "Sleepy time": "Сонные реакции",
  "Eating noises": "Звуки еды",
  "Feed reactions": "Реакции на кормление",
  Hiccup: "Икота",
  Singing: "Пение",
  "Hearing music": "Слышит музыку",
  Farts: "Пуки",
  "Loud noise reactions": "Реакции на громкие звуки",
  "Furby Dropped": "Фёрби уронили",
  "Furby Sick": "Фёрби болеет",
  "Furby Hungry": "Фёрби голоден",
  "Furby Bored": "Фёрби скучает",
  "Eating reactions": "Реакции на еду",
  "Wakeup actions": "Пробуждение",
  "Sleep actions": "Засыпание",
  "Coming back from": "Возвращение",
  "Playing with friend": "Игра с другом",
  Reactions: "Реакции",
  "Misc reactions": "Разные реакции",
  "Speaking names": "Произнесение имён",
  "Connected to world app": "Подключение к приложению",
  "App name screen reactions": "Экран имени в приложении",
  "Out of app notifications": "Уведомления вне приложения",
  "World App": "Мир приложения",
  "How bout this one": "«Как насчёт этого?»",
  "Octave Notes": "Ноты (октава)",
  "Personality Dreams": "Сны личностей",
};

const expand = (cell: string): number[] => {
  const s = cell.trim();
  if (/^\d+$/.test(s)) return [Number(s)];
  const range = s.match(/^(\d+)\s*-\s*(\d+)$/);
  if (range) {
    const out: number[] = [];
    for (let n = Number(range[1]); n <= Number(range[2]); n++) out.push(n);
    return out;
  }
  return s.split(",").map((x) => x.trim()).filter((x) => /^\d+$/.test(x)).map(Number);
};

export function parseActionList(md: string): ActionSection[] {
  const sections: Array<ActionSection & { en: string }> = [];
  let cur: (ActionSection & { en: string }) | null = null;
  let inTable = false;
  for (const raw of md.split(/\r?\n/)) {
    const line = raw.trim();
    const h = line.match(/^##\s+(.*)$/);
    if (h) {
      const m = h[1].match(/^([\d-]+)\s*-\s*(.+)$/);
      const en = (m ? m[2] : h[1]).trim();
      cur = { range: m ? m[1] : "", en, title: [SECTION_RU[en] ?? en, en], rows: [] };
      sections.push(cur);
      inTable = false;
      continue;
    }
    if (!line.startsWith("|") || !cur) continue;
    let body = line.slice(1);
    if (body.endsWith("|")) body = body.slice(0, -1);
    const cells = body.split("|").map((c) => c.trim());
    if (cells[0] === "Input") {
      inTable = true;
      continue;
    }
    if (!inTable || cells.length < 5 || /^:?-+/.test(cells[0])) continue;
    const text = cells.slice(4).join("|").replace(/^"(.*)"$/, "$1").trim();
    const specifics = expand(cells[3]);
    for (const i of expand(cells[0]))
      for (const x of expand(cells[1]))
        for (const s of expand(cells[2]))
          for (const p of specifics.length ? specifics : [0]) {
            // Notes are really input 70 (checked on a real Furby); "How bout this one" moves to 71
            const input = cur.en === "Octave Notes" ? 70 : cur.en === "How bout this one" ? 71 : i;
            cur.rows.push([input, x, s, p, text]);
          }
  }
  return sections
    .filter((s) => s.rows.length > 0)
    .map(({ en, ...s }) => ({ ...s, range: en === "Octave Notes" ? "70" : en === "How bout this one" ? "71" : s.range }));
}

function loadFull(): ActionSection[] | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as ActionSection[]) : null;
  } catch {
    return null;
  }
}

export interface CatalogState {
  full: ActionSection[] | null;
  installing: boolean;
  phase: "idle" | "download" | "parse" | "save" | "done";
  received: number;
  total: number;
  error: string | null;
}

export const catalog = createStore<CatalogState>({ full: loadFull(), installing: false, phase: "idle", received: 0, total: RAW_BYTES, error: null });

export const fullCount = (full: ActionSection[] | null) => (full ? full.reduce((n, s) => n + s.rows.length, 0) : 0);

const SOURCES: Array<{ url: string; headers?: Record<string, string> }> = [
  { url: ACTIONS_URL },
  { url: "https://cdn.jsdelivr.net/gh/Jeija/bluefluff@master/doc/actionlist.md" },
  { url: "https://api.github.com/repos/Jeija/bluefluff/contents/doc/actionlist.md", headers: { Accept: "application/vnd.github.raw" } },
];

export async function installFull() {
  if (catalog.get().installing) return;
  catalog.set({ installing: true, phase: "download", received: 0, total: RAW_BYTES, error: null });
  let text: string | null = null;
  let lastErr = "";
  for (let i = 0; i < SOURCES.length && !text; i++) {
    const ac = new AbortController();
    const timeout = window.setTimeout(() => ac.abort(), 15000);
    try {
      const res = await fetch(SOURCES[i].url, { cache: "no-store", signal: ac.signal, headers: SOURCES[i].headers });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      if (res.body) {
        const header = Number(res.headers.get("content-length")) || 0;
        const reader = res.body.getReader();
        const chunks: Uint8Array[] = [];
        let received = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
          received += value.length;
          catalog.set({ received, total: Math.max(RAW_BYTES, header, received) });
        }
        const all = new Uint8Array(received);
        let offset = 0;
        for (const c of chunks) {
          all.set(c, offset);
          offset += c.length;
        }
        text = new TextDecoder().decode(all);
      } else {
        text = await res.text();
        catalog.set({ received: text.length, total: text.length });
      }
      if (!text || !text.includes("| Input |")) throw new Error(tr("список пришёл пустым", "the list came back empty"));
    } catch (e) {
      lastErr = e instanceof Error && e.name === "AbortError" ? tr("источник не ответил за 15 с", "the source timed out after 15 s") : e instanceof Error ? e.message : String(e);
      catalog.set({ received: 0, total: RAW_BYTES });
      text = null;
    } finally {
      window.clearTimeout(timeout);
    }
  }
  try {
    if (!text) throw new Error(lastErr || tr("ни один источник не ответил", "no source responded"));
    catalog.set({ phase: "parse" });
    await new Promise((r) => setTimeout(r, 30));
    const full = parseActionList(text);
    if (full.length === 0) throw new Error(tr("не удалось разобрать список", "could not parse the list"));
    catalog.set({ phase: "save" });
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(full));
    } catch {
      /* kept in memory only */
    }
    catalog.set({ full, installing: false, phase: "done", total: catalog.get().received || RAW_BYTES });
    toast(tr("Полный список установлен", "Full list installed"), `${fullCount(full)} ${tr("команд", "commands")}`, Download);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    catalog.set({ installing: false, phase: "idle", error: msg });
    toast(tr("Не удалось скачать список", "Couldn't download the list"), msg, TriangleAlert, "err");
  }
}

export function removeFull() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
  catalog.set({ full: null, phase: "idle", received: 0 });
}

/** Russian → English keywords, so searching in Russian finds English transcripts. */
const SYNONYMS: Record<string, string[]> = {
  смех: ["laugh", "giggle", "gefaw"], смея: ["laugh", "giggle"], хих: ["giggle"], пук: ["fart", "toot"], отрыж: ["burp"],
  пес: ["sing", "song"], пен: ["sing"], пое: ["sing"], танц: ["dance", "noh-lah"], сон: ["sleep", "snore", "yawn", "dream"],
  спат: ["sleep", "snore"], храп: ["snore"], зев: ["yawn"], еда: ["eat", "food", "nom", "hungry", "yum"], корм: ["feed", "eat", "food"],
  голод: ["hungry"], вкус: ["yum", "delicious", "tasty"], привет: ["hi", "hello", "hey"], пока: ["bye", "later"], кот: ["meow", "cat", "kitten"],
  кош: ["meow", "cat"], мяу: ["meow"], собак: ["dog", "puppy", "bark"], пират: ["pirate"], ниндз: ["ninja"], принцесс: ["princess"],
  любл: ["love", "luurve"], люб: ["love"], груст: ["sad", "cry"], плач: ["cry"], страш: ["scare", "scream", "afraid"], крик: ["scream"],
  музык: ["music", "tunes"], нот: ["do", "re", "mi", "fa", "sol"], имя: ["name"], тошн: ["puke", "vomit"], рвот: ["puke"], ико: ["hiccup"],
  холод: ["cold", "shiver"], жар: ["hot"], горяч: ["hot"], ура: ["yay", "woo", "hooray", "yippee"], друг: ["friend", "buddy", "besties"],
  подар: ["gift", "present"], фото: ["photo", "cheese", "pose"], игр: ["play", "game"], щекот: ["tickle"], глад: ["pet", "rub"],
  живот: ["belly", "tummy"], туалет: ["toilet", "poop"], какаш: ["poop"], душ: ["shower"], молод: ["good job", "great"], видео: ["video"],
  скуч: ["bored", "boring"], бол: ["sick", "ouch"], упал: ["fall", "careful", "ow"],
};

export function searchTerms(query: string): string[] {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  const out = new Set(words);
  for (const w of words) {
    for (const [key, values] of Object.entries(SYNONYMS)) {
      if (w.startsWith(key) || (w.length >= 3 && key.startsWith(w))) values.forEach((v) => out.add(v));
    }
  }
  return [...out];
}

export function rowMatches(text: string, nums: string, terms: string[], numeric: string): boolean {
  const lower = text.toLowerCase();
  if (terms.some((t) => lower.includes(t))) return true;
  return numeric !== "" && nums.includes(numeric);
}
