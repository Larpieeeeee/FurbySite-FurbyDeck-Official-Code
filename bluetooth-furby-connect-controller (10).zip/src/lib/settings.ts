import { createStore } from "./store";

export type Lang = "ru" | "en";
export type Theme = "system" | "light" | "dark";
export type TouchControls = "auto" | "always" | "never";
export type Density = "normal" | "compact";
export type AiProvider = "anthropic" | "openai";

export const ACCENTS: Array<{ id: string; hex: string; ru: string; en: string }> = [
  { id: "teal", hex: "#0f9b8e", ru: "Бирюза", en: "Teal" },
  { id: "blue", hex: "#2f7de1", ru: "Синий", en: "Blue" },
  { id: "indigo", hex: "#3b5bdb", ru: "Индиго", en: "Indigo" },
  { id: "violet", hex: "#7c4dff", ru: "Фиолет", en: "Violet" },
  { id: "pink", hex: "#e0479e", ru: "Розовый", en: "Pink" },
  { id: "amber", hex: "#cf8a12", ru: "Янтарь", en: "Amber" },
  { id: "green", hex: "#5b8c5a", ru: "Зелёный", en: "Green" },
  { id: "emerald", hex: "#12a37a", ru: "Изумруд", en: "Emerald" },
  { id: "ocean", hex: "#0a6c8f", ru: "Океан", en: "Ocean" },
];

export const SETTINGS_VERSION = 3;

export interface Settings {
  version: number;
  // appearance
  lang: Lang;
  /** true once the user picked a language manually — then the browser no longer overrides it */
  langPicked: boolean;
  theme: Theme;
  accent: string;
  density: Density;
  reduceMotion: boolean;
  grid: boolean;
  bottomInset: number;
  touchControls: TouchControls;
  // feedback
  toasts: boolean;
  sfx: boolean;
  sfxVolume: number;
  musicVolume: number;
  vibrate: boolean;
  voice: boolean;
  // misc
  warningAccepted: boolean;
  favorites: string[];
  playlistPause: number;
  verboseLog: boolean;
  autoscroll: boolean;
  // connection
  telemetryOnConnect: boolean;
  antennaOffOnDisconnect: boolean;
  connectEffect: string;
  restoreLight: boolean;
  // AI (optional, user's own key)
  aiProvider: AiProvider;
  aiKey: string;
  aiModel: string;
  // furby voice
  furbyLang: Lang;
  chatter: boolean;
  chatterEvery: number;
  chatterInGames: boolean;
  chatterSilly: boolean;
  quietUntil: number;
  talkOnEvents: boolean;
  gameTalk: boolean;
  // reactions & sensors
  reactions: boolean;
  reactTummy: boolean;
  reactHead: boolean;
  reactTongue: boolean;
  reactShake: boolean;
  reactFlip: boolean;
  touchHoldMs: number;
  gateWhileMoving: boolean;
  motionSensitivity: number;
  motionThreshold: number;
  motionCooldown: number;
  tiltSensitivity: number;
  tiltInvertX: boolean;
  invertX: boolean;
  invertY: boolean;
  rhythmLatency: number;
  octaveInput: number;
  // safety
  safeMode: boolean;
  confirmDanger: boolean;
  // light
  ledBrightness: number;
  ledGamma: boolean;
  ledFps: number;
  ledSpeed: number;
  gameLights: boolean;
  lightMode: string;
  /** deviceId (Web Bluetooth id) → antenna colour, remembered per toy */
  deviceColors: Record<string, number>;
  morseText: string;
  // music
  dance: boolean;
  danceEvery: number;
  musicLoop: boolean;
  beatLight: boolean;
}

/** Picks the language from the browser's language list; unsupported languages fall back to English. */
export const detectLang = (): Lang => {
  try {
    const list = navigator.languages?.length ? navigator.languages : [navigator.language];
    for (const l of list) if (l.toLowerCase().startsWith("ru")) return "ru";
    for (const l of list) if (l.toLowerCase().startsWith("en")) return "en";
    return "en";
  } catch {
    return "ru";
  }
};

export const DEFAULT_SETTINGS: Settings = {
  version: SETTINGS_VERSION,
  lang: detectLang(),
  langPicked: false,
  theme: "light",
  accent: "#0f9b8e",
  density: "normal",
  reduceMotion: false,
  grid: true,
  bottomInset: 72,
  touchControls: "auto",
  toasts: true,
  sfx: true,
  sfxVolume: 0.6,
  musicVolume: 0.7,
  vibrate: true,
  voice: false,
  warningAccepted: false,
  favorites: [],
  playlistPause: 1.8,
  verboseLog: false,
  autoscroll: true,
  telemetryOnConnect: true,
  antennaOffOnDisconnect: true,
  connectEffect: "",
  restoreLight: true,
  aiProvider: "anthropic",
  aiKey: "",
  aiModel: "",
  furbyLang: "ru",
  chatter: true,
  chatterEvery: 35,
  chatterInGames: false,
  chatterSilly: false,
  quietUntil: 0,
  talkOnEvents: true,
  gameTalk: true,
  reactions: true,
  reactTummy: true,
  reactHead: true,
  reactTongue: false,
  reactShake: true,
  reactFlip: true,
  touchHoldMs: 350,
  gateWhileMoving: true,
  motionSensitivity: 55,
  motionThreshold: 45,
  motionCooldown: 4,
  tiltSensitivity: 3,
  tiltInvertX: false,
  invertX: false,
  invertY: false,
  rhythmLatency: 0,
  octaveInput: 70,
  safeMode: true,
  confirmDanger: true,
  ledBrightness: 100,
  ledGamma: true,
  ledFps: 12,
  ledSpeed: 1,
  gameLights: true,
  lightMode: "",
  deviceColors: {},
  morseText: "FURBY",
  dance: true,
  danceEvery: 4,
  musicLoop: true,
  beatLight: false,
};

const mergeSettings = (d: Settings, s: Record<string, unknown>): Settings => {
  const m = { ...d, ...s } as Settings;
  const v = typeof s.version === "number" ? s.version : 1;
  if (v < SETTINGS_VERSION) {
    // v3: Bluetooth delay pinned to minimum, gentler shake detection
    m.rhythmLatency = 0;
    m.motionThreshold = d.motionThreshold;
    m.motionSensitivity = d.motionSensitivity;
  }
  if (m.langPicked !== true) m.lang = detectLang();
  m.version = SETTINGS_VERSION;
  return m;
};

export const settings = createStore<Settings>(DEFAULT_SETTINGS, "furby.settings.v2", mergeSettings);
export const useSettings = settings.use;
