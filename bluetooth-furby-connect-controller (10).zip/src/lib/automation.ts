/** Sensor rules (event → action) and delayed timers. */
import { furby, furby2, type FurbyController, type InputType } from "./furby/controller";
import { tr, type Text } from "./i18n";
import { progress } from "./progress";
import { createStore } from "./store";
import { toast } from "./toast";

export interface Rule {
  id: string;
  on: boolean;
  event: string;
  code: string;
  cooldown: number;
  fired: number;
}
export type TimerKind = "action" | "random" | "wake" | "sleep";
export interface Timer {
  id: string;
  at: number;
  kind: TimerKind;
  code?: string;
  input?: number;
}

export const RULE_EVENTS: Array<{ key: string; type: InputType; name: Text; group: Text }> = [
  { key: "shake", type: "shake", name: ["Ферби трясут", "Furby is shaken"], group: ["Движение", "Movement"] },
  { key: "shake.hard", type: "shakeHard", name: ["Сильная тряска", "Hard shake"], group: ["Движение", "Movement"] },
  { key: "still", type: "still", name: ["Долго неподвижен (30 с)", "Still for a long time (30 s)"], group: ["Движение", "Movement"] },
  { key: "upside-down", type: "flip", name: ["Перевёрнут вверх ногами", "Turned upside down"], group: ["Движение", "Movement"] },
  { key: "left-side", type: "lieL", name: ["Лежит на левом боку", "Lying on the left side"], group: ["Движение", "Movement"] },
  { key: "right-side", type: "lieR", name: ["Лежит на правом боку", "Lying on the right side"], group: ["Движение", "Movement"] },
  { key: "antenna.left", type: "antL", name: ["Антенна влево", "Antenna left"], group: ["Антенна", "Antenna"] },
  { key: "antenna.right", type: "antR", name: ["Антенна вправо", "Antenna right"], group: ["Антенна", "Antenna"] },
  { key: "antenna.forward", type: "antF", name: ["Антенна вперёд ↑", "Antenna forward ↑"], group: ["Антенна", "Antenna"] },
  { key: "antenna.back", type: "antB", name: ["Антенна назад ↓", "Antenna back ↓"], group: ["Антенна", "Antenna"] },
  { key: "antenna.down", type: "antPress", name: ["Антенна нажата", "Antenna pressed"], group: ["Антенна", "Antenna"] },
  { key: "head", type: "head", name: ["Гладят затылок", "Head is petted"], group: ["Датчики", "Sensors"] },
  { key: "tummy", type: "tummy", name: ["Щекочут живот", "Tummy is tickled"], group: ["Датчики", "Sensors"] },
  { key: "leftSide", type: "sideL", name: ["Трогают левый бок", "Left side touched"], group: ["Датчики", "Sensors"] },
  { key: "rightSide", type: "sideR", name: ["Трогают правый бок", "Right side touched"], group: ["Датчики", "Sensors"] },
  { key: "tail", type: "tail", name: ["Тянут хвост", "Tail pulled"], group: ["Датчики", "Sensors"] },
  { key: "tongue", type: "tongue", name: ["Нажат язык", "Tongue pressed"], group: ["Датчики", "Sensors"] },
];

const uid = () => Math.random().toString(36).slice(2, 10);
const rule = (event: string, code: string, cooldown: number): Rule => ({ id: uid(), on: false, event, code, cooldown, fired: 0 });
export const defaultRules = (): Rule[] => [
  rule("shake", "9/0/0/3", 6),
  rule("shake.hard", "9/1/0/2", 12),
  rule("tummy", "55/2/14/0", 6),
  rule("tail", "3/1/0/1", 8),
  rule("upside-down", "10/0/1/0", 10),
  rule("antenna.down", "40/0/0/0", 8),
  rule("still", "8/0/0/0", 60),
];

export const automation = createStore<{ rules: Rule[]; timers: Timer[] }>({ rules: defaultRules(), timers: [] }, "furby.automation.v1");

export const TIMER_PRESETS: Array<{ name: Text; kind: TimerKind; code?: string; input?: number; minutes: number }> = [
  { name: ["Покормить", "Feed"], kind: "action", code: "56/3/0/0", minutes: 15 },
  { name: ["Разбудить", "Wake up"], kind: "wake", minutes: 5 },
  { name: ["Уложить спать", "Put to sleep"], kind: "sleep", minutes: 30 },
  { name: ["Развлечь репликой", "Entertain with a phrase"], kind: "random", input: 8, minutes: 10 },
];

function runCode(code: string, on: FurbyController = furby) {
  const [i, x, s, p] = code.split("/").map(Number);
  on.action(i, x, s, p, true);
}

export function runTimer(t: Pick<Timer, "kind" | "code" | "input">) {
  if (t.kind === "wake") furby.wake();
  else if (t.kind === "sleep") furby.sleep();
  else if (t.kind === "random") furby.randomInput(t.input ?? 8, true);
  else if (t.code) runCode(t.code);
}

export const rules = {
  add: () => automation.set((s) => ({ rules: [...s.rules, rule("tongue", "1/3/0/6", 6)] })),
  update: (id: string, patch: Partial<Rule>) => automation.set((s) => ({ rules: s.rules.map((r) => (r.id === id ? { ...r, ...patch } : r)) })),
  remove: (id: string) => automation.set((s) => ({ rules: s.rules.filter((r) => r.id !== id) })),
  reset: () => automation.set({ rules: defaultRules() }),
  test: (r: Rule) => runCode(r.code),
  addTimer: (kind: TimerKind, minutes: number, code?: string, input?: number) =>
    automation.set((s) => ({ timers: [...s.timers, { id: uid(), at: Date.now() + minutes * 60000, kind, code, input }] })),
  removeTimer: (id: string) => automation.set((s) => ({ timers: s.timers.filter((t) => t.id !== id) })),
};

let started = false;
const lastFire: Record<string, number> = {};

export function startAutomation() {
  if (started) return;
  started = true;
  for (const toy of [furby, furby2]) {
    toy.onInput((ev) => {
      const st = toy.getState();
      if (st.status !== "ready" || st.inGame || st.scene) return;
      const now = performance.now();
      for (const r of automation.get().rules) {
        if (!r.on) continue;
        const def = RULE_EVENTS.find((e) => e.key === r.event);
        if (!def || def.type !== ev.type) continue;
        if (now - (lastFire[r.id] ?? -1e9) < r.cooldown * 1000) continue;
        lastFire[r.id] = now;
        runCode(r.code, toy);
        rules.update(r.id, { fired: r.fired + 1 });
        toy.ruleFired();
        progress.bump("rules");
      }
    });
  }
  window.setInterval(() => {
    const due = automation.get().timers.filter((t) => t.at <= Date.now());
    if (!due.length || !furby.connected) return;
    for (const t of due) {
      runTimer(t);
      rules.removeTimer(t.id);
    }
    toast(tr("Таймер сработал", "Timer fired"));
  }, 1000);
}
