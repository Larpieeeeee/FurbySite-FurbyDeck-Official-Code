/** Smart search: intents + Russian stemming + typo tolerance, offline. Optional AI mode with the user's own key. */
import { CATEGORIES, LIBRARY } from "./actions/library";
import { catalog } from "./actions/catalog";
import type { Text } from "./i18n";
import { settings } from "./settings";

export type Code = [number, number, number, number];
export interface Hit {
  code: Code;
  ru: string;
  en: string;
  score: number;
}

const norm = (s: string) => s.toLowerCase().replace(/ё/g, "е").replace(/[^a-zа-я0-9/\s]/g, " ");
const ENDINGS = ["иями", "ями", "ами", "ого", "его", "ому", "ему", "ыми", "ими", "ться", "тся", "ает", "яет", "ует", "ают", "яют", "уют", "ала", "ила", "ела", "али", "или", "ели", "ах", "ях", "ов", "ев", "ей", "ам", "ям", "ом", "ем", "ой", "ий", "ый", "ая", "яя", "ое", "ее", "ую", "юю", "ет", "ит", "ут", "ют", "ат", "ят", "ть", "сь", "ся", "а", "я", "о", "е", "ы", "и", "у", "ю", "ь", "й"];
export function stem(w: string) {
  if (w.length <= 4 || !/[а-я]/.test(w)) return w;
  for (const e of ENDINGS) if (w.length - e.length >= 3 && w.endsWith(e)) return w.slice(0, -e.length);
  return w;
}
function lev(a: string, b: string): number {
  if (Math.abs(a.length - b.length) > 2) return 9;
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
const close = (s: string, key: string) => key.startsWith(s) || (s.length >= 4 && s.startsWith(key)) || (s.length >= 5 && key.length >= 5 && lev(s, key.slice(0, s.length)) <= 1);

interface Intent {
  id: string;
  name: Text;
  keys: string[];
  cats: number[];
  words: string[];
}
export const INTENTS: Intent[] = [
  { id: "sleep", name: ["сон и колыбельные", "sleep and lullabies"], keys: ["сон", "спат", "сп", "усн", "засып", "колыбел", "зев", "дрем", "отбо", "ноч", "укач", "sleep", "nap", "yawn", "lullab", "night", "bed", "tired"], cats: [12, 13, 6, 74], words: ["yawn", "sleep", "snore", "dream", "lullaby"] },
  { id: "fun", name: ["смех и щекотка", "laughter and tickling"], keys: ["весел", "смеш", "смех", "смея", "хихик", "ржа", "прикол", "щекот", "шут", "fun", "laugh", "giggl", "tickl", "joke"], cats: [2, 3, 4, 55], words: ["laugh", "giggle", "tickle", "hee"] },
  { id: "love", name: ["нежности и объятия", "love and hugs"], keys: ["люб", "нежн", "обним", "обнят", "сердеч", "поцел", "мил", "ласк", "гладит", "love", "hug", "heart", "kiss", "cute", "pet"], cats: [5, 45, 1], words: ["love", "hug", "kiss", "heart", "pet"] },
  { id: "food", name: ["еда и голод", "food and hunger"], keys: ["ест", "еда", "ед", "голод", "корм", "кушат", "чавк", "вкусн", "обед", "hungr", "food", "eat", "feed", "yum", "snack"], cats: [14, 15, 23, 26, 56], words: ["eat", "yum", "nom", "hungry", "munch", "delicious"] },
  { id: "sing", name: ["пение и ноты", "singing and notes"], keys: ["пе", "песн", "пою", "поет", "музык", "нот", "мелод", "sing", "song", "music", "note", "melod"], cats: [17, 18, 70], words: ["sing", "song", "la la", "music"] },
  { id: "dance", name: ["танцы и вечеринка", "dancing and party"], keys: ["танц", "пляс", "движ", "вечерин", "туса", "dance", "party", "groove"], cats: [9, 18, 66], words: ["dance", "party", "shake"] },
  { id: "fart", name: ["пуки и отрыжка", "farts and burps"], keys: ["пук", "перд", "отрыж", "газ", "вонь", "fart", "burp", "toot", "gas"], cats: [7, 19], words: ["fart", "burp", "toot"] },
  { id: "hello", name: ["приветствия", "greetings"], keys: ["привет", "здравств", "здоров", "поздоров", "хай", "hello", "hi", "hey", "greet"], cats: [40, 29, 43], words: ["hey", "hello", "hi "] },
  { id: "wow", name: ["удивление и восторг", "surprise and joy"], keys: ["удив", "восторг", "вау", "ого", "радост", "ура", "побед", "surpris", "wow", "yay", "joy", "win", "victor"], cats: [53, 41, 60], words: ["wow", "yay", "whoa", "omg", "did it"] },
  { id: "sad", name: ["грусть и испуг", "sadness and fear"], keys: ["груст", "плач", "страш", "испуг", "бои", "уронил", "sad", "cry", "scar", "afraid", "fear", "drop"], cats: [20, 21, 22, 10], words: ["sad", "cry", "scared", "ouch", "whoa"] },
  { id: "sick", name: ["тошнота и болезнь", "sickness"], keys: ["бол", "тошн", "рвот", "заболе", "sick", "puke", "vomit", "ill"], cats: [22, 56], words: ["puke", "sick", "vomit", "gross"] },
  { id: "shake", name: ["тряска", "shaking"], keys: ["тряс", "трях", "кача", "shake", "wobbl"], cats: [9, 11], words: ["shake", "dizzy", "jelly"] },
  { id: "dream", name: ["сны характеров", "personality dreams"], keys: ["сны", "мечт", "характер", "пират", "ниндз", "принцесс", "кошк", "диджей", "dream", "pirate", "ninja", "princess", "cat"], cats: [74], words: ["dream", "pirate", "ninja", "meow"] },
];

interface Entry {
  code: Code;
  ru: string;
  en: string;
}
function pool(): Entry[] {
  const seen = new Set<string>();
  const out: Entry[] = [];
  for (const r of LIBRARY) {
    seen.add(r.slice(0, 4).join("/"));
    out.push({ code: [r[0], r[1], r[2], r[3]], ru: r[4], en: r[5] });
  }
  for (const s of catalog.get().full ?? []) {
    for (const r of s.rows) {
      const k = r.slice(0, 4).join("/");
      if (seen.has(k)) continue;
      seen.add(k);
      out.push({ code: [r[0], r[1], r[2], r[3]], ru: "", en: r[4] });
    }
  }
  return out;
}

export function smartSearch(query: string): { hits: Hit[]; intents: Intent[] } {
  const q = norm(query).trim();
  if (!q) return { hits: [], intents: [] };
  const entries = pool();
  const nums = q.match(/^\d+(?:[\s/.,-]+\d+){0,3}$/) ? q.split(/[\s/.,-]+/).map(Number) : null;
  if (nums) {
    const hits = entries.filter((e) => nums.every((n, i) => e.code[i] === n)).map((e) => ({ ...e, score: 100 }));
    return { hits: hits.slice(0, 60), intents: [] };
  }
  const tokens = q.split(/\s+/).filter((w) => w.length > 1);
  const stems = tokens.map(stem);
  const intents = INTENTS.filter((it) => stems.some((s) => it.keys.some((k) => close(s, k))));
  const hits: Hit[] = [];
  for (const e of entries) {
    let score = 0;
    const ru = norm(e.ru);
    const en = norm(e.en);
    const cat = CATEGORIES[e.code[0]];
    const catText = cat ? norm(`${cat[0]} ${cat[1]}`) : "";
    for (const it of intents) {
      if (it.cats.includes(e.code[0])) score += 6;
      if (it.words.some((w) => en.includes(w))) score += 3;
    }
    for (const s of stems) {
      if (s.length < 2) continue;
      if (ru.includes(s)) score += 5;
      else if (s.length >= 5 && ru.split(" ").some((w) => w.length >= 4 && lev(stem(w), s) <= 1)) score += 3;
      if (s.length >= 3 && en.includes(s)) score += 3;
      if (s.length >= 3 && catText.includes(s)) score += 2;
    }
    if (score > 0) hits.push({ ...e, score });
  }
  hits.sort((a, b) => b.score - a.score);
  return { hits: hits.slice(0, 40), intents };
}

// ---- optional AI (user's own key, called straight from the browser) ----------------
export async function askAI(system: string, user: string): Promise<string> {
  const s = settings.get();
  if (!s.aiKey) throw new Error("no key");
  if (s.aiProvider === "openai") {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${s.aiKey}` },
      body: JSON.stringify({ model: s.aiModel || "gpt-4o-mini", temperature: 0.2, messages: [{ role: "system", content: system }, { role: "user", content: user }] }),
    });
    if (!res.ok) throw new Error(`OpenAI ${res.status}: ${(await res.text()).slice(0, 160)}`);
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? "";
  }
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": s.aiKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
    body: JSON.stringify({ model: s.aiModel || "claude-haiku-4-5", max_tokens: 900, system, messages: [{ role: "user", content: user }] }),
  });
  if (!res.ok) throw new Error(`Anthropic ${res.status}: ${(await res.text()).slice(0, 160)}`);
  const data = await res.json();
  return data.content?.map((c: { text?: string }) => c.text ?? "").join("") ?? "";
}

export async function aiSearch(query: string): Promise<Hit[]> {
  const entries = pool();
  const list = LIBRARY.map((r) => `${r[0]}/${r[1]}/${r[2]}/${r[3]} ${r[4]} | ${r[5]}`).join("\n");
  const text = await askAI(
    "You pick Furby Connect actions. Answer ONLY with a JSON array of up to 12 codes like [\"55/2/14/0\"], best first.",
    `Request: ${query}\n\nAvailable actions (code name | phrase):\n${list}`,
  );
  const codes: string[] = JSON.parse(text.match(/\[[\s\S]*\]/)?.[0] ?? "[]");
  return codes
    .map((c) => entries.find((e) => e.code.join("/") === String(c).trim()))
    .filter((e): e is Entry => !!e)
    .map((e, i) => ({ ...e, score: 100 - i }));
}
