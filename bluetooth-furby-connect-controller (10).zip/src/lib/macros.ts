/** Macro studio: steps of actions, light, mood and pauses. Plus the Furby piano (input 70). */
import { audio, mtof, tone } from "./audio/synth";
import { actionName, broadcast, furby } from "./furby/controller";
import { LIGHT_MODES, setMoodValue, setStaticColor, startLight, stopLight } from "./furby/lighting";
import { MOODS, hexToRgb, type MoodType } from "./furby/protocol";
import { pick, tr, type Text } from "./i18n";
import { progress } from "./progress";
import { settings } from "./settings";
import { createStore } from "./store";

export type StepKind = "action" | "random" | "color" | "effect" | "mood" | "wake" | "sleep" | "lcdOff" | "debug" | "lightOff" | "note";
export interface MacroStep {
  id: string;
  kind: StepKind;
  wait: number;
  code?: [number, number, number, number];
  input?: number;
  hex?: string;
  effect?: string;
  mood?: MoodType;
  value?: number;
  note?: number;
}
export interface Macro {
  id: string;
  name: string;
  nameEn?: string;
  loop: boolean;
  steps: MacroStep[];
}

export const NOTE_NAMES: Text[] = [["До", "Do"], ["Ре", "Re"], ["Ми", "Mi"], ["Фа", "Fa"], ["Соль", "Sol"], ["Ля", "La"], ["Си", "Ti"], ["До↑", "Do↑"]];
export const NOTE_KEYS = ["A", "S", "D", "F", "G", "H", "J", "K"];
const NOTE_MIDI = [60, 62, 64, 65, 67, 69, 71, 72];
export const MELODIES: Array<{ name: Text; notes: number[] }> = [
  { name: ["Ода к радости", "Ode to Joy"], notes: [2, 2, 3, 4, 4, 3, 2, 1, 0, 0, 1, 2, 2, 1, 1] },
  { name: ["Twinkle", "Twinkle"], notes: [0, 0, 4, 4, 5, 5, 4, 3, 3, 2, 2, 1, 1, 0] },
  { name: ["Имперский марш", "Imperial March"], notes: [4, 4, 4, 2, 6, 4, 2, 6, 4] },
  { name: ["Кукарача", "La Cucaracha"], notes: [0, 0, 0, 3, 5, 0, 0, 0, 3, 5] },
  { name: ["Гамма", "Scale"], notes: [0, 1, 2, 3, 4, 5, 6, 7] },
];

const uid = () => Math.random().toString(36).slice(2, 10);
export const mk = {
  action: (code: [number, number, number, number], wait = 2400): MacroStep => ({ id: uid(), kind: "action", code, wait }),
  random: (input: number, wait = 2400): MacroStep => ({ id: uid(), kind: "random", input, wait }),
  color: (hex: string, wait = 500): MacroStep => ({ id: uid(), kind: "color", hex, wait }),
  effect: (effect: string, wait = 800): MacroStep => ({ id: uid(), kind: "effect", effect, wait }),
  mood: (mood: MoodType, value: number, wait = 250): MacroStep => ({ id: uid(), kind: "mood", mood, value, wait }),
  note: (note: number, wait = 950): MacroStep => ({ id: uid(), kind: "note", note, wait }),
  simple: (kind: StepKind, wait = 1500): MacroStep => ({ id: uid(), kind, wait }),
};

const PRESETS = (): Macro[] => [
  { id: "preset-morning", name: "Доброе утро", nameEn: "Good morning", loop: false, steps: [mk.simple("wake", 2200), mk.color("#cf8a12"), mk.action([40, 0, 0, 0]), mk.action([40, 0, 1, 4], 2200), mk.mood(2, 10), mk.mood(0, 80), mk.random(8, 1800)] },
  { id: "preset-party", name: "Вечеринка", nameEn: "Party", loop: false, steps: [mk.effect("jump-rainbow"), mk.action([66, 0, 0, 2], 2600), mk.action([9, 3, 0, 3], 2600), mk.effect("smooth-neon", 600), mk.note(0, 900), mk.note(2, 900), mk.note(4, 1200), mk.action([41, 0, 1, 1], 2200), mk.simple("lightOff", 200)] },
  { id: "preset-calm", name: "Успокоить и уложить", nameEn: "Calm down and sleep", loop: false, steps: [mk.mood(0, 15), mk.mood(1, 0), mk.mood(2, 75), mk.effect("breathe-gold", 900), mk.action([12, 2, 1, 1], 3200), mk.action([12, 2, 0, 2], 2600), mk.simple("sleep", 1500), mk.color("#000000", 200)] },
  { id: "preset-scale", name: "Гамма до-до", nameEn: "Do-do scale", loop: false, steps: [0, 1, 2, 3, 4, 5, 6, 7].map((n) => mk.note(n)) },
  { id: "preset-spa", name: "Спа-сеанс", nameEn: "Spa session", loop: false, steps: [mk.effect("wave-ocean", 700), mk.mood(4, 100), mk.mood(1, 0), mk.action([1, 3, 0, 8], 2600), mk.action([3, 3, 0, 13]), mk.action([5, 3, 0, 4], 2600), mk.effect("breathe-ocean", 3000)] },
];

export const macros = createStore<{ list: Macro[]; selected: string }>({ list: PRESETS(), selected: "preset-morning" }, "furby.macros.v1");
export const runner = createStore<{ running: string | null; step: number }>({ running: null, step: -1 });

export const macroName = (m: Macro) => (settings.get().lang === "en" && m.nameEn ? m.nameEn : m.name);
export const macroDuration = (m: Macro) => m.steps.reduce((n, s) => n + s.wait, 0) / 1000;

export function stepLabel(s: MacroStep): string {
  switch (s.kind) {
    case "action":
      return s.code ? actionName(...s.code) : "?";
    case "random":
      return `${tr("Случайная реплика", "Random phrase")} · input ${s.input}`;
    case "color":
      return `${tr("Антенна", "Antenna")} ${s.hex}`;
    case "effect": {
      const m = LIGHT_MODES.find((x) => x.id === s.effect);
      return `${tr("Свет", "Light")}: ${m ? pick(m.name) : s.effect}`;
    }
    case "mood":
      return `${pick(MOODS[s.mood ?? 0].label)} → ${s.value}`;
    case "note":
      return `${tr("Нота", "Note")} ${pick(NOTE_NAMES[s.note ?? 0])}`;
    case "wake":
      return tr("Разбудить", "Wake up");
    case "sleep":
      return tr("Уложить спать", "Put to sleep");
    case "lcdOff":
      return tr("Глаза выкл", "Eyes off");
    case "debug":
      return tr("Дебаг-экран", "Debug screen");
    case "lightOff":
      return tr("Свет выкл", "Light off");
  }
}

export const macroOps = {
  select: (id: string) => macros.set({ selected: id }),
  create() {
    const m: Macro = { id: uid(), name: tr("Новый макрос", "New macro"), loop: false, steps: [] };
    macros.set((s) => ({ list: [...s.list, m], selected: m.id }));
  },
  duplicate(id: string) {
    const src = macros.get().list.find((m) => m.id === id);
    if (!src) return;
    const m: Macro = { ...src, id: uid(), name: `${macroName(src)} 2`, nameEn: undefined, steps: src.steps.map((s) => ({ ...s, id: uid() })) };
    macros.set((s) => ({ list: [...s.list, m], selected: m.id }));
  },
  remove(id: string) {
    macros.set((s) => {
      const list = s.list.filter((m) => m.id !== id);
      return { list, selected: list[0]?.id ?? "" };
    });
  },
  update: (id: string, patch: Partial<Macro>) => macros.set((s) => ({ list: s.list.map((m) => (m.id === id ? { ...m, ...patch } : m)) })),
  addStep: (id: string, step: MacroStep) => macros.set((s) => ({ list: s.list.map((m) => (m.id === id ? { ...m, steps: [...m.steps, step] } : m)) })),
  updateStep: (id: string, sid: string, patch: Partial<MacroStep>) =>
    macros.set((s) => ({ list: s.list.map((m) => (m.id === id ? { ...m, steps: m.steps.map((x) => (x.id === sid ? { ...x, ...patch } : x)) } : m)) })),
  removeStep: (id: string, sid: string) => macros.set((s) => ({ list: s.list.map((m) => (m.id === id ? { ...m, steps: m.steps.filter((x) => x.id !== sid) } : m)) })),
  moveStep(id: string, sid: string, dir: -1 | 1) {
    macros.set((s) => ({
      list: s.list.map((m) => {
        if (m.id !== id) return m;
        const steps = [...m.steps];
        const i = steps.findIndex((x) => x.id === sid);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= steps.length) return m;
        [steps[i], steps[j]] = [steps[j], steps[i]];
        return { ...m, steps };
      }),
    }));
  },
  restorePresets: () => macros.set((s) => ({ list: [...PRESETS(), ...s.list.filter((m) => !m.id.startsWith("preset-"))] })),
};

export function playNote(n: number, sendToFurby = true) {
  const { ac, sfx } = audio();
  tone(ac.currentTime + 0.01, mtof(NOTE_MIDI[n] ?? 60), 0.35, sfx, { type: "triangle", gain: 0.18 });
  if (sendToFurby) broadcast((f) => f.action(settings.get().octaveInput, 0, 0, n, true));
  progress.count("notes");
  progress.bump("notes");
}

function execStep(s: MacroStep) {
  switch (s.kind) {
    case "action":
      if (s.code) broadcast((f) => f.action(s.code![0], s.code![1], s.code![2], s.code![3], true));
      break;
    case "random":
      broadcast((f) => f.randomInput(s.input ?? 8, true));
      break;
    case "color":
      setStaticColor(hexToRgb(s.hex ?? "#000000"));
      break;
    case "effect":
      if (s.effect) startLight(s.effect);
      break;
    case "mood":
      setMoodValue(s.mood ?? 0, s.value ?? 50);
      break;
    case "note":
      playNote(s.note ?? 0);
      break;
    case "wake":
      broadcast((f) => f.wake());
      break;
    case "sleep":
      broadcast((f) => f.sleep());
      break;
    case "lcdOff":
      broadcast((f) => f.setEyes(false));
      break;
    case "debug":
      furby.debugNext(7);
      break;
    case "lightOff":
      stopLight();
      break;
  }
}

let token = 0;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function runMacro(m: Macro) {
  const my = ++token;
  runner.set({ running: m.id, step: 0 });
  broadcast((f) => f.setScene(m.id));
  progress.bump("macros");
  progress.count("macro");
  progress.addXp(5);
  try {
    do {
      for (let i = 0; i < m.steps.length; i++) {
        if (my !== token || furby.getState().inGame) return;
        runner.set({ step: i });
        execStep(m.steps[i]);
        await sleep(Math.max(50, m.steps[i].wait));
      }
    } while (m.loop && my === token && m.steps.length > 0);
  } finally {
    if (my === token) {
      runner.set({ running: null, step: -1 });
      broadcast((f) => f.setScene(null));
    }
  }
}

export function stopMacro() {
  token++;
  runner.set({ running: null, step: -1 });
  broadcast((f) => f.setScene(null));
}

export async function playMelody(notes: number[]) {
  const my = ++token;
  runner.set({ running: "melody", step: 0 });
  for (let i = 0; i < notes.length; i++) {
    if (my !== token) return;
    runner.set({ step: i });
    playNote(notes[i]);
    await sleep(820);
  }
  if (my === token) runner.set({ running: null, step: -1 });
}
