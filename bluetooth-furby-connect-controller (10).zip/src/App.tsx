import { useEffect, useState } from "react";
import {
  Activity, BookOpen, Bluetooth, CircleHelp, ExternalLink, FlaskConical, Gamepad2, Joystick, Languages, Lightbulb, Monitor, Music, ScrollText,
  Search, Settings2, ShieldAlert, Terminal, Trophy, Unplug, Workflow, Wrench, Zap, TriangleAlert,
} from "lucide-react";
import { HandshakeModal, Toasts, WarningModal } from "@/components/Modals";
import { Sidebar } from "@/components/Sidebar";
import { AutomationTab, StudioTab } from "@/components/tabs/Automate";
import { ControlTab } from "@/components/tabs/Control";
import { GamesTab } from "@/components/tabs/Games";
import { CommandsTab, SearchTab } from "@/components/tabs/Library";
import { LightTab, MusicTab } from "@/components/tabs/Media";
import { AboutTab, ProgressTab, SettingsTab } from "@/components/tabs/Me";
import { DlcCard } from "@/components/tabs/Dlc";
import { DiagnosticsTab } from "@/components/tabs/Diagnostics";
import { DebugTab, JournalTab, MonitorTab } from "@/components/tabs/System";
import { Button, Chip, goTab, nav, type TabId } from "@/components/ui";
import { ACTIONS_URL } from "@/lib/actions/catalog";
import { CONNECT_STEPS, furby, furby2 } from "@/lib/furby/controller";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { detectLang, settings, useSettings } from "@/lib/settings";
import { cn } from "@/utils/cn";

const TABS: Array<{ id: TabId; icon: typeof Joystick; name: Text }> = [
  { id: "control", icon: Joystick, name: ["Пульт", "Remote"] },
  { id: "games", icon: Gamepad2, name: ["Игры", "Games"] },
  { id: "search", icon: Search, name: ["Поиск", "Search"] },
  { id: "light", icon: Lightbulb, name: ["Свет", "Lights"] },
  { id: "music", icon: Music, name: ["Музыка", "Music"] },
  { id: "commands", icon: BookOpen, name: ["Команды", "Commands"] },
  { id: "studio", icon: Workflow, name: ["Студия", "Studio"] },
  { id: "auto", icon: Zap, name: ["Автоматика", "Automation"] },
  { id: "progress", icon: Trophy, name: ["Прогресс", "Progress"] },
  { id: "debug", icon: Terminal, name: ["Дебаг", "Debug"] },
  { id: "diag", icon: Activity, name: ["Диагностика", "Diagnostics"] },
  { id: "monitor", icon: Monitor, name: ["Монитор", "Monitor"] },
  { id: "journal", icon: ScrollText, name: ["Журнал", "Log"] },
  { id: "settings", icon: Settings2, name: ["Настройки", "Settings"] },
  { id: "about", icon: CircleHelp, name: ["О проекте", "About"] },
];

function useApplySettings() {
  const theme = useSettings((s) => s.theme);
  const accent = useSettings((s) => s.accent);
  const density = useSettings((s) => s.density);
  const grid = useSettings((s) => s.grid);
  const reduce = useSettings((s) => s.reduceMotion);
  const inset = useSettings((s) => s.bottomInset);
  const lang = useLang();
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const dark = theme === "dark" || (theme === "system" && mq.matches);
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#16191d" : "#f2f3f0");
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [theme]);
  useEffect(() => {
    const d = document.documentElement;
    d.style.setProperty("--accent-color", accent);
    d.dataset.density = density;
    d.dataset.grid = grid ? "on" : "off";
    d.classList.toggle("reduce-motion", reduce);
    d.style.setProperty("--bottom-inset", `${inset}px`);
    d.lang = lang;
    document.title = lang === "en" ? "Furby Deck — BLE remote for Furby Connect" : "Furby Deck — BLE пульт для Furby Connect";
  }, [accent, density, grid, reduce, inset, lang]);
  useEffect(() => {
    // follow the browser language until the user picks one manually
    const onLangChange = () => {
      if (!settings.get().langPicked) settings.set({ lang: detectLang() });
    };
    window.addEventListener("languagechange", onLangChange);
    return () => window.removeEventListener("languagechange", onLangChange);
  }, []);
}

function useWide() {
  const [wide, setWide] = useState(() => window.matchMedia("(min-width: 1024px)").matches);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const on = () => setWide(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return wide;
}

function Logo() {
  return (
    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-invert text-on-invert">
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
        <path d="M6 18 9 6M10.5 18 13 6M15 18l2.5-12M4 12h16" />
      </svg>
    </span>
  );
}

function Header() {
  const t = useT();
  const lang = useLang();
  const status = useFurby((s) => s.status);
  const step = useFurby((s) => s.step);
  const confirmStep = useFurby((s) => s.confirm?.step ?? 0);
  const demo = useFurby((s) => s.demo);
  const accepted = useSettings((s) => s.warningAccepted);
  const linked = status === "ready" || status === "confirming";
  const label = status === "ready" ? t("на связи", "online") : status === "confirming" ? `${confirmStep}/6` : status === "connecting" ? `${step}/${CONNECT_STEPS}` : t("нет связи", "offline");
  const connect = () => (accepted ? void furby.connect() : nav.set({ warning: true }));
  return (
    <header className="sticky top-0 z-30 border-b border-line bg-paper/90 backdrop-blur pt-[env(safe-area-inset-top)]">
      <div className="mx-auto flex h-16 max-w-[1320px] items-center gap-2 px-3 sm:gap-3 sm:px-4">
        <Logo />
        <div className="hidden min-w-0 sm:block">
          <p className="font-display text-lg font-bold leading-none tracking-tight">
            FURBY<span className="text-signal">·</span>DECK
          </p>
          <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.3em] text-muted">Connect · Bluetooth LE</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full border border-line bg-panel py-1 pl-2.5 pr-1 text-xs font-medium sm:ml-3">
          <span className={cn("h-2 w-2 rounded-full", status === "ready" ? "bg-signal" : linked || status === "connecting" ? "anim-blink bg-amber" : "bg-line-strong")} />
          <span className="pr-1.5">{label}</span>
          {demo && <Chip tone="amber">{t("демо", "demo")}</Chip>}
        </span>
        <Chip tone="amber" className="hidden md:inline-flex" onClick={() => goTab("about")}>
          <Languages className="h-3 w-3" />
          {t("тесты: RU", "tested: RU")}
        </Chip>
        <div className="ml-auto flex items-center gap-1">
          {linked ? (
            <Button size="sm" onClick={() => { furby.disconnect(); furby2.disconnect(); }}>
              <Unplug className="h-4 w-4" />
              <span className="hidden sm:inline">{t("Отключить", "Disconnect")}</span>
            </Button>
          ) : (
            <>
              <Button size="sm" variant="primary" disabled={status === "connecting"} onClick={connect}>
                <Bluetooth className="h-4 w-4" />
                <span className="hidden sm:inline">{t("Подключить", "Connect")}</span>
              </Button>
              <Button size="sm" disabled={status === "connecting"} onClick={() => void furby.connectDemo()}>
                <FlaskConical className="h-4 w-4" />
                <span className="hidden sm:inline">{t("Демо", "Demo")}</span>
              </Button>
            </>
          )}
          <Button size="sm" variant="ghost" className="px-2 font-mono" onClick={() => settings.set({ lang: lang === "ru" ? "en" : "ru", langPicked: true })} aria-label="Language">
            {lang === "ru" ? "EN" : "RU"}
          </Button>
          <Button size="icon" variant="ghost" className="text-flare" onClick={() => nav.set({ warning: true })} aria-label={t("Предупреждение", "Warning")}>
            <ShieldAlert className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" onClick={() => goTab("settings")} aria-label={t("Настройки", "Settings")}>
            <Settings2 className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="hidden sm:inline-flex" onClick={() => goTab("debug")} aria-label={t("Дебаг", "Debug")}>
            <Wrench className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="hidden sm:inline-flex" onClick={() => goTab("about")} aria-label={t("О проекте", "About")}>
            <CircleHelp className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}

function Banner() {
  const t = useT();
  const supported = useFurby((s) => s.supported);
  const status = useFurby((s) => s.status);
  const error = useFurby((s) => s.error);
  if (status !== "idle") return null;
  if (supported && !error) return null;
  return (
    <div className={cn("flex items-center gap-3 rounded-2xl border px-4 py-3", error && supported ? "border-flare/30 bg-flare-dim" : "border-amber/30 bg-amber-dim")}>
      <TriangleAlert className={cn("h-5 w-5 shrink-0", error && supported ? "text-flare" : "text-amber")} />
      <p className="min-w-0 flex-1 text-sm text-ink">
        {error ?? t("Браузер не поддерживает Web Bluetooth. На iPhone открой сайт в Bluefy, на Android — в Chrome. Или включи демо-режим.", "This browser doesn't support Web Bluetooth. On iPhone open the site in Bluefy, on Android use Chrome. Or turn on demo mode.")}
      </p>
      <Button size="sm" variant="primary" onClick={() => void furby.connectDemo()}>
        {t("Демо", "Demo")}
      </Button>
    </div>
  );
}

function Footer() {
  const t = useT();
  const tx = useFurby((s) => s.stats.tx);
  const rx = useFurby((s) => s.stats.rx);
  return (
    <footer className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 rounded-2xl border border-line bg-panel px-4 py-3 font-mono text-xs">
      <span className="text-muted">
        TX {tx} <span className="ml-3">RX {rx}</span>
      </span>
      <span className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
        <button type="button" onClick={() => goTab("about")} className="inline-flex items-center gap-1.5 text-amber hover:underline">
          <Languages className="h-3.5 w-3.5" />
          {t("тесты только на русском Connect", "tested on Russian Connect only")}
        </button>
        <button type="button" onClick={() => nav.set({ warning: true })} className="text-flare hover:underline">
          {t("Ферби может сломаться — я не виноват", "Furby may break — not my fault")}
        </button>
        <a href={ACTIONS_URL.replace("raw.githubusercontent.com", "github.com").replace("/master/", "/blob/master/")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-ink-2 hover:text-ink">
          <ExternalLink className="h-3.5 w-3.5" />
          actionlist.md
        </a>
      </span>
    </footer>
  );
}

export default function App() {
  useApplySettings();
  const lang = useLang();
  const tab = nav.use((n) => n.tab);
  const wide = useWide();

  return (
    <div className="min-h-screen text-ink antialiased">
      <Header />
      <div className="pb-safe mx-auto max-w-[1320px] space-y-4 px-3 py-4 sm:px-4">
        <Banner />
        <div className="grid items-start gap-4 lg:grid-cols-[340px_minmax(0,1fr)]">
          {wide && (
            <aside className="min-w-0">
              <Sidebar />
            </aside>
          )}
          <main className="min-w-0 space-y-4">
            <nav className="no-scrollbar sticky top-[calc(4rem+env(safe-area-inset-top))] z-20 flex gap-1.5 overflow-x-auto rounded-2xl border border-line bg-panel/95 p-1.5 backdrop-blur lg:flex-wrap lg:overflow-x-visible lg:static">
              {TABS.map((x) => (
                <button
                  key={x.id}
                  type="button"
                  onClick={() => nav.set({ tab: x.id })}
                  className={cn("flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium transition-colors", tab === x.id ? "bg-invert text-on-invert" : "text-ink-2 hover:bg-panel-2 hover:text-ink")}
                >
                  <x.icon className="h-4 w-4" />
                  {pick(x.name, lang)}
                </button>
              ))}
            </nav>
            <div key={tab} className="anim-rise">
            {tab === "control" && (
              <>
                {!wide && <Sidebar />}
                <ControlTab />
              </>
            )}
            {tab === "games" && <GamesTab />}
            {tab === "search" && <SearchTab />}
            {tab === "light" && <LightTab />}
            {tab === "music" && <MusicTab />}
            {tab === "commands" && <CommandsTab />}
            {tab === "studio" && <StudioTab />}
            {tab === "auto" && <AutomationTab />}
            {tab === "progress" && <ProgressTab />}
            {tab === "debug" && (
              <div className="space-y-4">
                <DebugTab />
                <DlcCard />
              </div>
            )}
            {tab === "diag" && <DiagnosticsTab />}
            {tab === "monitor" && <MonitorTab />}
            {tab === "journal" && <JournalTab />}
            {tab === "settings" && <SettingsTab />}
            {tab === "about" && <AboutTab />}
            </div>
            <Footer />
          </main>
        </div>
      </div>
      <HandshakeModal />
      <WarningModal />
      <Toasts />
    </div>
  );
}
