/** Memory, quiz and logic mini games */
import { Brain, Calculator, CheckCheck, CircleHelp, Hand, Languages, Lightbulb, Music2, Palette, Scissors, Sparkle } from "lucide-react";
import { audio, mtof, tone } from "@/lib/audio/synth";
import type { InputType } from "@/lib/furby/controller";
import type { Text } from "@/lib/i18n";
import { LANE_COLORS, arrow, banner, bar, bg, circle, def, pick, randi, rr, shuffle, text } from "./kit";
import type { GameApi, GameInst } from "./types";

interface Sym {
  type: InputType;
  label: Text;
  color: string;
  note: number;
  furby?: number;
}

const hexRgb = (hex: string): [number, number, number] => {
  const v = parseInt(hex.slice(1), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
};

function memory(api: GameApi, syms: Sym[], hideOnFurby = false): GameInst {
  const seq = [randi(0, syms.length - 1)];
  let phase: "pause" | "on" | "off" | "input" = "pause";
  let t = 1;
  let i = 0;
  let lit = -1;
  let litT = 0;
  const play = (k: number) => {
    const { ac, sfx } = audio();
    tone(ac.currentTime + 0.01, mtof(syms[k].note), 0.35, sfx, { type: "triangle", gain: 0.2 });
    api.furby.led(...hexRgb(syms[k].color));
    if (syms[k].furby !== undefined) api.furby.action(70, 0, 0, syms[k].furby!);
  };
  return {
    update(dt, inp) {
      litT -= dt;
      if (phase === "input") {
        for (const e of inp.events) {
          const k = syms.findIndex((s) => s.type === e.type);
          if (k < 0) continue;
          lit = k;
          litT = 0.25;
          play(k);
          if (k === seq[i]) {
            i++;
            if (i === seq.length) {
              api.add(seq.length * 10);
              api.sfx("good");
              seq.push(randi(0, syms.length - 1));
              phase = "pause";
              t = 0.9;
            }
          } else {
            phase = "pause";
            t = 1.3;
            if (api.hurt()) return;
          }
          return;
        }
        return;
      }
      t -= dt;
      if (t > 0) return;
      if (phase === "pause") {
        phase = "on";
        i = 0;
        t = 0.55;
        lit = seq[0];
        litT = 0.55;
        play(lit);
      } else if (phase === "on") {
        phase = "off";
        t = 0.2;
        lit = -1;
      } else if (phase === "off") {
        i++;
        if (i >= seq.length) {
          phase = "input";
          i = 0;
        } else {
          phase = "on";
          t = 0.55;
          lit = seq[i];
          litT = 0.55;
          play(lit);
        }
      }
    },
    draw() {
      const { ctx, w, h, pal } = api;
      bg(api);
      const hidden = hideOnFurby && api.furby.connected && phase !== "input";
      const pos = syms.length === 4 ? [[0.3, 0.55], [0.5, 0.32], [0.7, 0.55], [0.5, 0.78]] : syms.map((_, k) => [(k + 0.5) / syms.length, 0.55]);
      const s = Math.min(w, h) * 0.18;
      syms.forEach((sym, k) => {
        const on = lit === k && litT > 0 && !hidden;
        ctx.globalAlpha = on ? 1 : 0.28;
        rr(ctx, pos[k][0] * w - s / 2, pos[k][1] * h - s / 2, s, s, s * 0.25, sym.color);
        ctx.globalAlpha = 1;
        text(ctx, api.t(...sym.label), pos[k][0] * w, pos[k][1] * h + s * 0.7, 12, pal.muted);
      });
      text(ctx, hidden ? api.t("Смотри на антенну Фёрби!", "Watch Furby's antenna!") : phase === "input" ? api.t("Повтори!", "Repeat!") : api.t("Запоминай…", "Memorize…"), w / 2, 22, 16, pal.fg, "center", 700);
    },
  };
}

interface Q {
  q: string;
  qColor?: string;
  opts: string[];
  answer: number;
}

function quiz(api: GameApi, gen: () => Q, rounds = 12, time = 8): GameInst {
  const KEYS4: InputType[] = ["antL", "antF", "antR", "antB"];
  const KEYS2: InputType[] = ["antL", "antR"];
  let cur = gen();
  let n = 0;
  let t = time;
  let flash = 0;
  let picked = -1;
  const next = () => {
    n++;
    if (n >= rounds) api.over(true);
    else {
      cur = gen();
      t = time;
      picked = -1;
    }
  };
  return {
    update(dt, inp) {
      if (flash > 0) {
        flash -= dt;
        if (flash <= 0) next();
        return;
      }
      t -= dt;
      const keys = cur.opts.length === 2 ? KEYS2 : KEYS4;
      for (const e of inp.events) {
        const k = keys.indexOf(e.type);
        if (k < 0) continue;
        picked = k;
        flash = 0.8;
        if (k === cur.answer) {
          api.add(50 + Math.round(t * 10));
          api.sfx("good");
        } else if (api.hurt()) return;
        return;
      }
      if (t <= 0) {
        picked = -2;
        flash = 0.8;
        api.hurt();
      }
    },
    draw() {
      const { ctx, w, h, pal } = api;
      bg(api);
      text(ctx, cur.q, w / 2, h * 0.42, Math.min(40, w / 12), cur.qColor ?? pal.fg, "center", 800);
      bar(ctx, w * 0.25, h * 0.08, w * 0.5, 8, t / time, pal.fg, pal.surface2);
      const four = cur.opts.length === 4;
      const pos = four ? [[0.17, 0.42, 0], [0.5, 0.2, 2], [0.83, 0.42, 3], [0.5, 0.8, 1]] : [[0.2, 0.7, 0], [0.8, 0.7, 3]];
      cur.opts.forEach((o, k) => {
        const [x, y, dir] = pos[k];
        const col = flash > 0 && k === cur.answer ? pal.green : flash > 0 && k === picked ? pal.red : pal.surface2;
        rr(ctx, x * w - 80, y * h - 24, 160, 48, 12, col);
        arrow(ctx, x * w - 62, y * h, 16, dir, pal.muted);
        text(ctx, o, x * w + 8, y * h, 15, pal.fg, "center", 700);
      });
      text(ctx, `${Math.min(n + 1, rounds)}/${rounds}`, w - 12, 18, 13, pal.muted, "right", 600);
    },
  };
}

const FURBISH: Array<[string, string, string]> = [
  ["Ah-may", "Гладить", "Pet"], ["Ah-tah", "Еда", "Food"], ["Ay-loh", "Свет", "Light"], ["Boo", "Нет", "No"], ["Dah", "Большой", "Big"],
  ["Dah-ay-loh", "Солнце", "Sun"], ["Dee", "Маленький", "Little"], ["Doo-ay-loo-lah", "Игра", "Game"], ["Ee-day", "Хорошо", "Good"],
  ["Ee-kah-lee-koo", "Музыка", "Music"], ["Ee-tay", "Да", "Yes"], ["Kah", "Я", "Me"], ["Koh-koh", "Ещё", "More"], ["Lay-lah", "Дом", "Home"],
  ["May-lah", "Обнимашки", "Hug"], ["May-may", "Любовь", "Love"], ["May-tah", "Поцелуй", "Kiss"], ["Nee-tye", "Щекотка", "Tickle"],
  ["Noh-lah", "Танец", "Dance"], ["Noo-lah", "Друг", "Friend"], ["Noo-loo", "Счастливый", "Happy"], ["Oo-nye", "Ты", "You"],
  ["Wah-tah", "Вода", "Water"], ["Way-loh", "Сон", "Sleep"], ["Wee-tee", "Петь", "Sing"], ["Tee-tah", "Дерево", "Tree"],
  ["Boo-noo-loo", "Грустный", "Sad"], ["Moh-moh", "Монстр", "Monster"],
];

const COLORS: Array<[string, string, string]> = [["#ef4444", "Красный", "Red"], ["#22c55e", "Зелёный", "Green"], ["#3b82f6", "Синий", "Blue"], ["#eab308", "Жёлтый", "Yellow"]];

const answers4 = (correct: number, spread: number): { opts: string[]; answer: number } => {
  const set = new Set([correct]);
  while (set.size < 4) set.add(correct + randi(-spread, spread) || correct + set.size);
  const opts = shuffle([...set]);
  return { opts: opts.map(String), answer: opts.indexOf(correct) };
};

export const BRAIN = [
  def("simon", ["Повторяй за мной", "Simon Says"], ["Запомни порядок цветов и повтори его антенной.", "Memorize the colour order and repeat it with the antenna."], Brain, "logic", ["antenna"], (api) =>
    memory(api, [
      { type: "antL", label: ["← влево", "← left"], color: LANE_COLORS[0], note: 64 },
      { type: "antF", label: ["↑ вперёд", "↑ forward"], color: LANE_COLORS[2], note: 69 },
      { type: "antR", label: ["→ вправо", "→ right"], color: LANE_COLORS[3], note: 73 },
      { type: "antB", label: ["↓ назад", "↓ back"], color: LANE_COLORS[1], note: 76 },
    ])),

  def("touchmem", ["Сенсорная память", "Touch Memory"], ["Повтори порядок касаний: язык, хвост, голова, живот.", "Repeat the touch order: tongue, tail, head, tummy."], Hand, "logic", ["tongue", "tail", "head", "tummy"], (api) =>
    memory(api, [
      { type: "tongue", label: ["Язык", "Tongue"], color: "#f59e0b", note: 62 },
      { type: "tail", label: ["Хвост", "Tail"], color: "#ec4899", note: 66 },
      { type: "head", label: ["Голова", "Head"], color: "#3b82f6", note: 69 },
      { type: "tummy", label: ["Живот", "Tummy"], color: "#22c55e", note: 74 },
    ]), { tap: null }),

  def("ledmem", ["Цвета антенны", "Antenna Colours"], ["Цвета показывает только антенна Фёрби! Запомни и повтори антенной.", "Only Furby's antenna shows the colours! Memorize and repeat with the antenna."], Lightbulb, "logic", ["antenna"], (api) =>
    memory(api, [
      { type: "antL", label: ["← фиолетовый", "← purple"], color: LANE_COLORS[0], note: 60 },
      { type: "antF", label: ["↑ зелёный", "↑ green"], color: LANE_COLORS[2], note: 64 },
      { type: "antR", label: ["→ красный", "→ red"], color: LANE_COLORS[3], note: 67 },
      { type: "antB", label: ["↓ голубой", "↓ cyan"], color: LANE_COLORS[1], note: 72 },
    ], true)),

  def("melody", ["Повтори мелодию", "Repeat the Melody"], ["Фёрби поёт ноты (до, ми, соль, до) — повтори их антенной.", "Furby sings notes (do, mi, sol, do) — repeat them with the antenna."], Music2, "rhythm", ["antenna"], (api) =>
    memory(api, [
      { type: "antL", label: ["← до", "← do"], color: LANE_COLORS[0], note: 60, furby: 0 },
      { type: "antF", label: ["↑ ми", "↑ mi"], color: LANE_COLORS[2], note: 64, furby: 2 },
      { type: "antR", label: ["→ соль", "→ sol"], color: LANE_COLORS[3], note: 67, furby: 4 },
      { type: "antB", label: ["↓ до", "↓ do"], color: LANE_COLORS[1], note: 72, furby: 7 },
    ])),

  def("furbish", ["Язык Фёрбиш", "Furbish Quiz"], ["Угадай, что значит слово на фёрбише. Ответ — антенной.", "Guess what the Furbish word means. Answer with the antenna."], Languages, "logic", ["antenna"], (api) =>
    quiz(api, () => {
      const items = shuffle(FURBISH).slice(0, 4);
      const correct = randi(0, 3);
      return { q: items[correct][0], opts: items.map((x) => api.t(x[1], x[2])), answer: correct };
    })),

  def("math", ["Устный счёт", "Mental Math"], ["Реши пример и выбери ответ антенной.", "Solve the problem and pick the answer with the antenna."], Calculator, "logic", ["antenna"], (api) => {
    let n = 0;
    return quiz(api, () => {
      n++;
      const max = 10 + n * 4;
      const op = pick(n > 4 ? ["+", "−", "×"] : ["+", "−"]);
      let a = randi(1, max);
      let b = randi(1, max);
      if (op === "×") {
        a = randi(2, 9);
        b = randi(2, 9);
      }
      if (op === "−" && b > a) [a, b] = [b, a];
      const c = op === "+" ? a + b : op === "−" ? a - b : a * b;
      return { q: `${a} ${op} ${b}`, ...answers4(c, 6) };
    });
  }),

  def("truefalse", ["Верно или нет", "True or False"], ["Пример верный? Антенна вправо — да, влево — нет.", "Is it correct? Antenna right — yes, left — no."], CheckCheck, "logic", ["antennaLR"], (api) =>
    quiz(api, () => {
      const a = randi(2, 30);
      const b = randi(2, 30);
      const ok = Math.random() < 0.5;
      const c = ok ? a + b : a + b + pick([-3, -2, -1, 1, 2, 3]);
      return { q: `${a} + ${b} = ${c}`, opts: [api.t("Нет", "No"), api.t("Да", "Yes")], answer: ok ? 1 : 0 };
    }, 15, 5)),

  def("stroop", ["Цвет, а не слово", "Colour, Not Word"], ["Выбери ЦВЕТ, которым написано слово, а не само слово.", "Pick the COLOUR the word is written in, not the word itself."], Palette, "logic", ["antenna"], (api) =>
    quiz(api, () => {
      const word = randi(0, 3);
      let ink = randi(0, 3);
      if (ink === word) ink = (ink + randi(1, 3)) % 4;
      return { q: api.t(COLORS[word][1], COLORS[word][2]).toUpperCase(), qColor: COLORS[ink][0], opts: COLORS.map((c) => api.t(c[1], c[2])), answer: ink };
    }, 15, 4)),

  def("flashes", ["Посчитай вспышки", "Count the Flashes"], ["Сосчитай вспышки, нажми язык столько же раз и подтверди хвостом.", "Count the flashes, press the tongue that many times and confirm with the tail."], Sparkle, "logic", ["tongue", "tail"], (api) => {
    let n = randi(3, 5);
    let phase: "show" | "count" | "res" = "show";
    let k = 0;
    let t = 0.8;
    let on = false;
    let count = 0;
    let level = 1;
    return {
      update(dt, inp) {
        t -= dt;
        if (phase === "show") {
          if (t > 0) return;
          if (on) {
            on = false;
            t = 0.28;
            api.furby.led(0, 0, 0);
            if (++k >= n) phase = "count";
          } else {
            on = true;
            t = Math.max(0.12, 0.25 - level * 0.01);
            api.furby.led(255, 255, 255);
            api.sfx("tick");
          }
        } else if (phase === "count") {
          for (const e of inp.events) {
            if (e.type === "tongue") count++;
            if (e.type === "tail") {
              if (count === n) {
                api.add(20 * level);
                api.sfx("good");
              } else api.hurt();
              phase = "res";
              t = 1.2;
            }
          }
        } else if (t <= 0) {
          level++;
          n = randi(3, 4 + level);
          k = 0;
          count = 0;
          phase = "show";
          t = 0.6;
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, on ? (pal.dark ? "#e4e4e7" : "#18181b") : pal.bg);
        if (phase === "count") banner(api, String(count), api.t("Язык — +1, хвост — готово", "Tongue +1, tail — done"));
        else if (phase === "res") banner(api, `${api.t("Было", "It was")} ${n}`);
        else text(ctx, api.t("Смотри!", "Watch!"), w / 2, h * 0.15, 16, on ? pal.bg : pal.muted, "center", 700);
      },
    };
  }, { tap: null }),

  def("rps", ["Камень, ножницы, бумага", "Rock Paper Scissors"], ["Играй против Фёрби: влево — камень, вперёд — бумага, вправо — ножницы. 7 раундов.", "Play against Furby: left — rock, forward — paper, right — scissors. 7 rounds."], Scissors, "party", ["antennaLR", "antennaFB"], (api) => {
    const NAMES: Text[] = [["Камень", "Rock"], ["Бумага", "Paper"], ["Ножницы", "Scissors"]];
    let round = 0;
    let me = -1;
    let fur = -1;
    let res = 0;
    let wins = 0;
    let losses = 0;
    return {
      update(dt, inp) {
        if (res > 0) {
          res -= dt;
          if (res <= 0) {
            me = -1;
            if (++round >= 7) api.over(wins > losses);
          }
          return;
        }
        const e = inp.events.find((x) => x.type === "antL" || x.type === "antF" || x.type === "antR");
        if (!e) return;
        me = e.type === "antL" ? 0 : e.type === "antF" ? 1 : 2;
        fur = randi(0, 2);
        const d = (me - fur + 3) % 3;
        if (d === 1) {
          wins++;
          api.add(100);
          api.sfx("good");
          api.furby.say("lose");
        } else if (d === 2) {
          losses++;
          api.sfx("error");
          api.furby.say("win");
        }
        api.furby.led(...(([[150, 150, 150], [255, 255, 255], [255, 0, 0]] as Array<[number, number, number]>)[fur]));
        res = 1.6;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        text(ctx, `${api.t("Ты", "You")} ${wins} : ${losses} ${api.t("Фёрби", "Furby")}`, w / 2, 26, 18, pal.fg, "center", 800);
        if (me < 0) banner(api, api.t("Выбирай!", "Choose!"), api.t("← камень · ↑ бумага · → ножницы", "← rock · ↑ paper · → scissors"));
        else {
          text(ctx, api.t(...NAMES[me]), w * 0.3, h / 2, 22, pal.fg, "center", 800);
          text(ctx, "vs", w / 2, h / 2, 16, pal.muted);
          text(ctx, api.t(...NAMES[fur]), w * 0.7, h / 2, 22, pal.fg, "center", 800);
        }
      },
    };
  }, { lives: 0, hud: false }),

  def("guess", ["Угадай число", "Guess the Number"], ["Фёрби загадал число от 1 до 100. Антенна вперёд/назад — ±1, влево/вправо — ±10, язык — проверить. Антенна подскажет цветом.", "Furby picked a number from 1 to 100. Antenna forward/back ±1, left/right ±10, tongue to check. The antenna hints with colour."], CircleHelp, "logic", ["antenna", "tongue"], (api) => {
    let secret = randi(1, 100);
    let value = 50;
    let tries = 0;
    let round = 1;
    let hint = "";
    let hold = 0;
    return {
      update(dt, inp) {
        for (const e of inp.events) {
          if (e.type === "antF") value++;
          if (e.type === "antB") value--;
          if (e.type === "antR") value += 10;
          if (e.type === "antL") value -= 10;
          if (e.type === "tongue") {
            tries++;
            const d = secret - value;
            if (d === 0) {
              api.add(Math.max(10, 110 - tries * 10));
              api.sfx("level");
              hint = api.t("Угадал!", "Correct!");
              if (++round > 5) api.over(true);
              secret = randi(1, 100);
              tries = 0;
              api.furby.led(0, 255, 0);
            } else {
              hint = d > 0 ? api.t("Больше ↑", "Higher ↑") : api.t("Меньше ↓", "Lower ↓");
              const a = Math.abs(d);
              api.furby.led(...((a < 6 ? [255, 0, 0] : a < 20 ? [255, 140, 0] : [0, 80, 255]) as [number, number, number]));
              api.sfx("tick");
            }
          }
        }
        hold = inp.ay !== 0 ? hold + dt : 0;
        if (hold > 0.5) {
          value += inp.ay;
          hold = 0.42;
        }
        value = Math.max(1, Math.min(100, value));
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        text(ctx, String(value), w / 2, h * 0.42, Math.min(96, w / 5), pal.fg, "center", 800);
        text(ctx, hint, w / 2, h * 0.66, 18, pal.muted, "center", 700);
        text(ctx, `${api.t("Раунд", "Round")} ${Math.min(round, 5)}/5 · ${api.t("попыток", "tries")}: ${tries}`, w / 2, h - 20, 13, pal.muted);
        circle(ctx, w / 2, h * 0.2, 4, pal.faint);
      },
    };
  }, { lives: 0 }),
];
