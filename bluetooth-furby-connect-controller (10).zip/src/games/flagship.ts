/** Space (tilt), Subway Run and Orders. */
import { Megaphone, Rocket, TrainFront } from "lucide-react";
import type { InputType } from "@/lib/furby/controller";
import type { Text } from "@/lib/i18n";
import { bar, chance, circle, clamp, heart, pick, poly, rand, randi, rr, shuffle, star, strokeCircle, text } from "./kit";
import type { GameApi, GameDef, GameInst, InputFrame } from "./types";

// ---------------------------------------------------------------------------
// Space: the harder you tilt Furby, the faster the ship flies sideways
// ---------------------------------------------------------------------------
interface Rock { x: number; y: number; vx: number; vy: number; r: number; rot: number; vr: number; hp: number; pts: number[] }
interface Ufo { x: number; y: number; t: number; hp: number; cd: number }
interface Item { x: number; y: number; k: "star" | "shield" | "triple" | "slow" | "heart" }

function createSpace(api: GameApi): GameInst {
  let sx = api.w / 2;
  let sy = api.h * 0.8;
  let inv = 0;
  let shield = 0;
  let triple = 0;
  let slow = 0;
  let cd = 0;
  let wave = 1;
  let waveT = 0;
  let spawnT = 1;
  let shots: Array<{ x: number; y: number; vx: number }> = [];
  let eshots: Array<{ x: number; y: number; vx: number; vy: number }> = [];
  let rocks: Rock[] = [];
  let ufos: Ufo[] = [];
  let items: Item[] = [];
  let boss: { x: number; y: number; hp: number; max: number; t: number; cd: number } | null = null;
  let tilt = 0;
  const stars = Array.from({ length: 80 }, () => ({ x: Math.random(), y: Math.random(), z: rand(0.2, 1) }));
  const S = () => Math.max(0.6, Math.min(api.w, api.h) / 420);

  const rock = (x: number, y: number, r: number): Rock => ({
    x, y, r, vx: rand(-40, 40), vy: rand(60, 120) + wave * 12, rot: 0, vr: rand(-2, 2), hp: r > 22 * S() ? 3 : 1,
    pts: Array.from({ length: 9 }, () => rand(0.75, 1.15)),
  });

  const hitShip = () => {
    if (inv > 0) return;
    if (shield > 0) {
      shield = 0;
      inv = 1;
      api.sfx("pop");
      return;
    }
    inv = 1.6;
    api.fx.burst(sx, sy, "#f87171", 20, 220);
    api.hurt();
  };

  return {
    update(dt: number, inp: InputFrame) {
      const s = S();
      const { w, h } = api;
      tilt = inp.tiltX;
      waveT += dt;
      if (waveT > 22 && !boss) {
        waveT = 0;
        wave++;
        api.fx.float(api.t(`Волна ${wave}`, `Wave ${wave}`), w / 2, h * 0.3, "#93c5fd");
        if (wave % 4 === 0) boss = { x: w / 2, y: -60, hp: 30 + wave * 5, max: 30 + wave * 5, t: 0, cd: 1.5 };
      }
      sx = clamp(sx + inp.tiltX * w * 0.95 * dt, 20 * s, w - 20 * s);
      sy = clamp(sy - inp.tiltY * h * 0.55 * dt, h * 0.45, h - 34 * s);
      inv = Math.max(0, inv - dt);
      shield = Math.max(0, shield - dt);
      triple = Math.max(0, triple - dt);
      slow = Math.max(0, slow - dt);
      cd -= dt;
      if ((inp.has("tongue") || inp.held.tongue) && cd <= 0) {
        cd = 0.22;
        shots.push({ x: sx, y: sy - 16 * s, vx: 0 });
        if (triple > 0) shots.push({ x: sx, y: sy - 12 * s, vx: -140 }, { x: sx, y: sy - 12 * s, vx: 140 });
        api.sfx("shoot");
      }
      const k = slow > 0 ? 0.45 : 1;
      spawnT -= dt;
      if (spawnT <= 0 && !boss) {
        spawnT = Math.max(0.32, 1.25 - wave * 0.09);
        if (wave >= 2 && chance(0.22)) ufos.push({ x: rand(40, w - 40), y: -30, t: rand(0, 6), hp: 3, cd: rand(1, 2) });
        else rocks.push(rock(rand(20, w - 20), -40, rand(14, 32) * s));
        if (chance(0.12)) items.push({ x: rand(30, w - 30), y: -20, k: pick(["star", "star", "shield", "triple", "slow", "heart"] as const) });
      }
      for (const sh of shots) {
        sh.y -= 620 * dt;
        sh.x += sh.vx * dt;
      }
      for (const r of rocks) {
        r.x += r.vx * dt * k;
        r.y += r.vy * dt * k;
        r.rot += r.vr * dt;
        if (r.x < r.r || r.x > w - r.r) r.vx *= -1;
      }
      for (const u of ufos) {
        u.t += dt * k;
        u.y += 50 * dt * k;
        u.x += Math.sin(u.t * 2) * 140 * dt * k;
        u.cd -= dt * k;
        if (u.cd <= 0) {
          u.cd = rand(1.2, 2.2);
          eshots.push({ x: u.x, y: u.y + 10, vx: (sx - u.x) * 0.4, vy: 220 });
        }
      }
      for (const e of eshots) {
        e.x += e.vx * dt * k;
        e.y += e.vy * dt * k;
      }
      for (const it of items) it.y += 90 * dt;
      if (boss) {
        boss.t += dt * k;
        boss.y = Math.min(boss.y + 60 * dt, h * 0.18);
        boss.x = w / 2 + Math.sin(boss.t * 0.8) * w * 0.33;
        boss.cd -= dt * k;
        if (boss.cd <= 0) {
          boss.cd = 1.1;
          for (let a = -2; a <= 2; a++) eshots.push({ x: boss.x, y: boss.y + 30, vx: a * 70, vy: 230 });
        }
      }
      for (const sh of shots) {
        for (const r of rocks) {
          if (r.hp > 0 && Math.hypot(sh.x - r.x, sh.y - r.y) < r.r) {
            sh.y = -999;
            r.hp--;
            if (r.hp <= 0) {
              api.add(r.r > 22 * s ? 30 : 15, r.x, r.y);
              api.fx.burst(r.x, r.y, "#a8a29e", 12, 160);
              api.sfx("boom");
              if (r.r > 22 * s) rocks.push(rock(r.x, r.y, r.r * 0.55), rock(r.x, r.y, r.r * 0.55));
            }
          }
        }
        for (const u of ufos) {
          if (u.hp > 0 && Math.hypot(sh.x - u.x, sh.y - u.y) < 22 * s) {
            sh.y = -999;
            if (--u.hp <= 0) {
              api.add(60, u.x, u.y);
              api.fx.burst(u.x, u.y, "#c084fc", 16, 200);
              api.sfx("boom");
            }
          }
        }
        if (boss && Math.abs(sh.x - boss.x) < 60 * s && Math.abs(sh.y - boss.y) < 30 * s) {
          sh.y = -999;
          boss.hp--;
          if (boss.hp <= 0) {
            api.add(1000, boss.x, boss.y);
            api.fx.burst(boss.x, boss.y, "#fbbf24", 50, 320, 4);
            api.fx.shake(10);
            api.sfx("win");
            boss = null;
          }
        }
      }
      for (const r of rocks) if (r.hp > 0 && Math.hypot(r.x - sx, r.y - sy) < r.r + 12 * s) {
        r.hp = 0;
        hitShip();
      }
      for (const u of ufos) if (u.hp > 0 && Math.hypot(u.x - sx, u.y - sy) < 26 * s) {
        u.hp = 0;
        hitShip();
      }
      for (const e of eshots) if (Math.hypot(e.x - sx, e.y - sy) < 12 * s) {
        e.y = 9999;
        hitShip();
      }
      for (const it of items) {
        if (Math.hypot(it.x - sx, it.y - sy) < 26 * s) {
          it.y = 9999;
          api.sfx("coin");
          if (it.k === "star") api.add(50, sx, sy - 30);
          if (it.k === "shield") shield = 6;
          if (it.k === "triple") triple = 8;
          if (it.k === "slow") slow = 5;
          if (it.k === "heart" && api.lives < 5) api.heal();
        }
      }
      shots = shots.filter((q) => q.y > -20);
      rocks = rocks.filter((r) => r.hp > 0 && r.y < h + 60);
      ufos = ufos.filter((u) => u.hp > 0 && u.y < h + 40);
      eshots = eshots.filter((e) => e.y < h + 20);
      items = items.filter((it) => it.y < h + 20);
      api.score += dt * 5;
    },

    draw() {
      const { ctx, w, h } = api;
      const s = S();
      ctx.fillStyle = "#070b18";
      ctx.fillRect(-20, -20, w + 40, h + 40);
      for (const st of stars) {
        st.y = (st.y + st.z * 0.004 * (slow > 0 ? 0.4 : 1)) % 1;
        circle(ctx, st.x * w, st.y * h, st.z * 1.6, `rgba(255,255,255,${0.3 + st.z * 0.6})`);
      }
      for (const it of items) {
        const c = { star: "#facc15", shield: "#38bdf8", triple: "#a3e635", slow: "#c084fc", heart: "#f87171" }[it.k];
        if (it.k === "star") star(ctx, it.x, it.y, 10 * s, c, api.time);
        else if (it.k === "heart") heart(ctx, it.x, it.y, 9 * s, c);
        else {
          strokeCircle(ctx, it.x, it.y, 11 * s, c, 2);
          text(ctx, { shield: "S", triple: "3", slow: "T" }[it.k], it.x, it.y + 1, 12 * s, c, "center", 800);
        }
      }
      for (const r of rocks) {
        const pts: number[] = [];
        r.pts.forEach((m, i) => {
          const a = r.rot + (i / r.pts.length) * Math.PI * 2;
          pts.push(r.x + Math.cos(a) * r.r * m, r.y + Math.sin(a) * r.r * m);
        });
        poly(ctx, pts, "#78716c");
      }
      for (const u of ufos) {
        circle(ctx, u.x, u.y - 6 * s, 9 * s, "#e9d5ff");
        rr(ctx, u.x - 22 * s, u.y - 4 * s, 44 * s, 12 * s, 6 * s, "#a855f7");
      }
      if (boss) {
        rr(ctx, boss.x - 64 * s, boss.y - 24 * s, 128 * s, 48 * s, 20 * s, "#7c3aed");
        circle(ctx, boss.x, boss.y - 14 * s, 20 * s, "#ddd6fe");
        bar(ctx, w * 0.2, 10, w * 0.6, 8, boss.hp / boss.max, "#f472b6", "#ffffff22");
      }
      for (const e of eshots) circle(ctx, e.x, e.y, 4 * s, "#fb7185");
      for (const q of shots) rr(ctx, q.x - 2, q.y - 8, 4, 14, 2, "#7dd3fc");
      if (inv <= 0 || Math.floor(api.time * 12) % 2) {
        poly(ctx, [sx, sy - 18 * s, sx + 14 * s, sy + 12 * s, sx, sy + 6 * s, sx - 14 * s, sy + 12 * s], "#60a5fa");
        circle(ctx, sx, sy + 13 * s, (4 + Math.random() * 3) * s, "#fb923c");
        if (shield > 0) strokeCircle(ctx, sx, sy, 26 * s, "#38bdf8", 2);
      }
      text(ctx, `${api.t("Очки", "Score")}: ${Math.floor(api.score)}`, 12, 18, 15, "#f4f4f5", "left", 700);
      text(ctx, api.t(`Волна ${wave}`, `Wave ${wave}`), 12, 38, 12, "#a1a1aa", "left", 600);
      for (let i = 0; i < api.lives; i++) heart(ctx, w - 16 - i * 20, 18, 7, "#f87171");
      const gw = Math.min(180, w * 0.4);
      rr(ctx, w / 2 - gw / 2, h - 16, gw, 6, 3, "#ffffff22");
      circle(ctx, w / 2 + (tilt * gw) / 2, h - 13, 6, Math.abs(tilt) > 0.6 ? "#fb923c" : "#60a5fa");
      text(ctx, api.t("наклон = скорость", "tilt = speed"), w / 2, h - 28, 11, "#a1a1aa");
    },
  };
}

export const spaceGame: GameDef = {
  id: "space",
  name: ["Космос", "Space"],
  desc: [
    "Наклоняй Фёрби, чтобы лететь: чем сильнее наклон, тем быстрее корабль. Язык — выстрел. Астероиды, НЛО, бонусы и босс каждые 4 волны.",
    "Tilt Furby to fly: the stronger the tilt, the faster the ship. Tongue fires. Asteroids, UFOs, power-ups and a boss every 4 waves.",
  ],
  icon: Rocket,
  cat: "arcade",
  controls: ["tilt", "tongue"],
  hud: false,
  tap: "tongue",
  create: createSpace,
};

// ---------------------------------------------------------------------------
// Subway Run: three lanes, jump, roll, coins
// ---------------------------------------------------------------------------
interface RunObj { lane: number; z: number; kind: "low" | "high" | "train" | "coin"; len: number; taken?: boolean }

function createSurf(api: GameApi): GameInst {
  let lane = 0;
  let lx = 0;
  let jy = 0;
  let vy = 0;
  let roll = 0;
  let inv = 0;
  let dist = 0;
  let coins = 0;
  let speed = 16;
  let objs: RunObj[] = [];
  let nextZ = 30;

  const spawnRow = (z: number) => {
    const lanes = shuffle([-1, 0, 1]);
    const blocked = randi(1, 2);
    for (let i = 0; i < blocked; i++) {
      const kind = pick(["train", "low", "high", "train"] as const);
      objs.push({ lane: lanes[i], z, kind, len: kind === "train" ? rand(6, 11) : 0.6 });
    }
    const free = lanes[2];
    if (chance(0.7)) for (let c = 0; c < 5; c++) objs.push({ lane: free, z: z + c * 1.6, kind: "coin", len: 0 });
  };

  return {
    update(dt: number, inp: InputFrame) {
      speed = Math.min(34, 16 + dist / 120);
      if (inp.has("antL")) lane = Math.max(-1, lane - 1);
      if (inp.has("antR")) lane = Math.min(1, lane + 1);
      if ((inp.has("antF") || inp.has("tongue")) && jy <= 0.001) {
        vy = 9.5;
        api.sfx("jump");
      }
      if (inp.has("antB")) {
        roll = 0.7;
        if (jy > 0) vy = -14;
      }
      vy -= 27 * dt;
      jy = Math.max(0, jy + vy * dt);
      if (jy === 0 && vy < 0) vy = 0;
      roll = Math.max(0, roll - dt);
      inv = Math.max(0, inv - dt);
      lx += (lane - lx) * Math.min(1, dt * 12);
      const dz = speed * dt;
      dist += dz;
      for (const o of objs) o.z -= dz;
      nextZ -= dz;
      while (nextZ < 75) {
        spawnRow(nextZ);
        nextZ += rand(10, 15) * (1 + speed / 70);
      }
      for (const o of objs) {
        if (o.kind === "coin") {
          if (!o.taken && Math.abs(o.z) < 0.9 && o.lane === lane && jy < 2) {
            o.taken = true;
            coins++;
            api.sfx("coin");
          }
          continue;
        }
        if (inv > 0 || o.z > 0.6 || o.z + o.len < -0.4 || Math.abs(lx - o.lane) > 0.45) continue;
        if (o.kind === "low" && jy > 0.8) continue;
        if (o.kind === "high" && roll > 0) continue;
        o.z = -99;
        inv = 1.2;
        api.fx.shake(8);
        api.hurt();
      }
      objs = objs.filter((o) => o.z + o.len > -3 && !(o.kind === "coin" && o.taken));
      api.score = Math.floor(dist) + coins * 10;
    },

    draw() {
      const { ctx, w, h, pal } = api;
      const y0 = h * 0.28;
      const y1 = h * 0.96;
      const proj = (z: number) => 1 / (1 + Math.max(-0.9, z) / 7);
      const X = (l: number, z: number) => w / 2 + l * w * 0.26 * proj(z);
      const Y = (z: number) => y0 + (y1 - y0) * proj(z);
      ctx.fillStyle = pal.dark ? "#0f172a" : "#e0f2fe";
      ctx.fillRect(-20, -20, w + 40, h + 40);
      ctx.fillStyle = pal.dark ? "#1e293b" : "#cbd5e1";
      ctx.beginPath();
      ctx.moveTo(w / 2 - w * 0.06, y0);
      ctx.lineTo(w / 2 + w * 0.06, y0);
      ctx.lineTo(w * 1.1, y1 + 40);
      ctx.lineTo(-w * 0.1, y1 + 40);
      ctx.fill();
      ctx.strokeStyle = pal.dark ? "#475569" : "#94a3b8";
      ctx.lineWidth = 2;
      for (const l of [-1.5, -0.5, 0.5, 1.5]) {
        ctx.beginPath();
        ctx.moveTo(X(l, 80), Y(80));
        ctx.lineTo(X(l, -0.9), Y(-0.9));
        ctx.stroke();
      }
      const sorted = [...objs].sort((a, b) => b.z - a.z);
      for (const o of sorted) {
        if (o.z > 80) continue;
        const f = proj(o.z);
        const x = X(o.lane, o.z);
        const y = Y(o.z);
        const lw = w * 0.22 * f;
        if (o.kind === "coin") circle(ctx, x, y - 30 * f, 9 * f, "#facc15");
        else if (o.kind === "train") {
          const fb = proj(o.z + o.len);
          const yb = Y(o.z + o.len);
          const th = h * 0.42;
          poly(ctx, [x - lw / 2, y - th * f, x + lw / 2, y - th * f, X(o.lane, o.z + o.len) + (lw / 2) * (fb / f), yb - th * fb, X(o.lane, o.z + o.len) - (lw / 2) * (fb / f), yb - th * fb], pal.dark ? "#334155" : "#94a3b8");
          rr(ctx, x - lw / 2, y - th * f, lw, th * f, 6 * f, "#ef4444");
          rr(ctx, x - lw * 0.35, y - th * f * 0.85, lw * 0.7, th * f * 0.3, 4 * f, "#fecaca");
        } else if (o.kind === "low") {
          rr(ctx, x - lw / 2, y - 26 * f, lw, 26 * f, 4 * f, "#f59e0b");
          rr(ctx, x - lw / 2, y - 18 * f, lw, 7 * f, 2, "#18181b");
        } else {
          rr(ctx, x - lw / 2, y - 120 * f, 6 * f, 120 * f, 2, "#64748b");
          rr(ctx, x + lw / 2 - 6 * f, y - 120 * f, 6 * f, 120 * f, 2, "#64748b");
          rr(ctx, x - lw / 2, y - 120 * f, lw, 26 * f, 4 * f, "#22c55e");
        }
      }
      const px = X(lx, 0);
      const ph = roll > 0 ? 30 : 60;
      const py = Y(0) - jy * h * 0.06;
      if (inv <= 0 || Math.floor(api.time * 12) % 2) {
        rr(ctx, px - 20, py - ph, 40, ph, 14, "#3b82f6");
        circle(ctx, px - 7, py - ph + 16, 4, "#ffffff");
        circle(ctx, px + 7, py - ph + 16, 4, "#ffffff");
      }
      text(ctx, `${api.t("Монеты", "Coins")}: ${coins}`, 12, 40, 13, pal.muted, "left", 600);
    },
  };
}

export const surfGame: GameDef = {
  id: "surf",
  name: ["Метро-раннер", "Subway Run"],
  desc: [
    "Беги по трём путям: антенна влево/вправо — смена пути, вперёд или язык — прыжок, назад — подкат. Собирай монеты.",
    "Run on three tracks: antenna left/right changes track, forward or tongue jumps, back rolls. Grab the coins.",
  ],
  icon: TrainFront,
  cat: "arcade",
  controls: ["antenna", "tongue"],
  tap: null,
  create: createSurf,
};

// ---------------------------------------------------------------------------
// Orders: do what the screen says within 2 seconds
// ---------------------------------------------------------------------------
const ORDERS: Array<{ type: InputType; text: Text; min: number }> = [
  { type: "tongue", text: ["Нажми на язык", "Press the tongue"], min: 1 },
  { type: "tail", text: ["Дёрни хвост", "Pull the tail"], min: 1 },
  { type: "antL", text: ["Антенну влево", "Antenna left"], min: 1 },
  { type: "antR", text: ["Антенну вправо", "Antenna right"], min: 1 },
  { type: "antF", text: ["Антенну вперёд", "Antenna forward"], min: 1 },
  { type: "antB", text: ["Антенну назад", "Antenna back"], min: 1 },
  { type: "head", text: ["Погладь голову", "Pet the head"], min: 2 },
  { type: "tummy", text: ["Погладь живот", "Rub the tummy"], min: 2 },
  { type: "tiltL", text: ["Наклони влево", "Tilt left"], min: 3 },
  { type: "tiltR", text: ["Наклони вправо", "Tilt right"], min: 3 },
  { type: "sideL", text: ["Нажми левый бок", "Press the left side"], min: 4 },
  { type: "sideR", text: ["Нажми правый бок", "Press the right side"], min: 4 },
  { type: "flip", text: ["Переверни вверх ногами", "Flip upside down"], min: 5 },
];
const ORDER_TYPES = new Set(ORDERS.map((o) => o.type));
const LIMIT = 2;

function createOrders(api: GameApi): GameInst {
  let phase: "wait" | "order" = "wait";
  let timer = 1.2;
  let order = ORDERS[0];
  let elapsed = 0;
  let correct = 0;
  let streak = 0;
  let wrongFlash = 0;
  let okFlash = 0;
  let lastType: InputType | null = null;
  const level = () => 1 + Math.floor(correct / 8);

  const next = () => {
    const pool = ORDERS.filter((o) => o.min <= level() && o.type !== lastType);
    order = pick(pool);
    lastType = order.type;
    phase = "order";
    elapsed = 0;
    api.speak(api.t(...order.text));
    api.sfx("tick");
  };

  return {
    update(dt: number, inp: InputFrame) {
      wrongFlash = Math.max(0, wrongFlash - dt);
      okFlash = Math.max(0, okFlash - dt);
      if (phase === "wait") {
        timer -= dt;
        if (timer <= 0) next();
        return;
      }
      elapsed += dt;
      for (const ev of inp.events) {
        if (ev.type === order.type) {
          const mult = 1 + Math.floor(streak / 5) * 0.5;
          const pts = Math.round((100 + 400 * Math.max(0, 1 - elapsed / LIMIT)) * mult);
          api.add(pts, api.w / 2, api.h * 0.62);
          correct++;
          streak++;
          okFlash = 0.4;
          api.sfx("good");
          const v = [34, 197, 94] as const;
          api.furby.led(v[0], v[1], v[2]);
          phase = "wait";
          timer = 0.7;
          return;
        }
        if (ORDER_TYPES.has(ev.type)) {
          // A wrong action is allowed — only running out of time costs a life
          wrongFlash = 0.35;
          api.sfx("error");
        }
      }
      if (elapsed >= LIMIT) {
        streak = 0;
        phase = "wait";
        timer = 0.9;
        api.furby.led(255, 0, 0);
        api.hurt();
      }
    },

    draw() {
      const { ctx, w, h, pal } = api;
      ctx.fillStyle = okFlash > 0 ? (pal.dark ? "#052e16" : "#dcfce7") : wrongFlash > 0 ? (pal.dark ? "#3f0d0d" : "#fee2e2") : pal.bg;
      ctx.fillRect(-20, -20, w + 40, h + 40);
      if (phase === "order") {
        text(ctx, api.t(...order.text), w / 2, h * 0.42, clamp(w / 13, 22, 46), pal.fg, "center", 800);
        bar(ctx, w * 0.2, h * 0.55, w * 0.6, 12, 1 - elapsed / LIMIT, elapsed > 1.4 ? pal.red : pal.fg, pal.dark ? "#ffffff1a" : "#0000000f");
        if (wrongFlash > 0) text(ctx, api.t("Не то! Ещё есть время", "Wrong! There's still time"), w / 2, h * 0.66, 15, pal.red, "center", 700);
      } else text(ctx, api.t("Приготовься…", "Get ready…"), w / 2, h * 0.45, 22, pal.muted, "center", 700);
      const mult = 1 + Math.floor(streak / 5) * 0.5;
      text(ctx, `${api.t("Уровень", "Level")} ${level()} · ${api.t("серия", "streak")} ${streak} · ×${mult}`, w / 2, h - 22, 13, pal.muted, "center", 600);
    },
  };
}

export const ordersGame: GameDef = {
  id: "orders",
  name: ["Приказы", "Orders"],
  desc: [
    "На экране появляется приказ — выполни его с Фёрби за 2 секунды. Чем быстрее, тем больше очков. Ошибаться можно, жизнь снимается только если время вышло.",
    "An order appears — do it with Furby within 2 seconds. Faster means more points. Mistakes are allowed; you only lose a life when time runs out.",
  ],
  icon: Megaphone,
  cat: "party",
  controls: ["antenna", "tongue", "tail", "head", "tummy", "tilt", "sides", "flip"],
  tap: null,
  create: createOrders,
};
