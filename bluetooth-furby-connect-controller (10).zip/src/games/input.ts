/** Merges Furby sensors, keyboard and on-screen buttons into one input stream for games. */
import { furby, type InputType } from "@/lib/furby/controller";
import { settings } from "@/lib/settings";
import type { HoldKey, InputEv, InputFrame } from "./types";

const KEYS: Record<string, InputType> = {
  ArrowLeft: "antL",
  KeyA: "antL",
  ArrowRight: "antR",
  KeyD: "antR",
  ArrowUp: "antF",
  KeyW: "antF",
  ArrowDown: "antB",
  KeyS: "antB",
  Space: "tongue",
  Enter: "tongue",
  KeyT: "tail",
  KeyB: "tummy",
  KeyH: "head",
  KeyZ: "sideL",
  KeyC: "sideR",
  KeyX: "shake",
  KeyF: "flip",
  KeyQ: "tiltL",
  KeyE: "tiltR",
};
const HOLDS: HoldKey[] = ["tongue", "tail", "tummy", "head", "sideL", "sideR"];

class InputHub {
  /** In tilt-only games the arrow keys steer the tilt */
  tiltMode = false;
  private queue: InputEv[] = [];
  private held = new Set<InputType>();
  private tx = 0;
  private ty = 0;
  private cleanup: Array<() => void> = [];

  private map(code: string): InputType | undefined {
    const type = KEYS[code];
    if (this.tiltMode && type === "antL") return "tiltL";
    if (this.tiltMode && type === "antR") return "tiltR";
    return type;
  }

  attach() {
    this.detach();
    const down = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      if (el && /INPUT|TEXTAREA|SELECT/.test(el.tagName)) return;
      const type = this.map(e.code);
      if (!type) return;
      e.preventDefault();
      if (e.repeat) return;
      this.held.add(type);
      this.queue.push({ type, t: performance.now(), src: "key" });
    };
    const up = (e: KeyboardEvent) => {
      const type = this.map(e.code);
      if (type) this.held.delete(type);
    };
    const blur = () => this.held.clear();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    const off = furby.onInput((ev) => this.queue.push(ev));
    this.cleanup = [
      () => window.removeEventListener("keydown", down),
      () => window.removeEventListener("keyup", up),
      () => window.removeEventListener("blur", blur),
      off,
    ];
    this.queue = [];
    this.held.clear();
    this.tx = 0;
    this.ty = 0;
    return () => this.detach();
  }

  detach() {
    this.cleanup.forEach((fn) => fn());
    this.cleanup = [];
    this.held.clear();
    this.queue = [];
  }

  press(type: InputType) {
    this.held.add(type);
    this.queue.push({ type, t: performance.now(), src: "touch" });
  }

  release(type: InputType) {
    this.held.delete(type);
  }

  frame(dt: number): InputFrame {
    const s = furby.getState().sensors;
    const k = 0.6 + settings.get().tiltSensitivity * 0.2;
    const h = (t: InputType) => this.held.has(t);
    const ax = s?.x || (h("antR") ? 1 : 0) - (h("antL") ? 1 : 0);
    const ay = s?.y || (h("antF") ? 1 : 0) - (h("antB") ? 1 : 0);
    let gx = (s?.tiltX ?? 0) * k;
    const gy = Math.max(-1, Math.min(1, (s?.tiltY ?? 0) * k));
    const key = (h("tiltR") ? 1 : 0) - (h("tiltL") ? 1 : 0);
    if (key) gx = key;
    gx = Math.max(-1, Math.min(1, gx));
    const blend = Math.min(1, dt * 7);
    this.tx += (gx - this.tx) * blend;
    this.ty += (gy - this.ty) * blend;
    const touches = s?.touches ?? [];
    const held = {} as Record<HoldKey, boolean>;
    for (const name of HOLDS) held[name] = touches.includes(name) || h(name);
    const events = this.queue.splice(0);
    return { ax, ay, tiltX: this.tx, tiltY: this.ty, held, events, has: (type) => events.some((e) => e.type === type) };
  }
}

export const input = new InputHub();
