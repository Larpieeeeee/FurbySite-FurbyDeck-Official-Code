/** Party and pet mini games */
import { Cherry, Dices, FerrisWheel, Flame, Heart, Snowflake } from "lucide-react";
import { audio, kick } from "@/lib/audio/synth";
import type { Text } from "@/lib/i18n";
import { banner, bar, bg, circle, clamp, def, heart, poly, rand, randi, rr, star, text } from "./kit";

const TASKS: Text[] = [
  ["Погладь Фёрби по голове", "Pet Furby's head"], ["Спой куплет любимой песни", "Sing a verse of your favourite song"],
  ["Станцуй 10 секунд", "Dance for 10 seconds"], ["Расскажи анекдот", "Tell a joke"], ["Изобрази Фёрби", "Do a Furby impression"],
  ["Скажи «привет» на фёрбише: «Хэй!»", "Say hi in Furbish: “Hey!”"], ["Сделай комплимент соседу", "Compliment the person next to you"],
  ["Покажи смешную рожицу", "Make a funny face"], ["Передай Фёрби соседу", "Pass Furby to the next player"],
  ["Пропусти ход", "Skip a turn"], ["Крутани ещё раз", "Spin again"], ["Придумай Фёрби новое имя", "Invent a new name for Furby"],
];

export const PARTY = [
  def("potato", ["Горячая картошка", "Hot Potato"], ["Передавайте Фёрби по кругу. Антенна краснеет, писк ускоряется… У кого «взорвётся» — тот проиграл раунд. Язык — новый раунд.", "Pass Furby around. The antenna turns red and the beeping speeds up… whoever holds it at the boom loses. Tongue starts a round."], Flame, "party", ["tongue"], (api) => {
    let phase: "idle" | "run" | "boom" = "idle";
    let left = 0;
    let total = 1;
    let beep = 0;
    let rounds = 0;
    let t = 0;
    return {
      update(dt, inp) {
        if (phase === "idle") {
          if (inp.has("tongue")) {
            phase = "run";
            total = left = rand(12, 35);
          }
          return;
        }
        if (phase === "run") {
          left -= dt;
          beep -= dt;
          const k = 1 - left / total;
          if (beep <= 0) {
            beep = Math.max(0.12, 1 - k * 0.9);
            api.sfx("tick");
            api.furby.led(Math.round(255 * k), Math.round(255 * (1 - k)), 0);
          }
          if (left <= 0) {
            phase = "boom";
            t = 2.5;
            rounds++;
            api.score = rounds * 10;
            api.sfx("boom");
            api.fx.shake(12, 0.6);
            api.furby.random(20);
          }
          return;
        }
        t -= dt;
        if (t <= 0) {
          if (rounds >= 5) api.over(true);
          phase = "idle";
        }
      },
      draw() {
        const { pal } = api;
        bg(api, phase === "boom" ? (pal.dark ? "#7f1d1d" : "#fecaca") : pal.bg);
        if (phase === "idle") banner(api, api.t("Нажми язык — старт", "Press the tongue to start"), `${api.t("Раунд", "Round")} ${rounds + 1}/5`);
        else if (phase === "run") banner(api, api.t("Передавай!", "Pass it!"), api.t("Быстрее, пока не взорвалось", "Quick, before it blows"));
        else banner(api, api.t("БУМ!", "BOOM!"), api.t("Кто держит Фёрби — проиграл раунд", "Whoever holds Furby loses the round"));
      },
    };
  }, { lives: 0, hud: false }),

  def("freeze", ["Замри!", "Freeze!"], ["Пока играет музыка — танцуй с Фёрби (наклоны, антенна). Музыка стихла — замри! Фёрби почувствует движение.", "While the music plays, dance with Furby (tilt, antenna). When it stops — freeze! Furby feels any movement."], Snowflake, "party", ["tilt", "antenna", "shake"], (api) => {
    let phase: "dance" | "freeze" = "dance";
    let t = rand(5, 9);
    let beatT = 0;
    let round = 0;
    return {
      update(dt, inp) {
        t -= dt;
        const moved = inp.events.some((e) => ["tiltL", "tiltR", "shake", "flip", "antL", "antR", "antF", "antB"].includes(e.type));
        if (phase === "dance") {
          beatT -= dt;
          if (beatT <= 0) {
            beatT = 0.5;
            const { ac, music } = audio();
            kick(ac.currentTime + 0.01, music);
          }
          if (moved) api.add(1);
          if (t <= 0) {
            phase = "freeze";
            t = 3;
            api.sfx("whoosh");
            api.furby.led(0, 160, 255);
          }
        } else {
          if (moved) {
            api.fx.shake(8);
            if (api.hurt()) return;
            t = 0;
          }
          if (t <= 0) {
            phase = "dance";
            t = rand(4, 9);
            round++;
            api.add(50);
            api.furby.led(255, 0, 200);
          }
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, phase === "freeze" ? (pal.dark ? "#082f49" : "#e0f2fe") : pal.bg);
        banner(api, phase === "dance" ? api.t("Танцуй!", "Dance!") : api.t("ЗАМРИ!", "FREEZE!"), phase === "freeze" ? `${Math.ceil(t)}` : `${api.t("Раунд", "Round")} ${round + 1}`);
        if (phase === "dance") for (let i = 0; i < 5; i++) circle(ctx, w * (0.2 + i * 0.15), h * 0.8 + Math.sin(api.time * 8 + i) * 10, 8, pal.pink);
      },
    };
  }, { tap: null }),

  def("slots", ["Однорукий бандит", "Slot Machine"], ["Дёрни хвост как рычаг! Ставка 10 монет, три одинаковых — выигрыш.", "Pull the tail like a lever! 10 coins per spin, three of a kind wins."], Cherry, "party", ["tail"], (api) => {
    const PAY = [30, 50, 80, 120, 300];
    let coins = 100;
    let reels = [0, 1, 2];
    let spin = 0;
    let spins = 0;
    let msg = "";
    const sym = (ctx: CanvasRenderingContext2D, k: number, x: number, y: number, s: number) => {
      if (k === 0) circle(ctx, x, y, s * 0.3, "#ef4444");
      else if (k === 1) star(ctx, x, y, s * 0.35, "#eab308");
      else if (k === 2) heart(ctx, x, y, s * 0.3, "#ec4899");
      else if (k === 3) poly(ctx, [x, y - s * 0.35, x + s * 0.28, y, x, y + s * 0.35, x - s * 0.28, y], "#06b6d4");
      else text(ctx, "7", x, y, s * 0.6, "#a855f7", "center", 900);
    };
    return {
      update(dt, inp) {
        if (spin > 0) {
          spin -= dt;
          for (let i = 0; i < 3; i++) if (spin > i * 0.35) reels[i] = randi(0, 4);
          if (spin <= 0) {
            const [a, b, c] = reels;
            const win = a === b && b === c ? PAY[a] : a === b || b === c || a === c ? 15 : 0;
            coins += win;
            msg = win ? `+${win}` : api.t("Мимо", "No luck");
            api.sfx(win ? "win" : "error");
            api.score = coins;
            if (coins < 10) api.over(false);
            else if (spins >= 25) api.over(true);
          }
          return;
        }
        if (inp.has("tail") && coins >= 10) {
          coins -= 10;
          spins++;
          spin = 1.2;
          msg = "";
          api.sfx("whoosh");
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const s = Math.min(w / 4.5, h * 0.4);
        for (let i = 0; i < 3; i++) {
          const x = w / 2 + (i - 1) * s * 1.1;
          rr(ctx, x - s / 2, h * 0.4 - s / 2, s, s, 14, pal.surface2);
          sym(ctx, reels[i], x, h * 0.4, s);
        }
        text(ctx, `${api.t("Монеты", "Coins")}: ${coins} · ${api.t("вращений", "spins")} ${spins}/25`, w / 2, h * 0.75, 16, pal.fg, "center", 700);
        text(ctx, msg || api.t("Дёрни хвост!", "Pull the tail!"), w / 2, h * 0.86, 15, pal.muted);
      },
    };
  }, { lives: 0, hud: false, tap: "tail" }),

  def("dice", ["Кости", "Dice Duel"], ["Потряси Фёрби (или нажми язык), чтобы бросить кости против Фёрби. 5 раундов.", "Shake Furby (or press the tongue) to roll the dice against Furby. 5 rounds."], Dices, "party", ["shake", "tongue"], (api) => {
    let round = 0;
    let anim = 0;
    let mine = [1, 1];
    let his = [1, 1];
    let wins = 0;
    let res = "";
    const face = (x: number, y: number, s: number, v: number) => {
      const { ctx, pal } = api;
      rr(ctx, x - s / 2, y - s / 2, s, s, s * 0.18, pal.surface2);
      const P: Record<number, number[][]> = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] };
      for (const [dx, dy] of P[v]) circle(ctx, x + dx * s * 0.26, y + dy * s * 0.26, s * 0.08, pal.fg);
    };
    return {
      update(dt, inp) {
        if (anim > 0) {
          anim -= dt;
          mine = [randi(1, 6), randi(1, 6)];
          his = [randi(1, 6), randi(1, 6)];
          if (anim <= 0) {
            const a = mine[0] + mine[1];
            const b = his[0] + his[1];
            if (a > b) {
              wins++;
              api.add(100);
              res = api.t("Ты выиграл раунд!", "You win the round!");
              api.furby.led(0, 255, 0);
            } else res = a === b ? api.t("Ничья", "Draw") : api.t("Фёрби выиграл", "Furby wins");
            if (a < b) api.furby.led(255, 0, 0);
            if (++round >= 5) api.over(wins >= 3);
          }
          return;
        }
        if (inp.has("shake") || inp.has("tongue")) {
          anim = 1;
          res = "";
          api.sfx("whoosh");
        }
      },
      draw() {
        const { w, h, pal, ctx } = api;
        bg(api);
        const s = Math.min(w / 7, h / 4);
        face(w * 0.22, h * 0.45, s, mine[0]);
        face(w * 0.36, h * 0.45, s, mine[1]);
        face(w * 0.64, h * 0.45, s, his[0]);
        face(w * 0.78, h * 0.45, s, his[1]);
        text(ctx, api.t("Ты", "You"), w * 0.29, h * 0.45 - s, 15, pal.muted);
        text(ctx, api.t("Фёрби", "Furby"), w * 0.71, h * 0.45 - s, 15, pal.muted);
        text(ctx, res || api.t("Потряси Фёрби!", "Shake Furby!"), w / 2, h * 0.78, 18, pal.fg, "center", 700);
      },
    };
  }, { lives: 0 }),

  def("wheel", ["Колесо заданий", "Wheel of Dares"], ["Дёрни хвост, чтобы крутануть колесо с весёлыми заданиями для компании. 10 вращений.", "Pull the tail to spin a wheel of fun party dares. 10 spins."], FerrisWheel, "party", ["tail"], (api) => {
    let ang = 0;
    let vel = 0;
    let spins = 0;
    let task = -1;
    return {
      update(dt, inp) {
        if (vel > 0) {
          ang += vel * dt;
          vel = Math.max(0, vel - 3.2 * dt);
          if (vel === 0) {
            const n = TASKS.length;
            task = Math.floor((((-ang - Math.PI / 2) % (Math.PI * 2)) + Math.PI * 4) % (Math.PI * 2) / ((Math.PI * 2) / n)) % n;
            api.sfx("level");
            api.score = ++spins;
            if (spins >= 10) window.setTimeout(() => api.over(true), 2500);
          }
          return;
        }
        if (inp.has("tail")) {
          vel = rand(9, 14);
          task = -1;
          api.sfx("whoosh");
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const R = Math.min(w, h) * 0.32;
        const cx = w / 2;
        const cy = h * 0.42;
        const n = TASKS.length;
        for (let i = 0; i < n; i++) {
          ctx.fillStyle = `hsl(${(i * 360) / n} 70% ${pal.dark ? 40 : 65}%)`;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.arc(cx, cy, R, ang + (i * Math.PI * 2) / n, ang + ((i + 1) * Math.PI * 2) / n);
          ctx.fill();
        }
        poly(ctx, [cx - 10, cy - R - 14, cx + 10, cy - R - 14, cx, cy - R + 4], pal.fg);
        text(ctx, task >= 0 ? api.t(...TASKS[task]) : api.t("Дёрни хвост!", "Pull the tail!"), w / 2, h * 0.88, Math.min(20, w / 22), pal.fg, "center", 700);
      },
    };
  }, { lives: 0, tap: "tail" }),

  def("pet", ["Питомец", "Pet Care"], ["Ухаживай за питомцем: язык — покормить, голова и живот — поиграть, хвост — помыть, антенна назад (держать) — сон. Не дай шкалам упасть до нуля!", "Care for your pet: tongue feeds, head and tummy play, tail washes, hold the antenna back to sleep. Don't let any bar hit zero!"], Heart, "party", ["tongue", "head", "tummy", "tail", "antennaFB"], (api) => {
    const s = { food: 80, fun: 80, energy: 80, clean: 80 };
    let lastMood = 0;
    return {
      update(dt, inp) {
        const k = 1 + api.time / 60;
        s.food -= 1.6 * k * dt;
        s.fun -= 2 * k * dt;
        s.energy -= 1 * k * dt;
        s.clean -= 0.9 * k * dt;
        for (const e of inp.events) {
          if (e.type === "tongue") {
            s.food += 12;
            api.sfx("coin");
          }
          if (e.type === "head" || e.type === "tummy") {
            s.fun += 10;
            api.sfx("pop");
          }
          if (e.type === "tail") {
            s.clean += 12;
            api.sfx("whoosh");
          }
        }
        if (inp.ay < 0) s.energy += 18 * dt;
        for (const key of Object.keys(s) as Array<keyof typeof s>) s[key] = clamp(s[key], 0, 100);
        if (api.time - lastMood > 6) {
          lastMood = api.time;
          api.furby.mood(3, Math.round(s.food));
        }
        api.score = Math.floor(api.time * 10);
        if (Object.values(s).some((v) => v <= 0)) api.over(api.time > 60);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const mood = Math.min(s.food, s.fun, s.energy, s.clean);
        const cx = w / 2;
        const cy = h * 0.36;
        const r = Math.min(w, h) * 0.17;
        circle(ctx, cx, cy, r, pal.violet);
        circle(ctx, cx - r * 0.35, cy - r * 0.15, r * 0.14, "#fff");
        circle(ctx, cx + r * 0.35, cy - r * 0.15, r * 0.14, "#fff");
        circle(ctx, cx - r * 0.35, cy - r * 0.12, r * 0.07, "#18181b");
        circle(ctx, cx + r * 0.35, cy - r * 0.12, r * 0.07, "#18181b");
        ctx.strokeStyle = "#18181b";
        ctx.lineWidth = 3;
        ctx.beginPath();
        if (mood > 40) ctx.arc(cx, cy + r * 0.2, r * 0.3, 0.2, Math.PI - 0.2);
        else ctx.arc(cx, cy + r * 0.55, r * 0.3, Math.PI + 0.3, -0.3);
        ctx.stroke();
        const rows: Array<[Text, number, string]> = [
          [["Еда (язык)", "Food (tongue)"], s.food, pal.amber],
          [["Веселье (голова/живот)", "Fun (head/tummy)"], s.fun, pal.pink],
          [["Энергия (антенна назад)", "Energy (antenna back)"], s.energy, pal.blue],
          [["Чистота (хвост)", "Clean (tail)"], s.clean, pal.green],
        ];
        rows.forEach(([label, v, c], i) => {
          const y = h * 0.62 + i * 26;
          text(ctx, api.t(...label), w * 0.1, y, 13, pal.muted, "left", 600);
          bar(ctx, w * 0.5, y - 5, w * 0.4, 10, v / 100, v < 25 ? pal.red : c, pal.surface2);
        });
      },
    };
  }, { lives: 0, tap: null }),
];
