import type { LucideIcon } from "lucide-react";
import type { ComponentType } from "react";
import type { SfxKind } from "@/lib/audio/synth";
import type { InputType, SayKind } from "@/lib/furby/controller";
import type { MoodType } from "@/lib/furby/protocol";
import type { Lang, Text } from "@/lib/i18n";
import type { Fx } from "./kit";

export type Ctl = "antenna" | "antennaLR" | "antennaFB" | "tongue" | "tail" | "tummy" | "head" | "sides" | "tilt" | "shake" | "flip";
export type Cat = "arcade" | "rhythm" | "skill" | "logic" | "party";
export type HoldKey = "tongue" | "tail" | "tummy" | "head" | "sideL" | "sideR";

export interface InputEv {
  type: InputType;
  t: number;
  src: "furby" | "key" | "touch";
}

export interface InputFrame {
  /** Antenna: -1 left … 1 right */
  ax: number;
  /** Antenna: 1 forward … -1 back */
  ay: number;
  /** Smoothed tilt -1..1 */
  tiltX: number;
  tiltY: number;
  held: Record<HoldKey, boolean>;
  events: InputEv[];
  has(type: InputType): boolean;
}

export interface Palette {
  bg: string;
  surface: string;
  surface2: string;
  fg: string;
  muted: string;
  faint: string;
  line: string;
  dark: boolean;
  blue: string;
  red: string;
  green: string;
  amber: string;
  violet: string;
  pink: string;
  cyan: string;
  orange: string;
  lime: string;
  teal: string;
}

export interface GameApi {
  ctx: CanvasRenderingContext2D;
  w: number;
  h: number;
  time: number;
  level: number;
  lang: Lang;
  pal: Palette;
  t(ru: string, en: string): string;
  score: number;
  lives: number;
  ended: boolean;
  add(n: number, x?: number, y?: number): void;
  hurt(): boolean;
  heal(): void;
  over(win?: boolean): void;
  fx: Fx;
  sfx(kind: SfxKind): void;
  vibrate(ms?: number): void;
  speak(text: string): void;
  furby: {
    readonly connected: boolean;
    say(kind: SayKind): void;
    led(r: number, g: number, b: number): void;
    action(i: number, x: number, s: number, p: number): void;
    random(input: number): void;
    mood(type: MoodType, v: number): void;
  };
  canvas(w: number, h: number): HTMLCanvasElement;
  pointer: { x: number; y: number; down: boolean };
  getLevel(key: string): number;
  setLevel(key: string, v: number): void;
}

export interface GameInst {
  update(dt: number, inp: InputFrame): void;
  draw(): void;
  pause?(paused: boolean): void;
  dispose?(): void;
}

export interface GameDef {
  id: string;
  name: Text;
  desc: Text;
  icon: LucideIcon;
  cat: Cat;
  controls: Ctl[];
  featured?: boolean;
  /** 0 = no lives display */
  lives?: number;
  aspect?: number;
  hud?: boolean;
  /** What a tap on the canvas means (default: tongue if the game uses it) */
  tap?: InputType | null;
  levels?: Array<{ name: Text; sub?: Text }>;
  levelUnit?: string;
  create?: (api: GameApi) => GameInst;
  component?: ComponentType<{ onExit(): void }>;
}
