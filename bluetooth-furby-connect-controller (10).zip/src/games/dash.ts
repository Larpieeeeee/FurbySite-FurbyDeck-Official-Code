/** Furby Dash — a Geometry Dash style runner. Every jump is the tongue (or Space / tap). */
import { Zap } from "lucide-react";
import { mulberry32 } from "@/lib/audio/synth";
import type { Text } from "@/lib/i18n";
import { bar, circle, clamp, poly, rr, text } from "./kit";
import type { GameApi, GameDef, GameInst, InputFrame } from "./types";

type Mode = "cube" | "ship" | "ball" | "ufo" | "wave" | "robot" | "spider" | "swing";
interface Obj {
  k: "spike" | "block" | "portal";
  x: number;
  y: number;
  w: number;
  h: number;
  down?: boolean;
  mode?: Mode;
}
interface Seg {
  mode: Mode;
  x0: number;
  x1: number;
  ceil: number | null;
}
interface LevelSpec {
  name: Text;
  modes: Mode[];
  seed: number;
  speed: number;
  diff: number;
  hue: number;
}

const MODE_NAMES: Record<Mode, Text> = {
  cube: ["Куб", "Cube"],
  ship: ["Корабль", "Ship"],
  ball: ["Шар", "Ball"],
  ufo: ["НЛО", "UFO"],
  wave: ["Волна", "Wave"],
  robot: ["Робот", "Robot"],
  spider: ["Паук", "Spider"],
  swing: ["Качели", "Swing"],
};
const MODE_COLORS: Record<Mode, string> = {
  cube: "#22c55e",
  ship: "#ec4899",
  ball: "#f97316",
  ufo: "#a855f7",
  wave: "#06b6d4",
  robot: "#eab308",
  spider: "#ef4444",
  swing: "#84cc16",
};

export const DASH_LEVELS: LevelSpec[] = [
  { name: ["Первый шаг", "First Step"], modes: ["cube", "cube"], seed: 1, speed: 8.4, diff: 0, hue: 215 },
  { name: ["Ракета", "Rocket"], modes: ["cube", "ship", "cube"], seed: 2, speed: 8.6, diff: 0.1, hue: 265 },
  { name: ["Мячик", "Bouncy"], modes: ["cube", "ball", "cube"], seed: 3, speed: 8.7, diff: 0.15, hue: 150 },
  { name: ["НЛО", "UFO"], modes: ["cube", "ufo", "cube"], seed: 4, speed: 8.8, diff: 0.2, hue: 300 },
  { name: ["Волна", "Wave"], modes: ["cube", "wave", "cube"], seed: 5, speed: 8.8, diff: 0.25, hue: 190 },
  { name: ["Робот", "Robot"], modes: ["robot", "cube", "robot"], seed: 6, speed: 9, diff: 0.3, hue: 35 },
  { name: ["Паук", "Spider"], modes: ["cube", "spider", "cube"], seed: 7, speed: 9, diff: 0.35, hue: 345 },
  { name: ["Качели", "Swing"], modes: ["ship", "swing", "cube"], seed: 8, speed: 9.2, diff: 0.4, hue: 55 },
  { name: ["Микстейп", "Mixtape"], modes: ["cube", "ship", "ball", "ufo"], seed: 9, speed: 9.4, diff: 0.5, hue: 120 },
  { name: ["Буря", "Storm"], modes: ["wave", "spider", "robot", "swing"], seed: 10, speed: 9.6, diff: 0.6, hue: 230 },
  { name: ["Хаос", "Chaos"], modes: ["cube", "wave", "ball", "ship", "spider", "ufo"], seed: 11, speed: 10, diff: 0.75, hue: 5 },
  { name: ["Финал", "Finale"], modes: ["robot", "ship", "spider", "wave", "swing", "ball", "cube"], seed: 12, speed: 10.4, diff: 0.9, hue: 280 },
];

const CORRIDOR: Partial<Record<Mode, number>> = { ship: 9, ufo: 9, wave: 9, swing: 9, ball: 6, spider: 6 };
const spike = (x: number, y: number, down = false): Obj => ({ k: "spike", x, y, w: 1, h: 1, down });

function build(spec: LevelSpec) {
  const r = mulberry32(spec.seed * 977 + 13);
  const objs: Obj[] = [];
  const segs: Seg[] = [];
  const segLen = Math.round(54 - spec.diff * 8);
  let x = 0;
  const st = { gc: 4.5, side: false };
  spec.modes.forEach((mode, i) => {
    const ceil = CORRIDOR[mode] ?? null;
    const x0 = x;
    const x1 = x + segLen + (i === 0 ? 10 : 0);
    segs.push({ mode, x0, x1, ceil });
    if (i > 0) objs.push({ k: "portal", x: x0, y: 0, w: 1, h: ceil ?? 4, mode });
    st.gc = (ceil ?? 9) / 2;
    st.side = false;
    let cx = x0 + (i === 0 ? 14 : 7);
    while (cx < x1 - 7) {
      const d = spec.diff;
      if (mode === "cube" || mode === "robot") {
        const p = r();
        const gap = 5.5 - d * 1.3 + r() * 3;
        if (p < 0.3) {
          objs.push(spike(cx, 0));
          cx += 1 + gap;
        } else if (p < 0.5) {
          objs.push(spike(cx, 0), spike(cx + 1, 0));
          cx += 2 + gap;
        } else if (p < 0.6 && d >= 0.3) {
          objs.push(spike(cx, 0), spike(cx + 1, 0), spike(cx + 2, 0));
          cx += 4 + gap;
        } else if (p < 0.82) {
          const w = 3 + Math.floor(r() * 3);
          objs.push({ k: "block", x: cx, y: 0, w, h: 1 });
          if (r() < 0.45 + d * 0.3) objs.push(spike(cx + w + 2.5, 0));
          cx += w + 4 + gap;
        } else {
          objs.push({ k: "block", x: cx, y: 0, w: 2, h: 1 }, { k: "block", x: cx + 4, y: 0, w: 3, h: 2 });
          if (mode === "robot") objs.push({ k: "block", x: cx + 9, y: 0, w: 2, h: 3 });
          cx += (mode === "robot" ? 11 : 7) + gap;
        }
      } else if (mode === "ball" || mode === "spider") {
        st.side = !st.side;
        const n = 2 + Math.floor(r() * (2 + d * 2));
        for (let k = 0; k < n; k++) objs.push(st.side ? spike(cx + k, 0) : spike(cx + k, (ceil ?? 6) - 1, true));
        cx += n + (mode === "spider" ? 3.5 : 5.2) - d + r() * 2;
      } else {
        const c = ceil ?? 9;
        const gapSize = ({ ship: 3.7, ufo: 3.9, wave: 3.3, swing: 3.7 } as Record<string, number>)[mode] - d * 0.6;
        st.gc = clamp(st.gc + (r() * 2 - 1) * (2.1 - d * 0.5), gapSize / 2 + 0.6, c - gapSize / 2 - 0.6);
        const bottom = st.gc - gapSize / 2;
        const top = st.gc + gapSize / 2;
        if (bottom > 0.05) objs.push({ k: "block", x: cx, y: 0, w: 1.5, h: bottom });
        if (top < c - 0.05) objs.push({ k: "block", x: cx, y: top, w: 1.5, h: c - top });
        cx += 1.5 + 4.6 - d + r() * 2;
      }
    }
    x = x1;
  });
  return { objs, segs, length: x + 4 };
}

function create(api: GameApi): GameInst {
  const spec = DASH_LEVELS[api.level] ?? DASH_LEVELS[0];
  const lvl = build(spec);
  const SIZE = 0.9;
  let px = 0;
  let py = 0;
  let vy = 0;
  let gdir = 1;
  let mode: Mode = lvl.segs[0].mode;
  let onGround = true;
  let rot = 0;
  let boost = 0;
  let dead = false;
  let deadT = 0;
  let attempts = 1;
  let attemptT = 1.6;
  let won = false;
  let trail: Array<[number, number]> = [];
  const best = () => api.getLevel(`dash:${api.level}`);

  const segAt = (x: number) => lvl.segs.find((s) => x >= s.x0 && x < s.x1) ?? lvl.segs[lvl.segs.length - 1];

  const reset = () => {
    px = 0;
    py = 0;
    vy = 0;
    gdir = 1;
    mode = lvl.segs[0].mode;
    onGround = true;
    rot = 0;
    dead = false;
    trail = [];
  };

  const die = () => {
    if (dead) return;
    dead = true;
    deadT = 0.7;
    const pct = Math.floor((px / lvl.length) * 100);
    api.setLevel(`dash:${api.level}`, pct);
    api.score = Math.max(api.score, pct);
    api.fx.burst(api.w * 0.28, api.h * 0.5, MODE_COLORS[mode], 26, 260, 4);
    api.fx.shake(7);
    api.sfx("hit");
    api.vibrate(60);
  };

  return {
    update(dt: number, inp: InputFrame) {
      if (won) return;
      if (dead) {
        deadT -= dt;
        if (deadT <= 0) {
          attempts++;
          attemptT = 1.6;
          reset();
        }
        return;
      }
      const hold = inp.held.tongue;
      const press = inp.has("tongue");
      attemptT = Math.max(0, attemptT - dt);
      const seg = segAt(px);
      const prevY = py;
      px += spec.speed * dt;

      switch (mode) {
        case "cube":
          vy -= 90 * gdir * dt;
          if (onGround && (press || hold)) {
            vy = 23 * gdir;
            onGround = false;
            if (gdir === 1) api.fx.burst(api.w * 0.28, api.h - (api.h / 10.5) * 0.8, "#ffffff", 5, 70, 2);
          }
          break;
        case "robot":
          if (onGround && (press || hold)) {
            vy = 15 * gdir;
            onGround = false;
            boost = 0.24;
            if (gdir === 1) api.fx.burst(api.w * 0.28, api.h - (api.h / 10.5) * 0.8, "#ffffff", 5, 70, 2);
          }
          if (!onGround && hold && boost > 0) {
            vy += 78 * gdir * dt;
            boost -= dt;
          } else boost = 0;
          vy -= 90 * gdir * dt;
          break;
        case "ball":
          vy -= 75 * gdir * dt;
          if (onGround && press) {
            gdir = -gdir;
            vy = 4 * gdir;
            onGround = false;
          }
          break;
        case "ufo":
          vy -= 50 * gdir * dt;
          if (press) vy = 13 * gdir;
          vy = Math.max(-14, Math.min(14, vy));
          break;
        case "ship":
          vy += (hold ? 55 : -55) * dt;
          vy = clamp(vy, -10, 10);
          break;
        case "wave":
          vy = (hold ? 1 : -1) * spec.speed;
          break;
        case "spider":
          vy -= 90 * gdir * dt;
          if (onGround && press) {
            gdir = -gdir;
            py = gdir === -1 ? (seg.ceil ?? 6) - SIZE : 0;
            vy = 0;
            onGround = false;
          }
          break;
        case "swing":
          vy -= 50 * gdir * dt;
          if (press) gdir = -gdir;
          vy = clamp(vy, -11, 11);
          break;
      }
      py += vy * dt;
      onGround = false;

      if (py < 0) {
        py = 0;
        if (vy < 0) vy = 0;
        if (gdir === 1) onGround = true;
      }
      const ceil = seg.ceil;
      if (ceil !== null && py + SIZE > ceil) {
        py = ceil - SIZE;
        if (vy > 0) vy = 0;
        if (gdir === -1) onGround = true;
      }
      if (ceil === null && py > 12) py = 12;

      const canLand = mode === "cube" || mode === "robot" || mode === "ball" || mode === "spider";
      for (const o of lvl.objs) {
        if (o.x > px + 2 || o.x + o.w < px - 1) continue;
        if (o.k === "portal") {
          if (o.mode && mode !== o.mode && px + SIZE > o.x + 0.5) {
            mode = o.mode;
            gdir = 1;
            vy = 0;
            api.sfx("whoosh");
            api.furby.led(...hexRgb(MODE_COLORS[mode]));
          }
          continue;
        }
        if (o.k === "block") {
          if (px + SIZE <= o.x || px >= o.x + o.w) continue;
          const top = o.y + o.h;
          if (py < top && py + SIZE > o.y) {
            if (canLand && gdir === 1 && prevY >= top - 0.3 && vy <= 0) {
              py = top;
              vy = 0;
              onGround = true;
            } else if (canLand && gdir === -1 && prevY + SIZE <= o.y + 0.3 && vy >= 0) {
              py = o.y - SIZE;
              vy = 0;
              onGround = true;
            } else die();
          }
        } else {
          const hx = o.x + 0.3;
          const hy = o.down ? o.y + 0.5 : o.y;
          if (px + 0.1 < hx + 0.4 && px + 0.8 > hx && py + 0.1 < hy + 0.5 && py + 0.8 > hy) die();
        }
      }

      if (mode === "cube" || mode === "robot") rot = onGround ? Math.round(rot / (Math.PI / 2)) * (Math.PI / 2) : rot + 7 * dt * gdir;
      else if (mode === "ball") rot += 9 * dt * gdir;
      else rot = Math.atan2(-vy, spec.speed) * 0.8;
      if (mode === "wave") {
        trail.push([px, py]);
        if (trail.length > 40) trail.shift();
      }

      if (!dead && px >= lvl.length) {
        won = true;
        api.setLevel(`dash:${api.level}`, 100);
        api.score = 100 + Math.max(0, 50 - attempts);
        api.fx.burst(api.w / 2, api.h / 2, MODE_COLORS[mode], 40, 300, 4);
        api.over(true);
      }
    },

    draw() {
      const { ctx, w, h, pal } = api;
      const dark = pal.dark;
      const B = h / 10.5;
      const ox = w * 0.28;
      const sx = (x: number) => (x - px) * B + ox;
      const sy = (y: number) => h - B * 0.8 - y * B;
      ctx.fillStyle = `hsl(${spec.hue} 40% ${dark ? 9 : 95}%)`;
      ctx.fillRect(-20, -20, w + 40, h + 40);
      const hills = (factor: number, radius: number, lift: number, light: number) => {
        const off = (((px * factor) % 160) + 160) % 160;
        ctx.fillStyle = `hsl(${spec.hue} 26% ${light}%)`;
        for (let i = -1; i * 160 - off < w + 160; i++) circle(ctx, i * 160 - off, sy(0) - lift, radius, ctx.fillStyle as string);
      };
      hills(0.15, 90, -10, dark ? 13 : 88);
      hills(0.35, 60, -4, dark ? 16 : 80);
      const deco = (factor: number, size: number, alpha: number) => {
        const off2 = (((px * factor) % 340) + 340) % 340;
        ctx.strokeStyle = `hsla(${spec.hue}, 65%, ${dark ? 62 : 42}%, ${alpha})`;
        ctx.lineWidth = 3;
        for (let i = -1; i * 340 - off2 < w + 340; i++) {
          const cx = i * 340 - off2 + 90;
          const cy = h * 0.3;
          ctx.beginPath();
          if ((i & 1) === 0) ctx.rect(cx - size / 2, cy - size / 2, size, size);
          else ctx.arc(cx, cy, size / 2, 0, Math.PI * 2);
          ctx.stroke();
        }
      };
      deco(0.08, 74, 0.2);
      deco(0.16, 130, 0.1);
      ctx.strokeStyle = `hsl(${spec.hue} 30% ${dark ? 16 : 88}%)`;
      ctx.lineWidth = 1;
      for (let gx = Math.floor(px - 8); gx < px + w / B; gx++) {
        if (gx % 2) continue;
        ctx.beginPath();
        ctx.moveTo(sx(gx), 0);
        ctx.lineTo(sx(gx), sy(0));
        ctx.stroke();
      }
      const ground = `hsl(${spec.hue} 35% ${dark ? 17 : 80}%)`;
      const accent = `hsl(${spec.hue} 70% ${dark ? 60 : 45}%)`;
      ctx.fillStyle = ground;
      ctx.fillRect(-20, sy(0), w + 40, h);
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = accent;
      ctx.fillRect(-20, sy(0) - 5, w + 40, 5);
      ctx.globalAlpha = 1;
      ctx.fillStyle = accent;
      ctx.fillRect(-20, sy(0), w + 40, 3);
      ctx.fillStyle = `hsl(${spec.hue} 30% ${dark ? 22 : 70}%)`;
      ctx.fillRect(-20, sy(0) + 5, w + 40, 1);
      for (const s of lvl.segs) {
        if (s.ceil === null || s.x1 < px - 8 || s.x0 > px + w / B) continue;
        ctx.fillStyle = ground;
        ctx.fillRect(sx(s.x0), -20, (s.x1 - s.x0) * B, sy(s.ceil) + 20);
        ctx.fillStyle = accent;
        ctx.fillRect(sx(s.x0), sy(s.ceil) - 2, (s.x1 - s.x0) * B, 2);
      }
      const blockFill = `hsl(${spec.hue} 30% ${dark ? 22 : 72}%)`;
      for (const o of lvl.objs) {
        if (o.x > px + w / B || o.x + o.w < px - 8) continue;
        if (o.k === "block") {
          rr(ctx, sx(o.x), sy(o.y + o.h), o.w * B, o.h * B, 3, blockFill);
          ctx.strokeStyle = accent;
          ctx.lineWidth = 2;
          ctx.strokeRect(sx(o.x) + 1, sy(o.y + o.h) + 1, o.w * B - 2, o.h * B - 2);
        } else if (o.k === "spike") {
          const x0 = sx(o.x);
          if (o.down) poly(ctx, [x0 + 2, sy(o.y + 1), x0 + B - 2, sy(o.y + 1), x0 + B / 2, sy(o.y + 0.1)], pal.fg);
          else poly(ctx, [x0 + 2, sy(o.y), x0 + B - 2, sy(o.y), x0 + B / 2, sy(o.y + 0.9)], pal.fg);
        } else if (o.mode) {
          const c = MODE_COLORS[o.mode];
          const pcx = sx(o.x) + B * 0.5;
          const pcy = sy(o.h / 2);
          const ry = o.h * B * 0.48;
          ctx.globalAlpha = 0.18;
          ctx.fillStyle = c;
          ctx.beginPath();
          ctx.ellipse(pcx, pcy, B * 0.72, ry, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
          ctx.strokeStyle = c;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.ellipse(pcx, pcy, B * 0.72, ry, 0, 0, Math.PI * 2);
          ctx.stroke();
          text(ctx, api.t(...MODE_NAMES[o.mode]), pcx, sy(o.h) - 12, 12, c, "center", 700);
        }
      }
      if (mode === "wave" && trail.length > 1) {
        ctx.strokeStyle = MODE_COLORS.wave;
        ctx.lineWidth = B * 0.25;
        ctx.globalAlpha = 0.5;
        ctx.beginPath();
        trail.forEach(([tx, ty], i) => (i ? ctx.lineTo(sx(tx) + B * 0.45, sy(ty) - B * 0.45) : ctx.moveTo(sx(tx) + B * 0.45, sy(ty) - B * 0.45)));
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
      if (!dead) {
        const cx = ox + (SIZE * B) / 2;
        const cy = sy(py) - (SIZE * B) / 2;
        const s = SIZE * B;
        const c = MODE_COLORS[mode];
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(-rot);
        if (gdir === -1 && (mode === "ship" || mode === "ufo" || mode === "swing" || mode === "robot" || mode === "spider")) ctx.scale(1, -1);
        if (mode === "cube" || mode === "robot" || mode === "spider") {
          rr(ctx, -s / 2, -s / 2, s, s, s * 0.15, c);
          rr(ctx, -s * 0.28, -s * 0.28, s * 0.56, s * 0.56, s * 0.08, pal.dark ? "#0b0b0e" : "#ffffff");
          rr(ctx, -s * 0.16, -s * 0.16, s * 0.32, s * 0.32, s * 0.05, c);
          if (mode !== "cube") {
            ctx.strokeStyle = c;
            ctx.lineWidth = 3;
            for (const lx of mode === "spider" ? [-0.45, -0.15, 0.15, 0.45] : [-0.25, 0.25]) {
              ctx.beginPath();
              ctx.moveTo(lx * s, s / 2);
              ctx.lineTo(lx * s * 1.3, s * 0.72);
              ctx.stroke();
            }
          }
        } else if (mode === "ball") {
          circle(ctx, 0, 0, s / 2, c);
          ctx.strokeStyle = pal.dark ? "#0b0b0e" : "#ffffff";
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(-s / 2, 0);
          ctx.lineTo(s / 2, 0);
          ctx.stroke();
        } else if (mode === "ship" || mode === "swing") {
          poly(ctx, [-s * 0.6, s * 0.35, s * 0.65, 0, -s * 0.6, -s * 0.35, -s * 0.35, 0], c);
        } else if (mode === "ufo") {
          circle(ctx, 0, -s * 0.12, s * 0.28, pal.dark ? "#e4e4e7" : "#ffffff");
          rr(ctx, -s * 0.6, -s * 0.05, s * 1.2, s * 0.32, s * 0.16, c);
        } else {
          poly(ctx, [-s * 0.4, s * 0.3, s * 0.5, 0, -s * 0.4, -s * 0.3], c);
        }
        ctx.restore();
      }
      const finishX = sx(lvl.length);
      if (finishX < w + 80 && finishX > -80) {
        ctx.globalAlpha = 0.95;
        ctx.strokeStyle = accent;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.ellipse(finishX, sy(0) - B * 3.5, B * 1.1, B * 3.5, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = accent;
        ctx.fill();
        ctx.globalAlpha = 1;
        text(ctx, "✓", finishX, sy(0) - B * 3.5, B * 2.2, accent, "center", 800);
      }
      if (attemptT > 0) {
        ctx.globalAlpha = Math.min(1, attemptT);
        text(ctx, `${api.t("Попытка", "Attempt")} ${attempts}`, w / 2, h * 0.62, Math.min(34, w / 12), pal.fg, "center", 800);
        ctx.globalAlpha = 1;
      }
      const pct = clamp(px / lvl.length, 0, 1);
      bar(ctx, w * 0.2, 10, w * 0.6, 8, pct, accent, pal.dark ? "#ffffff22" : "#00000014");
      text(ctx, `${Math.floor(pct * 100)}%`, w * 0.82, 14, 13, pal.fg, "left", 700);
      text(ctx, `${api.t("Попытка", "Attempt")} ${attempts}`, 12, 14, 13, pal.muted, "left", 600);
      text(ctx, `${api.t(...MODE_NAMES[mode])} · ${api.t("рекорд", "best")} ${best()}%`, 12, 34, 12, pal.muted, "left", 500);
    },
  };
}

const hexRgb = (hex: string): [number, number, number] => {
  const v = parseInt(hex.slice(1), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
};

export const dashGame: GameDef = {
  id: "dash",
  featured: true,
  name: ["Furby Dash", "Furby Dash"],
  desc: [
    "Аналог Geometry Dash: 12 уровней и 8 режимов — куб, корабль, шар, НЛО, волна, робот, паук и качели. Прыжок — нажатие на язык.",
    "A Geometry Dash–style runner: 12 levels and 8 modes — cube, ship, ball, UFO, wave, robot, spider and swing. Jump by pressing the tongue.",
  ],
  icon: Zap,
  cat: "arcade",
  controls: ["tongue"],
  lives: 0,
  hud: false,
  aspect: 16 / 9,
  levelUnit: "%",
  levels: DASH_LEVELS.map((l) => ({
    name: l.name,
    sub: [l.modes.map((m) => MODE_NAMES[m][0]).join(" → "), l.modes.map((m) => MODE_NAMES[m][1]).join(" → ")] as Text,
  })),
  create,
};
