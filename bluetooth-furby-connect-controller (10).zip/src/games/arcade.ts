/** Arcade mini games */
import {
  ArrowBigUp, Bird, Blocks, Car, CloudLightning, Cookie, Fish, Footprints, Ghost, Grid2x2, Hammer, Joystick, Layers, Palette, Route,
  Shapes, Star, Target, Volleyball, Wind, Worm, Activity, Bug,
} from "lucide-react";
import type { InputType } from "@/lib/furby/controller";
import { LANE_COLORS, banner, bg, chance, circle, clamp, def, line, pick, poly, rand, randi, ring, rr, star, strokeCircle, text } from "./kit";
import type { GameApi, GameInst, InputFrame } from "./types";

const DIRS: Record<string, [number, number]> = { antL: [-1, 0], antR: [1, 0], antF: [0, -1], antB: [0, 1] };
const dirOf = (inp: InputFrame): [number, number] | null => {
  for (const e of inp.events) if (DIRS[e.type]) return DIRS[e.type];
  return null;
};

function catcher(api: GameApi, mode: "antenna" | "tilt", good: string, bad: string): GameInst {
  let x = api.w / 2;
  let items: Array<{ x: number; y: number; good: boolean; v: number }> = [];
  let t = 0;
  let speed = 1;
  return {
    update(dt, inp) {
      const { w, h } = api;
      speed += dt * 0.02;
      x = clamp(x + (mode === "antenna" ? inp.ax * 0.9 : inp.tiltX * 1.15) * w * dt, 30, w - 30);
      t -= dt;
      if (t <= 0) {
        t = Math.max(0.35, 0.9 / speed);
        items.push({ x: rand(20, w - 20), y: -20, good: !chance(0.25), v: rand(120, 200) * speed });
      }
      for (const it of items) {
        it.y += it.v * dt;
        if (it.y > h - 46 && it.y < h - 20 && Math.abs(it.x - x) < 44) {
          it.y = 9999;
          if (it.good) {
            api.add(10, it.x, h - 60);
            api.sfx("coin");
          } else {
            api.fx.burst(it.x, h - 40, api.pal.red, 16);
            api.hurt();
          }
        }
      }
      items = items.filter((i) => i.y < api.h + 30);
    },
    draw() {
      const { ctx, h } = api;
      bg(api);
      for (const it of items) {
        if (!it.good) circle(ctx, it.x, it.y, 11, bad);
        else if (mode === "antenna") star(ctx, it.x, it.y, 12, good, api.time * 2);
        else {
          circle(ctx, it.x, it.y, 12, good);
          circle(ctx, it.x, it.y, 4, api.pal.bg);
        }
      }
      rr(ctx, x - 44, h - 34, 88, 18, 9, api.pal.fg);
    },
  };
}

export const ARCADE = [
  def("flappy", ["Флаппи-пушок", "Flappy Fluff"], ["Жми язык, чтобы взлетать между трубами.", "Press the tongue to flap between the pipes."], Bird, "arcade", ["tongue"], (api) => {
    let y = api.h / 2;
    let vy = 0;
    let go = false;
    let t = 0;
    let pipes: Array<{ x: number; g: number; p: boolean }> = [];
    return {
      update(dt, inp) {
        const { w, h } = api;
        if (inp.has("tongue")) {
          vy = -h * 0.72;
          go = true;
          api.sfx("jump");
        }
        if (!go) return;
        vy += h * 2.1 * dt;
        y += vy * dt;
        t -= dt;
        if (t <= 0) {
          t = 1.45;
          pipes.push({ x: w + 30, g: rand(h * 0.3, h * 0.7), p: false });
        }
        const gs = h * 0.32;
        for (const p of pipes) {
          p.x -= w * 0.3 * dt;
          if (!p.p && p.x < w * 0.25) {
            p.p = true;
            api.add(1);
            api.sfx("coin");
          }
          if (Math.abs(p.x - w * 0.25) < 40 && Math.abs(y - p.g) > gs / 2 - 14) api.over(false);
        }
        if (y > h - 10 || y < 0) api.over(false);
        pipes = pipes.filter((p) => p.x > -60);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const gs = h * 0.32;
        for (const p of pipes) {
          rr(ctx, p.x - 26, -10, 52, p.g - gs / 2 + 10, 8, pal.green);
          rr(ctx, p.x - 26, p.g + gs / 2, 52, h, 8, pal.green);
        }
        circle(ctx, w * 0.25, y, 14, pal.amber);
        circle(ctx, w * 0.25 + 5, y - 4, 3, "#18181b");
        if (!go) banner(api, api.t("Нажми язык", "Press the tongue"));
      },
    };
  }, { lives: 0 }),

  def("cave", ["Пещера", "Cave Flyer"], ["Держи язык — летишь вверх, отпусти — вниз. Не касайся стен.", "Hold the tongue to rise, release to fall. Don't touch the walls."], Wind, "arcade", ["tongue"], (api) => {
    let y = api.h / 2;
    let vy = 0;
    let off = 0;
    let dist = 0;
    const SEG = 20;
    const n = Math.ceil(api.w / SEG) + 3;
    let gapC = api.h / 2;
    const cols: Array<[number, number]> = Array.from({ length: n }, () => [api.h * 0.15, api.h * 0.85]);
    return {
      update(dt, inp) {
        const { w, h } = api;
        const speed = w * 0.3 + dist * 0.02;
        vy = clamp(vy + (inp.held.tongue ? -1 : 1) * h * 1.7 * dt, -h * 0.6, h * 0.6);
        y += vy * dt;
        off += speed * dt;
        dist += speed * dt;
        while (off > SEG) {
          off -= SEG;
          cols.shift();
          const gap = Math.max(h * 0.32, h * 0.7 - dist * 0.004);
          gapC = clamp(gapC + rand(-h * 0.06, h * 0.06), gap / 2 + 10, h - gap / 2 - 10);
          cols.push([gapC - gap / 2, gapC + gap / 2]);
        }
        const c = cols[Math.floor((w * 0.25 + off) / SEG)];
        if (c && (y < c[0] + 8 || y > c[1] - 8)) api.over(false);
        api.score = Math.floor(dist / 20);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        cols.forEach(([top, bot], i) => {
          const x = i * SEG - off;
          ctx.fillStyle = pal.dark ? "#3f3f46" : "#a1a1aa";
          ctx.fillRect(x, 0, SEG + 1, top);
          ctx.fillRect(x, bot, SEG + 1, h - bot);
        });
        circle(ctx, w * 0.25, y, 10, pal.cyan);
      },
    };
  }, { lives: 0 }),

  def("stack", ["Башня", "Stacker"], ["Жми язык, чтобы уронить блок ровно на башню.", "Press the tongue to drop the block right on top of the tower."], Layers, "arcade", ["tongue"], (api) => {
    const H = 26;
    let blocks: Array<{ x: number; w: number }> = [{ x: api.w / 2 - 90, w: 180 }];
    let cur = { x: 0, w: 180, dir: 1 };
    let speed = 160;
    return {
      update(dt, inp) {
        cur.x += cur.dir * speed * dt;
        if (cur.x < 0 || cur.x + cur.w > api.w) cur.dir *= -1;
        if (!inp.has("tongue")) return;
        const top = blocks[blocks.length - 1];
        const l = Math.max(cur.x, top.x);
        const r = Math.min(cur.x + cur.w, top.x + top.w);
        if (r - l <= 0) {
          api.over(false);
          return;
        }
        const perfect = Math.abs(cur.x - top.x) < 5;
        const nb = perfect ? { x: top.x, w: top.w } : { x: l, w: r - l };
        blocks.push(nb);
        api.add(perfect ? 3 : 1, nb.x + nb.w / 2, api.h * 0.4);
        api.sfx(perfect ? "good" : "pop");
        cur = { x: 0, w: nb.w, dir: 1 };
        speed += 12;
      },
      draw() {
        const { ctx, h } = api;
        bg(api);
        const shift = Math.max(0, blocks.length - Math.floor((h * 0.6) / H));
        blocks.forEach((b, i) => rr(ctx, b.x, h - (i - shift + 1) * H, b.w, H - 2, 4, `hsl(${(i * 23) % 360} 70% 55%)`));
        rr(ctx, cur.x, h - (blocks.length - shift + 1) * H - 4, cur.w, H - 2, 4, `hsl(${(blocks.length * 23) % 360} 70% 55%)`);
      },
    };
  }, { lives: 0 }),

  def("stars", ["Звездопад", "Star Catcher"], ["Лови звёзды корзиной, двигая антенну влево-вправо. Бомбы не лови!", "Catch the stars by moving the antenna left and right. Avoid the bombs!"], Star, "arcade", ["antennaLR"], (api) => catcher(api, "antenna", "#facc15", "#18181b")),

  def("donuts", ["Пончики", "Donut Drop"], ["Наклоняй Фёрби, чтобы ловить пончики тарелкой.", "Tilt Furby to catch donuts on the plate."], Cookie, "arcade", ["tilt"], (api) => catcher(api, "tilt", "#f472b6", "#3f3f46")),

  def("meteors", ["Метеоритный дождь", "Meteor Shower"], ["Наклонами уклоняйся от метеоритов как можно дольше.", "Dodge the meteors by tilting for as long as you can."], CloudLightning, "arcade", ["tilt"], (api) => {
    let x = api.w / 2;
    let rocks: Array<{ x: number; y: number; r: number; v: number }> = [];
    let t = 0;
    let inv = 0;
    return {
      update(dt, inp) {
        const { w, h } = api;
        x = clamp(x + inp.tiltX * w * 1.1 * dt, 16, w - 16);
        inv -= dt;
        t -= dt;
        if (t <= 0) {
          t = Math.max(0.15, 0.7 - api.time * 0.01);
          rocks.push({ x: rand(0, w), y: -20, r: rand(8, 20), v: rand(150, 260) + api.time * 4 });
        }
        for (const r of rocks) {
          r.y += r.v * dt;
          if (inv <= 0 && Math.hypot(r.x - x, r.y - (h - 30)) < r.r + 12) {
            r.y = 9999;
            inv = 1;
            api.hurt();
          }
        }
        rocks = rocks.filter((r) => r.y < h + 30);
        api.score = Math.floor(api.time * 10);
      },
      draw() {
        const { ctx, h, pal } = api;
        bg(api);
        for (const r of rocks) circle(ctx, r.x, r.y, r.r, pal.orange);
        if (inv <= 0 || Math.floor(api.time * 12) % 2) poly(ctx, [x, h - 44, x + 14, h - 16, x - 14, h - 16], pal.blue);
      },
    };
  }),

  def("snake", ["Змейка", "Snake"], ["Поворачивай антенной. Ешь яблоки и не врезайся.", "Steer with the antenna. Eat apples and don't crash."], Worm, "arcade", ["antenna"], (api) => {
    const W = 20;
    const H = 13;
    let snake = [[5, 6], [4, 6], [3, 6]];
    let dir = [1, 0];
    let next = [1, 0];
    let food = [12, 6];
    let t = 0;
    const place = () => {
      do food = [randi(0, W - 1), randi(0, H - 1)];
      while (snake.some(([a, b]) => a === food[0] && b === food[1]));
    };
    return {
      update(dt, inp) {
        const d = dirOf(inp);
        if (d && (d[0] !== -dir[0] || d[1] !== -dir[1])) next = d;
        t -= dt;
        if (t > 0) return;
        t = Math.max(0.07, 0.17 - snake.length * 0.003);
        dir = next;
        const head = [snake[0][0] + dir[0], snake[0][1] + dir[1]];
        if (head[0] < 0 || head[1] < 0 || head[0] >= W || head[1] >= H || snake.some(([a, b]) => a === head[0] && b === head[1])) {
          api.over(false);
          return;
        }
        snake.unshift(head);
        if (head[0] === food[0] && head[1] === food[1]) {
          api.add(10);
          api.sfx("coin");
          place();
        } else snake.pop();
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const c = Math.min(w / W, (h - 30) / H);
        const ox = (w - c * W) / 2;
        const oy = 30;
        ring(ctx, ox, oy, c * W, c * H, 6, pal.line);
        circle(ctx, ox + (food[0] + 0.5) * c, oy + (food[1] + 0.5) * c, c * 0.35, pal.red);
        snake.forEach(([a, b], i) => rr(ctx, ox + a * c + 1, oy + b * c + 1, c - 2, c - 2, c * 0.3, i ? pal.green : pal.lime));
      },
    };
  }, { lives: 0 }),

  def("pong", ["Понг", "Pong"], ["Ракетка двигается антенной вперёд/назад. До 7 очков.", "Move the paddle with the antenna forward/back. First to 7."], Joystick, "arcade", ["antennaFB"], (api) => {
    let py = api.h / 2;
    let ay = api.h / 2;
    let bx = api.w / 2;
    let by = api.h / 2;
    let vx = 260;
    let vy = 120;
    let me = 0;
    let ai = 0;
    const serve = (d: number) => {
      bx = api.w / 2;
      by = api.h / 2;
      vx = 260 * d;
      vy = rand(-160, 160);
    };
    return {
      update(dt, inp) {
        const { w, h } = api;
        py = clamp(py - inp.ay * h * 0.9 * dt, 40, h - 40);
        ay += clamp(by - ay, -h * 0.55 * dt, h * 0.55 * dt);
        bx += vx * dt;
        by += vy * dt;
        if (by < 8 || by > h - 8) vy *= -1;
        if (bx < 30 && Math.abs(by - py) < 44 && vx < 0) {
          vx = -vx * 1.06;
          vy += (by - py) * 4;
          api.sfx("pop");
        }
        if (bx > w - 30 && Math.abs(by - ay) < 44 && vx > 0) {
          vx = -vx * 1.04;
          api.sfx("pop");
        }
        if (bx < 0) {
          ai++;
          serve(1);
        }
        if (bx > w) {
          me++;
          api.add(100);
          serve(-1);
        }
        if (me >= 7 || ai >= 7) api.over(me >= 7);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        line(ctx, w / 2, 0, w / 2, h, pal.line, 2);
        rr(ctx, 14, py - 40, 10, 80, 5, pal.blue);
        rr(ctx, w - 24, ay - 40, 10, 80, 5, pal.red);
        circle(ctx, bx, by, 8, pal.fg);
        text(ctx, `${me} : ${ai}`, w / 2, 40, 28, pal.fg, "center", 800);
      },
    };
  }, { lives: 0, hud: false }),

  def("breakout", ["Арканоид", "Breakout"], ["Ракетка — антенна влево/вправо, язык запускает мяч. Разбей все кирпичи.", "Paddle = antenna left/right, the tongue launches the ball. Break all bricks."], Blocks, "arcade", ["antennaLR", "tongue"], (api) => {
    let px = api.w / 2;
    let ball = { x: 0, y: 0, vx: 0, vy: 0, stuck: true };
    let bricks: Array<{ x: number; y: number; alive: boolean; c: string }> = [];
    let level = 0;
    const build = () => {
      bricks = [];
      for (let r = 0; r < 5 + Math.min(level, 3); r++) for (let c = 0; c < 10; c++) bricks.push({ x: c, y: r, alive: true, c: `hsl(${r * 40 + level * 30} 70% 55%)` });
    };
    build();
    return {
      update(dt, inp) {
        const { w, h } = api;
        px = clamp(px + inp.ax * w * 0.9 * dt, 50, w - 50);
        if (ball.stuck) {
          ball.x = px;
          ball.y = h - 40;
          if (inp.has("tongue")) ball = { x: px, y: h - 40, vx: rand(-150, 150), vy: -(320 + level * 30), stuck: false };
          return;
        }
        ball.x += ball.vx * dt;
        ball.y += ball.vy * dt;
        if (ball.x < 8 || ball.x > w - 8) ball.vx *= -1;
        if (ball.y < 8) ball.vy = Math.abs(ball.vy);
        if (ball.y > h - 34 && ball.y < h - 20 && Math.abs(ball.x - px) < 52 && ball.vy > 0) {
          ball.vy = -Math.abs(ball.vy);
          ball.vx = (ball.x - px) * 6;
          api.sfx("pop");
        }
        if (ball.y > h + 10) {
          ball.stuck = true;
          api.hurt();
        }
        const bw = w / 10;
        for (const b of bricks) {
          if (!b.alive) continue;
          if (ball.x > b.x * bw && ball.x < (b.x + 1) * bw && ball.y > 40 + b.y * 22 && ball.y < 40 + (b.y + 1) * 22) {
            b.alive = false;
            ball.vy *= -1;
            api.add(10);
            api.sfx("coin");
            break;
          }
        }
        if (bricks.every((b) => !b.alive)) {
          level++;
          build();
          ball.stuck = true;
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const bw = w / 10;
        for (const b of bricks) if (b.alive) rr(ctx, b.x * bw + 2, 40 + b.y * 22, bw - 4, 18, 4, b.c);
        rr(ctx, px - 50, h - 30, 100, 12, 6, pal.fg);
        circle(ctx, ball.x, ball.y, 8, pal.amber);
      },
    };
  }),

  def("invaders", ["Захватчики", "Invaders"], ["Наклоняй, чтобы двигать пушку, язык — выстрел.", "Tilt to move the cannon, tongue to fire."], Ghost, "arcade", ["tilt", "tongue"], (api) => {
    let x = api.w / 2;
    let shots: Array<{ x: number; y: number }> = [];
    let bombs: Array<{ x: number; y: number }> = [];
    let aliens: Array<{ c: number; r: number; alive: boolean }> = [];
    let ox = 0;
    let oy = 50;
    let dir = 1;
    let cd = 0;
    let wave = 0;
    const spawn = () => {
      aliens = [];
      for (let r = 0; r < 4; r++) for (let c = 0; c < 8; c++) aliens.push({ c, r, alive: true });
      ox = 0;
      oy = 50;
    };
    spawn();
    return {
      update(dt, inp) {
        const { w, h } = api;
        x = clamp(x + inp.tiltX * w * 1.1 * dt, 20, w - 20);
        cd -= dt;
        if ((inp.has("tongue") || inp.held.tongue) && cd <= 0) {
          cd = 0.35;
          shots.push({ x, y: h - 40 });
          api.sfx("shoot");
        }
        const sp = (40 + wave * 15) * dt;
        ox += dir * sp;
        const gw = Math.min(46, w / 11);
        if (ox < 0 || ox + gw * 8 > w) {
          dir *= -1;
          oy += 16;
        }
        for (const s of shots) s.y -= 480 * dt;
        for (const b of bombs) b.y += 220 * dt;
        for (const a of aliens) {
          if (!a.alive) continue;
          const ax = ox + a.c * gw + gw / 2;
          const ay = oy + a.r * 34;
          if (chance(0.0015 + wave * 0.0005)) bombs.push({ x: ax, y: ay });
          for (const s of shots) {
            if (Math.abs(s.x - ax) < gw * 0.4 && Math.abs(s.y - ay) < 14) {
              a.alive = false;
              s.y = -99;
              api.add(10, ax, ay);
              api.sfx("boom");
            }
          }
          if (ay > h - 60) api.over(false);
        }
        for (const b of bombs) {
          if (Math.abs(b.x - x) < 16 && Math.abs(b.y - (h - 30)) < 14) {
            b.y = 9999;
            api.hurt();
          }
        }
        shots = shots.filter((s) => s.y > 0);
        bombs = bombs.filter((b) => b.y < h);
        if (aliens.every((a) => !a.alive)) {
          wave++;
          spawn();
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const gw = Math.min(46, w / 11);
        for (const a of aliens) {
          if (!a.alive) continue;
          const ax = ox + a.c * gw + gw / 2;
          const ay = oy + a.r * 34;
          rr(ctx, ax - gw * 0.35, ay - 10, gw * 0.7, 20, 6, `hsl(${a.r * 60 + 120} 65% 55%)`);
          circle(ctx, ax - 5, ay - 2, 3, pal.bg);
          circle(ctx, ax + 5, ay - 2, 3, pal.bg);
        }
        for (const s of shots) rr(ctx, s.x - 2, s.y - 8, 4, 12, 2, pal.cyan);
        for (const b of bombs) circle(ctx, b.x, b.y, 4, pal.red);
        poly(ctx, [x, h - 44, x + 16, h - 18, x - 16, h - 18], pal.fg);
      },
    };
  }),

  def("frogger", ["Переход", "Road Hopper"], ["Прыгай антенной по клеткам и перейди дороги, не попав под машины.", "Hop across the roads with the antenna without getting hit."], Footprints, "arcade", ["antenna"], (api) => {
    const ROWS = 9;
    let fx = 4;
    let fy = ROWS - 1;
    let level = 1;
    const lanes = Array.from({ length: ROWS }, (_, r) => ({ speed: r === 0 || r === ROWS - 1 || r === 4 ? 0 : rand(0.6, 1.6) * (r % 2 ? 1 : -1), cars: [rand(0, 9), rand(0, 9)] }));
    return {
      update(dt, inp) {
        const d = dirOf(inp);
        if (d) {
          fx = clamp(fx + d[0], 0, 8);
          fy = clamp(fy + d[1], 0, ROWS - 1);
          api.sfx("tick");
        }
        if (fy === 0) {
          api.add(100 * level, api.w / 2, 40);
          level++;
          fy = ROWS - 1;
          api.sfx("good");
        }
        for (const [r, ln] of lanes.entries()) {
          ln.cars = ln.cars.map((c) => (((c + ln.speed * (1 + level * 0.15) * dt) % 10) + 10) % 10);
          if (r === fy && ln.speed !== 0 && ln.cars.some((c) => Math.abs(c - fx - 0.5) < 0.9)) {
            fy = ROWS - 1;
            api.hurt();
          }
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cw = w / 9;
        const ch = (h - 30) / ROWS;
        lanes.forEach((ln, r) => {
          ctx.fillStyle = ln.speed === 0 ? (pal.dark ? "#14532d" : "#dcfce7") : pal.surface2;
          ctx.fillRect(0, 30 + r * ch, w, ch - 1);
          for (const c of ln.cars) rr(ctx, (c - 0.5) * cw, 30 + r * ch + ch * 0.15, cw * 1.4, ch * 0.7, 6, `hsl(${r * 45} 70% 55%)`);
        });
        circle(ctx, (fx + 0.5) * cw, 30 + (fy + 0.5) * ch, ch * 0.32, pal.green);
      },
    };
  }),

  def("jumper", ["Прыгун", "Sky Jumper"], ["Наклоняй Фёрби влево-вправо и прыгай по платформам всё выше.", "Tilt left and right and bounce up the platforms."], ArrowBigUp, "arcade", ["tilt"], (api) => {
    let x = api.w / 2;
    let y = api.h - 60;
    let vy = 0;
    let cam = 0;
    let maxH = 0;
    let plats = Array.from({ length: 12 }, (_, i) => ({ x: rand(20, api.w - 90), y: api.h - 20 - i * 70 }));
    return {
      update(dt, inp) {
        const { w, h } = api;
        x = (((x + inp.tiltX * w * 1.2 * dt) % w) + w) % w;
        vy += 900 * dt;
        const ny = y + vy * dt;
        if (vy > 0) for (const p of plats) if (x > p.x && x < p.x + 70 && y <= p.y && ny >= p.y) vy = -560;
        y = ny;
        if (y - cam < h * 0.4) cam = y - h * 0.4;
        maxH = Math.max(maxH, -cam);
        api.score = Math.floor(maxH / 10);
        plats = plats.filter((p) => p.y - cam < h + 20);
        while (plats.length < 12) {
          const top = Math.min(...plats.map((p) => p.y));
          plats.push({ x: rand(10, w - 80), y: top - rand(55, 95) });
        }
        if (y - cam > h + 40) api.over(false);
      },
      draw() {
        const { ctx, pal } = api;
        bg(api);
        for (const p of plats) rr(ctx, p.x, p.y - cam, 70, 10, 5, pal.green);
        circle(ctx, x, y - cam - 12, 12, pal.violet);
      },
    };
  }, { lives: 0 }),

  def("racer", ["Гонка", "Road Racer"], ["Рули наклонами и обгоняй машины.", "Steer by tilting and overtake the cars."], Car, "arcade", ["tilt"], (api) => {
    let x = 0.5;
    let cars: Array<{ x: number; y: number; c: string }> = [];
    let t = 0;
    let off = 0;
    let inv = 0;
    return {
      update(dt, inp) {
        const speed = 1 + api.time * 0.02;
        x = clamp(x + inp.tiltX * 0.9 * dt, 0.1, 0.9);
        off = (off + speed * dt * 400) % 60;
        inv -= dt;
        t -= dt;
        if (t <= 0) {
          t = Math.max(0.4, 1.1 / speed);
          cars.push({ x: pick([0.25, 0.5, 0.75]), y: -60, c: pick(["#ef4444", "#22c55e", "#f59e0b", "#a855f7"]) });
        }
        for (const c of cars) {
          c.y += speed * 260 * dt;
          if (inv <= 0 && Math.abs(c.x - x) * api.w < 40 && Math.abs(c.y - (api.h - 70)) < 50) {
            c.y = 9999;
            inv = 1;
            api.hurt();
          }
        }
        cars = cars.filter((c) => c.y < api.h + 80);
        api.score = Math.floor(api.time * 12);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, pal.dark ? "#18181b" : "#d4d4d8");
        for (const lx of [0.375, 0.625]) for (let y = -60 + off; y < h; y += 60) rr(ctx, lx * w - 3, y, 6, 30, 3, pal.dark ? "#52525b" : "#fafafa");
        for (const c of cars) rr(ctx, c.x * w - 22, c.y - 36, 44, 72, 10, c.c);
        if (inv <= 0 || Math.floor(api.time * 12) % 2) rr(ctx, x * w - 22, h - 106, 44, 72, 10, pal.blue);
      },
    };
  }),

  def("lasers", ["Лазеры", "Laser Run"], ["Низкий лазер — прыгай языком, высокий — пригнись антенной назад.", "Low laser — jump with the tongue, high laser — duck with the antenna back."], Activity, "arcade", ["tongue", "antennaFB"], (api) => {
    let jy = 0;
    let vy = 0;
    let duck = 0;
    let lasers: Array<{ x: number; high: boolean; scored: boolean }> = [];
    let t = 1;
    return {
      update(dt, inp) {
        const { w } = api;
        if (inp.has("tongue") && jy <= 0) vy = 520;
        if (inp.has("antB")) duck = 0.6;
        vy -= 1500 * dt;
        jy = Math.max(0, jy + vy * dt);
        duck -= dt;
        t -= dt;
        const speed = 280 + api.time * 6;
        if (t <= 0) {
          t = rand(0.9, 1.6) * (300 / speed);
          lasers.push({ x: w + 20, high: chance(0.45), scored: false });
        }
        for (const l of lasers) {
          l.x -= speed * dt;
          if (Math.abs(l.x - w * 0.2) < 14) {
            const hit = l.high ? duck <= 0 : jy < 30;
            if (hit) {
              l.x = -99;
              api.hurt();
            }
          }
          if (!l.scored && l.x < w * 0.2 - 20) {
            l.scored = true;
            api.add(10);
          }
        }
        lasers = lasers.filter((l) => l.x > -40);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const gy = h * 0.8;
        line(ctx, 0, gy, w, gy, pal.line, 2);
        for (const l of lasers) line(ctx, l.x, l.high ? gy - 70 : gy - 16, l.x, l.high ? gy - 46 : gy, pal.red, 6);
        const ph = duck > 0 ? 28 : 56;
        rr(ctx, w * 0.2 - 14, gy - ph - jy, 28, ph, 10, pal.blue);
      },
    };
  }),

  def("rings", ["Цветные кольца", "Color Rings"], ["Прыгай языком сквозь кольца, только через часть своего цвета.", "Jump through the rings with the tongue, only through your own color."], Palette, "arcade", ["tongue"], (api) => {
    const COLS = [LANE_COLORS[0], LANE_COLORS[1], LANE_COLORS[2], LANE_COLORS[3]];
    let y = 0;
    let vy = 0;
    let cam = 0;
    let color = 0;
    let rings = [0, 1, 2, 3].map((i) => ({ y: -240 - i * 260, rot: rand(0, 6), sp: rand(1.2, 2) * (i % 2 ? 1 : -1), passed: false }));
    const colorAt = (ringRot: number, angle: number) => Math.floor((((angle - ringRot) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2) / (Math.PI / 2));
    return {
      update(dt, inp) {
        if (inp.has("tongue")) {
          vy = -420;
          api.sfx("jump");
        }
        vy += 1000 * dt;
        y += vy * dt;
        if (y > 0) {
          y = 0;
          vy = 0;
        }
        cam = Math.min(cam, y - api.h * 0.1);
        const R = Math.min(api.w, api.h) * 0.24;
        for (const r of rings) {
          r.rot += r.sp * dt;
          for (const [edge, ang] of [[r.y - R, -Math.PI / 2], [r.y + R, Math.PI / 2]] as const) {
            if (Math.abs(y - edge) < 9 && colorAt(r.rot, ang) !== color) api.over(false);
          }
          if (!r.passed && y < r.y - R - 12) {
            r.passed = true;
            api.add(1);
            color = randi(0, 3);
            api.sfx("coin");
          }
        }
        if (rings[0].y - cam > api.h + R) {
          const last = rings[rings.length - 1];
          rings = [...rings.slice(1), { y: last.y - 260, rot: rand(0, 6), sp: rand(1.2, 2.4) * (chance(0.5) ? 1 : -1), passed: false }];
        }
        if (y - cam > api.h) api.over(false);
      },
      draw() {
        const { ctx, w, h } = api;
        bg(api);
        const R = Math.min(w, h) * 0.24;
        const sy = (wy: number) => wy - cam + h * 0.15;
        for (const r of rings) {
          for (let q = 0; q < 4; q++) {
            ctx.strokeStyle = COLS[q];
            ctx.lineWidth = 14;
            ctx.beginPath();
            ctx.arc(w / 2, sy(r.y), R, r.rot + (q * Math.PI) / 2, r.rot + ((q + 1) * Math.PI) / 2);
            ctx.stroke();
          }
        }
        circle(ctx, w / 2, sy(y), 9, COLS[color]);
      },
    };
  }, { lives: 0 }),

  def("pins", ["Иголки", "Pin Shot"], ["Втыкай иглы в крутящийся шар языком, не задевая другие.", "Shoot pins into the spinning ball with the tongue without hitting others."], Target, "arcade", ["tongue"], (api) => {
    let rot = 0;
    let pins: number[] = [];
    let left = 8;
    let level = 1;
    let speed = 1.6;
    const reset = () => {
      pins = Array.from({ length: Math.min(level, 5) }, () => rand(0, Math.PI * 2));
      left = 6 + level;
      speed = 1.4 + level * 0.25;
    };
    reset();
    return {
      update(dt, inp) {
        rot += speed * dt * (1 + 0.3 * Math.sin(api.time * 1.3));
        if (!inp.has("tongue")) return;
        const a = (((Math.PI / 2 - rot) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        if (pins.some((p) => Math.abs(((p - a + Math.PI * 3) % (Math.PI * 2)) - Math.PI) < 0.2)) {
          api.over(false);
          return;
        }
        pins.push(a);
        api.add(1);
        api.sfx("pop");
        if (--left <= 0) {
          level++;
          api.add(10);
          api.sfx("level");
          reset();
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const R = Math.min(w, h) * 0.18;
        const cx = w / 2;
        const cy = h * 0.4;
        for (const p of pins) {
          const a = p + rot;
          line(ctx, cx + Math.cos(a) * R, cy + Math.sin(a) * R, cx + Math.cos(a) * R * 1.9, cy + Math.sin(a) * R * 1.9, pal.fg, 3);
          circle(ctx, cx + Math.cos(a) * R * 1.9, cy + Math.sin(a) * R * 1.9, 5, pal.fg);
        }
        circle(ctx, cx, cy, R, pal.violet);
        text(ctx, String(left), cx, cy, 24, "#fff", "center", 800);
        line(ctx, cx, h - 20, cx, h - 60, pal.fg, 3);
      },
    };
  }, { lives: 0 }),

  def("maze", ["Лабиринт", "Maze"], ["Веди точку антенной к выходу. Каждый лабиринт больше прошлого.", "Guide the dot to the exit with the antenna. Each maze is bigger."], Route, "arcade", ["antenna"], (api) => {
    let size = 6;
    let walls: boolean[][][] = [];
    let p = [0, 0];
    let timeLeft = 90;
    const gen = () => {
      const W = size + 2;
      const H = size;
      walls = Array.from({ length: H }, () => Array.from({ length: W }, () => [true, true, true, true]));
      const seen = new Set<string>();
      const stack = [[0, 0]];
      seen.add("0,0");
      const D = [[0, -1, 0, 2], [1, 0, 1, 3], [0, 1, 2, 0], [-1, 0, 3, 1]];
      while (stack.length) {
        const [x, y] = stack[stack.length - 1];
        const opts = D.filter(([dx, dy]) => x + dx >= 0 && y + dy >= 0 && x + dx < W && y + dy < H && !seen.has(`${x + dx},${y + dy}`));
        if (!opts.length) {
          stack.pop();
          continue;
        }
        const [dx, dy, a, b] = pick(opts);
        walls[y][x][a] = false;
        walls[y + dy][x + dx][b] = false;
        seen.add(`${x + dx},${y + dy}`);
        stack.push([x + dx, y + dy]);
      }
      p = [0, 0];
    };
    gen();
    return {
      update(dt, inp) {
        timeLeft -= dt;
        if (timeLeft <= 0) api.over(api.score > 0);
        const d = dirOf(inp);
        if (!d) return;
        const side = d[1] === -1 ? 0 : d[0] === 1 ? 1 : d[1] === 1 ? 2 : 3;
        if (!walls[p[1]][p[0]][side]) {
          p = [p[0] + d[0], p[1] + d[1]];
          api.sfx("tick");
        }
        if (p[1] === walls.length - 1 && p[0] === walls[0].length - 1) {
          api.add(100 + Math.floor(timeLeft));
          api.sfx("level");
          timeLeft += 20;
          size++;
          gen();
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const H = walls.length;
        const W = walls[0].length;
        const c = Math.min((w - 20) / W, (h - 50) / H);
        const ox = (w - c * W) / 2;
        const oy = 40;
        rr(ctx, ox + (W - 1) * c + 3, oy + (H - 1) * c + 3, c - 6, c - 6, 4, pal.green);
        for (let y = 0; y < H; y++)
          for (let x = 0; x < W; x++) {
            const [t, r, b, l] = walls[y][x];
            const X = ox + x * c;
            const Y = oy + y * c;
            if (t) line(ctx, X, Y, X + c, Y, pal.fg, 2);
            if (r) line(ctx, X + c, Y, X + c, Y + c, pal.fg, 2);
            if (b) line(ctx, X, Y + c, X + c, Y + c, pal.fg, 2);
            if (l) line(ctx, X, Y, X, Y + c, pal.fg, 2);
          }
        circle(ctx, ox + (p[0] + 0.5) * c, oy + (p[1] + 0.5) * c, c * 0.3, pal.blue);
        text(ctx, `${Math.ceil(timeLeft)} ${api.t("с", "s")}`, w - 12, 18, 14, pal.muted, "right", 700);
      },
    };
  }, { lives: 0 }),

  def("fishing", ["Рыбалка", "Fishing"], ["Крючок двигается антенной вперёд/назад, язык — подсечь рыбу. 60 секунд.", "Move the hook with the antenna forward/back, tongue to catch. 60 seconds."], Fish, "arcade", ["antennaFB", "tongue"], (api) => {
    let hook = 0.5;
    let fish: Array<{ x: number; y: number; v: number; s: number }> = [];
    let left = 60;
    return {
      update(dt, inp) {
        left -= dt;
        if (left <= 0) api.over(true);
        hook = clamp(hook - inp.ay * 0.7 * dt, 0.2, 0.95);
        if (fish.length < 6 && chance(dt * 2)) {
          const fromLeft = chance(0.5);
          fish.push({ x: fromLeft ? -30 : api.w + 30, y: rand(0.25, 0.92), v: rand(60, 160) * (fromLeft ? 1 : -1), s: rand(0.6, 1.4) });
        }
        for (const f of fish) f.x += f.v * dt;
        if (inp.has("tongue")) {
          const hx = api.w / 2;
          const hy = hook * api.h;
          const caught = fish.find((f) => Math.abs(f.x - hx) < 30 * f.s && Math.abs(f.y * api.h - hy) < 18);
          if (caught) {
            api.add(Math.round(caught.s * 20), hx, hy);
            api.sfx("good");
            caught.x = -999;
          } else api.sfx("error");
        }
        fish = fish.filter((f) => f.x > -60 && f.x < api.w + 60);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, pal.dark ? "#082f49" : "#e0f2fe");
        line(ctx, w / 2, 0, w / 2, hook * h, pal.fg, 2);
        strokeCircle(ctx, w / 2, hook * h, 8, pal.fg, 2);
        for (const f of fish) {
          const dir = Math.sign(f.v);
          ctx.fillStyle = f.s > 1.1 ? "#f97316" : "#38bdf8";
          ctx.beginPath();
          ctx.ellipse(f.x, f.y * h, 22 * f.s, 10 * f.s, 0, 0, Math.PI * 2);
          ctx.fill();
          poly(ctx, [f.x - dir * 20 * f.s, f.y * h, f.x - dir * 34 * f.s, f.y * h - 9 * f.s, f.x - dir * 34 * f.s, f.y * h + 9 * f.s], ctx.fillStyle as string);
        }
        text(ctx, `${Math.ceil(left)} ${api.t("с", "s")}`, w - 12, 18, 14, pal.muted, "right", 700);
      },
    };
  }, { lives: 0 }),

  def("juggle", ["Жонглёр", "Juggler"], ["Мячи падают в три колонки: антенна влево, язык (центр), антенна вправо.", "Balls fall in three columns: antenna left, tongue (middle), antenna right."], Volleyball, "arcade", ["antennaLR", "tongue"], (api) => {
    let balls: Array<{ c: number; y: number; v: number }> = [];
    let t = 0;
    const KEYS: InputType[] = ["antL", "tongue", "antR"];
    return {
      update(dt, inp) {
        const h = api.h;
        t -= dt;
        if (t <= 0 && balls.length < 3 + Math.floor(api.time / 20)) {
          t = 1.4;
          balls.push({ c: randi(0, 2), y: -20, v: 0 });
        }
        for (const b of balls) {
          b.v += 380 * dt;
          b.y += b.v * dt;
        }
        for (const ev of inp.events) {
          const c = KEYS.indexOf(ev.type);
          if (c < 0) continue;
          const target = balls.filter((b) => b.c === c && b.y > h * 0.6 && b.v > 0).sort((a, b) => b.y - a.y)[0];
          if (target) {
            target.v = -rand(420, 560);
            target.c = clamp(target.c + randi(-1, 1), 0, 2);
            api.add(5);
            api.sfx("pop");
          }
        }
        for (const b of balls) if (b.y > h + 10) {
          b.y = -9999;
          api.hurt();
        }
        balls = balls.filter((b) => b.y > -9000);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        ctx.fillStyle = pal.surface2;
        ctx.fillRect(0, h * 0.6, w, h * 0.4);
        for (let c = 0; c < 3; c++) text(ctx, [api.t("← антенна", "← antenna"), api.t("язык", "tongue"), api.t("антенна →", "antenna →")][c], (c + 0.5) * (w / 3), h - 14, 12, pal.muted);
        for (const b of balls) circle(ctx, (b.c + 0.5) * (w / 3), b.y, 14, LANE_COLORS[b.c]);
      },
    };
  }),

  def("moles", ["Сенсорные кроты", "Sensor Moles"], ["Каждая норка — датчик Фёрби. Бей крота нужным датчиком!", "Each hole is a Furby sensor. Whack the mole with the right sensor!"], Hammer, "arcade", ["head", "tummy", "sides", "tail", "tongue"], (api) => {
    const HOLES: Array<[InputType, string, string]> = [["head", "Голова", "Head"], ["tummy", "Живот", "Tummy"], ["sideL", "Лев. бок", "Left side"], ["sideR", "Прав. бок", "Right side"], ["tail", "Хвост", "Tail"], ["tongue", "Язык", "Tongue"]];
    let mole = -1;
    let up = 0;
    let wait = 1;
    let left = 60;
    return {
      update(dt, inp) {
        left -= dt;
        if (left <= 0) api.over(true);
        if (mole < 0) {
          wait -= dt;
          if (wait <= 0) {
            mole = randi(0, 5);
            up = Math.max(1.2, 2.6 - api.time * 0.02);
          }
          return;
        }
        up -= dt;
        for (const ev of inp.events) {
          if (ev.type === HOLES[mole][0]) {
            api.add(20, api.w / 2, api.h / 2);
            api.sfx("good");
            mole = -1;
            wait = rand(0.3, 0.9);
            return;
          }
        }
        if (up <= 0) {
          mole = -1;
          wait = 0.5;
          api.sfx("error");
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cw = w / 3;
        const ch = (h - 40) / 2;
        HOLES.forEach(([, ru, en], i) => {
          const cx = (i % 3 + 0.5) * cw;
          const cy = 40 + (Math.floor(i / 3) + 0.55) * ch;
          ctx.fillStyle = pal.surface2;
          ctx.beginPath();
          ctx.ellipse(cx, cy + 20, cw * 0.32, 18, 0, 0, Math.PI * 2);
          ctx.fill();
          if (i === mole) {
            circle(ctx, cx, cy, 30, "#a16207");
            circle(ctx, cx - 9, cy - 6, 4, "#fff");
            circle(ctx, cx + 9, cy - 6, 4, "#fff");
          }
          text(ctx, api.t(ru, en), cx, cy + 50, 13, i === mole ? pal.fg : pal.muted, "center", 700);
        });
        text(ctx, `${Math.ceil(left)} ${api.t("с", "s")}`, w - 12, 18, 14, pal.muted, "right", 700);
      },
    };
  }, { lives: 0 }),

  def("flies", ["Охота на мух", "Fly Hunt"], ["Прицел двигается антенной, язык ловит муху. 45 секунд.", "Move the aim with the antenna, catch flies with the tongue. 45 seconds."], Bug, "arcade", ["antenna", "tongue"], (api) => {
    let ax = api.w / 2;
    let ay = api.h / 2;
    let left = 45;
    let flies = Array.from({ length: 4 }, () => ({ x: rand(0, api.w), y: rand(0, api.h), a: rand(0, 6) }));
    return {
      update(dt, inp) {
        left -= dt;
        if (left <= 0) api.over(true);
        ax = clamp(ax + inp.ax * api.w * 0.6 * dt, 0, api.w);
        ay = clamp(ay - inp.ay * api.h * 0.6 * dt, 0, api.h);
        for (const f of flies) {
          f.a += rand(-4, 4) * dt;
          f.x = (f.x + Math.cos(f.a) * 120 * dt + api.w) % api.w;
          f.y = (f.y + Math.sin(f.a) * 120 * dt + api.h) % api.h;
        }
        if (inp.has("tongue")) {
          const f = flies.find((q) => Math.hypot(q.x - ax, q.y - ay) < 34);
          if (f) {
            api.add(10, f.x, f.y);
            api.sfx("good");
            f.x = rand(0, api.w);
            f.y = rand(0, api.h);
          } else api.sfx("error");
        }
      },
      draw() {
        const { ctx, w, pal } = api;
        bg(api);
        for (const f of flies) {
          circle(ctx, f.x, f.y, 5, pal.fg);
          ctx.globalAlpha = 0.4;
          circle(ctx, f.x - 5, f.y - 4, 4, pal.muted);
          circle(ctx, f.x + 5, f.y - 4, 4, pal.muted);
          ctx.globalAlpha = 1;
        }
        strokeCircle(ctx, ax, ay, 30, pal.red, 2);
        line(ctx, ax - 38, ay, ax + 38, ay, pal.red, 1);
        line(ctx, ax, ay - 38, ax, ay + 38, pal.red, 1);
        text(ctx, `${Math.ceil(left)} ${api.t("с", "s")}`, w - 12, 18, 14, pal.muted, "right", 700);
      },
    };
  }, { lives: 0 }),

  def("tetris", ["Тетрис", "Tetris"], ["Антенна влево/вправо — двигать, вперёд — повернуть, назад — ускорить, язык — сбросить.", "Antenna left/right moves, forward rotates, back speeds up, tongue drops."], Shapes, "arcade", ["antenna", "tongue"], (api) => {
    const W = 10;
    const H = 20;
    const SHAPES = [[[1, 1, 1, 1]], [[1, 1], [1, 1]], [[0, 1, 0], [1, 1, 1]], [[1, 0, 0], [1, 1, 1]], [[0, 0, 1], [1, 1, 1]], [[1, 1, 0], [0, 1, 1]], [[0, 1, 1], [1, 1, 0]]];
    const COL = ["#06b6d4", "#facc15", "#a855f7", "#3b82f6", "#f97316", "#ef4444", "#22c55e"];
    const grid: number[][] = Array.from({ length: H }, () => Array(W).fill(0));
    let piece = { s: SHAPES[0], c: 1, x: 3, y: 0 };
    let t = 0;
    let lines = 0;
    const fits = (s: number[][], x: number, y: number) => s.every((row, r) => row.every((v, c) => !v || (x + c >= 0 && x + c < W && y + r < H && (y + r < 0 || !grid[y + r][x + c]))));
    const spawn = () => {
      const i = randi(0, 6);
      piece = { s: SHAPES[i], c: i + 1, x: 3, y: -1 };
      if (!fits(piece.s, piece.x, piece.y + 1)) api.over(false);
    };
    const lock = () => {
      piece.s.forEach((row, r) => row.forEach((v, c) => { if (v && piece.y + r >= 0) grid[piece.y + r][piece.x + c] = piece.c; }));
      let cleared = 0;
      for (let r = H - 1; r >= 0; r--) if (grid[r].every((v) => v)) {
        grid.splice(r, 1);
        grid.unshift(Array(W).fill(0));
        cleared++;
        r++;
      }
      if (cleared) {
        lines += cleared;
        api.add([0, 100, 300, 500, 800][cleared]);
        api.sfx("level");
      }
      spawn();
    };
    spawn();
    return {
      update(dt, inp) {
        for (const e of inp.events) {
          if (e.type === "antL" && fits(piece.s, piece.x - 1, piece.y)) piece.x--;
          if (e.type === "antR" && fits(piece.s, piece.x + 1, piece.y)) piece.x++;
          if (e.type === "antF") {
            const rot = piece.s[0].map((_, c) => piece.s.map((row) => row[c]).reverse());
            if (fits(rot, piece.x, piece.y)) piece.s = rot;
          }
          if (e.type === "tongue") {
            while (fits(piece.s, piece.x, piece.y + 1)) piece.y++;
            lock();
            return;
          }
        }
        t -= dt * (inp.ay < 0 ? 8 : 1);
        if (t <= 0) {
          t = Math.max(0.1, 0.7 - lines * 0.02);
          if (fits(piece.s, piece.x, piece.y + 1)) piece.y++;
          else lock();
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const c = Math.min((h - 20) / H, (w * 0.6) / W);
        const ox = (w - c * W) / 2;
        const oy = 10;
        ring(ctx, ox - 2, oy - 2, c * W + 4, c * H + 4, 4, pal.line);
        grid.forEach((row, r) => row.forEach((v, cc) => v && rr(ctx, ox + cc * c + 1, oy + r * c + 1, c - 2, c - 2, 3, COL[v - 1])));
        piece.s.forEach((row, r) => row.forEach((v, cc) => v && piece.y + r >= 0 && rr(ctx, ox + (piece.x + cc) * c + 1, oy + (piece.y + r) * c + 1, c - 2, c - 2, 3, COL[piece.c - 1])));
        text(ctx, `${api.t("Линии", "Lines")}: ${lines}`, ox + c * W + 14, 40, 14, pal.muted, "left", 600);
      },
    };
  }, { lives: 0, aspect: 1 }),

  def("g2048", ["2048", "2048"], ["Сдвигай плитки антенной и соединяй одинаковые.", "Slide tiles with the antenna and merge equal ones."], Grid2x2, "arcade", ["antenna"], (api) => {
    let g = Array.from({ length: 4 }, () => Array(4).fill(0) as number[]);
    const add = () => {
      const free: Array<[number, number]> = [];
      g.forEach((row, r) => row.forEach((v, c) => !v && free.push([r, c])));
      if (free.length) {
        const [r, c] = pick(free);
        g[r][c] = chance(0.9) ? 2 : 4;
      }
    };
    add();
    add();
    const slide = (row: number[]) => {
      const a = row.filter((v) => v);
      for (let i = 0; i < a.length - 1; i++) if (a[i] === a[i + 1]) {
        a[i] *= 2;
        api.add(a[i]);
        a.splice(i + 1, 1);
      }
      while (a.length < 4) a.push(0);
      return a;
    };
    const canMove = () => g.some((row, r) => row.some((v, c) => !v || row[c + 1] === v || g[r + 1]?.[c] === v));
    return {
      update(_dt, inp) {
        const d = dirOf(inp);
        if (!d) return;
        const before = JSON.stringify(g);
        const T = (m: number[][]) => m[0].map((_, c) => m.map((row) => row[c]));
        if (d[0] === -1) g = g.map(slide);
        if (d[0] === 1) g = g.map((r) => slide([...r].reverse()).reverse());
        if (d[1] === -1) g = T(T(g).map(slide));
        if (d[1] === 1) g = T(T(g).map((r) => slide([...r].reverse()).reverse()));
        if (JSON.stringify(g) !== before) {
          add();
          api.sfx("pop");
        }
        if (!canMove()) api.over(false);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const s = Math.min(w, h - 40) * 0.9;
        const c = s / 4;
        const ox = (w - s) / 2;
        const oy = 30;
        g.forEach((row, r) => row.forEach((v, cc) => {
          rr(ctx, ox + cc * c + 4, oy + r * c + 4, c - 8, c - 8, 10, v ? `hsl(${(Math.log2(v) * 30) % 360} 70% ${pal.dark ? 45 : 60}%)` : pal.surface2);
          if (v) text(ctx, String(v), ox + cc * c + c / 2, oy + r * c + c / 2, c * (v > 999 ? 0.25 : 0.32), "#fff", "center", 800);
        }));
      },
    };
  }, { lives: 0, aspect: 1 }),
];
