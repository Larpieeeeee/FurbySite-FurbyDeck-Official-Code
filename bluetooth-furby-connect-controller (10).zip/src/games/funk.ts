/** Furby Funk — a Friday Night Funkin' style rhythm battle. The antenna is the 4 arrows. */
import { Mic } from "lucide-react";
import { audio, compose, sfx, degMidi, hat, mtof, scheduleBar, tone, voice, type ScaleName, type SongSpec, type Timbre, type MNote } from "@/lib/audio/synth";
import type { Text } from "@/lib/i18n";
import type { CustomLevel } from "@/lib/funkLevels";
import { settings } from "@/lib/settings";
import { LANE_COLORS, arrow, circle, clamp, laneOf, poly, rr, text } from "./kit";
import type { GameApi, GameDef, GameInst, InputEv, InputFrame } from "./types";

interface Char {
  name: Text;
  color: string;
  kind: number;
  timbre: Timbre;
}

export const FUNK_CHARS: Char[] = [
  { name: ["Бип", "Beep"], color: "#06b6d4", kind: 0, timbre: { formants: [700, 1800], type: "square", vib: 0.4, gain: 0.4 } },
  { name: ["Мята", "Mint"], color: "#22c55e", kind: 1, timbre: { formants: [820, 1180] } },
  { name: ["Гром", "Thunder"], color: "#8b5cf6", kind: 2, timbre: { formants: [460, 820], vib: 1.4 } },
  { name: ["Неон", "Neon"], color: "#ec4899", kind: 3, timbre: { formants: [420, 2100] } },
  { name: ["Король Пух", "King Fluff"], color: "#f59e0b", kind: 4, timbre: { formants: [600, 1000], vib: 1.2 } },
];
const PLAYER: Char = { name: ["Ты", "You"], color: "#3b82f6", kind: 5, timbre: { formants: [760, 1320] } };

interface Song {
  name: Text;
  char: number;
  spec: SongSpec;
}
const S = (ru: string, en: string, char: number, seed: number, bpm: number, scale: ScaleName, style: number, density: number, root = 57): Song => ({
  name: [ru, en],
  char,
  spec: { seed, bpm, scale, root, style, density },
});

export const FUNK_SONGS: Song[] = [
  S("Разогрев", "Warm-up", 0, 201, 100, "major", 0, 0.25),
  S("Схема", "Circuit", 0, 202, 110, "minor", 1, 0.35),
  S("Перезагрузка", "Reboot", 0, 203, 120, "penta", 0, 0.45),
  S("Чай с мятой", "Mint Tea", 1, 204, 104, "major", 3, 0.3, 60),
  S("Свежесть", "Fresh", 1, 205, 116, "mixo", 1, 0.4, 60),
  S("Сад", "Garden", 1, 206, 124, "dorian", 0, 0.5, 60),
  S("Тучи", "Clouds", 2, 207, 120, "minor", 2, 0.4, 55),
  S("Молния", "Lightning", 2, 208, 132, "minor", 2, 0.5, 55),
  S("Буря", "Storm", 2, 209, 140, "dorian", 1, 0.6, 55),
  S("Неон", "Neon Lights", 3, 210, 128, "minor", 0, 0.5),
  S("Полночь", "Midnight", 3, 211, 136, "penta", 1, 0.6),
  S("Форсаж", "Overdrive", 3, 212, 146, "minor", 2, 0.65),
  S("Трон", "Throne", 4, 213, 130, "major", 2, 0.55, 58),
  S("Корона", "Crown", 4, 214, 144, "mixo", 0, 0.65, 58),
  S("Финал", "Finale", 4, 215, 156, "minor", 2, 0.75, 58),
];

interface Note {
  time: number;
  lane: number;
  deg: number;
  len: number;
  who: 0 | 1;
  state: 0 | 1 | 2;
  sched: boolean;
}

const DIRX = [-1, 0, 0, 1];
const DIRY = [0, 1, -1, 0];

const RATINGS: Array<{ name: Text; points: number; heal: number; acc: number }> = [
  { name: ["Отлично!", "Sick!"], points: 350, heal: 0.023, acc: 1 },
  { name: ["Хорошо", "Good"], points: 200, heal: 0.014, acc: 0.75 },
  { name: ["Плохо", "Bad"], points: 100, heal: 0.005, acc: 0.4 },
];

interface Look {
  hair: string;
  jacket: string;
  shirt: string;
  pants: string;
  skin: string;
}
/** Original stage singers: mic, hoodie, distinct silhouettes — no third-party designs. */
export const LOOKS: Look[] = [
  { hair: "#7ff2d8", jacket: "#0f9b8e", shirt: "#e6fffb", pants: "#243b4a", skin: "#cfd8dc" },
  { hair: "#22c55e", jacket: "#5b8c5a", shirt: "#eafff9", pants: "#334155", skin: "#ffd9b8" },
  { hair: "#8b5cf6", jacket: "#3f3f46", shirt: "#f5f5f4", pants: "#1f2937", skin: "#f3c9a0" },
  { hair: "#ec4899", jacket: "#7c4dff", shirt: "#f5d0fe", pants: "#1e1b4b", skin: "#f6c8a8" },
  { hair: "#ffd166", jacket: "#cf8a12", shirt: "#fff7dd", pants: "#4a3410", skin: "#ffd9b8" },
  { hair: "#1f2937", jacket: "#f5f5f4", shirt: "#ffffff", pants: "#2f7de1", skin: "#ffd9b8" },
];

function drawHead(ctx: CanvasRenderingContext2D, ch: Char, cx: number, cy: number, r: number, facing: number, blink = false) {
  const look = LOOKS[ch.kind] ?? LOOKS[5];
  circle(ctx, cx, cy, r, look.skin);
  ctx.strokeStyle = "#0c1013";
  ctx.lineWidth = Math.max(2, r * 0.16);
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
  switch (ch.kind) {
    case 0:
      rr(ctx, cx - r, cy - r * 1.1, r * 2, r * 1.7, r * 0.4, look.hair);
      rr(ctx, cx - r * 0.7, cy - r * 0.35, r * 1.4, r * 0.5, r * 0.2, "#0c1013");
      circle(ctx, cx, cy - r * 1.3, r * 0.16, "#ff5c85");
      break;
    case 1:
      poly(ctx, [cx - r, cy - r * 0.3, cx + r, cy - r * 0.3, cx + r * 0.6, cy - r * 1.15, cx - r * 0.6, cy - r * 1.05], look.hair);
      circle(ctx, cx - r * 0.1, cy - r * 1.35, r * 0.3, "#16a34a");
      circle(ctx, cx + r * 0.45, cy - r * 1.5, r * 0.28, "#22c55e");
      break;
    case 2:
      poly(ctx, [cx - r * 0.75, cy - r * 0.7, cx - r * 0.4, cy - r * 1.8, cx, cy - r * 0.8, cx + r * 0.4, cy - r * 1.8, cx + r * 0.75, cy - r * 0.7], look.hair);
      rr(ctx, cx - r * 0.85, cy - r * 0.4, r * 1.7, r * 0.55, r * 0.2, "#18181b");
      break;
    case 3:
      poly(ctx, [cx - r * 1.15, cy + r * 0.3, cx - r * 0.95, cy - r * 1.5, cx + r * 0.95, cy - r * 1.5, cx + r * 1.15, cy + r * 0.3], look.jacket);
      rr(ctx, cx - r * 0.7, cy - r * 0.3, r * 1.4, r * 0.4, r * 0.18, "#ff2d95");
      break;
    case 4:
      poly(ctx, [cx - r, cy - r * 0.6, cx - r, cy - r * 1.6, cx - r * 0.4, cy - r * 1.15, cx, cy - r * 1.8, cx + r * 0.4, cy - r * 1.15, cx + r, cy - r * 1.6, cx + r, cy - r * 0.6], "#ffd166");
      break;
    default:
      poly(ctx, [cx - r, cy - r * 0.25, cx - r * 0.62, cy - r * 1.55, cx - r * 0.18, cy - r * 0.75, cx + r * 0.18, cy - r * 1.65, cx + r * 0.6, cy - r * 0.7, cx + r, cy - r * 1.3, cx + r, cy - r * 0.2], look.hair);
      break;
  }
  if (blink) {
    ctx.strokeStyle = "#18181b";
    ctx.lineWidth = Math.max(1.5, r * 0.16);
    ctx.beginPath();
    ctx.moveTo(cx + facing * r * 0.14, cy - r * 0.1);
    ctx.lineTo(cx + facing * r * 0.48, cy - r * 0.1);
    ctx.stroke();
  } else {
    circle(ctx, cx + facing * r * 0.3, cy - r * 0.1, r * 0.2, "#ffffff");
    circle(ctx, cx + facing * r * 0.36, cy - r * 0.08, r * 0.1, "#18181b");
  }
}

function drawChar(ctx: CanvasRenderingContext2D, ch: Char, x: number, y: number, s: number, bob: number, sing: { lane: number; k: number } | null, facing = 1, anim: { phase: number; time: number; miss: number } = { phase: 0, time: 0, miss: 0 }) {
  const look = LOOKS[ch.kind] ?? LOOKS[5];
  const micUp = !!sing;
  const stiff = ch.kind === 0; // robot moves mechanically
  const amp = ch.kind === 2 ? 1.3 : stiff ? 0.5 : 1;
  const sway = stiff ? 0 : Math.sin((anim.time + anim.phase) * 1.15) * 0.05;
  const bounce = micUp ? 0 : Math.sin((anim.time + anim.phase) * 2.4) * s * 0.015;
  const tapY = !micUp && Math.sin((anim.time + anim.phase) * 3.2) > 0.35 ? -s * 0.025 : 0;
  const blink = !micUp && Math.sin((anim.time + anim.phase) * 0.8) > 0.985;
  ctx.save();
  ctx.translate(x, y + bounce);
  if (facing < 0) ctx.scale(-1, 1);
  if (anim.miss > 0) {
    ctx.translate(Math.sin(anim.time * 55) * anim.miss * 5, 0);
    ctx.rotate(-0.14 * anim.miss);
  }
  const k = sing ? sing.k : 0;
  const lane = sing ? sing.lane : -1;
  if (micUp) {
    const dirWorld = lane === 3 ? 1 : lane === 0 ? -1 : 0;
    if (dirWorld !== 0) {
      // ← / → : lunge sideways in the arrow's direction (mirror-aware for the player)
      ctx.translate(facing * dirWorld * k * s * 0.12, 0);
      ctx.rotate(facing * dirWorld * 0.13 * k);
    } else if (lane === 2) {
      // ↑ : stretch upward
      ctx.translate(0, -k * s * 0.07);
      ctx.rotate(facing * -0.05 * k);
      ctx.scale(1 - 0.05 * k, 1 + 0.13 * k);
    } else if (lane === 1) {
      // ↓ : crouch down
      ctx.scale(1 + 0.09 * k, 1 - 0.15 * k);
      ctx.rotate(facing * 0.04 * k);
    } else {
      ctx.rotate(-0.1 * k);
    }
  } else ctx.rotate(sway);
  ctx.scale(1 + bob * 0.06 * amp, 1 - bob * 0.1 * amp);
  const w = s * 0.3;
  rr(ctx, -w * 0.44, -s * 0.3, w * 0.34, s * 0.3, s * 0.05, look.pants);
  rr(ctx, w * 0.1, -s * 0.3, w * 0.34, s * 0.3, s * 0.05, look.pants);
  rr(ctx, -w * 0.54, -s * 0.06, w * 0.48, s * 0.07, s * 0.03, "#111827");
  rr(ctx, w * 0.06, -s * 0.06 + tapY, w * 0.48, s * 0.07, s * 0.03, "#111817");
  rr(ctx, -w / 2, -s * 0.64, w, s * 0.36, s * 0.07, look.jacket);
  ctx.strokeStyle = "#0c1013";
  ctx.lineWidth = Math.max(2, s * 0.025);
  ctx.beginPath();
  ctx.roundRect(-w / 2, -s * 0.64, w, s * 0.36, s * 0.07);
  ctx.stroke();
  rr(ctx, -w * 0.14, -s * 0.62, w * 0.28, s * 0.3, s * 0.04, look.shirt);
  const armY = !micUp ? -s * 0.54 : lane === 2 ? -s * 0.99 : lane === 1 ? -s * 0.6 : -s * 0.86;
  rr(ctx, w * 0.32, armY, w * 0.2, s * 0.26, s * 0.06, look.jacket);
  rr(ctx, w * 0.58, armY - s * 0.05, w * 0.08, s * 0.16, s * 0.03, "#52525b");
  circle(ctx, w * 0.62, armY - s * 0.07, s * 0.06, "#27272a");
  drawHead(ctx, ch, 0, -s * 0.78, s * 0.17, 1, blink);
  const open = micUp ? s * 0.055 : 2;
  ctx.fillStyle = "#18181b";
  ctx.beginPath();
  ctx.ellipse(s * 0.05, -s * 0.71, s * 0.05, open / 1.7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawStage(api: GameApi, opp: Char, player: Char, pulse: number, floorY: number, scene = "theater") {
  const { ctx, w, h } = api;
  if (scene === "club") {
    ctx.fillStyle = "#140a2e";
    ctx.fillRect(-20, -20, w + 40, h + 40);
    const t = api.time;
    circle(ctx, w / 2, 58, 26, "#c9ccd4");
    ctx.save();
    ctx.beginPath();
    ctx.arc(w / 2, 58, 26, 0, Math.PI * 2);
    ctx.clip();
    for (let i = 0; i < 8; i++) {
      const a = t * 0.8 + (i * Math.PI) / 4;
      ctx.fillStyle = i % 2 ? "#ffffff66" : "#00000033";
      ctx.fillRect(w / 2 + Math.cos(a) * 26 - 9, 58 + Math.sin(a) * 26 - 9, 18, 18);
    }
    ctx.restore();
    const spot = ["#ff5c85", "#7ff2d8", "#ffd166"];
    for (let i = 0; i < 3; i++) {
      const sway = Math.sin(t * 0.7 + i * 2.1) * w * 0.3;
      ctx.globalAlpha = 0.1 + 0.12 * pulse;
      ctx.fillStyle = spot[i];
      poly(ctx, [w * (0.2 + i * 0.3) - 8, 16, w * (0.2 + i * 0.3) + 8, 16, w / 2 + sway + 70, floorY, w / 2 + sway - 70, floorY], ctx.fillStyle as string);
      ctx.globalAlpha = 1;
    }
    for (let i = 0; i < 18; i++) {
      const bw = w / 18;
      const amp = (0.15 + 0.85 * (0.5 + 0.5 * Math.sin(t * 3 + i * 1.7))) * (0.35 + 0.65 * pulse) * floorY * 0.42;
      ctx.fillStyle = i % 2 ? "#241447" : "#2c1a55";
      ctx.fillRect(i * bw + 1, floorY - amp, bw - 2, amp);
    }
    ctx.fillStyle = "#1b1038";
    ctx.fillRect(-20, floorY, w + 40, h - floorY + 40);
    ctx.fillStyle = player.color;
    ctx.fillRect(-20, floorY, w + 40, 2);
    return;
  }
  if (scene === "street") {
    ctx.fillStyle = "#0a0f1e";
    ctx.fillRect(-20, -20, w + 40, h + 40);
    circle(ctx, w * 0.82, 66, 26, "#e8eef7");
    circle(ctx, w * 0.82 + 10, 60, 24, "#0a0f1e");
    for (let i = 0; i < 8; i++) {
      const bw = w / 8;
      const bh = 90 + ((i * 97) % 5) * 38;
      ctx.fillStyle = "#131a2e";
      ctx.fillRect(i * bw, floorY - bh, bw - 4, bh);
      for (let wy = 0; wy < 4; wy++)
        for (let wx = 0; wx < 3; wx++)
          if ((i + wy * 3 + wx) % 3 === 0) {
            ctx.fillStyle = (Math.floor(api.time * 0.4) + i + wx) % 5 === 0 ? "#ffd16666" : "#3b4a7a55";
            ctx.fillRect(i * bw + 8 + wx * 14, floorY - bh + 10 + wy * 20, 8, 11);
          }
    }
    ctx.globalAlpha = 0.55 + 0.45 * Math.sin(api.time * 3);
    ctx.strokeStyle = "#ff5c85";
    ctx.lineWidth = 3;
    ctx.strokeRect(w * 0.1, floorY - 140, 96, 48);
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#17171f";
    ctx.fillRect(-20, floorY, w + 40, h - floorY + 40);
    ctx.fillStyle = player.color;
    ctx.fillRect(-20, floorY, w + 40, 2);
    return;
  }
  ctx.fillStyle = "#12121a";
  ctx.fillRect(-20, -20, w + 40, h + 40);
  ctx.fillStyle = "#3a1220";
  ctx.fillRect(-20, -20, w * 0.1 + 20, h + 40);
  ctx.fillRect(w - w * 0.1, -20, w * 0.1 + 20, h + 40);
  ctx.fillStyle = "#4a1728";
  ctx.fillRect(-20, -20, w + 40, 26);
  for (let i = 0; i < 4; i++) {
    const col = i % 2 ? opp.color : player.color;
    ctx.globalAlpha = 0.25 + 0.75 * pulse;
    circle(ctx, w * (0.18 + i * 0.22), 18, 7 + pulse * 3, col);
    ctx.globalAlpha = 1;
  }
  const st = api.time;
  for (let i = 0; i < 18; i++) {
    const bw2 = w / 18;
    const amp = (0.15 + 0.85 * (0.5 + 0.5 * Math.sin(st * 3 + i * 1.7))) * (0.35 + 0.65 * pulse) * floorY * 0.45;
    ctx.fillStyle = i % 2 ? "#1b2030" : "#221826";
    ctx.fillRect(i * bw2 + 1, floorY - amp, bw2 - 2, amp);
  }
  for (let i = 0; i < 4; i++) {
    const lx = w * (0.18 + i * 0.22);
    ctx.globalAlpha = 0.05 + 0.1 * pulse;
    ctx.fillStyle = i % 2 ? opp.color : player.color;
    poly(ctx, [lx - 7, 24, lx + 7, 24, lx + 52, floorY, lx - 52, floorY], ctx.fillStyle as string);
    ctx.globalAlpha = 1;
  }
  const sw = Math.min(w * 0.15, 120);
  const sh = Math.min(floorY - 46, 240);
  if (sh > 70) {
    rr(ctx, w / 2 - sw / 2, floorY - sh, sw, sh, 8, "#0b0b10");
    ctx.strokeStyle = "#3f3f46";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(w / 2 - sw / 2, floorY - sh, sw, sh, 8);
    ctx.stroke();
    circle(ctx, w / 2, floorY - sh * 0.68, sw * 0.26 * (1 + pulse * 0.07), "#27272a");
    circle(ctx, w / 2, floorY - sh * 0.68, sw * 0.12 * (1 + pulse * 0.14), "#0c1013");
    circle(ctx, w / 2, floorY - sh * 0.26, sw * 0.15 * (1 + pulse * 0.05), "#3f3f46");
  }
  ctx.fillStyle = "#17171f";
  ctx.fillRect(-20, floorY, w + 40, h - floorY + 40);
  ctx.fillStyle = player.color;
  ctx.fillRect(-20, floorY, w + 40, 2);
}

function drawHealthBar(api: GameApi, health: number, opp: Char, player: Char) {
  const { ctx, w, h } = api;
  const bw = Math.min(w * 0.62, 460);
  const bh = 16;
  const bx = (w - bw) / 2;
  const by = h - 28;
  const boundary = bx + bw * (1 - health);
  rr(ctx, bx, by, bw, bh, bh / 2, "#3f3f46");
  rr(ctx, bx, by, Math.max(bh, boundary - bx), bh, bh / 2, opp.color);
  rr(ctx, boundary, by, Math.max(bh, bx + bw - boundary), bh, bh / 2, player.color);
  const icon = (cx: number, ch: Char, facing: number) => {
    rr(ctx, cx - 20, by + bh / 2 - 20, 40, 40, 8, "#0c1013");
    rr(ctx, cx - 17, by + bh / 2 - 17, 34, 34, 6, ch.color);
    drawHead(ctx, ch, cx, by + bh / 2 + 4, 11, facing);
  };
  icon(clamp(boundary - 26, bx + 20, bx + bw - 20), opp, 1);
  icon(clamp(boundary + 26, bx + 20, bx + bw - 20), player, -1);
}

interface FunkLevel {
  songOf: (level: number) => Song;
  scene: string;
  playerKind: number;
  chart: { opp: number[]; player: number[] } | null;
}

export function charOfKind(kind: number): Char {
  if (kind === 5 || !LOOKS[kind]) return PLAYER;
  return { name: PLAYER.name, color: LOOKS[kind].jacket, kind, timbre: PLAYER.timbre };
}

function chartPhrase(arr: number[]): MNote[] {
  const notes: MNote[] = [];
  let i = 0;
  while (i < 32) {
    if (arr[i] >= 0) {
      let j = i;
      while (j < 32 && arr[j] === arr[i]) j++;
      notes.push({ step: i, deg: arr[i], len: Math.min(8, j - i) });
      i = j;
    } else i++;
  }
  return notes;
}

function createLevel(lvl: FunkLevel) {
  return (api: GameApi): GameInst => {
  const song = lvl.songOf(api.level);
  const opp = FUNK_CHARS[song.char] ?? FUNK_CHARS[0];
  const playerChar = charOfKind(lvl.playerKind);
  const chart = lvl.chart;
  const comp = compose(song.spec);
  const { ac, music: bus } = audio();
  const out = ac.createGain();
  out.connect(bus);
  const { stepDur, barDur } = comp;
  const CYCLES = 4;
  const totalBars = 2 + CYCLES * 8;
  const notes: Note[] = [];
  for (let c = 0; c < CYCLES; c++)
    for (const who of [0, 1] as const)
      for (let half = 0; half < 2; half++) {
        const phrase = chart ? chartPhrase(chart[who === 0 ? "opp" : "player"]) : comp.phrases[(c * 2 + half) % 4];
        const barStart = 1 + c * 8 + who * 4 + half * 2;
        for (const n of phrase)
          notes.push({ time: (barStart * 16 + n.step) * stepDur, lane: n.deg % 4, deg: n.deg, len: n.len * stepDur, who, state: 0, sched: false });
      }
  notes.sort((a, b) => a.time - b.time);
  const playerNotes = notes.filter((n) => n.who === 1);
  const endTime = notes[notes.length - 1].time + 2;

  const T0 = ac.currentTime + 0.8;
  let nextBar = 0;
  let health = 0.5;
  let score = 0;
  let combo = 0;
  let maxCombo = 0;
  let misses = 0;
  let accSum = 0;
  let judged = 0;
  let done = false;
  const flash = [0, 0, 0, 0];
  const strumHit = [0, 0, 0, 0, 0, 0, 0, 0];
  let oppSing: { lane: number; t: number } | null = null;
  let mySing: { lane: number; t: number } | null = null;
  let pop = { text: "", color: "#ffffff", t: 0 };
  let missT = 0;
  let songT = -1;
  const voiceGains = new Map<Note, GainNode>();

  const songNow = (perf = performance.now()) => {
    const o = ac.getOutputTimestamp?.();
    if (o && o.contextTime !== undefined && o.performanceTime) return o.contextTime + (perf - o.performanceTime) / 1000 - T0;
    return ac.currentTime - (ac.outputLatency || ac.baseLatency || 0) - (performance.now() - perf) / 1000 - T0;
  };
  const eventTime = (ev: InputEv) => songNow(ev.t) - (ev.src === "furby" ? settings.get().rhythmLatency / 1000 : 0);

  const scheduleAhead = () => {
    while (nextBar < totalBars && T0 + nextBar * barDur < ac.currentTime + 0.3) {
      const t0 = T0 + nextBar * barDur;
      if (nextBar === 0) {
        for (let b = 0; b < 4; b++) tone(t0 + b * stepDur * 4, b === 3 ? 1320 : 880, 0.06, out, { type: "sine", gain: 0.15 });
        for (let sc = 0; sc < 16; sc += 2) hat(t0 + sc * stepDur, out);
      } else if (nextBar === totalBars - 1) {
        scheduleBar(comp, 0, t0, out, { drums: 0 });
      } else {
        scheduleBar(comp, (nextBar - 1) % 4, t0, out, {});
      }
      nextBar++;
    }
    for (const n of notes) {
      if (n.sched) continue;
      if (T0 + n.time > ac.currentTime + 0.3) break;
      n.sched = true;
      const g = ac.createGain();
      g.connect(out);
      voiceGains.set(n, g);
      voice(T0 + n.time, mtof(degMidi(song.spec, n.deg) + 12), n.len * 0.9, g, n.who === 0 ? opp.timbre : PLAYER.timbre);
    }
  };

  const finish = (win: boolean) => {
    if (done) return;
    done = true;
    out.gain.setTargetAtTime(0, ac.currentTime, win ? 0.4 : 0.05);
    api.score = score;
    if (win) {
      api.setLevel(`funk:${api.level}`, score);
      api.setLevel(`funkclear:${api.level}`, 1);
      if (misses === 0) api.setLevel("funkfc", 1);
    }
    api.over(win);
  };

  scheduleAhead();

  return {
    update(_dt: number, inp: InputFrame) {
      if (done) return;
      scheduleAhead();
      songT = songNow();
      for (let i = 0; i < 4; i++) flash[i] = Math.max(0, flash[i] - _dt);
      for (let i = 0; i < 8; i++) strumHit[i] = Math.max(0, strumHit[i] - _dt * 6);
      pop.t = Math.max(0, pop.t - _dt);
      missT = Math.max(0, missT - _dt * 1.8);
      for (const ev of inp.events) {
        const lane = laneOf(ev.type);
        if (lane < 0) continue;
        flash[lane] = 0.12;
        strumHit[4 + lane] = 1;
        const te = eventTime(ev);
        let best: Note | null = null;
        for (const n of playerNotes) {
          if (n.state !== 0 || n.lane !== lane) continue;
          const d = Math.abs(n.time - te);
          if (d <= 0.17 && (!best || d < Math.abs(best.time - te))) best = n;
          if (n.time > te + 0.2) break;
        }
        if (!best) continue;
        const d = Math.abs(best.time - te);
        const r = d <= 0.075 ? 0 : d <= 0.12 ? 1 : 2;
        best.state = 1;
        const rating = RATINGS[r];
        score += rating.points;
        health = Math.min(1, health + rating.heal);
        combo++;
        maxCombo = Math.max(maxCombo, combo);
        accSum += rating.acc;
        judged++;
        mySing = { lane, t: songT };
        pop = { text: api.t(...rating.name), color: LANE_COLORS[lane], t: 0.6 };
        api.fx.burst(api.w * (api.w >= 720 ? 0.72 : 0.5), api.h * 0.5, LANE_COLORS[lane], 8, 150, 3);
        const v = parseInt(LANE_COLORS[lane].slice(1), 16);
        api.furby.led((v >> 16) & 255, (v >> 8) & 255, v & 255);
      }
      for (const n of playerNotes) {
        if (n.state !== 0) continue;
        if (n.time > songT - 0.19) break;
        n.state = 2;
        misses++;
        combo = 0;
        judged++;
        health -= 0.065;
        missT = 1;
        const mg = voiceGains.get(n);
        if (mg) mg.gain.setTargetAtTime(0, ac.currentTime, 0.015);
        sfx("error");
        api.fx.float(api.t("Мимо", "Miss"), api.w * (api.w >= 720 ? 0.7 : 0.5), api.h * 0.42, api.pal.red);
      }
      for (const n of notes) {
        if (n.who !== 0 || n.state !== 0 || n.time > songT) continue;
        n.state = 1;
        strumHit[n.lane] = 1;
        oppSing = { lane: n.lane, t: n.time };
      }
      if (health <= 0) finish(false);
      else if (songT > endTime) finish(true);
    },

    draw() {
      const { ctx, w, h, pal } = api;
      const wide = w >= 720;
      const lane = Math.min(64, wide ? w * 0.05 : w * 0.17);
      const gap = lane * 1.12;
      const recY = 56;
      const speed = h * 0.85;
      const px = (l: number) => (wide ? w * 0.56 : w / 2 - gap * 1.5) + l * gap;
      const ox = (l: number) => w * 0.06 + lane / 2 + l * gap;
      const beat = ((songT / (stepDur * 4)) % 1 + 1) % 1;
      const bob = songT > -2 ? Math.exp(-beat * 6) : 0;
      const charS = Math.min(h * 0.5, w * (wide ? 0.2 : 0.3));
      const pulse = Math.exp(-beat * 5);
      drawStage(api, opp, playerChar, pulse, h - charS * 0.35, lvl.scene);
      const singK = (s: { lane: number; t: number } | null) => (s && songT - s.t < 0.35 ? { lane: s.lane, k: 1 - (songT - s.t) / 0.35 } : null);
      drawChar(ctx, opp, wide ? w * 0.24 : w * 0.2, h - charS * 0.35, charS, bob, singK(oppSing), 1, { phase: opp.kind * 0.73, time: songT, miss: 0 });
      drawChar(ctx, playerChar, wide ? w * 0.78 : w * 0.8, h - charS * 0.35, charS, bob, singK(mySing), -1, { phase: 2.4, time: songT, miss: missT });

      const lines: Array<[(l: number) => number, 0 | 1]> = wide ? [[ox, 0], [px, 1]] : [[px, 1]];
      for (const [fx, who] of lines) {
        for (let l = 0; l < 4; l++) {
          const hit = strumHit[(who === 0 ? 0 : 4) + l];
          const lit = who === 1 && flash[l] > 0;
          const active = lit || hit > 0;
          arrow(ctx, fx(l), recY, lane, l, active ? LANE_COLORS[l] : pal.faint, true);
          if (hit > 0) {
            // each arrow pops in its own direction: ← ↓ ↑ →
            const k = 1 - hit;
            ctx.globalAlpha = Math.min(1, hit * 1.4);
            arrow(ctx, fx(l) + DIRX[l] * k * lane * 0.6, recY + DIRY[l] * k * lane * 0.6, lane * (1.25 - 0.25 * hit), l, LANE_COLORS[l]);
            ctx.globalAlpha = 1;
          } else if (lit) {
            arrow(ctx, fx(l), recY, lane * 1.05, l, LANE_COLORS[l]);
          }
        }
        for (const n of notes) {
          if (n.who !== who || n.state !== 0) continue;
          const dtn = n.time - songT;
          if (who === 0 && dtn < 0) continue;
          const y = recY + dtn * speed;
          if (y > h + lane) break;
          if (y < -lane) continue;
          const near = dtn < 0.14 && dtn > -0.06 ? 1 + (0.14 - Math.max(0, dtn)) * 1.7 : 1;
          arrow(ctx, fx(n.lane), y, lane * 0.92 * near, n.lane, LANE_COLORS[n.lane]);
        }
      }
      if (songT < 0 && songT > -barDur) {
        const idx = Math.floor((songT + barDur) / (stepDur * 4));
        const label = ["3", "2", "1", "GO!"][clamp(idx, 0, 3)];
        text(ctx, label, w / 2, h * 0.45, Math.min(64, w / 8), pal.fg, "center", 800);
      }
      drawHealthBar(api, health, opp, playerChar);
      if (pop.t > 0) {
        const k = 1 - pop.t / 0.6;
        const cx = wide ? w * 0.7 : w * 0.5;
        const size = Math.min(w / 11, 48);
        ctx.globalAlpha = Math.min(1, pop.t * 3);
        text(ctx, pop.text, cx, h * 0.4 - k * 22, size, pop.color, "center", 900);
        if (combo >= 5) text(ctx, `×${combo}`, cx, h * 0.4 - k * 22 + size * 0.75, size * 0.5, "#ffffff", "center", 800);
        ctx.globalAlpha = 1;
      }
      const acc = judged ? Math.round((accSum / judged) * 100) : 100;
      text(ctx, `${api.t("Очки", "Score")}: ${score}  ·  ${api.t("Промахи", "Misses")}: ${misses}  ·  ${api.t("Точность", "Accuracy")}: ${acc}%`, w - 12, 16, 12, "#e5e7eb", "right", 600);
      text(ctx, `${api.t(...opp.name)} — ${api.t(...song.name)}`, 12, 14, 12, pal.muted, "left", 600);
      void maxCombo;
    },

    pause(paused: boolean) {
      if (paused) void ac.suspend();
      else void ac.resume();
    },

    dispose() {
      out.gain.setTargetAtTime(0, ac.currentTime, 0.03);
      window.setTimeout(() => out.disconnect(), 500);
      if (ac.state === "suspended") void ac.resume();
    },
  };
    };
}

export const funkGame: GameDef = {
  id: "funk",
  featured: true,
  name: ["Furby Funk", "Furby Funk"],
  desc: [
    "Аналог Friday Night Funkin': соперник поёт, ты повторяешь стрелками антенны. 15 песен, 5 персонажей по 3 песни, все качаются в такт BPM.",
    "A Friday Night Funkin' style battle: the rival sings, you answer with the antenna arrows. 15 songs, 5 characters with 3 songs each, all bobbing to the BPM.",
  ],
  icon: Mic,
  cat: "rhythm",
  controls: ["antenna"],
  lives: 0,
  hud: false,
  aspect: 16 / 9,
  tap: null,
  levels: FUNK_SONGS.map((s) => ({ name: s.name, sub: [`${FUNK_CHARS[s.char].name[0]} · ${s.spec.bpm} BPM`, `${FUNK_CHARS[s.char].name[1]} · ${s.spec.bpm} BPM`] as Text })),
  create: createLevel({ songOf: (i) => FUNK_SONGS[i] ?? FUNK_SONGS[0], scene: "theater", playerKind: 5, chart: null }),
};

/** A saved custom level turned into a playable game definition. */
export function customFunkDef(lv: CustomLevel): GameDef {
  const name: Text = [lv.name, lv.name];
  return {
    id: `funk-${lv.id}`,
    name,
    desc: [
      lv.scene === "club" ? "Клубная сцена" : lv.scene === "street" ? "Ночная улица" : "Театральная сцена",
      lv.scene === "club" ? "Club stage" : lv.scene === "street" ? "Night street" : "Theatre stage",
    ],
    icon: Mic,
    cat: "rhythm",
    controls: ["antenna"],
    lives: 0,
    hud: false,
    aspect: 16 / 9,
    tap: null,
    levels: [{ name }],
    create: createLevel({
      songOf: () => ({ name, char: lv.opponent, spec: lv.spec }),
      scene: lv.scene,
      playerKind: lv.playerKind,
      chart: lv.chart,
    }),
  };
}
