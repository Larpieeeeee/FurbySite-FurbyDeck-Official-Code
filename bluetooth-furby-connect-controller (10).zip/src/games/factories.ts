/** 70 games generated from 14 configurable families. */
import type { LucideIcon } from "lucide-react";
import {
  Activity, ArrowBigUp, Award, Blocks, Bot, Brain, Building, Bug, Circle, CircleDot, Cloud, CloudLightning,
  Crosshair, Droplets, Flame, Footprints, Gauge, Gem, Ghost, Gift, Grid2x2, Hammer, Hash, Heart, Layers,
  Medal, Rocket, ShieldAlert, Star, Shapes, Snowflake, Sparkles, Sun, Target, Timer, TriangleAlert, Wind, Worm, Zap, Bird,
} from "lucide-react";
import type { Text } from "@/lib/i18n";
import { banner, bg, bar, chance, circle, clamp, def, heart, line, pick, poly, rand, randi, rr, star, strokeCircle, text } from "./kit";
import type { Ctl, GameDef, GameInst } from "./types";

function pickShape(ctx: CanvasRenderingContext2D, kind: string, x: number, y: number, r: number, danger = false) {
  switch (kind) {
    case "star": star(ctx, x, y, r, danger ? "#ef4444" : "#facc15", 0.3); break;
    case "coin": circle(ctx, x, y, r, "#f59e0b"); strokeCircle(ctx, x, y, r * 0.6, "#92400e", 2); break;
    case "heart": heart(ctx, x, y, r * 1.1, danger ? "#18181b" : "#ec4899"); break;
    case "candy": circle(ctx, x, y, r, danger ? "#18181b" : "#f472b6"); strokeCircle(ctx, x, y, r * 0.55, danger ? "#f87171" : "#fff", 3); break;
    case "snow": {
      ctx.strokeStyle = danger ? "#ef4444" : "#e0f2fe";
      ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) {
        const a = (i * Math.PI) / 3;
        line(ctx, x - Math.cos(a) * r, y - Math.sin(a) * r, x + Math.cos(a) * r, y + Math.sin(a) * r, ctx.strokeStyle as string, 3);
      }
      break;
    }
    case "gem": poly(ctx, [x, y - r, x + r * 0.8, y, x, y + r, x - r * 0.8, y], danger ? "#ef4444" : "#a855f7"); break;
    case "flame": poly(ctx, [x, y - r * 1.2, x + r * 0.8, y + r * 0.3, x, y + r, x - r * 0.8, y + r * 0.3], danger ? "#18181b" : "#f97316"); break;
    case "ring": strokeCircle(ctx, x, y, r * 0.8, danger ? "#ef4444" : "#22d3ee", 5); break;
    case "drop": poly(ctx, [x, y - r * 1.3, x + r * 0.75, y + r * 0.3, x - r * 0.75, y + r * 0.3], danger ? "#ef4444" : "#38bdf8"); break;
    case "bomb": circle(ctx, x, y, r, "#18181b"); strokeCircle(ctx, x, y, r, "#f87171", 3); line(ctx, x, y - r, x + 7, y - r - 8, "#f59e0b", 3); break;
    case "rock": circle(ctx, x, y, r, danger ? "#a8a29e" : "#78716c"); strokeCircle(ctx, x, y, r, "#57534e", 2); break;
    case "skull": circle(ctx, x, y, r, "#e5e7eb"); circle(ctx, x - r * 0.3, y - r * 0.15, r * 0.2, "#18181b"); circle(ctx, x + r * 0.3, y - r * 0.15, r * 0.2, "#18181b"); rr(ctx, x - r * 0.3, y + r * 0.35, r * 0.6, r * 0.3, 2, "#18181b"); break;
    default: circle(ctx, x, y, r, danger ? "#ef4444" : "#22c55e");
  }
}

// ───────────────────────── 1. Catch (9) ─────────────────────────
interface CatchCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  control: "antennaLR" | "tilt";
  good: string; bad: string;
  speed: number; spawn: number; badRate: number; drift: number;
}
function catchFamily(c: CatchCfg): GameDef {
  const controls: Ctl[] = [c.control];
  return def(c.id, c.name, c.desc, c.icon, "arcade", controls, (api): GameInst => {
    let px = api.w / 2;
    let items: Array<{ x: number; y: number; vy: number; vx: number; good: boolean }> = [];
    let t = 0.4;
    return {
      update(dt, inp) {
        px = clamp(px + (c.control === "antennaLR" ? inp.ax * 0.95 : inp.tiltX * 1.05) * api.w * dt, 44, api.w - 44);
        t -= dt;
        if (t <= 0) {
          t = c.spawn / (1 + api.time * 0.012);
          items.push({ x: rand(24, api.w - 24), y: -22, vy: rand(c.speed, c.speed * 1.5), vx: rand(-c.drift, c.drift), good: !chance(c.badRate) });
        }
        for (const it of items) {
          it.y += it.vy * dt;
          it.x += it.vx * dt;
          if (it.x < 24 || it.x > api.w - 24) it.vx *= -1;
        }
        items = items.filter((it) => {
          if (it.y > api.h - 48 && it.y < api.h - 14 && Math.abs(it.x - px) < 48) {
            if (it.good) {
              api.add(10, it.x, api.h - 64);
              api.sfx("coin");
            } else {
              api.fx.burst(it.x, it.y, api.pal.red, 16);
              api.sfx("hit");
              api.hurt();
            }
            return false;
          }
          return it.y < api.h + 40;
        });
      },
      draw() {
        const { ctx, h, pal } = api;
        bg(api);
        for (const it of items) pickShape(ctx, it.good ? c.good : c.bad, it.x, it.y, 15, !it.good);
        rr(ctx, px - 46, h - 30, 92, 18, 9, pal.fg);
        rr(ctx, px - 40, h - 36, 80, 10, 5, pal.surface2);
      },
    };
  });
}

const CATCHES: CatchCfg[] = [
  { id: "catch-coins", name: ["Ловля монет", "Coin catch"], desc: ["Лови монеты, уворачивайся от камней", "Catch coins, dodge rocks"], icon: Star, control: "antennaLR", good: "coin", bad: "rock", speed: 170, spawn: 1.1, badRate: 0.22, drift: 20 },
  { id: "catch-hearts", name: ["Ловля сердец", "Heart catch"], desc: ["Сердечки лови, бомбы не трогай", "Catch hearts, avoid bombs"], icon: Heart, control: "tilt", good: "heart", bad: "bomb", speed: 160, spawn: 1.0, badRate: 0.2, drift: 30 },
  { id: "catch-snow", name: ["Снежинки", "Snowflakes"], desc: ["Лови снежинки, камни не трогай", "Catch snowflakes, avoid rocks"], icon: Snowflake, control: "antennaLR", good: "snow", bad: "rock", speed: 130, spawn: 0.9, badRate: 0.18, drift: 45 },
  { id: "catch-candy", name: ["Конфеты", "Candy"], desc: ["Конфеты в корзину, бомбы мимо", "Candy in the basket, bombs away"], icon: Gift, control: "antennaLR", good: "candy", bad: "bomb", speed: 190, spawn: 1.0, badRate: 0.26, drift: 35 },
  { id: "catch-embers", name: ["Угольки", "Embers"], desc: ["Лови огоньки, снег не нужен", "Catch the embers, skip the snow"], icon: Flame, control: "tilt", good: "flame", bad: "snow", speed: 150, spawn: 0.95, badRate: 0.2, drift: 55 },
  { id: "catch-rings", name: ["Кольца", "Rings"], desc: ["Кольца — очки, черепа — жизнь", "Rings score, skulls cost a life"], icon: CircleDot, control: "antennaLR", good: "ring", bad: "skull", speed: 200, spawn: 1.15, badRate: 0.24, drift: 25 },
  { id: "catch-gems", name: ["Драгоценные камни", "Gems"], desc: ["Камни быстро, лови точно", "Fast gems, catch precisely"], icon: Award, control: "tilt", good: "gem", bad: "bomb", speed: 230, spawn: 1.2, badRate: 0.22, drift: 40 },
  { id: "catch-drops", name: ["Капли дождя", "Raindrops"], desc: ["Капли падают часто, камни реже", "Drops fall often, rocks less"], icon: Droplets, control: "antennaLR", good: "drop", bad: "rock", speed: 210, spawn: 0.75, badRate: 0.16, drift: 60 },
  { id: "catch-cookies", name: ["Печеньки", "Cookies"], desc: ["Печеньки тяжёлые и медленные", "Cookies are heavy and slow"], icon: Medal, control: "tilt", good: "candy", bad: "skull", speed: 120, spawn: 0.85, badRate: 0.22, drift: 15 },
];

// ───────────────────────── 2. Dodge falling (8) ─────────────────────────
interface DodgeCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  control: "antennaLR" | "tilt";
  shape: string; speed: number; spawn: number; drift: number; wide: boolean;
}
function dodgeFamily(c: DodgeCfg): GameDef {
  const controls: Ctl[] = [c.control];
  return def(c.id, c.name, c.desc, c.icon, "arcade", controls, (api): GameInst => {
    let px = api.w / 2;
    let obs: Array<{ x: number; y: number; vy: number; vx: number }> = [];
    let t = 0.3;
    return {
      update(dt, inp) {
        px = clamp(px + (c.control === "antennaLR" ? inp.ax * 1.0 : inp.tiltX * 1.1) * api.w * dt, 30, api.w - 30);
        t -= dt;
        if (t <= 0) {
          t = c.spawn / (1 + api.time * 0.014);
          obs.push({ x: rand(24, api.w - 24), y: -30, vy: rand(c.speed, c.speed * 1.4), vx: rand(-c.drift, c.drift) });
        }
        for (const o of obs) {
          o.y += o.vy * dt;
          o.x += o.vx * dt;
          if (o.x < 24 || o.x > api.w - 24) o.vx *= -1;
        }
        obs = obs.filter((o) => {
          const hw = c.wide ? 26 : 17;
          if (o.y > api.h - 52 && o.y < api.h - 20 && Math.abs(o.x - px) < hw + 14) {
            api.fx.burst(o.x, o.y, api.pal.red, 16);
            api.fx.shake(6);
            api.sfx("hit");
            api.hurt();
            return false;
          }
          return o.y < api.h + 40;
        });
        api.score += dt * 4;
      },
      draw() {
        const { ctx, h, pal } = api;
        bg(api);
        for (const o of obs) pickShape(ctx, c.shape, o.x, o.y, c.wide ? 24 : 17, true);
        circle(ctx, px, h - 34, 16, pal.blue);
        circle(ctx, px - 5, h - 38, 3.5, "#fff");
        circle(ctx, px + 5, h - 38, 3.5, "#fff");
      },
    };
  });
}

const DODGES: DodgeCfg[] = [
  { id: "dodge-rocks", name: ["Камнепад", "Rockfall"], desc: ["Падающие камни", "Falling rocks"], icon: CloudLightning, control: "antennaLR", shape: "rock", speed: 210, spawn: 0.95, drift: 30, wide: false },
  { id: "dodge-rain", name: ["Кислотный дождь", "Acid rain"], desc: ["Капли кислоты", "Acid drops"], icon: Droplets, control: "tilt", shape: "drop", speed: 250, spawn: 0.8, drift: 20, wide: false },
  { id: "dodge-arrows", name: ["Стрелы", "Arrows"], desc: ["Стрелы летят вниз", "Arrows raining down"], icon: Crosshair, control: "antennaLR", shape: "rock", speed: 290, spawn: 0.75, drift: 45, wide: false },
  { id: "dodge-balls", name: ["Падающие шары", "Falling balls"], desc: ["Шары отскакивают", "Bouncing balls"], icon: CircleDot, control: "tilt", shape: "bomb", speed: 190, spawn: 0.9, drift: 70, wide: false },
  { id: "dodge-bricks", name: ["Кирпичи", "Bricks"], desc: ["Широкие кирпичи", "Wide bricks"], icon: Blocks, control: "antennaLR", shape: "rock", speed: 230, spawn: 1.1, drift: 15, wide: true },
  { id: "dodge-skulls", name: ["Черепа", "Skulls"], desc: ["Черепа не трогать", "Don't touch the skulls"], icon: Ghost, control: "tilt", shape: "skull", speed: 220, spawn: 0.9, drift: 40, wide: false },
  { id: "dodge-snowballs", name: ["Снежные комья", "Snowballs"], desc: ["Комья снега", "Snowballs"], icon: Snowflake, control: "antennaLR", shape: "snow", speed: 200, spawn: 0.85, drift: 55, wide: false },
  { id: "dodge-flames", name: ["Огненные шары", "Fireballs"], desc: ["Огненные шары вниз", "Fireballs down"], icon: Flame, control: "tilt", shape: "flame", speed: 260, spawn: 0.8, drift: 35, wide: false },
];

// ───────────────────────── 3. Shooter (6) ─────────────────────────
interface ShooterCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  fire: number; enemyHp: number; speed: number; color: string; sine: boolean;
}
function shooterFamily(c: ShooterCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["antennaLR", "tongue"], (api): GameInst => {
    let px = api.w / 2;
    let bullets: Array<{ x: number; y: number }> = [];
    let ebullets: Array<{ x: number; y: number }> = [];
    let enemies: Array<{ x: number; y: number; hp: number }> = [];
    let dir = 1;
    let t = 0;
    let fireCd = 0;
    let inv = 0;
    const spawn = () => {
      enemies = [];
      for (let r = 0; r < 3; r++) for (let col = 0; col < 7; col++) enemies.push({ x: 60 + col * ((api.w - 120) / 6), y: -60 - r * 46, hp: c.enemyHp });
    };
    spawn();
    return {
      update(dt, inp) {
        px = clamp(px + inp.ax * api.w * 0.95 * dt, 26, api.w - 26);
        fireCd -= dt;
        inv = Math.max(0, inv - dt);
        if (inp.has("tongue") && fireCd <= 0) {
          fireCd = c.fire;
          bullets.push({ x: px, y: api.h - 40 });
          api.sfx("shoot");
        }
        for (const b of bullets) b.y -= 560 * dt;
        t += dt;
        const sway = c.sine ? Math.sin(t * 1.6) * 60 : 0;
        const drop = enemies.length && enemies.every((e) => e.y < 40) ? 0 : 26 * dt;
        for (const e of enemies) {
          e.x += dir * c.speed * dt;
          e.y += drop;
          if (c.sine) e.x += Math.sin(t * 3 + e.y) * 18 * dt;
        }
        if (enemies.some((e) => e.x > api.w - 30)) dir = -1;
        if (enemies.some((e) => e.x < 30)) dir = 1;
        if (enemies.length && enemies.every((e) => e.y > api.h - 70)) api.over(false);
        if (chance(0.006 + t * 0.0002) && enemies.length) {
          const src = pick(enemies);
          ebullets.push({ x: src.x, y: src.y, });
        }
        for (const eb of ebullets) eb.y += 300 * dt;
        for (const b of bullets) {
          for (const e of enemies) {
            if (e.hp > 0 && Math.abs(b.x - e.x) < 22 && Math.abs(b.y - e.y) < 18) {
              b.y = -99;
              e.hp--;
              if (e.hp <= 0) {
                api.add(20, e.x, e.y);
                api.fx.burst(e.x, e.y, c.color, 10, 150);
                api.sfx("boom");
              }
            }
          }
        }
        for (const eb of ebullets) {
          if (inv <= 0 && Math.abs(eb.x - px) < 16 && eb.y > api.h - 52) {
            eb.y = 9999;
            inv = 1;
            api.hurt();
          }
        }
        enemies = enemies.filter((e) => e.hp > 0);
        bullets = bullets.filter((b) => b.y > -20);
        ebullets = ebullets.filter((eb) => eb.y < api.h + 20);
        if (!enemies.length) {
          api.add(200, api.w / 2, api.h / 2);
          api.sfx("win");
          spawn();
        }
        void sway;
      },
      draw() {
        const { ctx, w, pal } = api;
        bg(api);
        for (const e of enemies) {
          circle(ctx, e.x, e.y, 15, c.color);
          circle(ctx, e.x - 5, e.y - 3, 3, "#18181b");
          circle(ctx, e.x + 5, e.y - 3, 3, "#18181b");
          if (e.hp > 1) text(ctx, String(e.hp), e.x, e.y - 24, 11, pal.muted, "center", 800);
        }
        for (const b of bullets) rr(ctx, b.x - 3, b.y - 8, 6, 14, 3, pal.amber);
        for (const eb of ebullets) circle(ctx, eb.x, eb.y, 5, pal.red);
        if (inv <= 0 || Math.floor(api.time * 12) % 2) {
          poly(ctx, [px, api.h - 58, px + 18, api.h - 24, px - 18, api.h - 24], pal.blue);
        }
        void w;
      },
    };
  });
}

const SHOOTERS: ShooterCfg[] = [
  { id: "sh-fighter", name: ["Истребитель", "Fighter"], desc: ["Классический истребитель", "Classic fighter"], icon: Rocket, fire: 0.3, enemyHp: 1, speed: 34, color: "#a855f7", sine: false },
  { id: "sh-drone", name: ["Дрон", "Drone"], desc: ["Быстрый огонь", "Fast fire"], icon: Zap, fire: 0.18, enemyHp: 1, speed: 42, color: "#22d3ee", sine: false },
  { id: "sh-blaster", name: ["Бластер", "Blaster"], desc: ["Медленный, но злой", "Slow but nasty"], icon: Target, fire: 0.45, enemyHp: 2, speed: 28, color: "#f43f5e", sine: false },
  { id: "sh-hive", name: ["Рой", "Swarm"], desc: ["Враги качаются", "Enemies sway"], icon: Bug, fire: 0.28, enemyHp: 1, speed: 36, color: "#84cc16", sine: true },
  { id: "sh-rail", name: ["Рельсовый пистолет", "Railgun"], desc: ["Один выстрел — один враг", "One shot, one enemy"], icon: Crosshair, fire: 0.6, enemyHp: 1, speed: 24, color: "#eab308", sine: false },
  { id: "sh-titan", name: ["Титан", "Titan"], desc: ["Два попадания на врага", "Two hits per enemy"], icon: CircleDot, fire: 0.34, enemyHp: 2, speed: 30, color: "#7c4dff", sine: true },
];

// ───────────────────────── 4. Runner (7) ─────────────────────────
interface RunnerCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  speed: number; gap: number; theme: [string, string]; shape: string;
}
function runnerFamily(c: RunnerCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["tongue"], (api): GameInst => {
    let vy = 0;
    let jy = 0;
    let obstacles: Array<{ x: number; h: number }> = [];
    let t = 1.4;
    let speed = c.speed;
    const jump = () => {
      vy = 620;
      api.sfx("jump");
    };
    return {
      update(dt, inp) {
        speed = c.speed + api.time * 3.5;
        if ((inp.has("tongue") || inp.held.tongue) && jy <= 0.01 && vy <= 0) jump();
        vy -= 1700 * dt;
        jy = Math.max(0, jy + vy * dt);
        t -= dt;
        if (t <= 0) {
          t = Math.max(0.5, c.gap / speed);
          obstacles.push({ x: api.w + 30, h: rand(34, 62) });
        }
        for (const o of obstacles) o.x -= speed * dt;
        obstacles = obstacles.filter((o) => {
          if (o.x < api.w * 0.2 + 16 && o.x + 34 > api.w * 0.2 - 16) {
            if (jy < o.h - 6) {
              api.fx.shake(7);
              api.sfx("hit");
              api.hurt();
              return false;
            }
          }
          return o.x > -50;
        });
        api.score += dt * 8;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, c.theme[1]);
        const gy = h - 60;
        ctx.fillStyle = c.theme[0];
        ctx.fillRect(-20, gy, w + 40, h - gy + 40);
        ctx.fillStyle = pal.amber;
        ctx.fillRect(-20, gy, w + 40, 3);
        for (const o of obstacles) {
          if (c.shape === "spike") poly(ctx, [o.x, gy, o.x + 34, gy, o.x + 17, gy - o.h], "#f87171");
          else if (c.shape === "cactus") {
            rr(ctx, o.x + 10, gy - o.h, 14, o.h, 6, "#22c55e");
            rr(ctx, o.x, gy - o.h * 0.6, 12, 8, 4, "#22c55e");
          } else rr(ctx, o.x, gy - o.h, 34, o.h, 6, "#a16207");
        }
        const px = w * 0.2;
        circle(ctx, px, gy - 18 - jy, 17, pal.blue);
        circle(ctx, px + 5, gy - 23 - jy, 3.5, "#fff");
        text(ctx, `${Math.floor(api.score)}`, 12, 18, 14, pal.muted, "left", 700);
      },
    };
  });
}

const RUNNERS: RunnerCfg[] = [
  { id: "run-skate", name: ["Скейт", "Skateboard"], desc: ["Скейт и трамплины", "Skate and ramps"], icon: Footprints, speed: 300, gap: 300, theme: ["#1e293b", "#0f172a"], shape: "box" },
  { id: "run-bike", name: ["Велосипед", "Bike"], desc: ["Велосипед по дороге", "Bike on the road"], icon: Activity, speed: 330, gap: 320, theme: ["#334155", "#0f172a"], shape: "box" },
  { id: "run-ski", name: ["Лыжи", "Skiing"], desc: ["Лыжи и сугробы", "Skis and snowdrifts"], icon: Wind, speed: 320, gap: 300, theme: ["#e2e8f0", "#f8fafc"], shape: "spike" },
  { id: "run-moto", name: ["Мотоцикл", "Motorbike"], desc: ["Мотоцикл и трубы", "Motorbike and pipes"], icon: Zap, speed: 360, gap: 330, theme: ["#1c1917", "#0c0a09"], shape: "box" },
  { id: "run-robot", name: ["Робот-бег", "Robot run"], desc: ["Робот и кактусы", "Robot and cacti"], icon: Bot, speed: 340, gap: 310, theme: ["#111827", "#030712"], shape: "cactus" },
  { id: "run-camel", name: ["Верблюд", "Camel"], desc: ["Пустыня и кактусы", "Desert and cacti"], icon: Sun, speed: 310, gap: 340, theme: ["#92400e", "#78350f"], shape: "cactus" },
  { id: "run-ice", name: ["Коньки", "Ice skating"], desc: ["Лёд и сосульки", "Ice and icicles"], icon: Snowflake, speed: 350, gap: 300, theme: ["#dbeafe", "#eff6ff"], shape: "spike" },
];

// ───────────────────────── 5. Race (5) ─────────────────────────
interface RaceCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  speed: number; density: number; carW: number; color: string;
}
function raceFamily(c: RaceCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["tilt"], (api): GameInst => {
    let x = 0.5;
    let cars: Array<{ x: number; y: number; c: string }> = [];
    let t = 0;
    let off = 0;
    let inv = 0;
    return {
      update(dt, inp) {
        const speed = (c.speed + api.time * 0.8) * 60;
        x = clamp(x + inp.tiltX * 0.95 * dt, 0.16, 0.84);
        off = (off + speed * dt) % 60;
        inv = Math.max(0, inv - dt);
        t -= dt;
        if (t <= 0) {
          t = c.density / (1 + api.time * 0.01);
          cars.push({ x: pick([0.28, 0.5, 0.72]), y: -70, c: chance(0.3) ? c.color : pick(["#ef4444", "#22c55e", "#f59e0b", "#a855f7"]) });
        }
        for (const car of cars) {
          car.y += speed * dt;
          if (inv <= 0 && Math.abs(car.x - x) * api.w < c.carW && Math.abs(car.y - (api.h - 70)) < 54) {
            car.y = 9999;
            inv = 1.2;
            api.fx.shake(8);
            api.sfx("hit");
            api.hurt();
          }
        }
        cars = cars.filter((car) => car.y < api.h + 90);
        api.score += dt * 10;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, "#18181b");
        ctx.fillStyle = "#27272a";
        ctx.fillRect(w * 0.2, 0, w * 0.6, h);
        for (const lx of [0.35, 0.5, 0.65]) for (let y = -60 + off; y < h; y += 60) rr(ctx, lx * w - 3, y, 6, 30, 3, "#fafafa");
        for (const car of cars) {
          rr(ctx, car.x * w - c.carW / 2, car.y - 46, c.carW, 92, 12, car.c);
          rr(ctx, car.x * w - c.carW * 0.3, car.y - 30, c.carW * 0.6, 30, 6, "#0c1013");
        }
        rr(ctx, x * w - 24, api.h - 116, 48, 96, 12, pal.blue);
        rr(ctx, x * w - 15, api.h - 100, 30, 34, 5, "#0c1013");
      },
    };
  });
}

const RACES: RaceCfg[] = [
  { id: "race-formula", name: ["Формула", "Formula"], desc: ["Быстрая трасса", "Fast track"], icon: Zap, speed: 1.6, density: 1.1, carW: 50, color: "#f43f5e" },
  { id: "race-moto", name: ["Мотогонки", "Moto race"], desc: ["Узкие мотоциклы", "Narrow bikes"], icon: Activity, speed: 1.9, density: 0.9, carW: 34, color: "#22d3ee" },
  { id: "race-tractor", name: ["Тракторы", "Tractors"], desc: ["Медленно, но надёжно", "Slow but steady"], icon: Gauge, speed: 1.1, density: 1.4, carW: 64, color: "#84cc16" },
  { id: "race-space", name: ["Космо-гонка", "Space race"], desc: ["Светящиеся корабли", "Glowing ships"], icon: Rocket, speed: 2.2, density: 1.0, carW: 44, color: "#a855f7" },
  { id: "race-cart", name: ["Картинг", "Karting"], desc: ["Карты и частые повороты", "Karts and tight gaps"], icon: Timer, speed: 1.8, density: 0.7, carW: 56, color: "#eab308" },
];

// ───────────────────────── 6. Target (6) ─────────────────────────
interface TargetCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  size: number; move: boolean; shrink: boolean; decoy: boolean; life: number;
}
function targetFamily(c: TargetCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "skill", ["antenna", "tongue"], (api): GameInst => {
    let cx = api.w / 2;
    let cy = api.h / 2;
    let tx = cx;
    let ty = cy;
    let size = c.size;
    let life = c.life;
    let decoy = false;
    const spawn = () => {
      size = c.size;
      life = c.life;
      tx = rand(size + 20, api.w - size - 20);
      ty = rand(size + 40, api.h - size - 30);
      decoy = c.decoy && chance(0.4);
    };
    spawn();
    return {
      update(dt, inp) {
        life -= dt;
        if (c.move) {
          tx += Math.sin(api.time * 2.2) * 90 * dt;
          ty += Math.cos(api.time * 1.7) * 60 * dt;
          tx = clamp(tx, size + 20, api.w - size - 20);
          ty = clamp(ty, size + 40, api.h - size - 30);
        }
        if (c.shrink) size = Math.max(14, size - dt * 4);
        if (life <= 0) {
          if (!decoy) api.hurt();
          spawn();
          return;
        }
        if (inp.has("tongue")) {
          const d = dist2(cx, cy, tx, ty);
          if (d < size) {
            if (decoy) {
              api.sfx("error");
              api.hurt();
            } else {
              api.add(Math.round(50 + life * 10), tx, ty);
              api.sfx("good");
              api.fx.burst(tx, ty, api.pal.green, 14, 180);
            }
            spawn();
            return;
          }
        }
        cx += (api.w * (0.5 + inp.ax * 0.45) - cx) * Math.min(1, dt * 12);
        cy += (api.h * (0.5 - inp.ay * 0.45) - cy) * Math.min(1, dt * 12);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const col = decoy ? pal.red : pal.green;
        for (let k = 3; k >= 1; k--) circle(ctx, tx, ty, (size * k) / 3, k % 2 ? col : pal.surface2);
        circle(ctx, tx, ty, size * 0.25, pal.fg);
        bar(ctx, w * 0.3, h - 22, w * 0.4, 8, life / c.life, col, pal.surface2);
        strokeCircle(ctx, cx, cy, 14, pal.fg, 3);
        line(ctx, cx - 22, cy, cx + 22, cy, pal.fg, 2);
        line(ctx, cx, cy - 22, cx, cy + 22, pal.fg, 2);
      },
    };
    function dist2(ax: number, ay: number, bx: number, by: number) {
      return Math.hypot(ax - bx, ay - by);
    }
  });
}

const TARGETS: TargetCfg[] = [
  { id: "tg-static", name: ["Мишень", "Target"], desc: ["Статичная мишень", "Static target"], icon: Target, size: 46, move: false, shrink: false, decoy: false, life: 5 },
  { id: "tg-moving", name: ["Бегущая цель", "Moving target"], desc: ["Цель качается", "The target sways"], icon: Crosshair, size: 42, move: true, shrink: false, decoy: false, life: 5 },
  { id: "tg-shrink", name: ["Сужающаяся", "Shrinking"], desc: ["Мишень мельчает", "The target shrinks"], icon: CircleDot, size: 54, move: false, shrink: true, decoy: false, life: 6 },
  { id: "tg-decoy", name: ["Ловушки", "Traps"], desc: ["Красные — ловушка", "Red ones are traps"], icon: ShieldAlert, size: 46, move: false, shrink: false, decoy: true, life: 4 },
  { id: "tg-rush", name: ["Спешка", "Rush"], desc: ["Мало времени", "Little time"], icon: Timer, size: 40, move: true, shrink: true, decoy: false, life: 2.4 },
  { id: "tg-big", name: ["Большая цель", "Big target"], desc: ["Огромная мишень", "Huge target"], icon: Award, size: 70, move: true, shrink: false, decoy: false, life: 6 },
];

// ───────────────────────── 7. Memory (5) ─────────────────────────
interface MemoryCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  pairs: number; numeric: boolean; timeLimit: number;
}
function memoryFamily(c: MemoryCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "logic", ["antenna", "tongue"], (api): GameInst => {
    const cols = c.pairs <= 6 ? 4 : 4;
    const rows = Math.ceil(c.pairs * 2 / cols);
    const total = c.pairs * 2;
    const deck: number[] = [];
    for (let i = 0; i < c.pairs; i++) {
      deck.push(i);
      deck.push(i);
    }
    const cards = shuffleArr(deck);
    let cursor = 0;
    let first = -1;
    let second = -1;
    let lock = 0;
    let matched = 0;
    let moves = 0;
    let time = c.timeLimit;
    let done = false;
    return {
      update(dt, inp) {
        if (done) {
          time -= dt;
          if (time <= 0) api.over(true);
          return;
        }
        time -= dt;
        if (time <= 0) {
          api.over(false);
          return;
        }
        lock = Math.max(0, lock - dt);
        if (lock === 0 && second !== -1) {
          first = -1;
          second = -1;
        }
        const row = Math.floor(cursor / cols);
        const col = cursor % cols;
        if (inp.has("antL")) cursor = row * cols + ((col + cols - 1) % cols);
        if (inp.has("antR")) cursor = row * cols + ((col + 1) % cols);
        if (inp.has("antF")) cursor = ((row + rows - 1) % rows) * cols + col;
        if (inp.has("antB")) cursor = ((row + 1) % rows) * cols + col;
        if (inp.has("tongue") && lock <= 0 && cards[cursor] !== -1) {
          if (first === -1) {
            first = cursor;
            api.sfx("tick");
          } else if (first !== cursor) {
            moves++;
            if (cards[first] === cards[cursor]) {
              cards[first] = -1;
              cards[cursor] = -1;
              matched++;
              api.add(20 + moves, api.w / 2, api.h / 2);
              api.sfx("good");
              first = -1;
              if (matched === c.pairs) {
                api.add(Math.round(time * 20));
                done = true;
                api.sfx("win");
              }
            } else {
              lock = 0.8;
              second = cursor;
              api.sfx("error");
            }
          }
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cs = Math.min((w - 30) / cols, (h - 70) / rows);
        const ox = (w - cs * cols) / 2;
        const oy = 44;
        for (let i = 0; i < total; i++) {
          const r = Math.floor(i / cols);
          const cl = i % cols;
          const x = ox + cl * cs + cs / 2;
          const y = oy + r * cs + cs / 2;
          const hidden = cards[i] === -1;
          if (hidden) {
            rr(ctx, x - cs * 0.4, y - cs * 0.4, cs * 0.8, cs * 0.8, 8, pal.line);
            continue;
          }
          const faceUp = i === first || i === second;
          if (faceUp) {
            rr(ctx, x - cs * 0.4, y - cs * 0.4, cs * 0.8, cs * 0.8, 8, pal.surface2);
            if (c.numeric) text(ctx, String(cards[i] + 1), x, y, cs * 0.4, GEM_COLORS_LOCAL[cards[i] % GEM_COLORS_LOCAL.length], "center", 800);
            else circle(ctx, x, y, cs * 0.22, GEM_COLORS_LOCAL[cards[i] % GEM_COLORS_LOCAL.length]);
          } else {
            rr(ctx, x - cs * 0.4, y - cs * 0.4, cs * 0.8, cs * 0.8, 8, pal.surface2);
            text(ctx, "?", x, y, cs * 0.4, pal.faint, "center", 800);
          }
          if (i === cursor && !hidden) strokeCircle(ctx, x, y, cs * 0.44, pal.fg, 2);
        }
        text(ctx, `${api.t("Ходов", "Moves")}: ${moves}`, 12, 18, 14, pal.muted, "left", 700);
        text(ctx, `${Math.ceil(time)} ${api.t("с", "s")}`, w - 12, 18, 14, time < 6 ? pal.red : pal.muted, "right", 700);
      },
    };
  });
}
const GEM_COLORS_LOCAL = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#3b82f6", "#a855f7", "#ec4899", "#14b8a6"];

function shuffleArr(a: number[]): number[] {
  const out = [...a];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

const MEMORIES: MemoryCfg[] = [
  { id: "mem-6", name: ["Память на 6 пар", "Memory 6 pairs"], desc: ["Шесть пар символов", "Six pairs of symbols"], icon: Brain, pairs: 6, numeric: false, timeLimit: 90 },
  { id: "mem-num", name: ["Память: числа", "Memory: numbers"], desc: ["Числа от 1 до 8", "Numbers 1 to 8"], icon: Hash, pairs: 6, numeric: true, timeLimit: 80 },
  { id: "mem-8", name: ["Память на 8 пар", "Memory 8 pairs"], desc: ["Восемь пар, 4×4", "Eight pairs, 4×4"], icon: Shapes, pairs: 8, numeric: false, timeLimit: 120 },
  { id: "mem-fast", name: ["Память-спринт", "Memory sprint"], desc: ["Больше пар, меньше времени", "More pairs, less time"], icon: Timer, pairs: 8, numeric: true, timeLimit: 70 },
  { id: "mem-zen", name: ["Память без спешки", "Relaxed memory"], desc: ["Спокойный темп", "A calm pace"], icon: Sparkles, pairs: 6, numeric: false, timeLimit: 150 },
];

// ───────────────────────── 8. Corridor (5) ─────────────────────────
interface CorridorCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  gap: number; speed: number; wall: string; theme: [string, string];
}
function corridorFamily(c: CorridorCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["antennaFB"], (api): GameInst => {
    let y = api.h / 2;
    let walls: Array<{ x: number; gy: number }> = [];
    let t = 0;
    return {
      update(dt, inp) {
        y = clamp(y - inp.ay * api.h * 0.85 * dt, 20, api.h - 20);
        t -= dt;
        if (t <= 0) {
          t = Math.max(0.7, 1.6 - api.time * 0.012);
          walls.push({ x: api.w + 30, gy: rand(c.gap / 2 + 30, api.h - c.gap / 2 - 30) });
        }
        for (const wl of walls) wl.x -= c.speed * dt;
        walls = walls.filter((wl) => {
          if (Math.abs(wl.x - api.w * 0.22) < 26) {
            if (Math.abs(y - wl.gy) > c.gap / 2 - 14) {
              api.fx.shake(7);
              api.sfx("hit");
              api.hurt();
              return false;
            }
          }
          return wl.x > -60;
        });
        api.score += dt * 6;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, c.theme[1]);
        for (const wl of walls) {
          if (c.wall === "teeth") {
            poly(ctx, [wl.x - 26, 0, wl.x + 26, 0, wl.x + 26, wl.gy - c.gap / 2, wl.x, wl.gy - c.gap / 2 - 18, wl.x - 26, wl.gy - c.gap / 2], c.theme[0]);
            poly(ctx, [wl.x - 26, wl.gy + c.gap / 2, wl.x, wl.gy + c.gap / 2 + 18, wl.x + 26, wl.gy + c.gap / 2, wl.x + 26, h, wl.x - 26, h], c.theme[0]);
          } else {
            rr(ctx, wl.x - 26, -10, 52, wl.gy - c.gap / 2 + 10, 6, c.theme[0]);
            rr(ctx, wl.x - 26, wl.gy + c.gap / 2, 52, h, 6, c.theme[0]);
          }
          ctx.strokeStyle = pal.amber;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(wl.x, wl.gy - c.gap / 2);
          ctx.lineTo(wl.x, wl.gy + c.gap / 2);
          ctx.stroke();
        }
        circle(ctx, w * 0.22, y, 14, pal.blue);
        circle(ctx, w * 0.22 + 5, y - 4, 3.5, "#fff");
        text(ctx, `${Math.floor(api.score)}`, 12, 18, 14, "#e5e7eb", "left", 700);
      },
    };
  });
}

const CORRIDORS: CorridorCfg[] = [
  { id: "cor-tunnel", name: ["Туннель", "Tunnel"], desc: ["Тесный туннель", "A tight tunnel"], icon: Wind, gap: 150, speed: 260, wall: "block", theme: ["#3f3f46", "#0c0a09"] },
  { id: "cor-canyon", name: ["Каньон", "Canyon"], desc: ["Скалы каньона", "Canyon rocks"], icon: TriangleAlert, gap: 170, speed: 240, wall: "block", theme: ["#92400e", "#1c1917"] },
  { id: "cor-teeth", name: ["Зубы", "Teeth"], desc: ["Острые зубы", "Sharp teeth"], icon: Zap, gap: 130, speed: 280, wall: "teeth", theme: ["#e5e7eb", "#0f172a"] },
  { id: "cor-space", name: ["Космический проход", "Space gap"], desc: ["Астероиды", "Asteroids"], icon: Rocket, gap: 185, speed: 300, wall: "block", theme: ["#475569", "#020617"] },
  { id: "cor-pipe", name: ["Труба", "Pipe"], desc: ["Зелёная труба", "Green pipe"], icon: Circle, gap: 140, speed: 270, wall: "block", theme: ["#16a34a", "#052e16"] },
];

// ───────────────────────── 9. Platform (5) ─────────────────────────
interface PlatformCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  speed: number; gapMin: number; gapMax: number; theme: [string, string];
}
function platformFamily(c: PlatformCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["tongue"], (api): GameInst => {
    const px = () => api.w * 0.22;
    const floorY = () => api.h - 50;
    let fy = 0;
    let vy = 0;
    let plats: Array<{ x: number; w: number }> = [];
    let gapLeft = 160;
    const seed = () => {
      plats = [];
      let x = -40;
      for (let i = 0; i < 8; i++) {
        plats.push({ x, w: rand(85, 145) });
        x += 145 + rand(c.gapMin, c.gapMax);
      }
      gapLeft = rand(c.gapMin, c.gapMax);
    };
    seed();
    const standing = () => plats.some((pl) => px() > pl.x && px() < pl.x + pl.w);
    return {
      update(dt, inp) {
        const speed = c.speed + api.time * 4;
        if ((inp.has("tongue") || inp.held.tongue) && fy <= 0.01 && vy <= 0 && standing()) {
          vy = 640;
          api.sfx("jump");
        }
        vy -= 1750 * dt;
        fy += vy * dt;
        if (fy < 0) {
          if (standing()) {
            fy = 0;
            vy = 0;
          } else {
            api.fx.shake(7);
            api.sfx("hit");
            api.hurt();
            seed();
            fy = 0;
            vy = 0;
            return;
          }
        }
        for (const pl of plats) pl.x -= speed * dt;
        plats = plats.filter((pl) => pl.x > -200);
        gapLeft -= speed * dt;
        if (gapLeft <= 0) {
          gapLeft = rand(c.gapMin, c.gapMax);
          const lastX = plats.length ? Math.max(...plats.map((pp) => pp.x + pp.w)) : api.w;
          plats.push({ x: Math.max(lastX + 60, api.w + 60), w: rand(85, 145) });
        }
        api.score += dt * 8;
      },
      draw() {
        const { ctx, h, pal } = api;
        bg(api, c.theme[1]);
        const fy0 = floorY();
        for (const pl of plats) {
          rr(ctx, pl.x, fy0, pl.w, 16, 6, c.theme[0]);
          ctx.fillStyle = pal.amber;
          ctx.fillRect(pl.x, fy0, pl.w, 3);
        }
        circle(ctx, px(), fy0 - 18 - fy, 17, pal.blue);
        circle(ctx, px() + 5, fy0 - 23 - fy, 3.5, "#fff");
        text(ctx, `${Math.floor(api.score)}`, 12, 18, 14, "#e5e7eb", "left", 700);
        void h;
      },
    };
  });
}

const PLATFORMS: PlatformCfg[] = [
  { id: "plat-hills", name: ["Холмы", "Hills"], desc: ["Зелёные холмы", "Green hills"], icon: ArrowBigUp, speed: 200, gapMin: 90, gapMax: 150, theme: ["#16a34a", "#052e16"] },
  { id: "plat-city", name: ["Крыши города", "City roofs"], desc: ["Крыши домов", "City rooftops"], icon: Building, speed: 230, gapMin: 80, gapMax: 140, theme: ["#475569", "#0f172a"] },
  { id: "plat-cave", name: ["Пещера", "Cave"], desc: ["Каменные плиты", "Stone slabs"], icon: Gem, speed: 210, gapMin: 100, gapMax: 160, theme: ["#78716c", "#1c1917"] },
  { id: "plat-roof", name: ["Паркур", "Parkour"], desc: ["Прыжки по крышам", "Rooftop jumps"], icon: Footprints, speed: 260, gapMin: 70, gapMax: 130, theme: ["#0ea5e9", "#0c4a6e"] },
  { id: "plat-lava", name: ["Лава", "Lava"], desc: ["Плиты над лавой", "Slabs over lava"], icon: Flame, speed: 245, gapMin: 85, gapMax: 155, theme: ["#ef4444", "#450a0a"] },
];

// ───────────────────────── 10. Flappy (4) ─────────────────────────
interface FlappyCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  gap: number; speed: number; pipeW: number; theme: string;
}
function flappyFamily(c: FlappyCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["tongue"], (api): GameInst => {
    let y = api.h / 2;
    let vy = 0;
    let go = false;
    let t = 0;
    let pipes: Array<{ x: number; g: number; p: boolean }> = [];
    return {
      update(dt, inp) {
        if (inp.has("tongue")) {
          vy = -api.h * 0.72;
          go = true;
          api.sfx("jump");
        }
        if (!go) return;
        vy += api.h * 2.1 * dt;
        y += vy * dt;
        t -= dt;
        if (t <= 0) {
          t = 1.45;
          pipes.push({ x: api.w + 30, g: rand(c.gap / 2 + 40, api.h - c.gap / 2 - 40), p: false });
        }
        for (const p of pipes) {
          p.x -= c.speed * dt;
          if (!p.p && p.x < api.w * 0.25) {
            p.p = true;
            api.add(1);
            api.sfx("coin");
          }
          if (Math.abs(p.x - api.w * 0.25) < 40 && Math.abs(y - p.g) > c.gap / 2 - 14) api.over(false);
        }
        if (y > api.h - 10 || y < 0) api.over(false);
        pipes = pipes.filter((p) => p.x > -60);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api, c.theme);
        for (const p of pipes) {
          rr(ctx, p.x - c.pipeW / 2, -10, c.pipeW, p.g - c.gap / 2 + 10, 8, "#22c55e");
          rr(ctx, p.x - c.pipeW / 2, p.g + c.gap / 2, c.pipeW, h, 8, "#22c55e");
        }
        circle(ctx, w * 0.25, y, 14, pal.amber);
        circle(ctx, w * 0.25 + 5, y - 4, 3.5, "#18181b");
        text(ctx, `${Math.floor(api.score)}`, 12, 18, 14, "#e5e7eb", "left", 700);
        if (!go) banner(api, api.t("Нажми язык", "Press the tongue"));
      },
    };
  });
}

const FLAPPY: FlappyCfg[] = [
  { id: "flap-classic", name: ["Классический флэппи", "Classic flappy"], desc: ["Обычные трубы", "Standard pipes"], icon: Bird, gap: 150, speed: 200, pipeW: 52, theme: "#7dd3fc" },
  { id: "flap-tight", name: ["Узкие трубы", "Tight pipes"], desc: ["Маленькие зазоры", "Small gaps"], icon: Zap, gap: 118, speed: 230, pipeW: 46, theme: "#a5b4fc" },
  { id: "flap-slow", name: ["Медленный полёт", "Slow flight"], desc: ["Спокойный темп", "A calm pace"], icon: Cloud, gap: 170, speed: 150, pipeW: 60, theme: "#bae6fd" },
  { id: "flap-fast", name: ["Скоростной", "Speed run"], desc: ["Очень быстро", "Very fast"], icon: Rocket, gap: 132, speed: 300, pipeW: 50, theme: "#c4b5fd" },
];

// ───────────────────────── 11. Breakout (4) ─────────────────────────
interface BrCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  rows: number; paddle: number; speed: number; hue: number;
}
function breakoutFamily(c: BrCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["antennaLR", "tongue"], (api): GameInst => {
    let px = api.w / 2;
    let ball = { x: 0, y: 0, vx: 0, vy: 0, stuck: true };
    let bricks: Array<{ x: number; y: number; alive: boolean; col: string }> = [];
    let level = 0;
    const build = () => {
      bricks = [];
      for (let r = 0; r < c.rows; r++)
        for (let col = 0; col < 10; col++)
          bricks.push({ x: col, y: r, alive: true, col: `hsl(${(r * 40 + c.hue + level * 30) % 360} 70% 55%)` });
    };
    build();
    return {
      update(dt, inp) {
        px = clamp(px + inp.ax * api.w * 0.95 * dt, 50, api.w - 50);
        if (ball.stuck) {
          ball.x = px;
          ball.y = api.h - 40;
          if (inp.has("tongue")) ball = { x: px, y: api.h - 40, vx: rand(-150, 150), vy: -(c.speed + level * 25), stuck: false };
          return;
        }
        ball.x += ball.vx * dt;
        ball.y += ball.vy * dt;
        if (ball.x < 8 || ball.x > api.w - 8) ball.vx *= -1;
        if (ball.y < 8) ball.vy = Math.abs(ball.vy);
        if (ball.y > api.h - 34 && ball.y < api.h - 20 && Math.abs(ball.x - px) < c.paddle / 2 && ball.vy > 0) {
          ball.vy = -Math.abs(ball.vy);
          ball.vx = (ball.x - px) * 6;
          api.sfx("pop");
        }
        if (ball.y > api.h + 10) {
          ball.stuck = true;
          api.hurt();
        }
        const bw = api.w / 10;
        for (const b of bricks) {
          if (!b.alive) continue;
          if (ball.x > b.x * bw && ball.x < (b.x + 1) * bw && ball.y > 40 + b.y * 22 && ball.y < 40 + (b.y + 1) * 22) {
            b.alive = false;
            ball.vy *= -1;
            api.add(10);
            api.sfx("coin");
            break;
          }
        }
        if (bricks.every((b) => !b.alive)) {
          level++;
          build();
          ball.stuck = true;
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const bw = w / 10;
        for (const b of bricks) if (b.alive) rr(ctx, b.x * bw + 2, 40 + b.y * 22, bw - 4, 18, 4, b.col);
        rr(ctx, px - c.paddle / 2, h - 30, c.paddle, 12, 6, pal.fg);
        circle(ctx, ball.x, ball.y, 8, pal.amber);
        text(ctx, `${api.t("Уровень", "Level")} ${level + 1}`, 12, 18, 14, pal.muted, "left", 700);
      },
    };
  });
}

const BREAKOUTS: BrCfg[] = [
  { id: "br-classic", name: ["Классический арканоид", "Classic breakout"], desc: ["Обычные кирпичи", "Standard bricks"], icon: Blocks, rows: 5, paddle: 100, speed: 330, hue: 200 },
  { id: "br-wide", name: ["Широкая ракетка", "Wide paddle"], desc: ["Ловить проще", "Easier to catch"], icon: Layers, rows: 6, paddle: 160, speed: 300, hue: 30 },
  { id: "br-fast", name: ["Быстрый мяч", "Fast ball"], desc: ["Мяч быстрее", "A faster ball"], icon: Zap, rows: 5, paddle: 90, speed: 430, hue: 300 },
  { id: "br-deep", name: ["Глубокий", "Deep stack"], desc: ["Много кирпичей", "Lots of bricks"], icon: Grid2x2, rows: 8, paddle: 110, speed: 350, hue: 150 },
];

// ───────────────────────── 12. Whack (2) ─────────────────────────
interface WhackCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  holes: number; life: number;
}
function whackFamily(c: WhackCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "skill", ["antenna", "tongue"], (api): GameInst => {
    const cols = c.holes <= 6 ? 3 : 3;
    const rowsN = Math.ceil(c.holes / cols);
    let cursor = 0;
    let mole = -1;
    let up = 0;
    let wait = 0.8;
    let popped = 0;
    return {
      update(dt, inp) {
        const row = Math.floor(cursor / cols);
        const col = cursor % cols;
        if (inp.has("antL")) cursor = row * cols + ((col + cols - 1) % cols);
        if (inp.has("antR")) cursor = row * cols + ((col + 1) % cols);
        if (inp.has("antF")) cursor = ((row + rowsN - 1) % rowsN) * cols + col;
        if (inp.has("antB")) cursor = ((row + 1) % rowsN) * cols + col;
        if (mole < 0) {
          wait -= dt;
          if (wait <= 0) {
            mole = randi(0, c.holes - 1);
            up = Math.max(0.9, c.life - api.time * 0.015);
          }
          return;
        }
        up -= dt;
        if (inp.has("tongue") && cursor === mole) {
          api.add(20, api.w / 2, api.h / 2);
          api.sfx("good");
          popped++;
          mole = -1;
          wait = rand(0.3, 0.8);
          return;
        }
        if (up <= 0) {
          mole = -1;
          wait = 0.5;
          api.sfx("error");
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cw = w / cols;
        const ch = (h - 40) / rowsN;
        for (let i = 0; i < c.holes; i++) {
          const cx = (i % cols + 0.5) * cw;
          const cy = 40 + (Math.floor(i / cols) + 0.5) * ch;
          ctx.fillStyle = pal.surface2;
          ctx.beginPath();
          ctx.ellipse(cx, cy + 18, cw * 0.3, 15, 0, 0, Math.PI * 2);
          ctx.fill();
          if (i === mole) {
            circle(ctx, cx, cy, 26, "#a16207");
            circle(ctx, cx - 8, cy - 5, 3.5, "#fff");
            circle(ctx, cx + 8, cy - 5, 3.5, "#fff");
          }
          if (i === cursor) strokeCircle(ctx, cx, cy, 34, pal.fg, 2);
        }
        text(ctx, `${api.t("Попал", "Whacked")}: ${popped}`, 12, 18, 14, pal.muted, "left", 700);
      },
    };
  });
}

const WHACKS: WhackCfg[] = [
  { id: "wh-6", name: ["Кроты 3×2", "Moles 3×2"], desc: ["Шесть нор", "Six holes"], icon: Hammer, holes: 6, life: 2.4 },
  { id: "wh-9", name: ["Кроты 3×3", "Moles 3×3"], desc: ["Девять нор", "Nine holes"], icon: Target, holes: 9, life: 1.9 },
];

// ───────────────────────── 13. Snake (2) ─────────────────────────
interface SnakeCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  wrap: boolean; speed: number; big: boolean;
}
function snakeFamily(c: SnakeCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["antenna"], (api): GameInst => {
    const W = 20;
    const H = 13;
    let snake = [[5, 6], [4, 6], [3, 6]];
    let dir = [1, 0];
    let next = [1, 0];
    let food = [12, 6];
    let t = 0;
    const place = () => {
      do food = [randi(0, W - 1), randi(0, H - 1)];
      while (snake.some(([a, b]) => a === food[0] && b === food[1]));
    };
    return {
      update(dt, inp) {
        const d = dirEvent(inp);
        if (d && (d[0] !== -dir[0] || d[1] !== -dir[1])) next = d;
        t -= dt;
        if (t > 0) return;
        t = Math.max(0.06, c.speed - snake.length * 0.003);
        dir = next;
        let head = [snake[0][0] + dir[0], snake[0][1] + dir[1]];
        if (c.wrap) {
          head = [(head[0] + W) % W, (head[1] + H) % H];
        } else if (head[0] < 0 || head[1] < 0 || head[0] >= W || head[1] >= H || snake.some(([a, b]) => a === head[0] && b === head[1])) {
          api.over(false);
          return;
        }
        if (snake.some(([a, b]) => a === head[0] && b === head[1])) {
          api.over(false);
          return;
        }
        snake.unshift(head);
        if (head[0] === food[0] && head[1] === food[1]) {
          api.add(c.big ? 30 : 10);
          api.sfx("coin");
          place();
        } else snake.pop();
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cs = Math.min(w / W, (h - 30) / H);
        const ox = (w - cs * W) / 2;
        const oy = 30;
        strokeCircle(ctx, ox + (cs * W) / 2, oy + (cs * H) / 2, Math.min(cs * W, cs * H) / 2 + 6, pal.line, 2);
        circle(ctx, ox + (food[0] + 0.5) * cs, oy + (food[1] + 0.5) * cs, cs * (c.big ? 0.42 : 0.35), pal.red);
        snake.forEach(([a, b], i) => rr(ctx, ox + a * cs + 1, oy + b * cs + 1, cs - 2, cs - 2, cs * 0.3, i ? pal.green : pal.lime));
        text(ctx, `${snake.length}`, 12, 18, 14, pal.muted, "left", 700);
      },
    };
    function dirEvent(inp: { events: Array<{ type: string }> }): number[] | null {
      for (const e of inp.events) {
        if (e.type === "antL") return [-1, 0];
        if (e.type === "antR") return [1, 0];
        if (e.type === "antF") return [0, -1];
        if (e.type === "antB") return [0, 1];
      }
      return null;
    }
  });
}

const SNAKES: SnakeCfg[] = [
  { id: "snake-wrap", name: ["Змейка-сквозь", "Wrapping snake"], desc: ["Стены проницаемы", "Walls are passable"], icon: Worm, wrap: true, speed: 0.16, big: false },
  { id: "snake-big", name: ["Змейка-обжора", "Greedy snake"], desc: ["Еда даёт больше", "Food gives more"], icon: Bug, wrap: false, speed: 0.18, big: true },
];

// ───────────────────────── 14. Stack (2) ─────────────────────────
interface StackCfg {
  id: string; name: Text; desc: Text; icon: LucideIcon;
  speed: number; shrink: number;
}
function stackFamily(c: StackCfg): GameDef {
  return def(c.id, c.name, c.desc, c.icon, "arcade", ["tongue"], (api): GameInst => {
    let blocks: Array<{ x: number; w: number }> = [{ x: api.w / 2 - 90, w: 180 }];
    let cur = { x: 0, w: 180, dir: 1 };
    let speed = c.speed;
    return {
      update(dt, inp) {
        cur.x += cur.dir * speed * dt;
        if (cur.x < 0 || cur.x + cur.w > api.w) cur.dir *= -1;
        if (!inp.has("tongue")) return;
        const top = blocks[blocks.length - 1];
        const l = Math.max(cur.x, top.x);
        const r = Math.min(cur.x + cur.w, top.x + top.w);
        if (r - l <= 0) {
          api.over(false);
          return;
        }
        const perfect = Math.abs(cur.x - top.x) < 5;
        const nb = perfect ? { x: top.x, w: top.w } : { x: l, w: r - l };
        blocks.push(nb);
        api.add(perfect ? 3 : 1, nb.x + nb.w / 2, api.h * 0.4);
        api.sfx(perfect ? "good" : "pop");
        cur = { x: 0, w: Math.max(30, nb.w * c.shrink), dir: 1 };
        speed += 12;
      },
      draw() {
        const { ctx, h, pal } = api;
        bg(api);
        const shift = Math.max(0, blocks.length - Math.floor((h * 0.6) / 30));
        blocks.forEach((b, i) => rr(ctx, b.x, h - (i - shift + 1) * 30, b.w, 28, 4, `hsl(${(i * 23) % 360} 70% 55%)`));
        rr(ctx, cur.x, h - (blocks.length - shift + 1) * 30 - 4, cur.w, 28, 4, `hsl(${(blocks.length * 23) % 360} 70% 55%)`);
        void pal;
      },
    };
  });
}

const STACKS: StackCfg[] = [
  { id: "stack-classic", name: ["Башня", "Tower"], desc: ["Классическая башня", "Classic tower"], icon: Layers, speed: 160, shrink: 0.94 },
  { id: "stack-narrow", name: ["Узкая башня", "Narrow tower"], desc: ["Блоки быстро мельчают", "Blocks shrink fast"], icon: Blocks, speed: 210, shrink: 0.88 },
];

export const FACTORY_GAMES: GameDef[] = [
  ...CATCHES.map(catchFamily),
  ...DODGES.map(dodgeFamily),
  ...SHOOTERS.map(shooterFamily),
  ...RUNNERS.map(runnerFamily),
  ...RACES.map(raceFamily),
  ...TARGETS.map(targetFamily),
  ...MEMORIES.map(memoryFamily),
  ...CORRIDORS.map(corridorFamily),
  ...PLATFORMS.map(platformFamily),
  ...FLAPPY.map(flappyFamily),
  ...BREAKOUTS.map(breakoutFamily),
  ...WHACKS.map(whackFamily),
  ...SNAKES.map(snakeFamily),
  ...STACKS.map(stackFamily),
];
