import type { LucideIcon } from "lucide-react";
import type { InputType } from "@/lib/furby/controller";
import type { Text } from "@/lib/i18n";
import type { Cat, Ctl, GameApi, GameDef, GameInst } from "./types";

/** Compact game definition helper */
export const def = (
  id: string,
  name: Text,
  desc: Text,
  icon: LucideIcon,
  cat: Cat,
  controls: Ctl[],
  create: (api: GameApi) => GameInst,
  extra: Partial<GameDef> = {},
): GameDef => ({ id, name, desc, icon, cat, controls, create, ...extra });

/** Maps performance.now() to Web Audio time (for rhythm judging) */
export function audioClock(ac: AudioContext) {
  return (perf = performance.now()) => {
    const o = ac.getOutputTimestamp?.();
    if (o && o.contextTime !== undefined && o.performanceTime) return o.contextTime + (perf - o.performanceTime) / 1000;
    return ac.currentTime - (ac.outputLatency || ac.baseLatency || 0) - (performance.now() - perf) / 1000;
  };
}

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const rand = (a = 0, b = 1) => a + Math.random() * (b - a);
export const randi = (a: number, b: number) => Math.floor(a + Math.random() * (b - a + 1));
export const pick = <T,>(arr: readonly T[]): T => arr[Math.floor(Math.random() * arr.length)];
export const chance = (p: number) => Math.random() < p;
export const dist = (ax: number, ay: number, bx: number, by: number) => Math.hypot(ax - bx, ay - by);
export const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}
export const overlap = (a: Box, b: Box) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

export const font = (size: number, weight = 600) => `${weight} ${Math.round(size)}px ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif`;

type C = CanvasRenderingContext2D;

export function text(ctx: C, s: string, x: number, y: number, size: number, color: string, align: CanvasTextAlign = "center", weight = 600) {
  ctx.font = font(size, weight);
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = "middle";
  ctx.fillText(s, x, y);
}

export function rr(ctx: C, x: number, y: number, w: number, h: number, r: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.roundRect(x, y, Math.max(0, w), Math.max(0, h), Math.max(0, Math.min(r, w / 2, h / 2)));
  ctx.fill();
}

export function ring(ctx: C, x: number, y: number, w: number, h: number, r: number, color: string, lw = 2) {
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.beginPath();
  ctx.roundRect(x, y, Math.max(0, w), Math.max(0, h), Math.max(0, Math.min(r, w / 2, h / 2)));
  ctx.stroke();
}

export function circle(ctx: C, x: number, y: number, r: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, Math.max(0, r), 0, Math.PI * 2);
  ctx.fill();
}

export function strokeCircle(ctx: C, x: number, y: number, r: number, color: string, lw = 2) {
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.beginPath();
  ctx.arc(x, y, Math.max(0, r), 0, Math.PI * 2);
  ctx.stroke();
}

export function poly(ctx: C, pts: number[], color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
  ctx.closePath();
  ctx.fill();
}

export function line(ctx: C, x1: number, y1: number, x2: number, y2: number, color: string, lw = 2) {
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}

export function bar(ctx: C, x: number, y: number, w: number, h: number, frac: number, color: string, bg: string) {
  rr(ctx, x, y, w, h, h / 2, bg);
  if (frac > 0) rr(ctx, x, y, Math.max(h, w * clamp(frac, 0, 1)), h, h / 2, color);
}

export function heart(ctx: C, x: number, y: number, s: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y + s * 0.9);
  ctx.bezierCurveTo(x - s * 1.4, y - s * 0.1, x - s * 0.6, y - s * 1.2, x, y - s * 0.35);
  ctx.bezierCurveTo(x + s * 0.6, y - s * 1.2, x + s * 1.4, y - s * 0.1, x, y + s * 0.9);
  ctx.fill();
}

export function star(ctx: C, x: number, y: number, r: number, color: string, rot = 0) {
  const pts: number[] = [];
  for (let i = 0; i < 10; i++) {
    const a = rot - Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 ? r * 0.45 : r;
    pts.push(x + Math.cos(a) * rad, y + Math.sin(a) * rad);
  }
  poly(ctx, pts, color);
}

/** Arrow: 0 left, 1 down, 2 up, 3 right */
export function arrow(ctx: C, cx: number, cy: number, size: number, dir: number, color: string, outline = false) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate([Math.PI, Math.PI / 2, -Math.PI / 2, 0][dir] ?? 0);
  const s = size / 2;
  ctx.beginPath();
  ctx.moveTo(s, 0);
  ctx.lineTo(0, -s * 0.92);
  ctx.lineTo(0, -s * 0.36);
  ctx.lineTo(-s * 0.92, -s * 0.36);
  ctx.lineTo(-s * 0.92, s * 0.36);
  ctx.lineTo(0, s * 0.36);
  ctx.lineTo(0, s * 0.92);
  ctx.closePath();
  if (outline) {
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.lineJoin = "round";
    ctx.stroke();
  } else {
    ctx.fillStyle = color;
    ctx.fill();
  }
  ctx.restore();
}

/** Antenna events in lane order ← ↓ ↑ → */
export const LANE_EVENTS: InputType[] = ["antL", "antB", "antF", "antR"];
export const LANE_COLORS = ["#a855f7", "#06b6d4", "#22c55e", "#ef4444"];
export const laneOf = (type: InputType) => LANE_EVENTS.indexOf(type);

export function bg(api: GameApi, color?: string) {
  api.ctx.fillStyle = color ?? api.pal.bg;
  api.ctx.fillRect(-20, -20, api.w + 40, api.h + 40);
}

export function banner(api: GameApi, title: string, sub?: string, color?: string) {
  const { ctx, w, h, pal } = api;
  text(ctx, title, w / 2, h / 2 - (sub ? 16 : 0), clamp(w / 14, 22, 44), color ?? pal.fg, "center", 800);
  if (sub) text(ctx, sub, w / 2, h / 2 + 22, clamp(w / 40, 13, 17), pal.muted, "center", 500);
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}
interface Floater {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}

export class Fx {
  private parts: Particle[] = [];
  private texts: Floater[] = [];
  private shakeT = 0;
  private shakeA = 0;

  burst(x: number, y: number, color: string, n = 14, speed = 180, size = 3) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = speed * (0.3 + Math.random() * 0.7);
      const life = 0.4 + Math.random() * 0.5;
      this.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life, max: life, color, size: size * (0.6 + Math.random() * 0.8) });
    }
    if (this.parts.length > 600) this.parts.splice(0, this.parts.length - 600);
  }

  float(text: string, x: number, y: number, color: string) {
    this.texts.push({ x, y, text, color, life: 0.9 });
    if (this.texts.length > 30) this.texts.shift();
  }

  shake(amount = 6, time = 0.25) {
    this.shakeA = amount;
    this.shakeT = time;
  }

  update(dt: number) {
    for (const p of this.parts) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 300 * dt;
      p.vx *= 1 - dt * 1.5;
    }
    this.parts = this.parts.filter((p) => p.life > 0);
    for (const t of this.texts) {
      t.life -= dt;
      t.y -= 40 * dt;
    }
    this.texts = this.texts.filter((t) => t.life > 0);
    this.shakeT = Math.max(0, this.shakeT - dt);
  }

  offset(): [number, number] {
    if (this.shakeT <= 0) return [0, 0];
    const k = this.shakeA * (this.shakeT / 0.25);
    return [(Math.random() * 2 - 1) * k, (Math.random() * 2 - 1) * k];
  }

  draw(ctx: C) {
    for (const p of this.parts) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      circle(ctx, p.x, p.y, p.size, p.color);
    }
    ctx.globalAlpha = 1;
    for (const t of this.texts) {
      ctx.globalAlpha = Math.max(0, Math.min(1, t.life * 2));
      text(ctx, t.text, t.x, t.y, 18, t.color, "center", 800);
    }
    ctx.globalAlpha = 1;
  }
}
