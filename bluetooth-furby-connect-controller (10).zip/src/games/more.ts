/** Six more games: tic-tac-toe, pinball, fruit slice, tanks, minesweeper, match-three. */
import { CircleDot, Crosshair, Hash, Pointer, Shapes, Target } from "lucide-react";
import { banner, bg, chance, circle, clamp, def, dist, line, pick, poly, rand, randi, rr, strokeCircle, text } from "./kit";
import type { GameDef, GameInst } from "./types";

// ───────────────────────── Tic-tac-toe vs Furby ─────────────────────────
const TTT_LINES: number[][] = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

export const tttGame = def(
  "ttt",
  ["Крестики-нолики", "Tic-Tac-Toe"],
  ["Игра против Фёрби: ты — синие X, он — красные O. Ход антенной, ставишь языком.", "Play against Furby: you are blue X, he is red O. Move with the antenna, place with the tongue."],
  Hash,
  "logic",
  ["antenna", "tongue"],
  (api): GameInst => {
    const board = Array<number>(9).fill(0);
    let cursor = 4;
    let phase: "play" | "end" = "play";
    let endT = 0;
    let win = false;
    let endText = "";

    const judge = () => {
      for (const [a, b, c] of TTT_LINES) if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
      return board.every((v) => v) ? 0 : -1;
    };
    const finish = (res: "win" | "lose" | "draw") => {
      phase = "end";
      endT = 1.5;
      endText = res === "win" ? api.t("Победа!", "You win!") : res === "lose" ? api.t("Фёрби выиграл", "Furby wins") : api.t("Ничья", "Draw");
      api.score = res === "win" ? 100 : res === "draw" ? 30 : 0;
      win = res !== "lose";
      api.sfx(res === "win" ? "win" : res === "lose" ? "lose" : "good");
    };
    const afterPlayer = () => {
      const r = judge();
      if (r === 1) return finish("win");
      if (r === 0) return finish("draw");
      // Furby's move: win → block → centre → corner → random
      const find = (p: number) => {
        for (const [a, b, c] of TTT_LINES) {
          const v = [board[a], board[b], board[c]];
          if (v.filter((x) => x === p).length === 2 && v.includes(0)) return [a, b, c][v.indexOf(0)];
        }
        return -1;
      };
      let m = find(2);
      if (m < 0) m = find(1);
      if (m < 0 && !board[4]) m = 4;
      if (m < 0) {
        const corners = [0, 2, 6, 8].filter((i) => !board[i]);
        if (corners.length) m = pick(corners);
      }
      if (m < 0) {
        const empty = board.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
        if (empty.length) m = pick(empty);
      }
      if (m >= 0) board[m] = 2;
      const r2 = judge();
      if (r2 === 2) finish("lose");
      else if (r2 === 0) finish("draw");
    };

    return {
      update(dt, inp) {
        if (phase === "end") {
          endT -= dt;
          if (endT <= 0) api.over(win);
          return;
        }
        const row = Math.floor(cursor / 3);
        const col = cursor % 3;
        if (inp.has("antL")) cursor = row * 3 + ((col + 2) % 3);
        if (inp.has("antR")) cursor = row * 3 + ((col + 1) % 3);
        if (inp.has("antF")) cursor = ((row + 2) % 3) * 3 + col;
        if (inp.has("antB")) cursor = ((row + 1) % 3) * 3 + col;
        if (inp.has("tongue") && !board[cursor]) {
          board[cursor] = 1;
          api.sfx("pop");
          afterPlayer();
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const size = Math.min(w * 0.72, h * 0.72);
        const ox = (w - size) / 2;
        const oy = (h - size) / 2 + 4;
        const cs = size / 3;
        for (let i = 1; i < 3; i++) {
          line(ctx, ox + i * cs, oy + 6, ox + i * cs, oy + size - 6, pal.fg, 3);
          line(ctx, ox + 6, oy + i * cs, ox + size - 6, oy + i * cs, pal.fg, 3);
        }
        board.forEach((v, i) => {
          const cx = ox + (i % 3) * cs + cs / 2;
          const cy = oy + Math.floor(i / 3) * cs + cs / 2;
          if (i === cursor && phase === "play") {
            rr(ctx, cx - cs * 0.4, cy - cs * 0.4, cs * 0.8, cs * 0.8, 12, pal.dark ? "#ffffff12" : "#00000010");
            strokeCircle(ctx, cx, cy, cs * 0.34, pal.faint, 2);
          }
          if (v === 1) {
            const s = cs * 0.24;
            line(ctx, cx - s, cy - s, cx + s, cy + s, pal.blue, 9);
            line(ctx, cx + s, cy - s, cx - s, cy + s, pal.blue, 9);
          }
          if (v === 2) strokeCircle(ctx, cx, cy, cs * 0.25, pal.red, 9);
        });
        if (phase === "end") banner(api, endText);
        text(ctx, api.t("Ты — синие X, Фёрби — красные O", "You are blue X, Furby is red O"), w / 2, h - 14, 12, pal.muted, "center", 600);
      },
    };
  },
);

// ───────────────────────── Pinball ─────────────────────────
export const pinballGame = def(
  "pinball",
  ["Пинбол", "Pinball"],
  ["Наклоны двигают флпперы, язык — оба сразу. Бамперы копят множитель до ×8, три шары.", "Tilts move the flippers, tongue presses both. Bumpers build a multiplier up to ×8, three balls."],
  CircleDot,
  "skill",
  ["tilt", "tongue"],
  (api): GameInst => {
    let px = api.w / 2;
    let py = api.h * 0.25;
    let vx = rand(-120, 120);
    let vy = 0;
    let balls = 3;
    let mult = 1;
    let lfT = 0;
    let rfT = 0;
    let msg = "";
    let msgT = 0;
    const R = 9;
    const bumpers = [
      { fx: 0.3, fy: 0.3, r: 24 },
      { fx: 0.7, fy: 0.3, r: 24 },
      { fx: 0.5, fy: 0.5, r: 28 },
    ];
    const respawn = () => {
      px = api.w * 0.5;
      py = api.h * 0.22;
      vx = rand(-110, 110);
      vy = 40;
      mult = 1;
    };
    return {
      update(dt, inp) {
        for (const e of inp.events) {
          if (e.type === "tiltL" || e.type === "tongue") lfT = 0.22;
          if (e.type === "tiltR" || e.type === "tongue") rfT = 0.22;
        }
        lfT = Math.max(0, lfT - dt);
        rfT = Math.max(0, rfT - dt);
        msgT = Math.max(0, msgT - dt);
        vy += 430 * dt;
        px += vx * dt;
        py += vy * dt;
        if (px < R) {
          px = R;
          vx = Math.abs(vx) * 0.9;
        }
        if (px > api.w - R) {
          px = api.w - R;
          vx = -Math.abs(vx) * 0.9;
        }
        if (py < R + 26) {
          py = R + 26;
          vy = Math.abs(vy) * 0.9;
        }
        for (const b of bumpers) {
          const bx = api.w * b.fx;
          const by = api.h * b.fy;
          const d = dist(px, py, bx, by);
          if (d < b.r + R) {
            const nx = (px - bx) / (d || 1);
            const ny = (py - by) / (d || 1);
            px = bx + nx * (b.r + R + 1);
            py = by + ny * (b.r + R + 1);
            vx = nx * 240;
            vy = ny * 240;
            api.add(50 * mult, bx, by);
            mult = Math.min(8, mult + 1);
            msg = `+${50 * (mult - 1)} ×${mult}`;
            msgT = 0.7;
            api.sfx("pop");
          }
        }
        // flippers (two zones at the bottom)
        if (py > api.h - 78 && vy > 0) {
          const inLeft = px > api.w * 0.1 && px < api.w * 0.47;
          const inRight = px > api.w * 0.53 && px < api.w * 0.9;
          if (inLeft && lfT > 0) {
            py = api.h - 78;
            vy = -430;
            vx += (px - api.w * 0.3) * 3.4;
            api.sfx("pop");
          } else if (inRight && rfT > 0) {
            py = api.h - 78;
            vy = -430;
            vx += (px - api.w * 0.7) * 3.4;
            api.sfx("pop");
          }
        }
        if (py > api.h + 30) {
          balls--;
          if (balls <= 0) {
            api.over(true);
            return;
          }
          respawn();
          api.sfx("error");
        }
        vx = clamp(vx, -420, 420);
        vy = clamp(vy, -560, 560);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        for (const b of bumpers) {
          const bx = w * b.fx;
          const by = h * b.fy;
          circle(ctx, bx, by, b.r, pal.surface2);
          strokeCircle(ctx, bx, by, b.r, pal.red, 3);
          text(ctx, "50", bx, by, 12, pal.muted, "center", 700);
        }
        // flippers
        const fy = h - 66;
        line(ctx, w * 0.12, fy + (lfT > 0 ? -16 : 12), w * 0.46, fy + (lfT > 0 ? 8 : 26), pal.fg, 10);
        line(ctx, w * 0.54, fy + (rfT > 0 ? 8 : 26), w * 0.88, fy + (rfT > 0 ? -16 : 12), pal.fg, 10);
        circle(ctx, px, py, R, pal.amber);
        strokeCircle(ctx, px, py, R, pal.fg, 2);
        for (let i = 0; i < balls; i++) circle(ctx, w - 18 - i * 16, 16, 6, pal.amber);
        if (msgT > 0) text(ctx, msg, px, py - 22, 15, pal.green, "center", 800);
        text(ctx, `×${mult}`, 14, h - 16, 16, pal.fg, "left", 800);
      },
    };
  },
);

// ───────────────────────── Fruit slice ─────────────────────────
const FRUIT_COLORS = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#ec4899", "#8b5cf6"];

export const fruitGame = def(
  "fruit",
  ["Фруктовый срез", "Fruit Slice"],
  ["Лезвие следует за антенной, язык — рубит. Режь фрукты, не задевай бомбы.", "The blade follows the antenna, the tongue slashes. Slice fruit, avoid the bombs."],
  Pointer,
  "arcade",
  ["antenna", "tongue"],
  (api): GameInst => {
    let bx = api.w / 2;
    let by = api.h / 2;
    let items: Array<{ x: number; y: number; vx: number; vy: number; r: number; color: string; bomb: boolean }> = [];
    let halves: Array<{ x: number; y: number; vx: number; vy: number; r: number; color: string; rot: number }> = [];
    const trail: Array<{ x: number; y: number; t: number }> = [];
    let spawnT = 0.5;
    return {
      update(dt, inp) {
        const tx = api.w * (0.5 + inp.ax * 0.44);
        const ty = api.h * (0.5 - inp.ay * 0.44);
        bx += (tx - bx) * Math.min(1, dt * 14);
        by += (ty - by) * Math.min(1, dt * 14);
        trail.push({ x: bx, y: by, t: api.time });
        while (trail.length && api.time - trail[0].t > 0.22) trail.shift();
        spawnT -= dt;
        if (spawnT <= 0) {
          spawnT = rand(0.85, 1.4);
          const fromLeft = chance(0.5);
          items.push({
            x: fromLeft ? -30 : api.w + 30,
            y: api.h + 20,
            vx: rand(120, 250) * (fromLeft ? 1 : -1),
            vy: -rand(380, 540),
            r: rand(24, 34),
            color: pick(FRUIT_COLORS),
            bomb: chance(0.18),
          });
        }
        for (const it of items) {
          it.vy += 700 * dt;
          it.x += it.vx * dt;
          it.y += it.vy * dt;
        }
        items = items.filter((it) => it.y < api.h + 70 && it.x > -80 && it.x < api.w + 80);
        if (inp.held.tongue) {
          for (const it of items) {
            if (dist(it.x, it.y, bx, by) >= it.r + 16) continue;
            const { x, y } = it;
            it.y = 9999;
            if (it.bomb) {
              api.fx.burst(x, y, "#18181b", 24, 240, 4);
              api.fx.shake(9);
              api.hurt();
              api.sfx("boom");
            } else {
              api.add(10, x, y);
              api.sfx("coin");
              halves.push({ x, y, vx: it.vx * 0.4 - 70, vy: -140, r: it.r, color: it.color, rot: 0 });
              halves.push({ x, y, vx: it.vx * 0.4 + 70, vy: -140, r: it.r, color: it.color, rot: Math.PI });
              api.fx.burst(x, y, it.color, 6, 130, 3);
            }
          }
          items = items.filter((it) => it.y < 9000);
        }
        for (const hf of halves) {
          hf.vy += 700 * dt;
          hf.x += hf.vx * dt;
          hf.y += hf.vy * dt;
          hf.rot += 5 * dt;
        }
        halves = halves.filter((hf) => hf.y < api.h + 80);
      },
      draw() {
        const { ctx, w, pal } = api;
        bg(api);
        for (const it of items) {
          circle(ctx, it.x, it.y, it.r, it.color);
          if (it.bomb) {
            circle(ctx, it.x, it.y, it.r * 0.6, "#18181b");
            strokeCircle(ctx, it.x, it.y, it.r, pal.fg, 3);
            line(ctx, it.x, it.y - it.r, it.x + 8, it.y - it.r - 10, pal.amber, 3);
          } else {
            poly(ctx, [it.x, it.y - it.r, it.x + 9, it.y - it.r - 10, it.x - 3, it.y - it.r - 12], "#16a34a");
          }
        }
        for (const hf of halves) {
          ctx.fillStyle = hf.color;
          ctx.beginPath();
          ctx.arc(hf.x, hf.y, hf.r, hf.rot, hf.rot + Math.PI);
          ctx.fill();
        }
        if (trail.length > 1) {
          ctx.strokeStyle = "#e0f2fe";
          ctx.lineWidth = 5;
          ctx.lineCap = "round";
          ctx.beginPath();
          trail.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
          ctx.stroke();
        }
        circle(ctx, bx, by, 7, "#ffffff");
        strokeCircle(ctx, bx, by, 7, pal.fg, 2);
        void w;
      },
    };
  },
);

// ───────────────────────── Tank battle ─────────────────────────
export const tankGame = def(
  "tank",
  ["Танковый бой", "Tank Battle"],
  ["Наклонами ведёшь танк по полю, язык стреляет. Волны врагов идут на тебя.", "Tilts drive the tank around the field, the tongue fires. Waves of enemies come at you."],
  Crosshair,
  "arcade",
  ["tilt", "tongue"],
  (api): GameInst => {
    let tx = api.w / 2;
    let ty = api.h * 0.78;
    let bullets: Array<{ x: number; y: number }> = [];
    let enemies: Array<{ x: number; y: number; vx: number; vy: number; hp: number }> = [];
    let spawnT = 1;
    let fireCd = 0;
    let inv = 0;
    let wave = 1;
    let waveT = 0;
    return {
      update(dt, inp) {
        tx = clamp(tx + inp.tiltX * api.w * 0.85 * dt, 30, api.w - 30);
        ty = clamp(ty - inp.tiltY * api.h * 0.65 * dt, api.h * 0.45, api.h - 34);
        fireCd -= dt;
        inv = Math.max(0, inv - dt);
        if (inp.has("tongue") && fireCd <= 0) {
          fireCd = 0.28;
          bullets.push({ x: tx, y: ty - 26 });
          api.sfx("shoot");
        }
        for (const b of bullets) b.y -= 540 * dt;
        waveT += dt;
        if (waveT > 14) {
          waveT = 0;
          wave++;
          api.fx.float(api.t(`Волна ${wave}`, `Wave ${wave}`), api.w / 2, api.h * 0.3, api.pal.amber);
        }
        spawnT -= dt;
        if (spawnT <= 0) {
          spawnT = Math.max(0.35, 1.3 - api.time * 0.02);
          enemies.push({ x: rand(30, api.w - 30), y: -30, vx: rand(-70, 70), vy: rand(55, 110) + wave * 8, hp: wave > 3 && chance(0.3) ? 2 : 1 });
        }
        for (const e of enemies) {
          e.x += e.vx * dt;
          e.y += e.vy * dt;
          if (e.x < 26 || e.x > api.w - 26) e.vx *= -1;
        }
        for (const b of bullets) {
          for (const e of enemies) {
            if (e.hp > 0 && dist(b.x, b.y, e.x, e.y) < 26) {
              b.y = -99;
              e.hp--;
              if (e.hp <= 0) {
                api.add(20, e.x, e.y);
                api.fx.burst(e.x, e.y, api.pal.amber, 12, 160);
                api.sfx("boom");
              }
            }
          }
        }
        for (const e of enemies) {
          if (e.hp > 0 && inv <= 0 && dist(e.x, e.y, tx, ty) < 28) {
            e.hp = 0;
            inv = 1.2;
            api.fx.shake(8);
            api.hurt();
          }
        }
        bullets = bullets.filter((b) => b.y > -20);
        enemies = enemies.filter((e) => e.hp > 0 && e.y < api.h + 40);
        api.score += dt * 2;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        ctx.strokeStyle = pal.dark ? "#ffffff08" : "#00000010";
        for (let gx = 0; gx < w; gx += 40) line(ctx, gx, 0, gx, h, ctx.strokeStyle as string, 1);
        for (const e of enemies) {
          rr(ctx, e.x - 18, e.y - 14, 36, 28, 5, pal.red);
          rr(ctx, e.x - 4, e.y - 22, 8, 12, 3, pal.red);
          if (e.hp > 1) text(ctx, String(e.hp), e.x, e.y, 11, "#fff", "center", 800);
        }
        for (const b of bullets) rr(ctx, b.x - 3, b.y - 8, 6, 14, 3, pal.amber);
        if (inv <= 0 || Math.floor(api.time * 12) % 2) {
          rr(ctx, tx - 20, ty - 16, 40, 32, 6, pal.blue);
          rr(ctx, tx - 4, ty - 30, 8, 16, 3, pal.blue);
          circle(ctx, tx, ty, 5, "#fff");
        }
        text(ctx, api.t(`Волна ${wave}`, `Wave ${wave}`), 12, 18, 14, pal.muted, "left", 700);
      },
    };
  },
);

// ───────────────────────── Minesweeper ─────────────────────────
export const sapperGame = def(
  "sapper",
  ["Сапёр", "Minesweeper"],
  ["10×10 и 14 мин: антенна двигает курсор, язык вскрывает, хвост ставит флаг.", "10×10 with 14 mines: antenna moves the cursor, tongue reveals, tail flags."],
  Target,
  "logic",
  ["antenna", "tongue", "tail"],
  (api): GameInst => {
    const N = 10;
    const MINES = 14;
    const grid = Array<number>(N * N).fill(0);
    const open = Array<boolean>(N * N).fill(false);
    const flag = Array<boolean>(N * N).fill(false);
    let cursor = 55;
    let first = true;
    let ended = false;
    let won = false;
    let endT = 0;
    let flags = 0;
    const at = (r: number, c: number) => r * N + c;
    const around = (i: number) => {
      const r = Math.floor(i / N);
      const c = i % N;
      const out: number[] = [];
      for (let dr = -1; dr <= 1; dr++)
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr;
          const nc = c + dc;
          if (nr >= 0 && nr < N && nc >= 0 && nc < N) out.push(at(nr, nc));
        }
      return out;
    };
    const plant = (safe: number) => {
      let placed = 0;
      while (placed < MINES) {
        const i = randi(0, N * N - 1);
        if (i === safe || grid[i] === -1) continue;
        grid[i] = -1;
        placed++;
      }
      for (let i = 0; i < N * N; i++) if (grid[i] !== -1) grid[i] = around(i).filter((j) => grid[j] === -1).length;
    };
    const reveal = (i: number) => {
      if (open[i] || flag[i]) return;
      open[i] = true;
      if (grid[i] === -1) {
        ended = true;
        won = false;
        endT = 1.4;
        for (let k = 0; k < N * N; k++) if (grid[k] === -1) open[k] = true;
        api.fx.shake(10);
        api.sfx("boom");
        return;
      }
      if (grid[i] === 0) for (const j of around(i)) reveal(j);
    };
    const NUM_COLORS = ["", "#2f7de1", "#12a37a", "#e8386a", "#7c4dff", "#cf8a12", "#0f9b8e", "#15181c", "#767d86"];
    return {
      update(dt, inp) {
        if (ended) {
          endT -= dt;
          if (endT <= 0) {
            if (won) api.score = Math.max(100, 2200 - Math.floor(api.time * 25));
            api.over(won);
          }
          return;
        }
        const row = Math.floor(cursor / N);
        const col = cursor % N;
        if (inp.has("antL")) cursor = at(row, (col + N - 1) % N);
        if (inp.has("antR")) cursor = at(row, (col + 1) % N);
        if (inp.has("antF")) cursor = at((row + N - 1) % N, col);
        if (inp.has("antB")) cursor = at((row + 1) % N, col);
        if (inp.has("tongue")) {
          if (first) {
            plant(cursor);
            first = false;
          }
          reveal(cursor);
          api.sfx("tick");
          if (ended) return;
          let opened = 0;
          for (let i = 0; i < N * N; i++) if (open[i] && grid[i] !== -1) opened++;
          if (opened === N * N - MINES) {
            ended = true;
            won = true;
            endT = 1.4;
            api.sfx("win");
          }
        }
        if (inp.has("tail") && !open[cursor]) {
          flag[cursor] = !flag[cursor];
          flags += flag[cursor] ? 1 : -1;
          api.sfx("pop");
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cs = Math.min((w - 16) / N, (h - 56) / N);
        const ox = (w - cs * N) / 2;
        const oy = 40;
        for (let i = 0; i < N * N; i++) {
          const r = Math.floor(i / N);
          const c = i % N;
          const x = ox + c * cs;
          const y = oy + r * cs;
          if (open[i]) {
            rr(ctx, x + 1, y + 1, cs - 2, cs - 2, 3, pal.dark ? "#23272d" : "#f4f4f5");
            if (grid[i] === -1) circle(ctx, x + cs / 2, y + cs / 2, cs * 0.24, pal.fg);
            else if (grid[i] > 0) text(ctx, String(grid[i]), x + cs / 2, y + cs / 2, cs * 0.55, NUM_COLORS[grid[i]], "center", 800);
          } else {
            rr(ctx, x + 1, y + 1, cs - 2, cs - 2, 3, pal.surface2);
            if (flag[i]) poly(ctx, [x + cs * 0.3, y + cs * 0.68, x + cs * 0.3, y + cs * 0.3, x + cs * 0.7, y + cs * 0.48], pal.red);
          }
          if (i === cursor) strokeCircle(ctx, x + cs / 2, y + cs / 2, cs * 0.42, pal.fg, 2);
        }
        text(ctx, `${t0(MINES - flags)}`, 12, 18, 14, pal.muted, "left", 700);
        text(ctx, `${Math.floor(api.time)} ${api.t("с", "s")}`, w - 12, 18, 14, pal.muted, "right", 700);
        if (ended) banner(api, won ? api.t("Поле чисто!", "Field clear!") : api.t("Бум!", "Boom!"));
        function t0(n: number) {
          return `⚑ ${n}`;
        }
      },
    };
  },
);

// ───────────────────────── Match-three ─────────────────────────
const GEM_COLORS = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#3b82f6", "#a855f7"];

export const match3Game = def(
  "match3",
  ["Три в ряд", "Match Three"],
  ["Антенна двигает курсор, язык выбирает фишку — соединяй одинаковые по три. 30 ходов.", "The antenna moves the cursor, the tongue picks a gem — match three of a kind. 30 moves."],
  Shapes,
  "logic",
  ["antenna", "tongue"],
  (api): GameInst => {
    const N = 8;
    const COLORS = 6;
    const grid = Array<number>(N * N).fill(0);
    const idx = (r: number, c: number) => r * N + c;
    const matches = () => {
      const out = new Set<number>();
      for (let r = 0; r < N; r++) {
        let run = 1;
        for (let c = 1; c <= N; c++) {
          if (c < N && grid[idx(r, c)] > 0 && grid[idx(r, c)] === grid[idx(r, c - 1)]) run++;
          else {
            if (run >= 3) for (let k = c - run; k < c; k++) out.add(idx(r, k));
            run = 1;
          }
        }
      }
      for (let c = 0; c < N; c++) {
        let run = 1;
        for (let r = 1; r <= N; r++) {
          if (r < N && grid[idx(r, c)] > 0 && grid[idx(r, c)] === grid[idx(r - 1, c)]) run++;
          else {
            if (run >= 3) for (let k = r - run; k < r; k++) out.add(idx(k, c));
            run = 1;
          }
        }
      }
      return [...out];
    };
    const refill = () => {
      for (let c = 0; c < N; c++) {
        let write = N - 1;
        for (let r = N - 1; r >= 0; r--) if (grid[idx(r, c)] > 0) grid[idx(write--, c)] = grid[idx(r, c)];
        while (write >= 0) grid[idx(write--, c)] = 1 + randi(0, COLORS - 1);
      }
    };
    // no starting matches
    let guard = 0;
    do {
      for (let i = 0; i < N * N; i++) grid[i] = 1 + randi(0, COLORS - 1);
      guard++;
    } while (matches().length && guard < 60);

    let cursor = 36;
    let sel = -1;
    let moves = 30;
    let chain = 1;
    let step: "idle" | "swapBack" | "clear" | "settle" = "idle";
    let stepT = 0;
    let a = -1;
    let b = -1;
    let clearSet: number[] = [];
    let ending = false;
    let endT = 0;

    const adjacent = (x: number, y: number) => {
      const r1 = Math.floor(x / N);
      const c1 = x % N;
      const r2 = Math.floor(y / N);
      const c2 = y % N;
      return Math.abs(r1 - r2) + Math.abs(c1 - c2) === 1;
    };
    const beginClear = (m: number[]) => {
      clearSet = m;
      api.add(10 * m.length * chain);
      api.sfx("coin");
      chain++;
      step = "clear";
      stepT = 0.3;
    };
    const settle = () => {
      for (const i of clearSet) grid[i] = 0;
      refill();
      const m = matches();
      if (m.length) beginClear(m);
      else {
        step = "idle";
        chain = 1;
        if (moves <= 0) {
          ending = true;
          endT = 1;
        }
      }
    };

    return {
      update(dt, inp) {
        if (ending) {
          endT -= dt;
          if (endT <= 0) api.over(true);
          return;
        }
        if (step !== "idle") {
          stepT -= dt;
          if (stepT <= 0) {
            if (step === "swapBack") {
              const t = grid[a];
              grid[a] = grid[b];
              grid[b] = t;
              step = "idle";
            } else if (step === "clear" || step === "settle") settle();
          }
          return;
        }
        const row = Math.floor(cursor / N);
        const col = cursor % N;
        if (inp.has("antL")) cursor = idx(row, (col + N - 1) % N);
        if (inp.has("antR")) cursor = idx(row, (col + 1) % N);
        if (inp.has("antF")) cursor = idx((row + N - 1) % N, col);
        if (inp.has("antB")) cursor = idx((row + 1) % N, col);
        if (inp.has("tongue")) {
          if (sel < 0) {
            sel = cursor;
            api.sfx("tick");
          } else if (sel === cursor) sel = -1;
          else if (adjacent(sel, cursor)) {
            const t = grid[sel];
            grid[sel] = grid[cursor];
            grid[cursor] = t;
            moves--;
            a = sel;
            b = cursor;
            sel = -1;
            api.sfx("pop");
            const m = matches();
            if (m.length) beginClear(m);
            else {
              step = "swapBack";
              stepT = 0.3;
            }
          } else sel = cursor;
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const cs = Math.min((w - 16) / N, (h - 64) / N);
        const ox = (w - cs * N) / 2;
        const oy = 40;
        for (let i = 0; i < N * N; i++) {
          const r = Math.floor(i / N);
          const c = i % N;
          const x = ox + c * cs + cs / 2;
          const y = oy + r * cs + cs / 2;
          const cleared = step === "clear" && clearSet.includes(i);
          const v = grid[i];
          if (v > 0) {
            circle(ctx, x, y, cs * 0.36 * (cleared ? 0.5 : 1), GEM_COLORS[v - 1]);
            circle(ctx, x - cs * 0.1, y - cs * 0.12, cs * 0.1, "#ffffff88");
          }
          if (i === cursor) strokeCircle(ctx, x, y, cs * 0.44, pal.fg, 2);
          if (i === sel) strokeCircle(ctx, x, y, cs * 0.48, pal.amber, 3);
        }
        text(ctx, `${api.t("Ходов", "Moves")}: ${moves}`, 12, 18, 14, pal.muted, "left", 700);
        if (chain > 1 && step !== "idle") text(ctx, `×${chain - 1}`, w - 12, 18, 16, pal.amber, "right", 800);
        if (ending) banner(api, api.t("Ходы кончились!", "Out of moves!"));
      },
    };
  },
);

export const MORE_GAMES: GameDef[] = [tttGame, pinballGame, fruitGame, tankGame, sapperGame, match3Game];
