import type { Text } from "@/lib/i18n";
import { ARCADE } from "./arcade";
import { FACTORY_GAMES } from "./factories";
import { MORE_GAMES } from "./more";
import { BRAIN } from "./brain";
import { clickerGame } from "./Clicker";
import { dashGame } from "./dash";
import { ordersGame, spaceGame, surfGame } from "./flagship";
import { funkGame } from "./funk";
import { PARTY } from "./party";
import { SKILL } from "./skill";
import type { Cat, Ctl, GameDef } from "./types";
import { washGame } from "./wash";

/** Highlighted at the top of the games tab */
export const FEATURED: GameDef[] = [dashGame, funkGame];

export const GAMES: GameDef[] = [dashGame, funkGame, washGame, spaceGame, surfGame, clickerGame, ordersGame, ...MORE_GAMES, ...FACTORY_GAMES, ...ARCADE, ...SKILL, ...BRAIN, ...PARTY];

export const CATEGORIES: Array<{ id: Cat | "all"; name: Text }> = [
  { id: "all", name: ["Все", "All"] },
  { id: "arcade", name: ["Аркады", "Arcade"] },
  { id: "rhythm", name: ["Ритм", "Rhythm"] },
  { id: "skill", name: ["Ловкость", "Skill"] },
  { id: "logic", name: ["Логика", "Brain"] },
  { id: "party", name: ["Компания", "Party"] },
];

export const CTL_LABELS: Record<Ctl, Text> = {
  antenna: ["Антенна (4 стороны)", "Antenna (4 ways)"],
  antennaLR: ["Антенна ← →", "Antenna ← →"],
  antennaFB: ["Антенна ↑ ↓", "Antenna ↑ ↓"],
  tongue: ["Язык", "Tongue"],
  tail: ["Хвост", "Tail"],
  tummy: ["Живот", "Tummy"],
  head: ["Голова", "Head"],
  sides: ["Бока", "Sides"],
  tilt: ["Наклоны", "Tilt"],
  shake: ["Тряска", "Shake"],
  flip: ["Переворот", "Flip"],
};

export const KEY_HINTS: Record<Ctl, string> = {
  antenna: "← ↑ → ↓ / WASD",
  antennaLR: "← → / A D",
  antennaFB: "↑ ↓ / W S",
  tongue: "Space",
  tail: "T",
  tummy: "B",
  head: "H",
  sides: "Z / C",
  tilt: "Q / E",
  shake: "X",
  flip: "F",
};
