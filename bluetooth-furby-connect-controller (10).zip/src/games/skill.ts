/** Timing and skill mini games */
import { Crosshair, Drum, Gauge, Goal, Medal, MoveHorizontal, Pointer, Swords, Target, Timer, Watch } from "lucide-react";
import { audio, tone } from "@/lib/audio/synth";
import type { InputType } from "@/lib/furby/controller";
import { settings } from "@/lib/settings";
import { audioClock, banner, bar, bg, circle, clamp, def, line, rand, ring, rr, strokeCircle, text } from "./kit";

const firstOf = (events: Array<{ type: InputType; t: number; src: string }>, ...types: InputType[]) => events.find((e) => types.includes(e.type));

export const SKILL = [
  def("reaction", ["Реакция", "Reaction"], ["Жди зелёный экран и жми язык как можно быстрее. 5 раундов.", "Wait for green and press the tongue as fast as possible. 5 rounds."], Timer, "skill", ["tongue"], (api) => {
    let phase: "wait" | "go" | "res" = "wait";
    let t = rand(1.5, 3.5);
    let goAt = 0;
    const times: number[] = [];
    let msg = "";
    return {
      update(dt, inp) {
        const p = firstOf(inp.events, "tongue");
        if (phase === "wait") {
          t -= dt;
          if (p) {
            times.push(1000);
            msg = api.t("Фальстарт!", "False start!");
            api.sfx("error");
            phase = "res";
            t = 1.2;
          } else if (t <= 0) {
            phase = "go";
            goAt = performance.now();
            api.sfx("tick");
            api.furby.led(0, 255, 0);
          }
        } else if (phase === "go") {
          if (p) {
            const ms = Math.max(90, p.t - goAt - (p.src === "furby" ? 50 : 0));
            times.push(ms);
            msg = `${Math.round(ms)} ${api.t("мс", "ms")}`;
            api.sfx("good");
            phase = "res";
            t = 1.2;
          } else if (performance.now() - goAt > 2000) {
            times.push(1000);
            msg = api.t("Слишком медленно", "Too slow");
            phase = "res";
            t = 1.2;
          }
        } else {
          t -= dt;
          if (t > 0) return;
          if (times.length >= 5) {
            api.score = Math.max(0, Math.round(1000 - times.reduce((a, b) => a + b, 0) / times.length));
            api.over(true);
          } else {
            phase = "wait";
            t = rand(1.5, 3.5);
            api.furby.led(255, 0, 0);
          }
        }
      },
      draw() {
        const { pal } = api;
        bg(api, phase === "go" ? (pal.dark ? "#14532d" : "#bbf7d0") : phase === "wait" ? (pal.dark ? "#450a0a" : "#fecaca") : pal.bg);
        banner(api, phase === "go" ? api.t("ЖМИ!", "PRESS!") : phase === "wait" ? api.t("Жди…", "Wait…") : msg, `${api.t("Раунд", "Round")} ${Math.min(5, times.length + (phase === "res" ? 0 : 1))}/5`);
      },
    };
  }, { lives: 0, hud: false }),

  def("duel", ["Дуэль на двоих", "Two-player Duel"], ["Игрок 1 жмёт язык, игрок 2 дёргает хвост. Кто первым после «Огонь!» — тот выиграл раунд. До 3 побед.", "Player 1 presses the tongue, player 2 pulls the tail. First after “Fire!” wins the round. First to 3."], Swords, "party", ["tongue", "tail"], (api) => {
    let phase: "wait" | "go" | "res" = "wait";
    let t = rand(2, 4);
    const wins = [0, 0];
    let msg = "";
    const win = (p: number, text: string) => {
      wins[p]++;
      msg = text;
      phase = "res";
      t = 1.6;
      api.sfx("good");
    };
    return {
      update(dt, inp) {
        const e = firstOf(inp.events, "tongue", "tail");
        if (phase === "wait") {
          t -= dt;
          if (e) win(e.type === "tongue" ? 1 : 0, api.t(`Фальстарт игрока ${e.type === "tongue" ? 1 : 2}!`, `Player ${e.type === "tongue" ? 1 : 2} false start!`));
          else if (t <= 0) {
            phase = "go";
            api.sfx("boom");
            api.furby.led(255, 255, 255);
          }
        } else if (phase === "go") {
          if (e) win(e.type === "tongue" ? 0 : 1, api.t(`Игрок ${e.type === "tongue" ? 1 : 2} быстрее!`, `Player ${e.type === "tongue" ? 1 : 2} is faster!`));
        } else {
          t -= dt;
          if (t > 0) return;
          if (Math.max(...wins) >= 3) {
            api.score = Math.max(...wins) * 100;
            api.over(true);
          } else {
            phase = "wait";
            t = rand(2, 4.5);
          }
        }
      },
      draw() {
        bg(api);
        banner(api, phase === "go" ? api.t("ОГОНЬ!", "FIRE!") : phase === "wait" ? api.t("Приготовились…", "Get ready…") : msg, `${api.t("Игрок 1 (язык)", "Player 1 (tongue)")} ${wins[0]} : ${wins[1]} ${api.t("Игрок 2 (хвост)", "Player 2 (tail)")}`);
      },
    };
  }, { lives: 0, hud: false, tap: null }),

  def("stopwatch", ["Ровно 5 секунд", "Exactly 5 Seconds"], ["Нажми язык, чтобы запустить секундомер, и останови его ровно на 5 секундах — вслепую. 3 попытки.", "Press the tongue to start the stopwatch and stop it at exactly 5 seconds — blind. 3 tries."], Watch, "skill", ["tongue"], (api) => {
    let phase: "idle" | "run" | "res" = "idle";
    let start = 0;
    let tries = 0;
    let msg = "";
    let resT = 0;
    return {
      update(dt, inp) {
        const p = firstOf(inp.events, "tongue");
        if (phase === "idle" && p) {
          start = p.t;
          phase = "run";
        } else if (phase === "run" && p) {
          const ms = p.t - start;
          api.add(Math.max(0, Math.round(1000 - Math.abs(ms - 5000))));
          msg = `${(ms / 1000).toFixed(3)} ${api.t("с", "s")}`;
          tries++;
          phase = "res";
          resT = 1.6;
        } else if (phase === "res") {
          resT -= dt;
          if (resT <= 0) {
            if (tries >= 3) api.over(true);
            else phase = "idle";
          }
        }
      },
      draw() {
        bg(api);
        const el = (performance.now() - start) / 1000;
        if (phase === "idle") banner(api, api.t("Нажми язык — старт", "Press the tongue to start"), `${api.t("Попытка", "Try")} ${tries + 1}/3`);
        else if (phase === "run") banner(api, el < 1 ? el.toFixed(2) : "?.??", api.t("Останови на 5.00", "Stop at 5.00"));
        else banner(api, msg, api.t("Цель: 5.000", "Goal: 5.000"));
      },
    };
  }, { lives: 0 }),

  def("tug", ["Перетягивание", "Tug of War"], ["Быстро дёргай хвост, чтобы перетянуть канат у соперника.", "Pull the tail quickly to win the tug of war."], MoveHorizontal, "skill", ["tail"], (api) => {
    let pos = 0;
    return {
      update(dt, inp) {
        for (const e of inp.events) if (e.type === "tail") {
          pos -= 0.06;
          api.sfx("pop");
        }
        pos += (0.32 + api.time * 0.012) * dt;
        if (pos <= -1) {
          api.score = Math.max(100, Math.round(2000 - api.time * 40));
          api.over(true);
        }
        if (pos >= 1) api.over(false);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        line(ctx, w * 0.1, h / 2, w * 0.9, h / 2, pal.amber, 6);
        const x = w / 2 + pos * w * 0.35;
        rr(ctx, x - 4, h / 2 - 30, 8, 60, 4, pal.red);
        rr(ctx, w * 0.12, h / 2 - 50, 10, 100, 5, pal.blue);
        rr(ctx, w * 0.88 - 10, h / 2 - 50, 10, 100, 5, pal.faint);
        text(ctx, api.t("Ты", "You"), w * 0.12, h / 2 + 70, 15, pal.fg);
        text(ctx, api.t("Соперник", "Rival"), w * 0.88, h / 2 + 70, 15, pal.fg);
      },
    };
  }, { lives: 0, hud: false, tap: "tail" }),

  def("tapper", ["Скоростной клюв", "Speed Beak"], ["Жми язык как можно чаще за 10 секунд.", "Press the tongue as often as you can in 10 seconds."], Pointer, "skill", ["tongue"], (api) => {
    let n = 0;
    let started = false;
    let left = 10;
    return {
      update(dt, inp) {
        for (const e of inp.events) if (e.type === "tongue") {
          started = true;
          n++;
          api.score = n * 10;
        }
        if (started) left -= dt;
        if (left <= 0) api.over(true);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        text(ctx, String(n), w / 2, h * 0.42, Math.min(90, w / 5), pal.fg, "center", 800);
        bar(ctx, w * 0.2, h * 0.65, w * 0.6, 10, left / 10, pal.fg, pal.surface2);
        if (!started) text(ctx, api.t("Начни жать язык!", "Start pressing the tongue!"), w / 2, h * 0.78, 16, pal.muted);
      },
    };
  }, { lives: 0 }),

  def("drummer", ["Барабанщик", "Drummer"], ["Слушай метроном и жми язык точно в такт. 32 удара.", "Listen to the metronome and press the tongue on the beat. 32 beats."], Drum, "rhythm", ["tongue"], (api) => {
    const { ac, music } = audio();
    const out = ac.createGain();
    out.connect(music);
    const clock = audioClock(ac);
    const beat = 60 / 100;
    const T0 = ac.currentTime + 1;
    const N = 36;
    const hit = new Array(N).fill(false);
    for (let i = 0; i < N; i++) tone(T0 + i * beat, i < 4 ? 660 : i % 4 === 0 ? 1320 : 990, 0.05, out, { type: "sine", gain: 0.25 });
    let now = -1;
    return {
      update(_dt, inp) {
        now = clock() - T0;
        for (const e of inp.events) {
          if (e.type !== "tongue") continue;
          const te = clock(e.t) - T0 - (e.src === "furby" ? settings.get().rhythmLatency / 1000 : 0);
          const k = Math.round(te / beat);
          if (k < 4 || k >= N || hit[k]) continue;
          const d = Math.abs(te - k * beat);
          if (d > 0.16) continue;
          hit[k] = true;
          const pts = d < 0.04 ? 100 : d < 0.08 ? 60 : 30;
          api.add(pts, api.w / 2, api.h * 0.3);
        }
        if (now > N * beat + 0.4) api.over(true);
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const ph = ((now / beat) % 1 + 1) % 1;
        const k = Math.floor(now / beat);
        circle(ctx, w / 2, h / 2, 40 + Math.exp(-ph * 6) * 26, k >= 0 && k < 4 ? pal.faint : pal.violet);
        text(ctx, k < 4 ? api.t("Слушай…", "Listen…") : `${Math.min(32, k - 3)}/32`, w / 2, h / 2, 18, "#fff", "center", 800);
      },
      dispose() {
        out.disconnect();
      },
    };
  }, { lives: 0 }),

  def("zone", ["Стоп-зона", "Stop Zone"], ["Останови бегунок языком в зелёной зоне. Зона уменьшается.", "Stop the slider in the green zone with the tongue. The zone shrinks."], Gauge, "skill", ["tongue"], (api) => {
    let pos = 0;
    let dir = 1;
    let speed = 0.8;
    let zone = 0.24;
    let zc = 0.5;
    let level = 1;
    return {
      update(dt, inp) {
        pos += dir * speed * dt;
        if (pos > 1 || pos < 0) {
          dir *= -1;
          pos = clamp(pos, 0, 1);
        }
        if (!inp.has("tongue")) return;
        if (Math.abs(pos - zc) < zone / 2) {
          api.add(10 * level);
          api.sfx("good");
          level++;
          zone = Math.max(0.05, zone * 0.9);
          speed *= 1.07;
          zc = rand(0.2, 0.8);
        } else api.hurt();
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const x0 = w * 0.1;
        const bw = w * 0.8;
        rr(ctx, x0, h / 2 - 14, bw, 28, 14, pal.surface2);
        rr(ctx, x0 + (zc - zone / 2) * bw, h / 2 - 14, zone * bw, 28, 8, pal.green);
        rr(ctx, x0 + pos * bw - 3, h / 2 - 24, 6, 48, 3, pal.fg);
        text(ctx, `${api.t("Уровень", "Level")} ${level}`, w / 2, h / 2 + 50, 15, pal.muted);
      },
    };
  }),

  def("basket", ["Баскетбол", "Basketball"], ["Шкала силы бегает — жми язык, когда она в отмеченной зоне. 10 бросков.", "The power meter moves — press the tongue when it's in the marked zone. 10 shots."], Medal, "skill", ["tongue"], (api) => {
    let power = 0;
    let dir = 1;
    let shots = 10;
    let anim = 0;
    let made = false;
    let target = rand(0.5, 0.8);
    let shotPower = 0;
    return {
      update(dt, inp) {
        if (anim > 0) {
          anim -= dt;
          if (anim <= 0) {
            shots--;
            if (shots <= 0) api.over(true);
            target = rand(0.45, 0.85);
          }
          return;
        }
        power += dir * 1.1 * dt;
        if (power > 1 || power < 0) {
          dir *= -1;
          power = clamp(power, 0, 1);
        }
        if (inp.has("tongue")) {
          shotPower = power;
          made = Math.abs(power - target) < 0.07;
          anim = 0.9;
          if (made) {
            api.add(20);
            api.sfx("good");
          } else api.sfx("error");
        }
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const hx = w * (0.45 + target * 0.45);
        const hy = h * 0.35;
        rr(ctx, hx - 30, hy, 60, 6, 3, pal.orange);
        ctx.strokeStyle = pal.faint;
        ctx.strokeRect(hx - 20, hy + 6, 40, 30);
        const sx = w * 0.12;
        const sy = h * 0.8;
        if (anim > 0) {
          const k = 1 - anim / 0.9;
          const ex = made ? hx : w * (0.45 + shotPower * 0.45);
          const ey = made ? hy : hy + 40;
          circle(ctx, sx + (ex - sx) * k, sy + (ey - sy) * k - Math.sin(k * Math.PI) * h * 0.35, 12, pal.orange);
        } else circle(ctx, sx, sy, 12, pal.orange);
        const mx = w * 0.06;
        rr(ctx, mx, h * 0.15, 14, h * 0.6, 7, pal.surface2);
        rr(ctx, mx, h * 0.15 + (1 - target - 0.07) * h * 0.6, 14, 0.14 * h * 0.6, 4, pal.green);
        rr(ctx, mx - 4, h * 0.15 + (1 - power) * h * 0.6 - 2, 22, 4, 2, pal.fg);
        text(ctx, `${api.t("Бросков", "Shots")}: ${shots}`, w - 12, 18, 14, pal.muted, "right", 600);
      },
    };
  }, { lives: 0 }),

  def("penalty", ["Пенальти", "Penalty Shootout"], ["Сначала 5 ударов, потом 5 сейвов. Выбирай угол антенной: влево, вперёд (центр), вправо.", "First 5 kicks, then 5 saves. Pick a corner with the antenna: left, forward (centre), right."], Goal, "skill", ["antennaLR", "antennaFB"], (api) => {
    let round = 0;
    let t = 2.5;
    let res = 0;
    let choice = 1;
    let other = 1;
    let msg = "";
    return {
      update(dt, inp) {
        if (res > 0) {
          res -= dt;
          if (res <= 0) {
            round++;
            t = 2.5;
            if (round >= 10) api.over(api.score >= 500);
          }
          return;
        }
        t -= dt;
        const e = firstOf(inp.events, "antL", "antF", "antR");
        if (!e && t > 0) return;
        choice = e ? (e.type === "antL" ? 0 : e.type === "antF" ? 1 : 2) : 1;
        other = Math.floor(Math.random() * 3);
        const kicking = round < 5;
        const good = kicking ? choice !== other : choice === other;
        if (good) {
          api.add(100);
          api.sfx("good");
        } else api.sfx("error");
        msg = kicking ? (good ? api.t("ГОЛ!", "GOAL!") : api.t("Вратарь взял", "Saved")) : good ? api.t("Сейв!", "Save!") : api.t("Пропустил", "Conceded");
        res = 1.4;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const gx = w * 0.2;
        const gw = w * 0.6;
        const gy = h * 0.25;
        ring(ctx, gx, gy, gw, h * 0.35, 4, pal.fg, 4);
        const kicking = round < 5;
        const keeper = res > 0 ? (kicking ? other : choice) : 1;
        const ball = res > 0 ? (kicking ? choice : other) : 1;
        rr(ctx, gx + (keeper + 0.5) * (gw / 3) - 20, gy + h * 0.12, 40, h * 0.22, 10, pal.amber);
        circle(ctx, res > 0 ? gx + (ball + 0.5) * (gw / 3) : w / 2, res > 0 ? gy + h * 0.2 : h * 0.85, 12, pal.fg);
        text(ctx, res > 0 ? msg : kicking ? api.t("Бей! ← ↑ →", "Kick! ← ↑ →") : api.t("Лови! ← ↑ →", "Save! ← ↑ →"), w / 2, h * 0.12, 20, pal.fg, "center", 800);
        text(ctx, `${Math.min(round + 1, 10)}/10`, w - 12, 18, 14, pal.muted, "right", 600);
      },
    };
  }, { lives: 0 }),

  def("darts", ["Дартс", "Darts"], ["Прицел качается — бросай дротик языком. 10 дротиков.", "The aim sways — throw a dart with the tongue. 10 darts."], Target, "skill", ["tongue"], (api) => {
    let darts: Array<[number, number]> = [];
    let end = 0;
    return {
      update(dt, inp) {
        if (end > 0) {
          end -= dt;
          if (end <= 0) api.over(true);
          return;
        }
        if (!inp.has("tongue")) return;
        const R = Math.min(api.w, api.h) * 0.34;
        const ax = Math.sin(api.time * 1.7) * R * 0.85 + rand(-4, 4);
        const ay = Math.sin(api.time * 2.3 + 1) * R * 0.85 + rand(-4, 4);
        darts.push([ax, ay]);
        const d = Math.hypot(ax, ay) / R;
        const pts = d < 0.1 ? 50 : d < 0.3 ? 25 : d < 0.6 ? 10 : d < 1 ? 5 : 0;
        api.add(pts, api.w / 2 + ax, api.h / 2 + ay);
        api.sfx(pts >= 25 ? "good" : "pop");
        if (darts.length >= 10) end = 1;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const R = Math.min(w, h) * 0.34;
        [1, 0.6, 0.3, 0.1].forEach((k, i) => circle(ctx, w / 2, h / 2, R * k, [pal.surface2, pal.blue, pal.amber, pal.red][i]));
        for (const [x, y] of darts) circle(ctx, w / 2 + x, h / 2 + y, 4, pal.fg);
        const ax = Math.sin(api.time * 1.7) * R * 0.85;
        const ay = Math.sin(api.time * 2.3 + 1) * R * 0.85;
        strokeCircle(ctx, w / 2 + ax, h / 2 + ay, 10, pal.fg, 2);
        text(ctx, `${10 - darts.length}`, w - 12, 18, 14, pal.muted, "right", 600);
      },
    };
  }, { lives: 0 }),

  def("archery", ["Лучник", "Archery"], ["Мишень двигается, ветер сносит стрелу. Стреляй языком. 8 стрел.", "The target moves and the wind pushes the arrow. Shoot with the tongue. 8 arrows."], Crosshair, "skill", ["tongue"], (api) => {
    let arrows = 8;
    let fly = 0;
    let wind = rand(-1, 1);
    let hits: number[] = [];
    const ty = (t: number) => api.h / 2 + Math.sin(t * 1.2) * api.h * 0.3;
    return {
      update(dt, inp) {
        if (fly > 0) {
          fly -= dt;
          if (fly <= 0) {
            const off = api.h / 2 + wind * 30 - ty(api.time);
            hits.push(off);
            const d = Math.abs(off) / 50;
            const pts = d < 0.2 ? 50 : d < 0.5 ? 25 : d < 1 ? 10 : 0;
            api.add(pts, api.w * 0.85, ty(api.time) + off);
            api.sfx(pts ? "good" : "error");
            wind = rand(-1, 1);
            if (--arrows <= 0) api.over(true);
          }
          return;
        }
        if (inp.has("tongue")) fly = 0.6;
      },
      draw() {
        const { ctx, w, h, pal } = api;
        bg(api);
        const y = ty(api.time);
        [50, 25, 10].forEach((r, i) => circle(ctx, w * 0.85, y, r, [pal.surface2, pal.blue, pal.red][i]));
        for (const off of hits.slice(-3)) circle(ctx, w * 0.85, y + off, 3, pal.fg);
        line(ctx, w * 0.1, h / 2, w * 0.2, h / 2, pal.faint, 1);
        if (fly > 0) {
          const k = 1 - fly / 0.6;
          line(ctx, w * (0.15 + k * 0.68) - 20, h / 2 + wind * 30 * k, w * (0.15 + k * 0.68), h / 2 + wind * 30 * k, pal.fg, 3);
        }
        text(ctx, `${api.t("Ветер", "Wind")} ${wind > 0 ? "↓" : "↑"} ${Math.abs(wind * 10).toFixed(0)}`, w / 2, 20, 14, pal.muted);
        text(ctx, `${arrows}`, w - 12, 18, 14, pal.muted, "right", 600);
      },
    };
  }, { lives: 0 }),
];
