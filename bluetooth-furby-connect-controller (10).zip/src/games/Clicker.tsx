/** Furby clicker: earn fluffs with the beak (tongue), antenna moves or tail pulls, then buy upgrades. */
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, ChevronLeft, MousePointerClick, RefreshCw, Sparkles } from "lucide-react";
import { Button, Card } from "@/components/ui";
import { sfx } from "@/lib/audio/synth";
import { furby, type InputType } from "@/lib/furby/controller";
import { formatNumber, pick as pickText, useLang, useT, type Text } from "@/lib/i18n";
import { progress, progressStore, type ClickerSave } from "@/lib/progress";
import { cn } from "@/utils/cn";
import { input } from "./input";
import type { GameDef } from "./types";

interface Upgrade {
  id: string;
  name: Text;
  desc: Text;
  base: number;
  growth: number;
  max?: number;
}

const UPGRADES: Upgrade[] = [
  { id: "beak", name: ["Крепкий клюв", "Strong beak"], desc: ["+1 за нажатие языка", "+1 per tongue press"], base: 15, growth: 1.15 },
  { id: "antenna", name: ["Чуткая антенна", "Sensitive antenna"], desc: ["+1 за движение антенны", "+1 per antenna move"], base: 15, growth: 1.15 },
  { id: "tail", name: ["Пушистый хвост", "Fluffy tail"], desc: ["+2 за рывок хвоста", "+2 per tail pull"], base: 25, growth: 1.15 },
  { id: "fan", name: ["Пуховый вентилятор", "Fluff fan"], desc: ["+1 в секунду", "+1 per second"], base: 50, growth: 1.15 },
  { id: "factory", name: ["Фабрика пуха", "Fluff factory"], desc: ["+8 в секунду", "+8 per second"], base: 600, growth: 1.15 },
  { id: "farm", name: ["Облачная ферма", "Cloud farm"], desc: ["+50 в секунду", "+50 per second"], base: 7000, growth: 1.15 },
  { id: "station", name: ["Космическая станция", "Space station"], desc: ["+300 в секунду", "+300 per second"], base: 80000, growth: 1.15 },
  { id: "galaxy", name: ["Пушистая галактика", "Fluffy galaxy"], desc: ["+2000 в секунду", "+2000 per second"], base: 1e6, growth: 1.15 },
  { id: "double", name: ["Двойной пух", "Double fluff"], desc: ["×2 за все клики", "×2 for every click"], base: 1000, growth: 6, max: 6 },
  { id: "crit", name: ["Счастливый клик", "Lucky click"], desc: ["+3% шанс клика ×10", "+3% chance of a ×10 click"], base: 500, growth: 2.2, max: 10 },
  { id: "combo", name: ["Комбо", "Combo"], desc: ["Быстрые клики дают до +25% каждый", "Fast clicks give up to +25% each"], base: 300, growth: 2.5, max: 8 },
  { id: "golden", name: ["Золотые пушинки", "Golden fluffs"], desc: ["Иногда появляется бонус ×30", "Sometimes a ×30 bonus appears"], base: 2000, growth: 3, max: 5 },
  { id: "night", name: ["Ночная смена", "Night shift"], desc: ["Доход, пока сайт закрыт (+1 час)", "Income while the site is closed (+1 hour)"], base: 5000, growth: 2.5, max: 8 },
];

const fresh = (): ClickerSave => ({ fluffs: 0, total: 0, clicks: 0, levels: {}, stardust: 0, prestiges: 0, lastSeen: Date.now() });
const cost = (u: Upgrade, lvl: number) => Math.ceil(u.base * Math.pow(u.growth, lvl));

function rates(s: ClickerSave) {
  const L = (id: string) => s.levels[id] ?? 0;
  const mult = Math.pow(2, L("double")) * (1 + s.stardust * 0.1);
  return {
    tongue: (1 + L("beak")) * mult,
    antenna: (1 + L("antenna")) * mult,
    tail: (2 + L("tail") * 2) * mult,
    perSec: (L("fan") + L("factory") * 8 + L("farm") * 50 + L("station") * 300 + L("galaxy") * 2000) * (1 + s.stardust * 0.1),
    crit: L("crit") * 0.03,
    combo: L("combo") * 0.25,
    golden: L("golden"),
    offlineHours: L("night"),
  };
}

function ClickerGame({ onExit }: { onExit(): void }) {
  const t = useT();
  const lang = useLang();
  const [save, setSave] = useState<ClickerSave>(() => {
    const s = progressStore.get().clicker ?? fresh();
    const r = rates(s);
    const away = Math.min((Date.now() - s.lastSeen) / 1000, r.offlineHours * 3600);
    const earned = away > 60 ? Math.floor(away * r.perSec * 0.5) : 0;
    return earned > 0 ? { ...s, fluffs: s.fluffs + earned, total: s.total + earned } : s;
  });
  const [floats, setFloats] = useState<Array<{ id: number; text: string; x: number }>>([]);
  const [golden, setGolden] = useState<{ x: number; y: number } | null>(null);
  const [boost, setBoost] = useState(0);
  const saveRef = useRef(save);
  saveRef.current = save;
  const combo = useRef({ last: 0, n: 0 });
  const counter = useRef(0);

  const click = (src: "tongue" | "antenna" | "tail") => {
    setSave((s) => {
      const r = rates(s);
      const now = performance.now();
      combo.current.n = now - combo.current.last < 600 ? Math.min(combo.current.n + 1, 20) : 0;
      combo.current.last = now;
      let gain = r[src] * (1 + Math.min(r.combo, (combo.current.n / 20) * r.combo));
      const crit = Math.random() < r.crit;
      if (crit) gain *= 10;
      if (boost > performance.now()) gain *= 30;
      const id = ++counter.current;
      setFloats((f) => [...f.slice(-12), { id, text: `+${formatNumber(gain, lang)}${crit ? "!" : ""}`, x: 30 + Math.random() * 40 }]);
      window.setTimeout(() => setFloats((f) => f.filter((x) => x.id !== id)), 800);
      return { ...s, fluffs: s.fluffs + gain, total: s.total + gain, clicks: s.clicks + 1 };
    });
    sfx("pop");
    if (furby.connected) furby.setLedFrame(src === "tongue" ? [255, 200, 0] : src === "tail" ? [255, 80, 200] : [0, 200, 255], true);
    if ((saveRef.current.clicks + 1) % 200 === 0) furby.say("good");
  };

  useEffect(() => {
    const detach = input.attach();
    furby.gameStart();
    const map: Partial<Record<InputType, "tongue" | "antenna" | "tail">> = { tongue: "tongue", tail: "tail", antL: "antenna", antR: "antenna", antF: "antenna", antB: "antenna" };
    let last = performance.now();
    const loop = window.setInterval(() => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;
      for (const ev of input.frame(dt).events) {
        const src = map[ev.type];
        if (src) click(src);
      }
      setSave((s) => {
        const ps = rates(s).perSec * dt;
        return ps > 0 ? { ...s, fluffs: s.fluffs + ps, total: s.total + ps } : s;
      });
    }, 50);
    const saver = window.setInterval(() => progress.saveClicker({ ...saveRef.current, lastSeen: Date.now() }), 2000);
    const goldTimer = window.setInterval(() => {
      const g = rates(saveRef.current).golden;
      if (g > 0 && Math.random() < 0.05 + g * 0.03) {
        setGolden({ x: 10 + Math.random() * 80, y: 10 + Math.random() * 60 });
        window.setTimeout(() => setGolden(null), 6000);
      }
    }, 3000);
    return () => {
      detach();
      furby.gameEnd();
      window.clearInterval(loop);
      window.clearInterval(saver);
      window.clearInterval(goldTimer);
      progress.saveClicker({ ...saveRef.current, lastSeen: Date.now() });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const r = rates(save);
  const buy = (u: Upgrade) => {
    const lvl = save.levels[u.id] ?? 0;
    const c = cost(u, lvl);
    if (save.fluffs < c || (u.max !== undefined && lvl >= u.max)) return;
    sfx("coin");
    setSave((s) => ({ ...s, fluffs: s.fluffs - c, levels: { ...s.levels, [u.id]: lvl + 1 } }));
  };
  const canPrestige = save.total >= 1e6;
  const prestige = () => {
    if (!canPrestige || !window.confirm(t("Сбросить пушинки и улучшения ради звёздной пыли?", "Reset fluffs and upgrades for stardust?"))) return;
    const dust = Math.floor(Math.sqrt(save.total / 1e6));
    setSave((s) => ({ ...fresh(), stardust: s.stardust + dust, prestiges: s.prestiges + 1, total: s.total }));
    sfx("level");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <Button variant="ghost" size="sm" onClick={onExit}>
          <ChevronLeft className="h-4 w-4" />
          {t("Назад к играм", "Back to games")}
        </Button>
        <span className="text-sm text-muted">{t("Сохраняется автоматически", "Saved automatically")}</span>
      </div>
      <Card className="relative overflow-hidden text-center">
        <p className="text-xs uppercase tracking-widest text-faint">{t("Пушинки", "Fluffs")}</p>
        <p className="mt-1 text-4xl font-semibold tabular-nums sm:text-5xl">{formatNumber(save.fluffs, lang)}</p>
        <p className="mt-1 text-sm text-muted">
          {formatNumber(r.perSec, lang)} {t("в секунду", "per second")} · {t("звёздная пыль", "stardust")}: {save.stardust}
        </p>
        {floats.map((f) => (
          <span key={f.id} className="anim-float pointer-events-none absolute top-16 text-lg font-bold text-fg" style={{ left: `${f.x}%` }}>
            {f.text}
          </span>
        ))}
        {golden && (
          <button
            type="button"
            onClick={() => {
              setGolden(null);
              setBoost(performance.now() + 10000);
              sfx("win");
            }}
            className="absolute flex h-12 w-12 items-center justify-center rounded-full bg-amber-400 text-white"
            style={{ left: `${golden.x}%`, top: `${golden.y}%` }}
            aria-label={t("Золотая пушинка", "Golden fluff")}
          >
            <Sparkles className="h-6 w-6" />
          </button>
        )}
        <div className="mt-5 grid grid-cols-3 gap-2">
          {(
            [
              ["tongue", t("Клюв", "Beak"), r.tongue],
              ["antenna", t("Антенна", "Antenna"), r.antenna],
              ["tail", t("Хвост", "Tail"), r.tail],
            ] as const
          ).map(([src, label, value]) => (
            <button
              key={src}
              type="button"
              onClick={() => click(src)}
              className="flex flex-col items-center gap-1 rounded-2xl border border-line-strong bg-surface-2 px-2 py-4 transition-transform active:scale-95"
            >
              {src === "antenna" ? <span className="flex"><ArrowLeft className="h-5 w-5" /><ArrowRight className="h-5 w-5" /></span> : <MousePointerClick className="h-5 w-5" />}
              <span className="text-sm font-medium">{label}</span>
              <span className="text-xs text-muted">+{formatNumber(value, lang)}</span>
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-faint">
          {t("Кликай на Фёрби: нажимай язык, двигай антенну в любую сторону или дёргай хвост.", "Click with Furby: press the tongue, move the antenna in any direction or pull the tail.")}
          {boost > performance.now() && ` ${t("Бонус ×30!", "×30 bonus!")}`}
        </p>
      </Card>
      <Card title={t("Улучшения", "Upgrades")}>
        <div className="grid gap-2 sm:grid-cols-2">
          {UPGRADES.map((u) => {
            const lvl = save.levels[u.id] ?? 0;
            const maxed = u.max !== undefined && lvl >= u.max;
            const c = cost(u, lvl);
            return (
              <button
                key={u.id}
                type="button"
                disabled={maxed || save.fluffs < c}
                onClick={() => buy(u)}
                className={cn(
                  "flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-2.5 text-left transition-colors enabled:hover:bg-surface-2 disabled:opacity-50",
                )}
              >
                <span className="min-w-0">
                  <span className="block text-sm font-medium">
                    {pickText(u.name, lang)} <span className="text-faint">· {lvl}</span>
                  </span>
                  <span className="block text-xs text-muted">{pickText(u.desc, lang)}</span>
                </span>
                <span className="shrink-0 text-sm tabular-nums">{maxed ? t("макс.", "max") : formatNumber(c, lang)}</span>
              </button>
            );
          })}
        </div>
      </Card>
      <Card title={t("Перерождение", "Rebirth")} hint={t("После миллиона пушинок можно начать заново и получить звёздную пыль: +10% к доходу навсегда.", "After a million fluffs you can start over for stardust: +10% income forever.")}>
        <Button variant="secondary" disabled={!canPrestige} onClick={prestige}>
          <RefreshCw className="h-4 w-4" />
          {t("Переродиться", "Rebirth")} {canPrestige && `(+${Math.floor(Math.sqrt(save.total / 1e6))})`}
        </Button>
      </Card>
    </div>
  );
}

export const clickerGame: GameDef = {
  id: "clicker",
  name: ["Фёрби-кликер", "Furby Clicker"],
  desc: [
    "Кликай клювом (язык), антенной (в любую сторону) или хвостом, копи пушинки и покупай улучшения. Есть автодоход, золотые бонусы и перерождение.",
    "Click with the beak (tongue), the antenna (any direction) or the tail, collect fluffs and buy upgrades. Auto-income, golden bonuses and rebirth.",
  ],
  icon: MousePointerClick,
  cat: "arcade",
  controls: ["tongue", "antenna", "tail"],
  component: ClickerGame,
};
