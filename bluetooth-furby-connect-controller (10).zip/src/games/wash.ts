/** Animal wash: rinse → soap → rinse → blow-dry. The tool is moved with the antenna (or by dragging). */
import { Droplets } from "lucide-react";
import type { Text } from "@/lib/i18n";
import { progress } from "@/lib/progress";
import { bar, circle, clamp, poly, rr, star, strokeCircle, text } from "./kit";
import type { GameApi, GameDef, GameInst, InputFrame } from "./types";

interface Animal {
  name: Text;
  body: string;
  belly: string;
  ear: "dog" | "cat" | "bunny" | "round" | "none";
  tail: "short" | "long" | "fluffy" | "curly" | "none";
  nose: string;
  patch?: string;
  spikes?: boolean;
}

export const ANIMALS: Animal[] = [
  { name: ["Пёсик", "Puppy"], body: "#d6a46b", belly: "#f1d3a8", ear: "dog", tail: "short", nose: "#3f2a1d", patch: "#8b5a2b" },
  { name: ["Котик", "Kitty"], body: "#9ca3af", belly: "#e5e7eb", ear: "cat", tail: "long", nose: "#f472b6" },
  { name: ["Зайка", "Bunny"], body: "#f5f5f4", belly: "#fde2e4", ear: "bunny", tail: "fluffy", nose: "#f472b6" },
  { name: ["Овечка", "Lamb"], body: "#f5f5f0", belly: "#e7e5e4", ear: "round", tail: "fluffy", nose: "#57534e", patch: "#57534e" },
  { name: ["Поросёнок", "Piglet"], body: "#f9a8d4", belly: "#fbcfe8", ear: "cat", tail: "curly", nose: "#db2777" },
  { name: ["Лисёнок", "Fox cub"], body: "#f97316", belly: "#fff7ed", ear: "cat", tail: "fluffy", nose: "#292524" },
  { name: ["Панда", "Panda"], body: "#fafafa", belly: "#e5e5e5", ear: "round", tail: "short", nose: "#18181b", patch: "#18181b" },
  { name: ["Мишка", "Teddy"], body: "#a16207", belly: "#d6a46b", ear: "round", tail: "short", nose: "#292524" },
  { name: ["Ёжик", "Hedgehog"], body: "#a8a29e", belly: "#e7d8c9", ear: "none", tail: "none", nose: "#18181b", spikes: true },
  { name: ["Хомяк", "Hamster"], body: "#fbbf24", belly: "#fef3c7", ear: "round", tail: "none", nose: "#f472b6" },
];

function drawAnimal(ctx: CanvasRenderingContext2D, a: Animal, cx: number, cy: number, s: number, sil: boolean) {
  const C = (c: string) => (sil ? "#000" : c);
  const ell = (x: number, y: number, rx: number, ry: number, c: string, rot = 0) => {
    ctx.fillStyle = C(c);
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
    ctx.fill();
  };
  const hx = cx - s * 0.3;
  const hy = cy - s * 0.12;
  const hr = s * 0.2;
  ctx.lineCap = "round";
  if (a.tail === "short") ell(cx + s * 0.44, cy - s * 0.02, s * 0.06, s * 0.05, a.body);
  if (a.tail === "fluffy") ell(cx + s * 0.46, cy - s * 0.04, s * 0.11, s * 0.09, a.body);
  if (a.tail === "long" || a.tail === "curly") {
    ctx.strokeStyle = C(a.body);
    ctx.lineWidth = s * (a.tail === "long" ? 0.06 : 0.035);
    ctx.beginPath();
    if (a.tail === "long") {
      ctx.moveTo(cx + s * 0.4, cy);
      ctx.quadraticCurveTo(cx + s * 0.6, cy - s * 0.05, cx + s * 0.55, cy - s * 0.26);
    } else ctx.arc(cx + s * 0.47, cy - s * 0.03, s * 0.05, 0, Math.PI * 1.6);
    ctx.stroke();
  }
  for (const lx of [-0.22, -0.06, 0.16, 0.31]) rr(ctx, cx + lx * s - s * 0.05, cy + s * 0.1, s * 0.1, s * 0.19, s * 0.04, C(a.body));
  if (a.spikes) for (let i = 0; i < 9; i++) {
    const x = cx - s * 0.24 + i * s * 0.08;
    poly(ctx, [x - s * 0.06, cy - s * 0.08, x + s * 0.02, cy - s * 0.3 + Math.abs(i - 4) * s * 0.02, x + s * 0.07, cy - s * 0.06], C("#57534e"));
  }
  ell(cx + s * 0.06, cy + s * 0.03, s * 0.38, s * 0.22, a.body);
  if (!sil) ell(cx + s * 0.06, cy + s * 0.1, s * 0.25, s * 0.11, a.belly);
  const earC = a.patch && a.ear !== "dog" ? a.patch : a.ear === "dog" ? a.patch ?? a.body : a.body;
  if (a.ear === "dog") {
    ell(hx - hr * 0.8, hy + hr * 0.1, hr * 0.32, hr * 0.62, earC, 0.3);
    ell(hx + hr * 0.8, hy + hr * 0.1, hr * 0.32, hr * 0.62, earC, -0.3);
  } else if (a.ear === "cat") {
    poly(ctx, [hx - hr * 0.9, hy - hr * 0.25, hx - hr * 0.55, hy - hr * 1.25, hx - hr * 0.12, hy - hr * 0.8], C(a.body));
    poly(ctx, [hx + hr * 0.9, hy - hr * 0.25, hx + hr * 0.55, hy - hr * 1.25, hx + hr * 0.12, hy - hr * 0.8], C(a.body));
  } else if (a.ear === "bunny") {
    ell(hx - hr * 0.38, hy - hr * 1.32, hr * 0.22, hr * 0.75, a.body);
    ell(hx + hr * 0.38, hy - hr * 1.32, hr * 0.22, hr * 0.75, a.body);
    if (!sil) {
      ell(hx - hr * 0.38, hy - hr * 1.32, hr * 0.1, hr * 0.55, "#fbcfe8");
      ell(hx + hr * 0.38, hy - hr * 1.32, hr * 0.1, hr * 0.55, "#fbcfe8");
    }
  } else if (a.ear === "round") {
    circle(ctx, hx - hr * 0.75, hy - hr * 0.75, hr * 0.33, C(earC));
    circle(ctx, hx + hr * 0.75, hy - hr * 0.75, hr * 0.33, C(earC));
  }
  circle(ctx, hx, hy, hr, C(a.body));
  if (sil) return;
  if (a.patch && a.ear === "round" && a.nose === "#18181b") {
    ell(hx - hr * 0.38, hy - hr * 0.05, hr * 0.24, hr * 0.3, a.patch, 0.5);
    ell(hx + hr * 0.38, hy - hr * 0.05, hr * 0.24, hr * 0.3, a.patch, -0.5);
  }
  for (const ex of [-0.36, 0.36]) {
    circle(ctx, hx + ex * hr, hy - hr * 0.08, hr * 0.13, "#ffffff");
    circle(ctx, hx + ex * hr, hy - hr * 0.06, hr * 0.08, "#18181b");
  }
  ell(hx, hy + hr * 0.32, hr * 0.14, hr * 0.1, a.nose);
  ctx.globalAlpha = 0.35;
  circle(ctx, hx - hr * 0.6, hy + hr * 0.38, hr * 0.14, "#f472b6");
  circle(ctx, hx + hr * 0.6, hy + hr * 0.38, hr * 0.14, "#f472b6");
  ctx.globalAlpha = 1;
}

const STAGES: Array<{ name: Text; color: string }> = [
  { name: ["Ополосни водой", "Rinse with water"], color: "#38bdf8" },
  { name: ["Намыль пеной", "Lather with soap"], color: "#f472b6" },
  { name: ["Смой пену", "Rinse off the foam"], color: "#38bdf8" },
  { name: ["Высуши феном", "Blow-dry"], color: "#f59e0b" },
];
const GW = 48;
const GH = 34;
const GOAL = 0.97;

function create(api: GameApi): GameInst {
  const animal = ANIMALS[api.level] ?? ANIMALS[0];
  const N = GW * GH;
  const inside = new Uint8Array(N);
  const dirt = new Float32Array(N);
  const foam = new Float32Array(N);
  const wet = new Float32Array(N);
  const prog = new Float32Array(N);
  const done = new Uint8Array(N);
  const jitter = new Float32Array(N).map(() => 0.7 + Math.random() * 0.6);

  // Mask: draw the silhouette at grid resolution and read back alpha
  const sg = GW / 1.24;
  const mask = api.canvas(GW, GH);
  const mctx = mask.getContext("2d")!;
  drawAnimal(mctx, animal, 0.6 * sg, 0.56 * sg, sg, true);
  const alpha = mctx.getImageData(0, 0, GW, GH).data;
  let insideCount = 0;
  const seed = Math.random() * 100;
  for (let i = 0; i < N; i++) {
    if (alpha[i * 4 + 3] > 100) {
      inside[i] = 1;
      insideCount++;
      const x = i % GW;
      const y = Math.floor(i / GW);
      const n = Math.sin(x * 0.45 + seed) * Math.cos(y * 0.5 - seed) + Math.sin((x + y) * 0.23 + seed * 2);
      dirt[i] = n > -0.2 ? clamp(0.45 + n * 0.4, 0.3, 1) : 0;
    }
  }
  insideCount = Math.max(1, insideCount);

  let stage = 0;
  let doneCount = 0;
  let u = 0.3;
  let v = 0.4;
  let stageTime = 0;
  let msgT = 1.6;
  let finished = 0;
  let cache = { key: "", base: null as HTMLCanvasElement | null, sil: null as HTMLCanvasElement | null, over: null as HTMLCanvasElement | null };

  const layout = () => {
    const s = Math.min(api.w * 0.72, (api.h - 100) / 0.9);
    const bw = 1.24 * s;
    const bh = 0.88 * s;
    return { s, x: (api.w - bw) / 2, y: (api.h - bh) / 2 + 22, w: bw, h: bh };
  };

  const apply = (i: number, k: number) => {
    if (stage === 0) {
      wet[i] = Math.max(wet[i], k);
    } else if (stage === 1) {
      foam[i] = Math.max(foam[i], k);
    } else if (stage === 2) {
      foam[i] = Math.min(foam[i], 1 - k);
      dirt[i] = Math.min(dirt[i], 1 - k);
      wet[i] = 1;
    } else {
      wet[i] = Math.min(wet[i], 1 - k);
    }
  };

  const completeStage = () => {
    for (let i = 0; i < N; i++) {
      if (!inside[i]) continue;
      if (stage === 0) {
        wet[i] = 1;
        dirt[i] *= 0.6;
      } else if (stage === 1) foam[i] = 1;
      else if (stage === 2) {
        foam[i] = 0;
        dirt[i] = 0;
        wet[i] = 1;
      } else wet[i] = 0;
    }
    const pts = Math.max(60, Math.round(500 - 18 * stageTime));
    const L = layout();
    api.add(pts, api.w / 2, L.y);
    api.sfx("good");
    stage++;
    stageTime = 0;
    prog.fill(0);
    done.fill(0);
    doneCount = 0;
    if (stage >= STAGES.length) {
      finished = 1.8;
      progress.bump("washed");
      api.setLevel(`wash:${api.level}`, api.score);
      api.furby.say("good");
    } else msgT = 1.3;
  };

  return {
    update(dt: number, inp: InputFrame) {
      if (finished > 0) {
        finished -= dt;
        if (Math.random() < 0.3) {
          const L = layout();
          api.fx.burst(L.x + Math.random() * L.w, L.y + Math.random() * L.h * 0.7, "#facc15", 4, 80, 2.5);
        }
        if (finished <= 0) api.over(true);
        return;
      }
      msgT = Math.max(0, msgT - dt);
      stageTime += dt;
      const L = layout();
      u += (inp.ax * 0.75 + inp.tiltX * 0.5) * dt;
      v -= (inp.ay * 0.75 - inp.tiltY * 0.3) * dt;
      if (api.pointer.down) {
        const tu = (api.pointer.x - L.x) / L.w;
        const tv = (api.pointer.y - L.y) / L.h;
        u += (tu - u) * Math.min(1, dt * 14);
        v += (tv - v) * Math.min(1, dt * 14);
      }
      u = clamp(u, -0.04, 1.04);
      v = clamp(v, -0.04, 1.04);
      const gx = u * GW;
      const gy = v * GH;
      const R = 3;
      for (let y = Math.max(0, Math.floor(gy - R)); y <= Math.min(GH - 1, Math.ceil(gy + R)); y++) {
        for (let x = Math.max(0, Math.floor(gx - R)); x <= Math.min(GW - 1, Math.ceil(gx + R)); x++) {
          const i = y * GW + x;
          if (!inside[i]) continue;
          const d = Math.hypot(x + 0.5 - gx, y + 0.5 - gy);
          if (d > R) continue;
          prog[i] += 4.4 * (1 - (0.6 * d) / R) * dt;
          apply(i, Math.min(1, prog[i] / 0.45));
          if (!done[i] && prog[i] >= 0.45) {
            done[i] = 1;
            doneCount++;
          }
        }
      }
      const tx = L.x + u * L.w;
      const ty = L.y + v * L.h;
      api.fx.burst(tx, ty, stage === 1 ? "#fbcfe8" : stage === 3 ? "#fdba74" : "#7dd3fc", 1, 70, 2);
      if (doneCount / insideCount >= GOAL) completeStage();
    },

    draw() {
      const { ctx, w, h, pal } = api;
      ctx.fillStyle = pal.bg;
      ctx.fillRect(-20, -20, w + 40, h + 40);
      const L = layout();
      rr(ctx, L.x - 20, L.y + L.h * 0.62, L.w + 40, L.h * 0.42, 24, pal.dark ? "#0c4a6e55" : "#e0f2fe");
      const key = `${Math.round(L.w)}x${Math.round(L.h)}`;
      if (cache.key !== key) {
        const base = api.canvas(L.w, L.h);
        drawAnimal(base.getContext("2d")!, animal, 0.6 * L.s, 0.56 * L.s, L.s, false);
        const sil = api.canvas(L.w, L.h);
        drawAnimal(sil.getContext("2d")!, animal, 0.6 * L.s, 0.56 * L.s, L.s, true);
        cache = { key, base, sil, over: api.canvas(L.w, L.h) };
      }
      ctx.drawImage(cache.base!, L.x, L.y, L.w, L.h);
      const over = cache.over!;
      const o = over.getContext("2d")!;
      o.globalCompositeOperation = "source-over";
      o.clearRect(0, 0, over.width, over.height);
      const cw = L.w / GW;
      const ch = L.h / GH;
      for (let i = 0; i < N; i++) {
        if (!inside[i]) continue;
        const x = (i % GW) * cw + cw / 2;
        const y = Math.floor(i / GW) * ch + ch / 2;
        if (dirt[i] > 0.02) {
          o.globalAlpha = dirt[i] * 0.75;
          circle(o, x, y, cw * 0.95 * jitter[i], "#7c4a1e");
        }
        if (wet[i] > 0.02) {
          o.globalAlpha = wet[i] * 0.22;
          circle(o, x, y, cw * 0.9, "#0ea5e9");
        }
        if (foam[i] > 0.02) {
          o.globalAlpha = Math.min(1, foam[i]) * 0.95;
          circle(o, x, y, cw * 0.85 * jitter[i] * (0.6 + foam[i] * 0.5), "#ffffff");
        }
      }
      o.globalAlpha = 1;
      o.globalCompositeOperation = "destination-in";
      o.drawImage(cache.sil!, 0, 0);
      o.globalCompositeOperation = "source-over";
      ctx.drawImage(over, L.x, L.y, L.w, L.h);

      if (stage < STAGES.length) {
        const st = STAGES[stage];
        const tx = L.x + u * L.w;
        const ty = L.y + v * L.h;
        strokeCircle(ctx, tx, ty, 3 * cw, st.color, 2);
        ctx.strokeStyle = pal.faint;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(w + 10, h * 0.15);
        ctx.quadraticCurveTo(tx + 120, ty - 140, tx + 26, ty - 26);
        ctx.stroke();
        if (stage === 3) {
          rr(ctx, tx + 14, ty - 44, 48, 26, 10, st.color);
          rr(ctx, tx + 40, ty - 22, 12, 28, 5, st.color);
        } else rr(ctx, tx + 12, ty - 36, 22, 22, 6, st.color);
        const cov = Math.min(100, Math.floor((doneCount / insideCount / GOAL) * 100));
        text(ctx, `${stage + 1}/4 · ${api.t(...st.name)}`, w / 2, 18, 16, pal.fg, "center", 700);
        bar(ctx, w / 2 - 110, 34, 220, 9, cov / 100, st.color, pal.dark ? "#ffffff22" : "#00000014");
        text(ctx, `${cov}%`, w / 2 + 122, 39, 12, pal.muted, "left", 700);
        if (msgT > 0) text(ctx, api.t(...st.name), w / 2, L.y - 6, 22, st.color, "center", 800);
      } else {
        text(ctx, api.t(`${animal.name[0]} чистый!`, `${animal.name[1]} is clean!`), w / 2, 22, 20, pal.fg, "center", 800);
        for (let k = 0; k < 5; k++) star(ctx, L.x + L.w * (0.15 + k * 0.18), L.y + 10 + Math.sin(api.time * 4 + k) * 6, 9, "#facc15");
      }
      text(ctx, api.t(...animal.name), 12, 18, 13, pal.muted, "left", 600);
    },
  };
}

export const washGame: GameDef = {
  id: "wash",
  name: ["Мойка животных", "Pet Wash"],
  desc: [
    "Сполосни животное водой, намыль пеной, смой и высуши феном. Шланг и фен двигаются антенной (или пальцем по экрану).",
    "Rinse the animal, lather it, rinse again and blow-dry. Move the hose and dryer with the antenna (or drag on screen).",
  ],
  icon: Droplets,
  cat: "arcade",
  controls: ["antenna", "tilt"],
  lives: 0,
  tap: null,
  levels: ANIMALS.map((a) => ({ name: a.name })),
  create,
};
