import { clsx, type ClassValue } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

/** Custom colour tokens from index.css, so tailwind-merge doesn't mistake text-ink for a font size */
const COLORS = [
  "paper", "panel", "panel-2", "ink", "ink-2", "muted", "faint", "line", "line-2", "line-strong", "signal", "signal-dim", "flare", "flare-dim",
  "amber", "amber-dim", "invert", "on-invert", "lcd", "bg", "surface", "surface-2", "fg", "inv", "inv-fg", "accent", "ok", "warn", "danger",
];

const twMerge = extendTailwindMerge({ extend: { theme: { color: COLORS } } });

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
