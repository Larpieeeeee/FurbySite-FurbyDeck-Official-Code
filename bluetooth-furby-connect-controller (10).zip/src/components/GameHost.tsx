import { useEffect, useRef, useState, type ReactNode } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ChevronLeft, Maximize, Pause, Play, RotateCcw, Trophy } from "lucide-react";
import { Button, Tag } from "@/components/ui";
import { input } from "@/games/input";
import { Fx, heart, text } from "@/games/kit";
import { CTL_LABELS, KEY_HINTS } from "@/games/registry";
import type { Ctl, GameApi, GameDef, Palette } from "@/games/types";
import { sfx } from "@/lib/audio/synth";
import { broadcast, furby, furby2, type InputType } from "@/lib/furby/controller";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT } from "@/lib/i18n";
import { progress } from "@/lib/progress";
import { settings, useSettings } from "@/lib/settings";
import { cn } from "@/utils/cn";

function readPalette(): Palette {
  const cs = getComputedStyle(document.documentElement);
  const v = (n: string) => cs.getPropertyValue(n).trim() || "#888888";
  return {
    bg: v("--bg"), surface: v("--surface"), surface2: v("--surface-2"), fg: v("--fg"), muted: v("--muted"), faint: v("--faint"), line: v("--line"),
    dark: document.documentElement.dataset.theme === "dark",
    blue: "#3b82f6", red: "#ef4444", green: "#22c55e", amber: "#f59e0b", violet: "#8b5cf6", pink: "#ec4899", cyan: "#06b6d4", orange: "#f97316", lime: "#84cc16", teal: "#14b8a6",
  };
}

function vibrate(ms = 40) {
  if (settings.get().vibrate) navigator.vibrate?.(ms);
}

function speak(textValue: string) {
  const s = settings.get();
  if (!s.voice || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(textValue);
  u.lang = s.lang === "en" ? "en-US" : "ru-RU";
  u.rate = 1.15;
  speechSynthesis.speak(u);
}

function TouchButton({ type, children, className }: { type: InputType; children: ReactNode; className?: string }) {
  return (
    <button
      type="button"
      onPointerDown={(e) => {
        e.preventDefault();
        input.press(type);
        vibrate(10);
      }}
      onPointerUp={() => input.release(type)}
      onPointerLeave={() => input.release(type)}
      onPointerCancel={() => input.release(type)}
      onContextMenu={(e) => e.preventDefault()}
      className={cn("flex h-14 min-w-14 touch-none select-none items-center justify-center rounded-2xl border border-line-strong bg-surface px-3 text-sm font-medium text-fg active:bg-surface-2", className)}
    >
      {children}
    </button>
  );
}

function TouchControls({ controls }: { controls: Ctl[] }) {
  const t = useT();
  const four = controls.includes("antenna");
  const lr = four || controls.includes("antennaLR");
  const fb = four || controls.includes("antennaFB");
  const blank = <span className="h-14 w-14" />;
  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
      {(lr || fb) && (
        <div className="grid grid-cols-3 gap-1.5">
          {blank}
          {fb ? <TouchButton type="antF"><ArrowUp className="h-5 w-5" /></TouchButton> : blank}
          {blank}
          {lr ? <TouchButton type="antL"><ArrowLeft className="h-5 w-5" /></TouchButton> : blank}
          {fb ? <TouchButton type="antB"><ArrowDown className="h-5 w-5" /></TouchButton> : blank}
          {lr ? <TouchButton type="antR"><ArrowRight className="h-5 w-5" /></TouchButton> : blank}
        </div>
      )}
      {controls.includes("tilt") && (
        <div className="flex gap-1.5">
          <TouchButton type="tiltL">{t("↶ Наклон", "↶ Tilt")}</TouchButton>
          <TouchButton type="tiltR">{t("Наклон ↷", "Tilt ↷")}</TouchButton>
        </div>
      )}
      <div className="flex flex-wrap justify-center gap-1.5">
        {controls.includes("tongue") && <TouchButton type="tongue" className="min-w-20">{t("Язык", "Tongue")}</TouchButton>}
        {controls.includes("tail") && <TouchButton type="tail">{t("Хвост", "Tail")}</TouchButton>}
        {controls.includes("head") && <TouchButton type="head">{t("Голова", "Head")}</TouchButton>}
        {controls.includes("tummy") && <TouchButton type="tummy">{t("Живот", "Tummy")}</TouchButton>}
        {controls.includes("sides") && <TouchButton type="sideL">{t("Л. бок", "L side")}</TouchButton>}
        {controls.includes("sides") && <TouchButton type="sideR">{t("П. бок", "R side")}</TouchButton>}
        {controls.includes("shake") && <TouchButton type="shake">{t("Тряска", "Shake")}</TouchButton>}
        {controls.includes("flip") && <TouchButton type="flip">{t("Переворот", "Flip")}</TouchButton>}
      </div>
    </div>
  );
}

interface Result {
  score: number;
  best: number;
  record: boolean;
  win: boolean;
}

export function GameHost({ def, level, onExit }: { def: GameDef; level: number; onExit(): void }) {
  const t = useT();
  const lang = useLang();
  const touchSetting = useSettings((s) => s.touchControls);
  const status = useFurby((s) => s.status);
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [phase, setPhase] = useState<"ready" | "play" | "over">("ready");
  const [paused, setPaused] = useState(false);
  const [run, setRun] = useState(0);
  const [result, setResult] = useState<Result | null>(null);
  const pausedRef = useRef(false);
  const instRef = useRef<{ pause?(p: boolean): void } | null>(null);
  const showTouch = touchSetting === "always" || (touchSetting === "auto" && status !== "ready");
  const showTouchRef = useRef(showTouch);
  showTouchRef.current = showTouch;
  const langRef = useRef(lang);
  langRef.current = lang;

  const togglePause = (p: boolean) => {
    pausedRef.current = p;
    setPaused(p);
    instRef.current?.pause?.(p);
  };

  useEffect(() => {
    if (phase !== "play" || !def.create) return;
    const canvas = canvasRef.current!;
    const wrap = wrapRef.current!;
    const ctx = canvas.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const fx = new Fx();
    const started = performance.now();
    const lng = langRef.current;
    let finished = false;
    let endWin = false;
    const pointer = { x: 0, y: 0, down: false };
    const api: GameApi = {
      ctx, w: 320, h: 240, time: 0, level, lang: lng, pal: readPalette(), score: 0, lives: def.lives ?? 3, ended: false,
      t: (ru, en) => (lng === "en" ? en : ru),
      add(n, x, y) {
        api.score = Math.max(0, api.score + n);
        if (x !== undefined && y !== undefined && n !== 0) fx.float(`${n > 0 ? "+" : ""}${n}`, x, y, n > 0 ? api.pal.fg : api.pal.red);
      },
      hurt() {
        if (api.ended) return true;
        api.lives -= 1;
        fx.shake(8);
        sfx("hit");
        vibrate(120);
        if (api.lives <= 0) {
          api.over(false);
          return true;
        }
        return false;
      },
      heal() {
        api.lives += 1;
      },
      over(win = false) {
        if (api.ended) return;
        api.ended = true;
        endWin = win;
      },
      fx, sfx, vibrate, speak,
      furby: {
        get connected() {
          return furby.connected || furby2.connected;
        },
        say: (k) => {
          if (settings.get().gameTalk) broadcast((f) => f.say(k));
        },
        led: (r, g, b) => {
          if (settings.get().gameLights) broadcast((f) => f.setLedFrame([r, g, b], true));
        },
        action: (i, x, s, p) => broadcast((f) => f.action(i, x, s, p, true)),
        random: (i) => broadcast((f) => f.randomInput(i, true)),
        mood: (ty, v) => broadcast((f) => f.setMood(ty, v)),
      },
      canvas: (w, h) => {
        const c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(w));
        c.height = Math.max(1, Math.round(h));
        return c;
      },
      pointer,
      getLevel: (k) => progress.level(k),
      setLevel: (k, v) => progress.setLevel(k, v),
    };
    const resize = () => {
      const fs = document.fullscreenElement === wrap;
      const w = wrap.clientWidth;
      const aspect = def.aspect ?? (w < 640 ? 0.95 : 1.6);
      const maxH = fs ? window.innerHeight - (showTouchRef.current ? 180 : 20) : window.innerHeight * 0.66;
      const h = Math.round(Math.max(230, Math.min(maxH, w / aspect)));
      canvas.style.height = `${h}px`;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      api.w = w;
      api.h = h;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    document.addEventListener("fullscreenchange", resize);
    input.tiltMode = def.controls.includes("tilt") && !def.controls.some((c) => c.startsWith("antenna"));
    const detach = input.attach();
    broadcast((f) => f.gameStart());
    api.furby.say("start");
    const inst = def.create(api);
    instRef.current = inst;
    const tap = def.tap === undefined ? (def.controls.includes("tongue") ? "tongue" : null) : def.tap;
    const local = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      pointer.x = e.clientX - r.left;
      pointer.y = e.clientY - r.top;
    };
    const down = (e: PointerEvent) => {
      local(e);
      pointer.down = true;
      if (tap) input.press(tap);
      canvas.setPointerCapture?.(e.pointerId);
    };
    const up = () => {
      pointer.down = false;
      if (tap) input.release(tap);
    };
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", local);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);
    const key = (e: KeyboardEvent) => {
      if (e.code === "Escape" || e.code === "KeyP") togglePause(!pausedRef.current);
    };
    window.addEventListener("keydown", key);

    let last = performance.now();
    let raf = 0;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (pausedRef.current) {
        input.frame(0);
        return;
      }
      api.time += dt;
      const frame = input.frame(dt);
      try {
        inst.update(dt, frame);
      } catch (err) {
        console.error(err);
        api.over(false);
      }
      fx.update(dt);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, api.w, api.h);
      const [sx, sy] = fx.offset();
      ctx.save();
      ctx.translate(sx, sy);
      try {
        inst.draw();
      } catch (err) {
        console.error(err);
      }
      fx.draw(ctx);
      ctx.restore();
      if (def.hud !== false) {
        text(ctx, `${api.t("Очки", "Score")}: ${Math.round(api.score)}`, 12, 18, 15, api.pal.fg, "left", 700);
        if ((def.lives ?? 3) > 0) for (let i = 0; i < Math.min(api.lives, 8); i++) heart(ctx, api.w - 16 - i * 20, 18, 7, api.pal.red);
      }
      if (api.ended && !finished) {
        finished = true;
        cancelAnimationFrame(raf);
        const rec = progress.recordGame(def.id, api.score, { win: endWin, seconds: (performance.now() - started) / 1000 });
        setResult({ score: Math.round(api.score), best: Math.round(rec.best), record: rec.isRecord, win: endWin });
        setPhase("over");
        sfx(endWin ? "win" : "lose");
        api.furby.say(endWin ? "win" : "lose");
      }
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      document.removeEventListener("fullscreenchange", resize);
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", local);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
      window.removeEventListener("keydown", key);
      detach();
      try {
        inst.dispose?.();
      } catch {
        /* ignore */
      }
      instRef.current = null;
      broadcast((f) => f.gameEnd());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, run, def, level]);

  const start = () => {
    setResult(null);
    togglePause(false);
    setRun((r) => r + 1);
    setPhase("play");
  };

  const levelName = def.levels?.[level] ? pick(def.levels[level].name, lang) : null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <Button variant="ghost" size="sm" onClick={onExit}>
          <ChevronLeft className="h-4 w-4" />
          {t("Назад", "Back")}
        </Button>
        <div className="min-w-0 flex-1 truncate text-center text-sm font-semibold">
          {pick(def.name, lang)}
          {levelName && <span className="font-normal text-muted"> · {levelName}</span>}
        </div>
        <div className="flex gap-1">
          {phase === "play" && (
            <Button variant="ghost" size="sm" onClick={() => togglePause(!paused)} aria-label={t("Пауза", "Pause")}>
              {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => void wrapRef.current?.requestFullscreen?.()} aria-label={t("Во весь экран", "Fullscreen")}>
            <Maximize className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div ref={wrapRef} className="relative overflow-hidden rounded-2xl border border-line bg-bg">
        <canvas ref={canvasRef} className="block w-full touch-none select-none" style={{ height: phase === "play" ? undefined : 320 }} />
        {phase !== "play" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 overflow-y-auto bg-surface/95 p-5 text-center">
            {phase === "ready" ? (
              <>
                <def.icon className="h-8 w-8 text-muted" />
                <h3 className="text-xl font-semibold">{pick(def.name, lang)}</h3>
                <p className="max-w-md text-sm leading-relaxed text-muted">{pick(def.desc, lang)}</p>
                <div className="flex max-w-md flex-wrap justify-center gap-1.5">
                  {def.controls.map((c) => (
                    <Tag key={c}>
                      {pick(CTL_LABELS[c], lang)} <span className="text-faint">· {KEY_HINTS[c]}</span>
                    </Tag>
                  ))}
                </div>
                <Button variant="primary" size="lg" onClick={start}>
                  <Play className="h-4 w-4" />
                  {t("Играть", "Play")}
                </Button>
              </>
            ) : (
              result && (
                <>
                  <Trophy className={cn("h-8 w-8", result.record ? "text-warn" : "text-muted")} />
                  <h3 className="text-xl font-semibold">{result.win ? t("Победа!", "Victory!") : t("Игра окончена", "Game over")}</h3>
                  <p className="text-4xl font-semibold tabular-nums">{result.score}</p>
                  <p className="text-sm text-muted">
                    {result.record ? t("Новый рекорд!", "New record!") : `${t("Рекорд", "Best")}: ${result.best}`}
                  </p>
                  <div className="flex gap-2">
                    <Button variant="primary" onClick={start}>
                      <RotateCcw className="h-4 w-4" />
                      {t("Ещё раз", "Play again")}
                    </Button>
                    <Button onClick={onExit}>{t("К списку", "To the list")}</Button>
                  </div>
                </>
              )
            )}
          </div>
        )}
        {paused && phase === "play" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-surface/90">
            <p className="text-lg font-semibold">{t("Пауза", "Paused")}</p>
            <Button variant="primary" onClick={() => togglePause(false)}>
              <Play className="h-4 w-4" />
              {t("Продолжить", "Resume")}
            </Button>
          </div>
        )}
        {phase === "play" && showTouch && (
          <div className="border-t border-line bg-surface p-3">
            <TouchControls controls={def.controls} />
          </div>
        )}
      </div>
      {phase === "play" && !showTouch && (
        <p className="text-center text-xs text-faint">{t("Esc или P — пауза. Можно играть и с клавиатуры.", "Esc or P to pause. You can also play with the keyboard.")}</p>
      )}
    </div>
  );
}
