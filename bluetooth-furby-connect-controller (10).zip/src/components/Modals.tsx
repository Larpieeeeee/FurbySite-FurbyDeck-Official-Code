import { useEffect, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Check, CircleCheck, Languages, Radio, RotateCcw, ShieldCheck, Skull, TriangleAlert, X } from "lucide-react";
import { Button, Chip, Label, Modal, Notice, Progress, nav } from "@/components/ui";
import { CONFIRM_MS, furby } from "@/lib/furby/controller";
import { DIR_LABELS, type Dir } from "@/lib/furby/protocol";
import { useConfirming } from "@/lib/furby/useFurby";
import { pick, useLang, useT } from "@/lib/i18n";
import { settings, useSettings } from "@/lib/settings";
import { dismissToast, toasts } from "@/lib/toast";
import { cn } from "@/utils/cn";
import { Joystick } from "./Sidebar";

export const TELEGRAM_URL = "https://t.me/furbydeck";
export const TIKTOK_URL = "https://www.tiktok.com/@larpieeeeee";

export function TestedNotice({ className }: { className?: string }) {
  const t = useT();
  return (
    <Notice icon={Languages} className={className}>
      <b>{t("Только русский Connect.", "Russian Connect only.")}</b>{" "}
      {t("Furby Connect выпускался только на русском и английском. Английская версия ещё не тестировалась — ", "Furby Connect only exists in Russian and English. The English version hasn't been tested yet — ")}
      <a className="font-medium text-signal underline-offset-2 hover:underline" href={TELEGRAM_URL} target="_blank" rel="noreferrer">
        {t("напиши в @furbydeck", "write to @furbydeck")}
      </a>
      {t(", если проверишь.", " if you try it.")}
    </Notice>
  );
}

export function WarningModal() {
  const t = useT();
  const accepted = useSettings((s) => s.warningAccepted);
  const open = nav.use((n) => n.warning || (!accepted && !n.demoOnly));
  const [agree, setAgree] = useState(accepted);
  const close = () => nav.set({ warning: false });
  const items = [
    t("Проверено только на русском Furby Connect — на английском ещё нет.", "Tested only on a Russian Furby Connect — not on English yet."),
    t("Проект неофициальный и не связан с Hasbro.", "The project is unofficial and not affiliated with Hasbro."),
    t("Авторы не возмещают ущерб и не чинят игрушки.", "The authors don't cover damage or repair toys."),
    t("Быстрые вспышки света опасны при светочувствительной эпилепсии.", "Fast light flashes are dangerous for photosensitive epilepsy."),
    t("Все действия ты выполняешь добровольно и на свой риск.", "Everything you do is voluntary and at your own risk."),
  ];
  return (
    <Modal
      open={open}
      onClose={accepted ? close : undefined}
      tone="flare"
      icon={Skull}
      title={t("Ферби может сломаться", "Furby may break")}
      subtitle={t("я не виноват", "not my fault")}
      footer={
        accepted ? (
          <Button variant="signal" onClick={close}>{t("Понятно", "Got it")}</Button>
        ) : (
          <>
            <Button variant="signal" disabled={!agree} onClick={() => { settings.set({ warningAccepted: true }); close(); }}>
              <ShieldCheck className="h-4 w-4" />
              {t("Принять и продолжить", "Accept and continue")}
            </Button>
            <Button onClick={() => { nav.set({ demoOnly: true, warning: false }); void furby.connectDemo(); }}>{t("Только демо-режим", "Demo mode only")}</Button>
          </>
        )
      }
    >
      <div className="space-y-4">
        <TestedNotice />
        <p>
          {t("Пульт работает напрямую с прошивкой игрушки по Bluetooth. Обычные команды безопасны, но ", "The remote talks to the toy's firmware directly over Bluetooth. Normal commands are safe, but ")}
          <b className="text-ink">{t("загрузка и удаление DLC, сырые пакеты и просадка питания", "uploading or deleting DLC, raw packets and low batteries")}</b>
          {t(" могут превратить Ферби в «кирпич». Восстановить его в домашних условиях почти невозможно.", " can turn Furby into a “brick”. Fixing it at home is almost impossible.")}
        </p>
        <ul className="space-y-2">
          {items.map((x) => (
            <li key={x} className="flex gap-2.5">
              <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
              {x}
            </li>
          ))}
        </ul>
        {!accepted && (
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-line bg-panel-2 p-3.5 font-medium text-ink">
            <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} className="mt-1 h-4 w-4" />
            {t("Я понял риск, беру ответственность на себя и не буду предъявлять претензии авторам.", "I understand the risk, take responsibility and won't make claims against the authors.")}
          </label>
        )}
      </div>
    </Modal>
  );
}

const ICONS: Record<Dir, typeof ArrowLeft> = { L: ArrowLeft, R: ArrowRight, F: ArrowUp, B: ArrowDown };
const ARROWS: Record<Dir, string> = { L: "←", R: "→", F: "↑", B: "↓" };

export function HandshakeModal() {
  const t = useT();
  const lang = useLang();
  const ctl = useConfirming();
  const confirm = ctl?.getState().confirm ?? null;
  const demo = ctl?.getState().demo ?? false;
  const name = ctl?.getState().deviceName ?? null;
  const status = ctl?.getState().status ?? "idle";
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 100);
    return () => window.clearInterval(id);
  }, []);
  if (!ctl || status !== "confirming" || !confirm) return null;
  const left = Math.max(0, confirm.deadline - now);
  const need = confirm.seq[confirm.step];
  const pad = (d: Dir) => {
    const Icon = ICONS[d];
    return (
      <button
        type="button"
        onPointerDown={() => ctl.demoAntenna(d)}
        onPointerUp={() => ctl.demoAntenna(null)}
        onPointerLeave={() => ctl.demoAntenna(null)}
        className={cn("flex h-10 items-center justify-center rounded-lg border bg-panel touch-none", need === d ? "anim-blink border-amber/50 bg-amber-dim text-amber" : "border-line text-ink-2")}
      >
        <Icon className="h-4 w-4" />
      </button>
    );
  };
  return (
    <Modal
      open
      wide
      icon={Radio}
      tone="amber"
      title={t("Повтори комбинацию поворотами", "Repeat the combination with turns")}
      subtitle={`${demo ? t("Furby (демо)", "Furby (demo)") : name ?? "Furby"} · ${t("6 поворотов антенны · 20 секунд на попытку", "6 antenna turns · 20 seconds per try")}`}
      aside={<Chip tone={confirm.errors ? "flare" : "signal"}>{confirm.errors ? `${t("ошибок", "mistakes")}: ${confirm.errors}` : t("без ошибок", "no mistakes")}</Chip>}
      footer={
        <>
          <Button variant="ghost" size="sm" onClick={() => ctl.disconnect()}>
            <X className="h-4 w-4" />
            {t("Отключиться", "Disconnect")}
          </Button>
          <span className="ml-auto font-mono text-xs text-muted">{t("попытка", "try")} {confirm.attempt}</span>
          <Button variant="primary" size="sm" onClick={() => ctl.newCombination()}>
            <RotateCcw className="h-4 w-4" />
            {t("Новая комбинация", "New combination")}
          </Button>
        </>
      }
    >
      <div className="grid gap-5 md:grid-cols-[230px_1fr]">
        <div className="rounded-xl border border-line bg-panel-2 p-3">
          <Label className="text-center">live · packet 0x21</Label>
          <Joystick className="mx-auto mt-2 w-full max-w-[200px]" ctl={ctl} />
          {demo && (
            <>
              <div className="mx-auto mt-3 grid max-w-[200px] grid-cols-3 gap-1.5">
                <span />
                {pad("F")}
                <span />
                {pad("L")}
                <span className="flex items-center justify-center font-mono text-[11px] text-muted">{confirm.step}/6</span>
                {pad("R")}
                <span />
                {pad("B")}
                <span />
              </div>
              <p className="mt-2 text-center text-[11px] text-muted">{t("Демо: мигает нужная стрелка. Можно жать стрелки на клавиатуре", "Demo: the needed arrow blinks. Keyboard arrows work too")}</p>
            </>
          )}
        </div>
        <div className="space-y-4">
          <p>
            {t("Пульт показал случайную последовательность поворотов. Веди антенну ", "The remote shows a random sequence of turns. Move the antenna ")}
            <b className="text-ink">{t("строго по порядку", "strictly in order")}</b>
            {t(" и ", " and ")}
            <b className="text-ink">{t("отпускай её между шагами", "release it between steps")}</b>
            {t(". Нажимать антенну вниз не нужно — нажатия просто игнорируются. Одна ошибка — и комбинация начинается заново.", ". No need to press the antenna down — presses are ignored. One mistake and the combination starts over.")}
          </p>
          <div key={confirm.errorAt} className={cn("grid grid-cols-6 gap-1.5", confirm.errorAt > 0 && "anim-shake")}>
            {confirm.seq.map((d, i) => {
              const Icon = ICONS[d];
              const done = i < confirm.step;
              const cur = i === confirm.step;
              return (
                <div key={i} className={cn("flex flex-col items-center gap-1 rounded-lg border py-2.5", done ? "border-signal bg-signal text-white" : cur ? "border-invert bg-invert text-on-invert" : "border-line bg-panel-2 text-ink-2")}>
                  {done ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                  <span className="font-mono text-[10px] opacity-70">{i + 1}</span>
                </div>
              );
            })}
          </div>
          {need && (
            <div className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 p-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-invert text-on-invert">{(() => { const I = ICONS[need]; return <I className="h-4 w-4" />; })()}</span>
              <div>
                <Label>{t(`шаг ${confirm.step + 1} из 6`, `step ${confirm.step + 1} of 6`)}</Label>
                <p className="font-display text-lg font-bold text-ink">{pick(DIR_LABELS[need], lang).toLowerCase()} {ARROWS[need]}</p>
              </div>
            </div>
          )}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-muted">{t("Осталось на попытку", "Time left for this try")}</span>
              <span className="font-mono text-ink">{(left / 1000).toFixed(1)} {t("с", "s")}</span>
            </div>
            <Progress value={left / CONFIRM_MS} tone={left < 5000 ? "flare" : "signal"} />
          </div>
        </div>
      </div>
    </Modal>
  );
}

export function Toasts() {
  const all = toasts.use((s) => s.items);
  // Phones get at most two toasts so they don't cover the screen
  const items = window.innerWidth < 640 ? all.slice(-2) : all;
  return (
    <div className="pointer-events-none fixed right-3 z-[60] flex w-[min(360px,calc(100vw-24px))] flex-col gap-2 sm:right-4" style={{ bottom: "calc(var(--bottom-inset) + 12px + env(safe-area-inset-bottom))" }}>
      {items.map((item) => {
        const Icon = item.icon ?? CircleCheck;
        return (
          <div key={item.id} className={cn("anim-toast pointer-events-auto flex items-start gap-3 rounded-xl border bg-panel px-3.5 py-3 shadow-lg", item.tone === "err" ? "border-flare/40" : item.tone === "warn" ? "border-amber/40" : "border-signal/40")}>
            <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", item.tone === "err" ? "text-flare" : item.tone === "warn" ? "text-amber" : "text-signal")} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-ink">{item.title}</p>
              {item.text && <p className="mt-0.5 text-xs text-muted">{item.text}</p>}
            </div>
            <button type="button" onClick={() => dismissToast(item.id)} className="text-faint hover:text-ink" aria-label="Close">
              <X className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
