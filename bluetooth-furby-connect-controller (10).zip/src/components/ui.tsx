import type { ButtonHTMLAttributes, ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { Info, TriangleAlert, X } from "lucide-react";
import { createStore } from "@/lib/store";
import { cn } from "@/utils/cn";

export type TabId = "control" | "games" | "search" | "light" | "music" | "commands" | "studio" | "auto" | "progress" | "debug" | "diag" | "monitor" | "journal" | "settings" | "about";
/** UI navigation shared between tabs */
export const nav = createStore<{ tab: TabId; warning: boolean; demoOnly: boolean }>({ tab: "control", warning: false, demoOnly: false });
export const goTab = (tab: TabId) => {
  nav.set({ tab });
  window.scrollTo({ top: 0, behavior: "smooth" });
};

type Variant = "primary" | "signal" | "secondary" | "ghost" | "danger" | "soft";
type Size = "sm" | "md" | "lg" | "icon";
const VARIANTS: Record<Variant, string> = {
  primary: "bg-invert text-on-invert hover:opacity-90",
  signal: "bg-signal text-white hover:opacity-90",
  secondary: "border border-line bg-panel text-ink hover:bg-panel-2",
  ghost: "text-ink-2 hover:bg-panel-2 hover:text-ink",
  danger: "border border-flare/40 bg-panel text-flare hover:bg-flare-dim",
  soft: "border border-signal/30 bg-signal-dim text-signal hover:opacity-90",
};
const SIZES: Record<Size, string> = { sm: "h-8 px-3 text-xs", md: "h-10 px-4 text-sm", lg: "h-12 px-6 text-base", icon: "h-9 w-9" };

export function Button({ variant = "secondary", size = "md", className, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size }) {
  return (
    <button
      type="button"
      className={cn("inline-flex cursor-pointer select-none items-center justify-center gap-2 rounded-lg font-medium transition-colors disabled:pointer-events-none disabled:opacity-40", VARIANTS[variant], SIZES[size], className)}
      {...props}
    />
  );
}

export function Card({ title, hint, icon: Icon, action, children, className, bodyClass, flush }: { title?: ReactNode; hint?: ReactNode; icon?: LucideIcon; action?: ReactNode; children: ReactNode; className?: string; bodyClass?: string; flush?: boolean }) {
  return (
    <section className={cn("overflow-hidden rounded-2xl border border-line bg-panel", className)}>
      {(title || action) && (
        <header className="flex items-center gap-3 border-b border-line px-4 py-3.5 sm:px-5">
          {Icon && <Icon className="h-[18px] w-[18px] shrink-0 text-signal" />}
          <div className="min-w-0 flex-1">
            {title && <h2 className="font-display text-[13px] font-bold uppercase tracking-[0.18em] text-ink">{title}</h2>}
            {hint && <p className="mt-0.5 text-xs text-muted">{hint}</p>}
          </div>
          {action}
        </header>
      )}
      <div className={cn(!flush && "p-4 sm:p-5", bodyClass)}>{children}</div>
    </section>
  );
}

type Tone = "neutral" | "signal" | "amber" | "flare" | "ink";
const TONES: Record<Tone, string> = {
  neutral: "border-line bg-panel text-ink-2",
  signal: "border-signal/30 bg-signal-dim text-signal",
  amber: "border-amber/30 bg-amber-dim text-amber",
  flare: "border-flare/30 bg-flare-dim text-flare",
  ink: "border-invert bg-invert text-on-invert",
};
export function Chip({ tone = "neutral", children, className, onClick }: { tone?: Tone; children: ReactNode; className?: string; onClick?: () => void }) {
  const C = onClick ? "button" : "span";
  return (
    <C type={onClick ? "button" : undefined} onClick={onClick} className={cn("inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[11px] font-medium", TONES[tone], onClick && "cursor-pointer hover:opacity-80", className)}>
      {children}
    </C>
  );
}
export function Tag({ active, children, className }: { active?: boolean; children: ReactNode; className?: string }) {
  return <Chip tone={active ? "ink" : "neutral"} className={cn("px-2.5 py-1 text-xs", className)}>{children}</Chip>;
}

export function Label({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("font-mono text-[10px] uppercase tracking-[0.2em] text-muted", className)}>{children}</p>;
}

export function Switch({ checked, onChange, disabled }: { checked: boolean; onChange(v: boolean): void; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={checked} disabled={disabled} onClick={() => onChange(!checked)} className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-40", checked ? "bg-signal" : "bg-line-strong")}>
      <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all", checked ? "left-[22px]" : "left-0.5")} />
    </button>
  );
}

export function Toggle({ checked, onChange, label, hint, disabled }: { checked: boolean; onChange(v: boolean): void; label: ReactNode; hint?: ReactNode; disabled?: boolean }) {
  return (
    <div className={cn("flex items-start justify-between gap-4 py-2.5", disabled && "opacity-50")}>
      <div className="min-w-0">
        <p className="text-sm text-ink">{label}</p>
        {hint && <p className="mt-0.5 text-xs leading-relaxed text-muted">{hint}</p>}
      </div>
      <Switch checked={checked} onChange={onChange} disabled={disabled} />
    </div>
  );
}

export function ToggleCard({ checked, onChange, title, hint }: { checked: boolean; onChange(v: boolean): void; title: ReactNode; hint?: ReactNode }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className={cn("flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-colors", checked ? "border-signal/40 bg-signal-dim" : "border-line bg-panel hover:bg-panel-2")}>
      <span className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", checked ? "bg-signal" : "bg-line-strong")}>
        <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all", checked ? "left-[22px]" : "left-0.5")} />
      </span>
      <span className="min-w-0">
        <span className={cn("block text-sm font-medium", checked ? "text-signal" : "text-ink")}>{title}</span>
        {hint && <span className="block text-xs text-muted">{hint}</span>}
      </span>
    </button>
  );
}

export function Slider({ label, value, min, max, step = 1, onChange, format, hint }: { label: ReactNode; value: number; min: number; max: number; step?: number; onChange(v: number): void; format?: (v: number) => string; hint?: ReactNode }) {
  const pct = ((value - min) / (max - min || 1)) * 100;
  return (
    <label className="block space-y-2 py-2">
      <span className="flex items-center justify-between gap-3 text-sm">
        <span className="text-ink">{label}</span>
        <span className="font-mono text-xs tabular-nums text-ink-2">{format ? format(value) : value}</span>
      </span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full" style={{ background: `linear-gradient(to right, var(--signal) ${pct}%, var(--line) ${pct}%)` }} />
      {hint && <span className="block text-xs text-muted">{hint}</span>}
    </label>
  );
}

export function Segmented<T extends string | number>({ value, options, onChange, className }: { value: T; options: Array<{ value: T; label: ReactNode }>; onChange(v: T): void; className?: string }) {
  return (
    <div className={cn("no-scrollbar inline-flex max-w-full gap-1 overflow-x-auto rounded-xl border border-line bg-panel-2 p-1", className)}>
      {options.map((o) => (
        <button key={String(o.value)} type="button" onClick={() => onChange(o.value)} className={cn("whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition-colors", value === o.value ? "bg-invert text-on-invert" : "text-ink-2 hover:text-ink")}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Modal({ open, onClose, title, subtitle, icon: Icon, tone = "neutral", children, footer, wide, aside }: { open: boolean; onClose?: () => void; title: ReactNode; subtitle?: ReactNode; icon?: LucideIcon; tone?: "neutral" | "flare" | "amber"; children: ReactNode; footer?: ReactNode; wide?: boolean; aside?: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 backdrop-blur-[2px] sm:items-center sm:p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
        className={cn("anim-pop flex max-h-[94vh] w-full flex-col overflow-hidden rounded-t-3xl border bg-panel sm:rounded-2xl", tone === "flare" ? "border-flare" : "border-line", wide ? "sm:max-w-3xl" : "sm:max-w-lg")}
      >
        <div className={cn("flex items-center gap-3 border-b px-5 py-4", tone === "flare" ? "border-flare/20 bg-flare-dim" : "border-line")}>
          {Icon && (
            <span className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", tone === "flare" ? "bg-flare text-white" : tone === "amber" ? "bg-amber-dim text-amber" : "bg-signal-dim text-signal")}>
              <Icon className="h-5 w-5" />
            </span>
          )}
          <div className="min-w-0 flex-1">
            <h2 className={cn("font-display text-lg font-bold leading-tight", tone === "flare" ? "text-flare" : "text-ink")}>{title}</h2>
            {subtitle && <p className={cn("mt-0.5 text-xs", tone === "flare" ? "font-mono uppercase tracking-[0.3em] text-flare/80" : "text-muted")}>{subtitle}</p>}
          </div>
          {aside}
          {onClose && (
            <button type="button" onClick={onClose} className="rounded-lg p-1 text-muted hover:bg-panel-2 hover:text-ink" aria-label="Close">
              <X className="h-5 w-5" />
            </button>
          )}
        </div>
        <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-5 py-5 text-sm leading-relaxed text-ink-2">{children}</div>
        {footer && <div className="flex flex-wrap items-center gap-2 border-t border-line bg-panel-2 px-5 py-3.5 pb-[calc(0.875rem+env(safe-area-inset-bottom))] sm:pb-3.5">{footer}</div>}
      </div>
    </div>
  );
}

export function Progress({ value, className, tone = "signal" }: { value: number | null; className?: string; tone?: "signal" | "flare" | "amber" }) {
  const color = tone === "flare" ? "bg-flare" : tone === "amber" ? "bg-amber" : "bg-signal";
  return (
    <div className={cn("relative h-1.5 w-full overflow-hidden rounded-full bg-line-2", className)}>
      {value === null ? <div className={cn("anim-indeterminate absolute inset-y-0 w-2/5 rounded-full", color)} /> : <div className={cn("h-full rounded-full transition-[width] duration-200", color)} style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }} />}
    </div>
  );
}

export function Notice({ tone = "amber", children, className, icon }: { tone?: "info" | "amber" | "flare" | "warn" | "danger"; children: ReactNode; className?: string; icon?: LucideIcon }) {
  const t = tone === "warn" ? "amber" : tone === "danger" ? "flare" : tone;
  const Icon = icon ?? (t === "info" ? Info : TriangleAlert);
  return (
    <div className={cn("flex gap-3 rounded-xl border px-3.5 py-3 text-[13px] leading-relaxed text-ink", t === "info" && "border-line bg-panel-2", t === "amber" && "border-amber/30 bg-amber-dim", t === "flare" && "border-flare/30 bg-flare-dim", className)}>
      <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", t === "info" ? "text-muted" : t === "amber" ? "text-amber" : "text-flare")} />
      <div className="min-w-0">{children}</div>
    </div>
  );
}

export function Stat({ label, value, tone, className }: { label: ReactNode; value: ReactNode; tone?: "signal" | "flare"; className?: string }) {
  return (
    <div className={cn("rounded-xl border border-line bg-panel-2 px-3 py-2.5", className)}>
      <p className={cn("font-display text-xl font-bold tabular-nums", tone === "signal" ? "text-signal" : tone === "flare" ? "text-flare" : "text-ink")}>{value}</p>
      <Label className="mt-0.5">{label}</Label>
    </div>
  );
}

export function IconBox({ icon: Icon, className, color }: { icon: LucideIcon; className?: string; color?: string }) {
  return (
    <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-line bg-panel text-signal", className)} style={color ? { color } : undefined}>
      <Icon className="h-4 w-4" />
    </span>
  );
}

export function Empty({ icon: Icon, title, text, children }: { icon: LucideIcon; title: ReactNode; text?: ReactNode; children?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-line-strong px-4 py-8 text-center">
      <Icon className="h-5 w-5 text-muted" />
      <p className="text-sm font-medium text-ink">{title}</p>
      {text && <p className="max-w-md text-xs leading-relaxed text-muted">{text}</p>}
      {children}
    </div>
  );
}

export const inputCls = "h-10 w-full rounded-lg border border-line bg-panel px-3 text-sm text-ink outline-none placeholder:text-faint focus:border-signal";
