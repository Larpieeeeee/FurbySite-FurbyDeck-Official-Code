import { useRef, useState } from "react";
import { ArrowLeftRight, ArrowUpDown, Bluetooth, CloudLightning, Disc3, Flame, FlaskConical, Hand, HeartPulse, Info, Lightbulb, MessageCircle, Moon, Power, Rainbow, SlidersHorizontal, Smile, Sparkles, Waves, Frown, Unplug } from "lucide-react";
import { Button, Card, Chip, Label, Progress, Slider, Switch, goTab } from "@/components/ui";
import { CONNECT_STEPS, furby, furby2, type FurbyController } from "@/lib/furby/controller";
import { lighting, moods, setMoodValue, setStaticColor, startLight } from "@/lib/furby/lighting";
import { MOODS, TOUCH_IDS, TOUCH_LABELS, hexToRgb, rgbToHex, type Dir, type MoodType, type Orientation, type Rgb } from "@/lib/furby/protocol";
import { useCtl, useFurby, useFurby2 } from "@/lib/furby/useFurby";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { settings, useSettings } from "@/lib/settings";
import { cn } from "@/utils/cn";

const STATE_LABEL: Record<string, Text> = {
  "": ["покой", "rest"], L: ["влево", "left"], R: ["вправо", "right"], F: ["вперёд", "forward"], B: ["назад", "back"], P: ["нажата", "pressed"],
};

/** Radar-style antenna joystick (packet 0x21). Clickable in demo mode. */
export function Joystick({ className, ctl }: { className?: string; ctl?: FurbyController }) {
  const t = useT();
  const lang = useLang();
  const dev = ctl ?? furby;
  const s = useCtl(dev, (st) => st.sensors);
  const demo = useCtl(dev, (st) => st.demo);
  const x = s?.x ?? 0;
  const y = s?.y ?? 0;
  const kx = 110 + x * 56;
  const ky = 110 - y * 56;
  const dx = kx - 110;
  const dy = ky - 110;
  const lenPct = (Math.hypot(dx, dy) / 220) * 100;
  const rawAngle = (Math.atan2(dy, dx) * 180) / Math.PI;
  const angleRef = useRef(rawAngle);
  const target = x || y ? rawAngle : angleRef.current;
  let angleDelta = target - angleRef.current;
  while (angleDelta > 180) angleDelta -= 360;
  while (angleDelta < -180) angleDelta += 360;
  angleRef.current += angleDelta;
  const angle = angleRef.current;
  const ticks = Array.from({ length: 24 }, (_, i) => i);
  const zone = (d: Dir, style: string) =>
    demo ? <button type="button" aria-label={d} onPointerDown={() => dev.demoAntenna(d)} onPointerUp={() => dev.demoAntenna(null)} onPointerLeave={() => dev.demoAntenna(null)} className={cn("absolute touch-none rounded-full", style)} /> : null;
  return (
    <div className={cn("relative aspect-square select-none", className)}>
      <svg viewBox="0 0 220 220" className="h-full w-full">
        <circle cx="110" cy="110" r="100" fill="var(--panel)" stroke="var(--line)" strokeWidth="2" />
        {ticks.map((i) => {
          const a = (i / 24) * Math.PI * 2;
          const long = i % 6 === 0;
          return <line key={i} x1={110 + Math.cos(a) * (long ? 84 : 92)} y1={110 + Math.sin(a) * (long ? 84 : 92)} x2={110 + Math.cos(a) * 100} y2={110 + Math.sin(a) * 100} stroke={long ? "var(--muted)" : "var(--line-strong)"} strokeWidth={long ? 2 : 1} />;
        })}
        <circle cx="110" cy="110" r="70" fill="none" stroke="var(--line-2)" strokeWidth="1.5" />
        <circle cx="110" cy="110" r="36" fill="none" stroke="var(--line-2)" strokeWidth="1.5" />
        <line x1="40" y1="110" x2="180" y2="110" stroke="var(--line)" strokeDasharray="3 4" />
        <line x1="110" y1="40" x2="110" y2="180" stroke="var(--line)" strokeDasharray="3 4" />
        {([[110, 40, "F"], [110, 180, "B"], [40, 110, "L"], [180, 110, "R"]] as const).map(([cx, cy, d]) => (
          <circle key={d} cx={cx} cy={cy} r="5" fill={s?.dir === d ? "var(--signal)" : "var(--signal-dim)"} stroke="var(--signal)" strokeOpacity={s?.dir === d ? 1 : 0.35} />
        ))}
        <text x="110" y="28" textAnchor="middle" fontSize="10" fontFamily="var(--font-mono)" fill="var(--muted)" letterSpacing="1">{t("ВПЕРЁД", "FWD")}</text>
        <text x="110" y="198" textAnchor="middle" fontSize="10" fontFamily="var(--font-mono)" fill="var(--muted)" letterSpacing="1">{t("НАЗАД", "BACK")}</text>
        <text x="24" y="114" textAnchor="middle" fontSize="10" fontFamily="var(--font-mono)" fill="var(--muted)">{t("Л", "L")}</text>
        <text x="196" y="114" textAnchor="middle" fontSize="10" fontFamily="var(--font-mono)" fill="var(--muted)">{t("П", "R")}</text>
        <text x="110" y="211" textAnchor="middle" fontSize="9" fontFamily="var(--font-mono)" fill="var(--ink-2)" letterSpacing="1">{pick(STATE_LABEL[s?.dir ?? ""], lang).toUpperCase()}</text>
      </svg>
      <div className="pointer-events-none absolute inset-0">
        <div
          className="absolute left-1/2 top-1/2 h-px origin-left bg-signal/60 transition-[width,transform] duration-150 ease-out"
          style={{ width: `${lenPct}%`, transform: `rotate(${angle}deg) translateY(-50%)`, opacity: x || y || s?.pressed ? 1 : 0 }}
        />
        <div
          className={cn(
            "absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-ink transition-all duration-200 ease-out",
            s?.pressed ? "h-3.5 w-3.5 bg-ink" : "h-6 w-6 bg-panel",
            (x || y) && "knob-active",
          )}
          style={{ left: `${(kx / 220) * 100}%`, top: `${(ky / 220) * 100}%` }}
        />
      </div>
      {zone("F", "left-[35%] top-[4%] h-[28%] w-[30%]")}
      {zone("B", "bottom-[4%] left-[35%] h-[28%] w-[30%]")}
      {zone("L", "left-[4%] top-[35%] h-[30%] w-[28%]")}
      {zone("R", "right-[4%] top-[35%] h-[30%] w-[28%]")}
    </div>
  );
}

const POSE: Record<Orientation, { label: Text; rot: number }> = {
  upright: { label: ["сидит", "sitting"], rot: 0 },
  "upside-down": { label: ["вверх ногами", "upside down"], rot: 180 },
  "right-side": { label: ["лежит на правом боку", "lying on the right"], rot: 90 },
  "left-side": { label: ["лежит на левом боку", "lying on the left"], rot: -90 },
  "tilted-right": { label: ["наклон вправо", "tilted right"], rot: 25 },
  "tilted-left": { label: ["наклон влево", "tilted left"], rot: -25 },
  "leaning-back": { label: ["откинут назад", "leaning back"], rot: 0 },
  "leaning-forward": { label: ["наклон вперёд", "leaning forward"], rot: 0 },
  unknown: { label: ["—", "—"], rot: 0 },
};

function DeviceCard() {
  const t = useT();
  const lang = useLang();
  const st = useFurby((s) => s.status);
  const step = useFurby((s) => s.step);
  const name = useFurby((s) => s.deviceName);
  const demo = useFurby((s) => s.demo);
  const s = useFurby((x) => x.sensors);
  const busy = useFurby((x) => x.busy);
  const chatterOn = useFurby((x) => x.chatterOn);
  const dancing = useFurby((x) => x.dancing);
  const debugStep = useFurby((x) => x.debugStep);
  const rx = useFurby((x) => x.stats.rx);
  const invX = useSettings((x) => x.invertX);
  const invY = useSettings((x) => x.invertY);
  const linked = st === "ready" || st === "confirming";
  const pose = POSE[s?.orientation ?? "unknown"];

  return (
    <section className="overflow-hidden rounded-2xl border border-line bg-panel">
      <header className="flex items-center gap-2.5 border-b border-line px-4 py-3.5">
        <span className={cn("h-2 w-2 rounded-full", st === "ready" ? "bg-signal" : linked || st === "connecting" ? "anim-blink bg-amber" : "bg-line-strong")} />
        <span className="min-w-0 flex-1 truncate font-display text-sm font-bold">{demo ? t("Furby (демо)", "Furby (demo)") : name ?? t("Ферби не подключён", "Furby not connected")}</span>
        {demo ? <Chip tone="amber">{t("демо", "demo")}</Chip> : st === "ready" ? <Chip tone="signal">BLE</Chip> : null}
      </header>
      {!linked ? (
        <div className="space-y-3 p-4">
          <p className="text-sm text-muted">{t("Подключи Ферби по Bluetooth или включи демо — виртуальный Ферби отвечает как настоящий.", "Connect Furby over Bluetooth or try the demo — the virtual Furby answers like a real one.")}</p>
          {st === "connecting" && (
            <div className="space-y-1.5">
              <Progress value={step / CONNECT_STEPS} />
              <Label>{t("подключение", "connecting")} {step}/{CONNECT_STEPS}</Label>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <Button variant="primary" disabled={st === "connecting"} onClick={() => void furby.connect()}>
              <Bluetooth className="h-4 w-4" />
              {t("Подключить", "Connect")}
            </Button>
            <Button disabled={st === "connecting"} onClick={() => void furby.connectDemo()}>
              <FlaskConical className="h-4 w-4" />
              {t("Демо", "Demo")}
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="border-b border-line p-4">
            <div className="flex items-center justify-between">
              <Label>antenna joystick</Label>
              <span className="font-mono text-[10px] text-muted">0x21</span>
            </div>
            <Joystick className="mx-auto mt-2 w-full max-w-[230px]" />
            <div className="mt-3 rounded-xl border border-line p-2.5">
              <Label className="mb-2 flex items-center gap-1.5" >
                {t("калибровка осей", "axis calibration")}
              </Label>
              <div className="grid grid-cols-2 gap-2">
                <Button size="sm" variant={invY ? "soft" : "secondary"} onClick={() => settings.set({ invertY: !invY })} title={t("Если тянешь вперёд, а пульт показывает «назад»", "If you push forward but the remote shows “back”")}>
                  <ArrowUpDown className="h-3.5 w-3.5" />
                  {t("верх / низ", "up / down")}
                </Button>
                <Button size="sm" variant={invX ? "soft" : "secondary"} onClick={() => settings.set({ invertX: !invX })}>
                  <ArrowLeftRight className="h-3.5 w-3.5" />
                  {t("лево / право", "left / right")}
                </Button>
              </div>
            </div>
          </div>
          <div className="space-y-2.5 p-4">
            <div className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 p-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-full border border-line bg-panel">
                <svg viewBox="0 0 24 24" className="h-6 w-6 transition-transform" style={{ transform: `rotate(${pose.rot}deg)` }}>
                  <path d="M12 3 L10 6 M12 3 L14 6 M12 3 V6" stroke="var(--signal)" strokeWidth="1.6" strokeLinecap="round" />
                  <ellipse cx="12" cy="14" rx="6" ry="7" fill="var(--ink)" />
                  <circle cx="10" cy="12" r="1.2" fill="var(--panel)" />
                  <circle cx="14" cy="12" r="1.2" fill="var(--panel)" />
                </svg>
              </span>
              <div>
                <Label>{t("положение", "position")}</Label>
                <p className="text-sm font-semibold">{pick(pose.label, lang)}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {TOUCH_IDS.map((id) => {
                const on = s?.touches.includes(id);
                return (
                  <button
                    key={id}
                    type="button"
                    disabled={!demo}
                    onPointerDown={() => furby.demoTouch(id, true)}
                    onPointerUp={() => furby.demoTouch(id, false)}
                    onPointerLeave={() => furby.demoTouch(id, false)}
                    className={cn("flex touch-none items-center gap-2 rounded-lg border px-2.5 py-2 text-left text-xs transition-colors", on ? "border-signal/40 bg-signal-dim text-signal" : "border-line bg-panel-2 text-ink-2", demo && "cursor-pointer hover:border-signal/40")}
                  >
                    <span className={cn("h-1.5 w-1.5 rounded-full", on ? "bg-signal" : "bg-line-strong")} />
                    {id === "head" ? t("Затылок", "Head") : pick(TOUCH_LABELS[id], lang)}
                  </button>
                );
              })}
            </div>
            {demo && <p className="text-center text-[11px] text-muted">{t("Демо: датчики можно нажимать — сработают правила автоматики", "Demo: sensors are clickable — automation rules will fire")}</p>}
          </div>
          <div className="space-y-2.5 border-t border-line pt-3">
            <DeviceColorRow ctl={furby} label={t("Цвет этой игрушки — запоминается", "This toy's colour — remembered")} />
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-muted">{t("Болтовня этого Фёрби", "This Furby's chatter")}</span>
              <Switch checked={chatterOn} onChange={(v) => furby.setChatterOn(v)} />
            </div>
          </div>
          <div className="grid grid-cols-3 divide-x divide-line border-t border-line text-center">
            {[
              [t("состояние", "state"), dancing ? t("танцует", "dancing") : busy ? t("говорит", "talking") : t("ждёт", "idle"), busy || dancing],
              [t("дебаг", "debug"), debugStep ? `${t("экран", "screen")} ${debugStep}` : t("выкл", "off"), false],
              [t("пакетов", "packets"), String(rx), false],
            ].map(([label, value, hi]) => (
              <div key={String(label)} className="px-2 py-3">
                <Label>{label}</Label>
                <p className={cn("mt-1 text-sm font-semibold", hi ? "text-signal" : "text-ink")}>{value}</p>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}

const SWATCHES: Rgb[] = [[15, 155, 142], [232, 56, 106], [124, 77, 255], [207, 138, 18], [79, 169, 245], [91, 140, 90], [255, 255, 255], [255, 69, 0]];
const QUICK_FX: Array<{ id: string; icon: typeof Rainbow; name: Text }> = [
  { id: "rainbow", icon: Rainbow, name: ["Радуга", "Rainbow"] },
  { id: "fade-neon", icon: Sparkles, name: ["Плазма", "Plasma"] },
  { id: "candle-fire", icon: Flame, name: ["Камин", "Fireplace"] },
  { id: "wave-ocean", icon: Waves, name: ["Океан", "Ocean"] },
  { id: "pulse-fire", icon: HeartPulse, name: ["Сердцебиение", "Heartbeat"] },
  { id: "storm", icon: CloudLightning, name: ["Гроза", "Storm"] },
  { id: "sensors", icon: Hand, name: ["Реакция", "Reaction"] },
  { id: "music", icon: Disc3, name: ["Музыка", "Music"] },
];

function AntennaCard() {
  const t = useT();
  const lang = useLang();
  const color = useFurby((s) => s.color);
  const mode = lighting.use((l) => l.mode);
  const brightness = useSettings((s) => s.ledBrightness);
  const [hex, setHex] = useState("#0f9b8e");
  const timer = useRef<number | undefined>(undefined);
  const pickColor = (c: Rgb) => {
    setHex(rgbToHex(c));
    setStaticColor(c);
  };
  return (
    <Card title={t("Антенна", "Antenna")} hint={t("RGB-светодиод · команда 0x14", "RGB LED · command 0x14")} icon={Lightbulb} action={<span className="font-mono text-xs text-muted">{rgbToHex(color).toUpperCase()}</span>}>
      <div className="grid grid-cols-8 gap-1.5">
        {SWATCHES.map((c) => (
          <button key={c.join()} type="button" onClick={() => pickColor(c)} aria-label={rgbToHex(c)} className={cn("aspect-square w-full rounded-lg border transition-transform hover:scale-105", hex === rgbToHex(c) ? "border-ink ring-2 ring-ink/15" : "border-line")} style={{ backgroundColor: rgbToHex(c) }} />
        ))}
      </div>
      <div className="mt-3 flex items-center gap-3">
        <label className="relative h-10 w-12 shrink-0 cursor-pointer overflow-hidden rounded-lg border border-line" style={{ backgroundColor: hex }}>
          <input type="color" value={hex} onChange={(e) => { setHex(e.target.value); window.clearTimeout(timer.current); timer.current = window.setTimeout(() => setStaticColor(hexToRgb(e.target.value)), 120); }} className="absolute inset-0 cursor-pointer opacity-0" />
        </label>
        <div className="flex-1">
          <Slider label={t("яркость", "brightness")} value={brightness} min={10} max={100} onChange={(v) => settings.set({ ledBrightness: v })} format={(v) => `${v}%`} />
        </div>
        <Button size="icon" variant="ghost" onClick={() => pickColor([0, 0, 0])} aria-label={t("Выключить", "Turn off")}>
          <Power className="h-4 w-4" />
        </Button>
      </div>
      <div className="mt-3 rounded-xl border border-line p-2.5">
        <div className="mb-2 flex items-center justify-between">
          <Label>{t("свет антенны", "antenna light")}</Label>
          <button type="button" onClick={() => goTab("light")} className="text-muted hover:text-signal" title={t("Полная лаборатория — вкладка «Свет»", "Full lab — the Lights tab")}>
            <Info className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="grid grid-cols-4 gap-1.5">
          {QUICK_FX.map((fx) => (
            <button key={fx.id} type="button" onClick={() => startLight(fx.id)} className={cn("flex flex-col items-center gap-1 rounded-lg border px-1 py-2 text-[11px] transition-colors", mode === fx.id ? "border-signal/40 bg-signal-dim text-signal" : "border-line text-ink-2 hover:bg-panel-2")}>
              <fx.icon className="h-4 w-4" />
              <span className="w-full break-words text-center text-[10px] leading-tight">{pick(fx.name, lang)}</span>
            </button>
          ))}
        </div>
      </div>
    </Card>
  );
}

function VoiceCard() {
  const t = useT();
  const chatter = useSettings((s) => s.chatter);
  const every = useSettings((s) => s.chatterEvery);
  const quiet = useSettings((s) => s.quietUntil) > Date.now();
  const phrase = useFurby((s) => s.lastPhrase);
  const phrases = useFurby((s) => s.phrases);
  const next = useFurby((s) => s.nextChatterIn);
  const ready = useFurby((s) => s.status === "ready");
  return (
    <Card title={t("Голос Ферби", "Furby's voice")} hint={t("Чтобы игрушка не молчала", "So the toy doesn't stay silent")} icon={MessageCircle} action={<Chip tone={quiet ? "amber" : chatter ? "signal" : "neutral"}>{quiet ? t("тихий час", "quiet hour") : chatter ? t("болтает", "chatty") : t("молчит", "silent")}</Chip>}>
      <div className="flex gap-2">
        <Button variant={chatter ? "soft" : "secondary"} className="flex-1" onClick={() => settings.set({ chatter: !chatter })}>
          <MessageCircle className="h-4 w-4" />
          {chatter ? t("Болтовня включена", "Chatter is on") : t("Болтовня выключена", "Chatter is off")}
        </Button>
        <Button size="icon" variant={quiet ? "soft" : "secondary"} className="h-10 w-10" title={t("Тихий час на 5 минут", "Quiet hour for 5 minutes")} onClick={() => settings.set({ quietUntil: quiet ? 0 : Date.now() + 5 * 60000 })}>
          <Moon className="h-4 w-4" />
        </Button>
      </div>
      <Button variant="signal" className="mt-2 w-full" disabled={!ready} onClick={() => furby.sayRandom()}>
        <MessageCircle className="h-4 w-4" />
        {t("Скажи что-нибудь", "Say something")}
      </Button>
      <Slider label={t("реплика при простое каждые", "idle phrase every")} value={every} min={10} max={120} step={5} onChange={(v) => settings.set({ chatterEvery: v })} format={(v) => `${v} ${t("с", "s")}`} />
      <div className="rounded-xl border border-line bg-panel-2 p-3">
        <p className="text-sm font-medium text-ink">{phrase ? `«${phrase}»` : t("Пока ничего не сказал", "Hasn't said anything yet")}</p>
        <div className="mt-1 flex justify-between font-mono text-[11px] text-muted">
          <span>{t("реплик за сессию", "phrases this session")}: {phrases}</span>
          {chatter && ready && !quiet && <span>{t("следующая", "next")} ~{next} {t("с", "s")}</span>}
        </div>
      </div>
    </Card>
  );
}

const MOOD_HINTS: Text[] = [["Больше движения и болтовни", "More movement and chatter"], ["Ворчание и капризы", "Grumbling and whims"], ["Зевота, просьбы уложить спать", "Yawning, asks to sleep"], ["0 — голодный, 100 — объелся", "0 hungry, 100 stuffed"], ["Низкое — Ферби заболеет", "Low — Furby gets sick"]];
const PRESETS: Record<string, number[]> = { happy: [80, 0, 10, 80, 100], grumpy: [30, 90, 60, 30, 60] };

function MoodCard() {
  const t = useT();
  const lang = useLang();
  const values = moods.use((m) => m.values);
  const timers = useRef<Partial<Record<MoodType, number>>>({});
  const change = (type: MoodType, v: number) => {
    setMoodValue(type, v, false);
    window.clearTimeout(timers.current[type]);
    timers.current[type] = window.setTimeout(() => furby.setMood(type, v), 220);
  };
  const preset = (vals: number[]) => vals.forEach((v, i) => setMoodValue(i as MoodType, v));
  return (
    <Card title={t("Настроение", "Mood")} hint={t("Moodmeter 0x23 — влияет на поведение", "Moodmeter 0x23 — affects behaviour")} icon={SlidersHorizontal}>
      {MOODS.map((m) => (
        <Slider key={m.type} label={<span title={pick(MOOD_HINTS[m.type], lang)}>{pick(m.label, lang)}</span>} value={values[m.type]} min={0} max={100} onChange={(v) => change(m.type, v)} />
      ))}
      <div className="mt-2 flex gap-2">
        <Button size="sm" onClick={() => preset(PRESETS.happy)}>
          <Smile className="h-3.5 w-3.5" />
          {t("Счастливый", "Happy")}
        </Button>
        <Button size="sm" onClick={() => preset(PRESETS.grumpy)}>
          <Frown className="h-3.5 w-3.5" />
          {t("Ворчун", "Grumpy")}
        </Button>
      </div>
    </Card>
  );
}

function DeviceColorRow({ ctl, label }: { ctl: FurbyController; label: string }) {
  const [hex, setHex] = useState("#0f9b8e");
  const timer = useRef<number | undefined>(undefined);
  const change = (v: string) => {
    setHex(v);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => ctl.setColor(hexToRgb(v)), 120);
  };
  return (
    <div className="flex items-center gap-2">
      <span className="h-7 w-7 shrink-0 rounded-full border border-line" style={{ backgroundColor: hex }} />
      <input type="color" value={hex} onChange={(e) => change(e.target.value)} aria-label={label} className="h-7 w-11 cursor-pointer rounded border border-line bg-panel p-0.5" />
      <span className="min-w-0 truncate text-xs text-muted">{label}</span>
    </div>
  );
}

function SecondDeviceCard() {
  const t = useT();
  const lang = useLang();
  const status = useFurby2((s) => s.status);
  const name = useFurby2((s) => s.deviceName);
  const step = useFurby2((s) => s.step);
  const chatterOn = useFurby2((s) => s.chatterOn);
  const secondDemo = useFurby2((s) => s.demo);
  const primaryLinked = useFurby((s) => s.status === "ready" || s.status === "confirming");
  if (!primaryLinked && status === "idle") return null;
  if (status === "idle") {
    return (
      <Card
        title={t("Второй Фёрби", "Second Furby")}
        icon={Bluetooth}
        hint={t("Свет, музыка, сцены и игры задействуют обе игрушки", "Lights, music, scenes and games use both toys")}
      >
        <p className="text-sm text-muted">
          {t("Второй Фёрби подключается отдельно: своё рукопожатие, свой цвет и своя болтовня.", "The second Furby connects separately: its own handshake, colour and chatter.")}
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button variant="primary" onClick={() => void furby2.connect()}>
            <Bluetooth className="h-4 w-4" />
            {t("Подключить", "Connect")}
          </Button>
          <Button onClick={() => void furby2.connectDemo()}>
            <FlaskConical className="h-4 w-4" />
            {t("Демо", "Demo")}
          </Button>
        </div>
      </Card>
    );
  }
  const linked = status === "ready";
  return (
    <Card
      title={name ?? t("Фёрби 2", "Furby 2")}
      icon={Bluetooth}
      action={
        <Chip tone={linked ? "signal" : "amber"}>
          {linked ? t("на связи", "online") : status === "confirming" ? t("рукопожатие", "handshake") : t("подключение…", "connecting…")}
        </Chip>
      }
    >
      {status === "connecting" && <Progress value={step / CONNECT_STEPS} className="mb-3" />}
      {linked && (
        <div className="space-y-3">
          <DeviceColorRow ctl={furby2} label={t("Цвет этой игрушки — запоминается", "This toy's colour — remembered")} />
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-muted">{t("Болтовня этого Фёрби", "This Furby's chatter")}</span>
            <Switch checked={chatterOn} onChange={(v) => furby2.setChatterOn(v)} />
          </div>
          <Button size="sm" variant="ghost" className="w-full" onClick={() => furby2.disconnect()}>
            <Unplug className="h-4 w-4" />
            {t("Отключить", "Disconnect")}
          </Button>
        </div>
      )}
      {status === "confirming" && <p className="text-sm text-muted">{t("Повтори комбинацию в окне подтверждения", "Repeat the combination in the confirmation window")}</p>}
      {linked && (
        <div className="mt-3 border-t border-line pt-3">
          <Label className="mb-1">{t("Антенна и датчики", "Antenna and sensors")}</Label>
          <Joystick ctl={furby2} className="mx-auto w-full max-w-[190px]" />
          {secondDemo && (
            <div className="mt-2 flex flex-wrap justify-center gap-1.5">
              {TOUCH_IDS.map((id) => (
                <button
                  key={id}
                  type="button"
                  onPointerDown={() => furby2.demoTouch(id, true)}
                  onPointerUp={() => furby2.demoTouch(id, false)}
                  onPointerLeave={() => furby2.demoTouch(id, false)}
                  className="touch-none rounded-lg border border-line bg-panel-2 px-2 py-1.5 text-[11px] text-ink-2 hover:border-signal/50"
                >
                  {id === "head" ? t("Затылок", "Head") : pick(TOUCH_LABELS[id], lang)}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </Card>
  );
}

export function Sidebar() {
  return (
    <div className="space-y-4">
      <DeviceCard />
      <SecondDeviceCard />
      <AntennaCard />
      <VoiceCard />
      <MoodCard />
    </div>
  );
}
