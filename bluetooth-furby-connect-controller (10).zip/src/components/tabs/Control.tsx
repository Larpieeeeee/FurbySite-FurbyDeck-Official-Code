import { useRef, useState } from "react";
import type { LucideIcon } from "lucide-react";
import { Cpu, Hand, Heart, Laugh, ListMusic, MessageCircle, Moon, Music, PartyPopper, Play, Sparkles, Square, Sun, Utensils, Wind, Workflow, Zap, Activity } from "lucide-react";
import { Button, Card, Chip, Empty, IconBox, Label, Slider, ToggleCard, goTab, inputCls } from "@/components/ui";
import { actionName, furby } from "@/lib/furby/controller";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { macroDuration, macroName, macros, runMacro, runner, stopMacro } from "@/lib/macros";
import { settings, useSettings } from "@/lib/settings";
import { cn } from "@/utils/cn";
import { parseFav } from "./Library";

type Code = [number, number, number, number];
const QUICK: Array<{ icon: LucideIcon; name: Text; code?: Code; input?: number }> = [
  { icon: Hand, name: ["Поздороваться", "Say hello"], code: [40, 0, 0, 0] },
  { icon: Laugh, name: ["Рассмешить", "Make laugh"], code: [55, 2, 14, 0] },
  { icon: Heart, name: ["Погладить", "Pet"], code: [1, 3, 0, 6] },
  { icon: Utensils, name: ["Покормить", "Feed"], code: [56, 3, 0, 0] },
  { icon: Music, name: ["Спеть", "Sing"], input: 17 },
  { icon: PartyPopper, name: ["Танцевать", "Dance"], code: [9, 3, 0, 3] },
  { icon: Wind, name: ["Пукнуть", "Fart"], code: [7, 0, 0, 0] },
  { icon: MessageCircle, name: ["Сказать что-нибудь", "Say something"], input: 8 },
  { icon: Sparkles, name: ["Звёзды в глазах", "Stars in eyes"], code: [40, 0, 1, 4] },
  { icon: Heart, name: ["Сердечки", "Hearts"], code: [44, 5, 0, 0] },
  { icon: Moon, name: ["Зевнуть", "Yawn"], code: [12, 2, 0, 2] },
  { icon: Wind, name: ["Отрыжка", "Burp"], code: [7, 3, 0, 0] },
];

const FIRST = ["Ah", "Bee", "Dah", "Day", "Dee", "Doo", "Kee", "Loo", "May", "Noo", "Tay", "Toh", "Way"];
const SECOND = ["Bay", "Boh", "Boo", "Dah", "Doh", "Doo", "Kah", "Koh", "Tah", "Toh"];
export const NAMES = FIRST.flatMap((f) => SECOND.map((s) => `${f}-${s}`)).filter((n) => n !== "Tay-Tah");

function QuickActions() {
  const t = useT();
  const lang = useLang();
  const ready = useFurby((s) => s.status === "ready");
  return (
    <Card title={t("Быстрые действия", "Quick actions")} hint={t("Один тап — один экшен по 0x13", "One tap — one 0x13 action")} icon={Zap} action={<Chip tone={ready ? "signal" : "neutral"}>{ready ? t("готов", "ready") : t("нет связи", "offline")}</Chip>}>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-4">
        {QUICK.map((q) => (
          <button
            key={q.name[1]}
            type="button"
            disabled={!ready}
            onClick={() => (q.code ? furby.action(...q.code) : furby.randomInput(q.input ?? 8))}
            className="rounded-xl border border-line bg-panel-2 p-3 text-left transition-colors hover:border-signal/50 disabled:opacity-50"
          >
            <IconBox icon={q.icon} />
            <p className="mt-3 text-sm font-medium text-ink">{pick(q.name, lang)}</p>
            <p className="mt-1 font-mono text-[11px] text-muted">{q.code ? q.code.join("/") : `input ${q.input}`}</p>
          </button>
        ))}
      </div>
    </Card>
  );
}

function StateCard() {
  const t = useT();
  const ready = useFurby((s) => s.status === "ready");
  const eyes = useFurby((s) => s.eyes);
  const telemetry = useFurby((s) => s.telemetry);
  const firmware = useFurby((s) => s.firmware);
  return (
    <Card title={t("Состояние", "State")} icon={Sun}>
      <div className="grid grid-cols-2 gap-2">
        <Button variant="primary" disabled={!ready} onClick={() => furby.wake()}>
          <Sun className="h-4 w-4" />
          {t("Разбудить", "Wake up")}
        </Button>
        <Button disabled={!ready} onClick={() => furby.sleep()}>
          <Moon className="h-4 w-4" />
          {t("Уложить спать", "Put to sleep")}
        </Button>
      </div>
      <div className="mt-2.5 space-y-2">
        <ToggleCard checked={eyes} onChange={(v) => furby.setEyes(v)} title={t("Подсветка LCD-глаз", "LCD eye backlight")} hint={t("Команда 0xCD — гасит экран, экономит батарею", "Command 0xCD — turns the screen off to save battery")} />
        <ToggleCard checked={telemetry} onChange={(v) => furby.setSensorStream(v)} title={t("Поток телеметрии", "Telemetry stream")} hint={t("0x20:0x0D — акселерометр и датчики 5 раз в секунду", "0x20:0x0D — accelerometer and sensors 5 times a second")} />
      </div>
      <div className="mt-2.5 flex flex-wrap gap-2">
        <Button size="sm" disabled={!ready} onClick={() => furby.randomInput(16)}>
          <Activity className="h-3.5 w-3.5" />
          {t("Икота", "Hiccups")}
        </Button>
        <Button size="sm" disabled={!ready} onClick={() => furby.readFirmware()}>
          <Cpu className="h-3.5 w-3.5" />
          {t("Версия прошивки", "Firmware version")}
          {firmware && <span className="font-mono text-muted">{firmware}</span>}
        </Button>
      </div>
    </Card>
  );
}

function NameCard() {
  const t = useT();
  const ready = useFurby((s) => s.status === "ready");
  const confirmDanger = useSettings((s) => s.confirmDanger);
  const [id, setId] = useState(46);
  const rename = () => {
    if (confirmDanger && !window.confirm(t(`Сменить имя Ферби на ${NAMES[id]}? Он запомнит новое имя.`, `Rename Furby to ${NAMES[id]}? It will remember the new name.`))) return;
    furby.setName(id);
  };
  return (
    <Card title={t("Имя Ферби", "Furby's name")} hint={t("129 имён из прошивки", "129 names from the firmware")} icon={MessageCircle}>
      <p className="text-xs leading-relaxed text-muted">{t("0x21 сохраняет имя, затем экшен 33/0/0 заставляет Ферби произнести его.", "0x21 saves the name, then action 33/0/0 makes Furby say it.")}</p>
      <select value={id} onChange={(e) => setId(Number(e.target.value))} className={cn(inputCls, "mt-3 font-mono")}>
        {NAMES.map((n, i) => (
          <option key={n} value={i}>
            {String(i).padStart(3, "0")} · {n}
          </option>
        ))}
      </select>
      <div className="mt-2.5 flex flex-wrap gap-2">
        <Button variant="signal" disabled={!ready} onClick={rename}>
          {t("Назвать", "Name it")} {NAMES[id]}
        </Button>
        <Button disabled={!ready} onClick={() => furby.sayName(id)}>
          {t("Произнести", "Say it")}
        </Button>
      </div>
      <p className="mt-2 text-xs text-muted">{t("Имя сохраняется в памяти игрушки и переживает переподключение.", "The name is stored in the toy and survives reconnecting.")}</p>
    </Card>
  );
}

function ScenariosCard() {
  const t = useT();
  const list = macros.use((m) => m.list);
  const running = runner.use((r) => r.running);
  const ready = useFurby((s) => s.status === "ready");
  return (
    <Card title={t("Сценарии", "Scenarios")} hint={t("Готовые макросы в один тап", "Ready-made macros in one tap")} icon={Workflow} action={<Button size="sm" variant="ghost" onClick={() => goTab("studio")}>{t("Открыть студию", "Open studio")}</Button>}>
      <div className="flex flex-wrap gap-2">
        {list.map((m) => (
          <Button key={m.id} variant={running === m.id ? "soft" : "secondary"} disabled={!ready} onClick={() => void runMacro(m)}>
            <Play className="h-3.5 w-3.5" />
            {macroName(m)}
            <span className="font-mono text-[11px] text-muted">{m.steps.length}</span>
          </Button>
        ))}
      </div>
      <Button size="sm" variant="ghost" className="mt-2" disabled={!running} onClick={stopMacro}>
        <Square className="h-3.5 w-3.5" />
        {t("Стоп", "Stop")}
      </Button>
      {running && <Label className="mt-2">{t("выполняется", "running")} · {macroDuration(list.find((m) => m.id === running) ?? list[0]).toFixed(1)} {t("с", "s")}</Label>}
    </Card>
  );
}

function PlaylistCard() {
  const t = useT();
  const favs = useSettings((s) => s.favorites);
  const pause = useSettings((s) => s.playlistPause);
  const ready = useFurby((s) => s.status === "ready");
  const [playing, setPlaying] = useState(-1);
  const token = useRef(0);
  const play = async () => {
    const my = ++token.current;
    for (let i = 0; i < favs.length; i++) {
      if (my !== token.current) return;
      setPlaying(i);
      const { code } = parseFav(favs[i]);
      furby.action(...code);
      await new Promise((r) => setTimeout(r, pause * 1000 + 1200));
    }
    if (my === token.current) setPlaying(-1);
  };
  const stop = () => {
    token.current++;
    setPlaying(-1);
  };
  return (
    <Card
      title={t("Плейлист", "Playlist")}
      hint={t("Избранные команды проигрываются по очереди", "Favourite commands play one after another")}
      icon={ListMusic}
      action={
        <div className="flex items-center gap-2">
          <div className="hidden w-36 sm:block">
            <Slider label={t("пауза", "pause")} value={pause} min={0.5} max={6} step={0.1} onChange={(v) => settings.set({ playlistPause: v })} format={(v) => `${v.toFixed(1)} ${t("с", "s")}`} />
          </div>
          {playing >= 0 ? (
            <Button size="sm" onClick={stop}>
              <Square className="h-3.5 w-3.5" />
              {t("Стоп", "Stop")}
            </Button>
          ) : (
            <Button size="sm" variant="signal" disabled={!favs.length || !ready} onClick={() => void play()}>
              <Play className="h-3.5 w-3.5" />
              {t("Проиграть", "Play")}
            </Button>
          )}
        </div>
      }
    >
      {favs.length === 0 ? (
        <Empty icon={ListMusic} title={t("Плейлист пуст", "The playlist is empty")} text={t("Отметь звёздочкой любые команды во вкладке «Команды» — они появятся здесь и переживут перезагрузку страницы.", "Star any commands in the Commands tab — they'll show up here and survive a page reload.")}>
          <Button size="sm" onClick={() => goTab("commands")}>{t("К командам", "To commands")}</Button>
        </Empty>
      ) : (
        <ol className="divide-y divide-line">
          {favs.map((f, i) => {
            const { code, text } = parseFav(f);
            return (
              <li key={f} className={cn("flex items-center gap-3 py-2", playing === i && "text-signal")}>
                <span className="w-6 font-mono text-xs text-muted">{String(i + 1).padStart(2, "0")}</span>
                <span className="min-w-0 flex-1 truncate text-sm">{text || actionName(...code)}</span>
                <span className="font-mono text-[11px] text-muted">{code.join("/")}</span>
              </li>
            );
          })}
        </ol>
      )}
    </Card>
  );
}

export function ControlTab() {
  return (
    <div className="space-y-4">
      <QuickActions />
      <div className="grid gap-4 xl:grid-cols-2">
        <StateCard />
        <NameCard />
      </div>
      <ScenariosCard />
      <PlaylistCard />
    </div>
  );
}
