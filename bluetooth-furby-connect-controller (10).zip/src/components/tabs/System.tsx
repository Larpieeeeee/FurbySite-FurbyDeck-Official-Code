import { useEffect, useMemo, useRef, useState, type FormEvent, type ChangeEvent } from "react";
import { Activity, ChartLine, Download, Eye, ListChecks, Radio, ScrollText, Terminal, Timer, Trash2, Upload } from "lucide-react";
import { Button, Card, Chip, Empty, Label, Notice, Stat, Toggle, inputCls } from "@/components/ui";
import { automation } from "@/lib/automation";
import { furby, furby2, type LogKind } from "@/lib/furby/controller";
import { sequencer } from "@/lib/furby/lighting";
import { DEBUG_SCREENS, ORIENTATION_LABELS, TOUCH_IDS, TOUCH_LABELS, parseHex } from "@/lib/furby/protocol";
import { useFurby, useFurby2 } from "@/lib/furby/useFurby";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { funkLevels } from "@/lib/funkLevels";
import { macros } from "@/lib/macros";
import { progress } from "@/lib/progress";
import { settings, useSettings } from "@/lib/settings";
import { toast } from "@/lib/toast";
import { cn } from "@/utils/cn";

const SCREEN_HINTS: Text[] = [
  ["Mood: сытость, усталость, самочувствие", "Mood: fullness, tiredness, wellness"],
  ["Часы реального времени и состояние BLE", "Real-time clock and BLE state"],
  ["Оси X / Y / Z в реальном времени", "X / Y / Z axes in real time"],
  ["Уровень звука и детектор голоса", "Sound level and voice detector"],
  ["Обмен с другими Ферби", "Exchange with other Furbies"],
  ["Состояние слотов загрузки", "Download slot states"],
  ["Таймеры уведомлений и событий", "Notification and event timers"],
];
const RAW_QUICK: Array<[string, string, string]> = [
  ["ImHere?", "ImHere?", "20 06"],
  ["Версия GP", "GP version", "fe"],
  ["Карта слотов", "Slot map", "72"],
  ["Глаза вкл", "Eyes on", "cd 01"],
  ["Дебаг-экран", "Debug screen", "db"],
  ["Антенна белая", "White antenna", "14 ff ff ff"],
  ["Сытость 100", "Fullness 100", "23 01 03 64"],
  ["Случайный экшен", "Random action", "10 00 08"],
];

export function DebugTab() {
  const t = useT();
  const lang = useLang();
  const step = useFurby((s) => s.debugStep);
  const eyes = useFurby((s) => s.eyes);
  const s = useFurby((x) => x.sensors);
  const telemetry = useFurby((x) => x.telemetry);
  const imHere = useFurby((x) => x.imHere);
  const ready = useFurby((x) => x.status === "ready");
  const [raw, setRaw] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const total = DEBUG_SCREENS.length;
  const send = (text: string) => {
    const bytes = parseHex(text);
    if (!bytes) return setErr(t("Нужно от 1 до 20 байт в hex, например: 13 00 37 02 0e 00", "Enter 1–20 hex bytes, e.g. 13 00 37 02 0e 00"));
    setErr(null);
    furby.sendRaw(bytes);
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    send(raw);
  };
  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <Card title={t("Дебаг-меню на глазах", "Eye debug menu")} hint={`${t("Секретные экраны прямо на LCD игрушки — команда 0xDB", "Secret screens right on the toy's LCD — command 0xDB")} · ${t("работает с основным Фёрби", "controls the primary toy")}`} icon={Eye} action={<Chip tone={step ? "signal" : "neutral"}>{step ? `${t("экран", "screen")} ${step}/${total}` : t("выключено", "off")}</Chip>}>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant={step === 0 ? "primary" : "secondary"}
              disabled={!ready}
              onClick={() => (step === 0 ? furby.debugOpen() : furby.debugClose(total))}
            >
              {step === 0 ? t("Включить", "Turn on") : t("Выключить", "Turn off")}
            </Button>
            <Button variant="signal" disabled={!ready || step === 0} onClick={() => furby.debugNext(total)}>
              {t("Следующий экран", "Next screen")}
            </Button>
          </div>
          <ol className="mt-4 space-y-1.5">
            {DEBUG_SCREENS.map((name, i) => (
              <li key={i} className={cn("flex items-start gap-3 rounded-lg border px-3 py-2", step === i + 1 ? "border-signal/40 bg-signal-dim" : "border-line")}>
                <span className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-md font-mono text-xs", step === i + 1 ? "bg-signal text-white" : "bg-panel-2 text-muted")}>{i + 1}</span>
                <span>
                  <span className="block text-sm font-medium">{pick(name, lang)}</span>
                  <span className="block text-xs text-muted">{pick(SCREEN_HINTS[i], lang)}</span>
                </span>
              </li>
            ))}
          </ol>
          <p className="mt-3 text-xs leading-relaxed text-muted">{t("Каждый пакет DB переключает экран по кругу: 7 дебаг-меню → обычные глаза. Если счётчик разъехался — жми «Следующий экран», пока не совпадёт.", "Each DB packet cycles the screens: 7 debug menus → normal eyes. If the counter drifts, press “Next screen” until it matches.")}</p>
        </Card>
        <div className="space-y-4">
          <Card title={t("Предпросмотр LCD", "LCD preview")} icon={Eye}>
            <div className="rounded-xl border border-line bg-lcd p-4 font-mono text-xs text-[#7ff2d8]">
              <p className="text-sm">{step ? pick(DEBUG_SCREENS[step - 1], lang) : t("Обычные глаза", "Normal eyes")}</p>
              <p className="mt-1 opacity-60">{step ? pick(SCREEN_HINTS[step - 1], lang) : t("анимация глаз по эмоциям", "emotion eye animation")}</p>
              <div className="mt-4 grid grid-cols-3 gap-2 text-[10px] uppercase tracking-widest">
                <span>screen<br /><b className="text-sm">{step}/{total}</b></span>
                <span>lcd<br /><b className="text-sm">{eyes ? "on" : "off"}</b></span>
                <span>ant<br /><b className="text-sm">{s?.dir ?? "none"}</b></span>
              </div>
            </div>
          </Card>
          <Card title={t("Живые датчики", "Live sensors")} hint={t("Пакет 0x21 · антенна, положение, щекотка", "Packet 0x21 · antenna, position, tickles")} icon={Activity} action={<Chip tone={s ? "signal" : "neutral"}>{s ? t("поток идёт", "streaming") : t("нет данных", "no data")}</Chip>}>
            <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
              <dt className="text-muted">{t("Антенна", "Antenna")}</dt>
              <dd>{s?.dir ?? t("покой", "rest")}</dd>
              <dt className="text-muted">{t("Положение", "Position")}</dt>
              <dd>{s ? pick(ORIENTATION_LABELS[s.orientation], lang) : "—"}</dd>
              <dt className="text-muted">{t("Пакет", "Packet")}</dt>
              <dd className="break-all font-mono text-xs">{s?.raw ?? "—"}</dd>
            </dl>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {TOUCH_IDS.map((id) => <Chip key={id} tone={s?.touches.includes(id) ? "signal" : "neutral"}>{pick(TOUCH_LABELS[id], lang)}</Chip>)}
            </div>
            <Toggle checked={telemetry} onChange={(v) => furby.setSensorStream(v)} label={t("Непрерывный поток акселерометра", "Continuous accelerometer stream")} hint={t("0x20:0x0D — включить, 0x20:0x0E — выключить", "0x20:0x0D on, 0x20:0x0E off")} />
          </Card>
        </div>
      </div>
      <Card title={t("Сырые команды", "Raw commands")} hint={t("Любой пакет в GeneralPlusWrite, до 20 байт", "Any packet to GeneralPlusWrite, up to 20 bytes")} icon={Terminal}>
        <Notice>{t("Первый байт — опкод. Безопасный режим блокирует команды записи и удаления DLC (0x50, 0x74 и др.).", "The first byte is the opcode. Safe mode blocks DLC write and delete commands (0x50, 0x74, etc).")}</Notice>
        <form onSubmit={submit} className="mt-3 flex gap-2">
          <input value={raw} onChange={(e) => setRaw(e.target.value)} placeholder="13 00 37 02 0e 00" className={cn(inputCls, "font-mono")} />
          <Button type="submit" variant="primary" disabled={!ready}>{t("Отправить", "Send")}</Button>
        </form>
        {err && <p className="mt-2 text-xs text-flare">{err}</p>}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {RAW_QUICK.map(([ru, en, hex]) => (
            <Button key={hex} size="sm" disabled={!ready} onClick={() => send(hex)}>
              {lang === "en" ? en : ru} <span className="font-mono text-[10px] text-muted">{hex}</span>
            </Button>
          ))}
        </div>
        <div className="mt-4 rounded-xl border border-line bg-panel-2 p-3">
          <Label>{t("последний ImHere (0x22)", "last ImHere (0x22)")}</Label>
          <p className="mt-1 break-all font-mono text-xs text-ink">{imHere ?? "—"}</p>
          <p className="mt-1 text-xs text-muted">{t("18 байт состояния; сообщество расшифровало их не полностью.", "18 bytes of state; the community hasn't fully decoded them.")}</p>
        </div>
      </Card>
    </div>
  );
}

function Chart({ tx, rx }: { tx: number[]; rx: number[] }) {
  const max = Math.max(4, ...tx, ...rx);
  const pts = (arr: number[]) => arr.map((v, i) => `${(i / (arr.length - 1)) * 440 + 5},${110 - (v / max) * 100}`).join(" ");
  return (
    <svg viewBox="0 0 450 120" className="h-40 w-full">
      {[0, 0.25, 0.5, 0.75, 1].map((k) => (
        <g key={k}>
          <line x1="5" x2="445" y1={110 - k * 100} y2={110 - k * 100} stroke="var(--line-2)" />
          <text x="447" y={113 - k * 100} fontSize="7" fill="var(--muted)" fontFamily="var(--font-mono)">{Math.round(max * k)}</text>
        </g>
      ))}
      <polyline points={pts(rx)} fill="none" stroke="var(--flare)" strokeWidth="1.8" strokeLinejoin="round" />
      <polyline points={pts(tx)} fill="none" stroke="var(--signal)" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  );
}

export function MonitorTab() {
  const t = useT();
  const lang = useLang();
  const stats1 = useFurby((s) => s.stats);
  const stats2 = useFurby2((s) => s.stats);
  const stats = useMemo(
    () => ({
      ...stats1,
      tx: stats1.tx + stats2.tx,
      rx: stats1.rx + stats2.rx,
      actions: stats1.actions + stats2.actions,
      rulesFired: stats1.rulesFired + stats2.rulesFired,
      txHist: stats1.txHist.map((v, i) => v + (stats2.txHist[i] ?? 0)),
      rxHist: stats1.rxHist.map((v, i) => v + (stats2.rxHist[i] ?? 0)),
      pings: [...stats1.pings, ...stats2.pings].sort((a, b) => a - b).slice(0, 10),
      cmds: Object.entries(stats2.cmds).reduce<Record<string, number>>((acc, [k, v]) => ({ ...acc, [k]: (acc[k] ?? 0) + v }), { ...stats1.cmds }),
    }),
    [stats1, stats2],
  );
  const secondReady = useFurby2((s) => s.status === "ready");
  const status = useFurby((s) => s.status);
  const demo = useFurby((s) => s.demo);
  const name = useFurby((s) => s.deviceName);
  const firmware = useFurby((s) => s.firmware);
  const connectedAt = useFurby((s) => s.connectedAt);
  const macroCount = macros.use((m) => m.list.length);
  const ruleCount = automation.use((a) => a.rules.length);
  const favs = useSettings((s) => s.favorites);
  const [pings, setPings] = useState<Array<number | null>>([]);
  const [busy, setBusy] = useState(false);
  const [, tick] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => tick((x) => x + 1), 1000);
    return () => window.clearInterval(id);
  }, []);
  const session = connectedAt ? Math.floor((Date.now() - connectedAt) / 1000) : 0;
  const hms = `${String(Math.floor(session / 3600)).padStart(2, "0")}:${String(Math.floor((session % 3600) / 60)).padStart(2, "0")}:${String(session % 60).padStart(2, "0")}`;
  const avg = stats.pings.length ? Math.round(stats.pings.reduce((a, b) => a + b, 0) / stats.pings.length) : null;
  const top = Object.entries(stats.cmds).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const runPings = async () => {
    setBusy(true);
    setPings([]);
    for (let i = 0; i < 4; i++) {
      const ms = await furby.ping();
      setPings((p) => [...p, ms]);
      await new Promise((r) => setTimeout(r, 300));
    }
    progress.bump("pings");
    setBusy(false);
  };
  const exportJson = () => {
    const data = { app: "furby-deck", version: 4, macros: macros.get().list, rules: automation.get().rules, favorites: settings.get().favorites, sequencer: sequencer.get().frames, funkLevels: funkLevels.get().list };
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    a.download = "furby-deck-backup.json";
    a.click();
  };
  const importJson = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (Array.isArray(data.macros)) macros.set({ list: data.macros, selected: data.macros[0]?.id ?? "" });
      if (Array.isArray(data.rules)) automation.set({ rules: data.rules });
      if (Array.isArray(data.favorites)) settings.set({ favorites: data.favorites });
      if (Array.isArray(data.sequencer)) sequencer.set({ frames: data.sequencer });
      if (Array.isArray(data.funkLevels)) funkLevels.set({ list: data.funkLevels });
      toast(t("Копия загружена", "Backup restored"));
    } catch {
      toast(t("Не удалось прочитать файл", "Couldn't read the file"), undefined, undefined, "err");
    }
  };
  return (
    <div className="space-y-4">
      <Card title={t("Активность канала", "Channel activity")} hint={t("Пакеты в секунду — видно keep-alive, телеметрию и команды", "Packets per second — keep-alive, telemetry and commands")} icon={ChartLine}>
        <div className="mb-2 flex flex-wrap items-center gap-4 font-mono text-xs">
          <span className="text-signal">● TX {stats.txHist[stats.txHist.length - 1]}/{t("с", "s")}</span>
          <span className="text-flare">● RX {stats.rxHist[stats.rxHist.length - 1]}/{t("с", "s")}</span>
          <span className="ml-auto text-muted">{t("последние 45 секунд", "last 45 seconds")}</span>
        </div>
        <Chart tx={stats.txHist} rx={stats.rxHist} />
      </Card>
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title={t("Сессия", "Session")} icon={Timer}>
          <div className="grid grid-cols-3 gap-2">
            <Stat label={t("на связи", "online")} value={hms} />
            <Stat label={t("экшенов", "actions")} value={stats.actions} />
            <Stat label={t("пакетов", "packets")} value={stats.rx} />
          </div>
          <dl className="mt-3 divide-y divide-line text-sm">
            {[
              [t("режим", "mode"), status === "idle" ? "—" : demo ? t("симулятор", "simulator") : "Bluetooth LE"],
              [t("устройство", "device"), ((demo ? t("Furby (демо)", "Furby (demo)") : name) ?? "—") + (secondReady ? ` + ${t("Фёрби 2", "Furby 2")}` : "")],
              [t("прошивка", "firmware"), firmware ? `GP ${firmware}` : "—"],
              [t("отправлено / получено", "sent / received"), `${stats.tx} / ${stats.rx}`],
              [t("правил сработало", "rules fired"), String(stats.rulesFired)],
              [t("средняя задержка", "average latency"), avg !== null ? `${avg} ${t("мс", "ms")}` : t("не измерялась", "not measured")],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3 py-1.5">
                <dt className="font-mono text-[11px] uppercase tracking-wider text-muted">{k}</dt>
                <dd className="text-right font-mono text-xs">{v}</dd>
              </div>
            ))}
          </dl>
        </Card>
        <Card title={t("Проверка связи", "Link check")} hint="ImHere ping: 20 06 → 0x22" icon={Radio} action={<Button size="sm" disabled={busy || status !== "ready"} onClick={() => void runPings()}>{t("Прогнать 4 пинга", "Run 4 pings")}</Button>}>
          {pings.length === 0 ? (
            <Empty icon={Radio} title={t("Замеров ещё не было", "No measurements yet")} text={t("Пинг показывает, за сколько Ферби отвечает на keep-alive.", "The ping shows how fast Furby answers a keep-alive.")} />
          ) : (
            <div className="grid grid-cols-4 gap-2">
              {pings.map((p, i) => <Stat key={i} label={`#${i + 1}`} value={p === null ? "—" : `${p}`} tone={p !== null && p > 500 ? "flare" : "signal"} />)}
            </div>
          )}
          <p className="mt-3 text-xs text-muted">{t("Норма для BLE — 30–200 мс. Больше 500 мс обычно значит слабый сигнал или занятый канал.", "Normal for BLE is 30–200 ms. Over 500 ms usually means a weak signal or a busy channel.")}</p>
        </Card>
        <Card title={t("Частые команды", "Frequent commands")} icon={ListChecks}>
          {top.length === 0 ? (
            <p className="text-sm text-muted">{t("Пока ничего не отправлялось.", "Nothing has been sent yet.")}</p>
          ) : (
            <ul className="space-y-2.5">
              {top.map(([k, v]) => (
                <li key={k}>
                  <div className="flex justify-between text-xs">
                    <span className="truncate">{k}</span>
                    <span className="font-mono text-muted">×{v}</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-line-2">
                    <div className="h-full rounded-full bg-signal" style={{ width: `${(v / top[0][1]) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title={t("Резервная копия", "Backup")} hint={t("Макросы, правила, плейлист и секвенсор", "Macros, rules, playlist and sequencer")} icon={Download}>
          <div className="grid grid-cols-3 gap-2">
            <Stat label={t("макросов", "macros")} value={macroCount} />
            <Stat label={t("правил", "rules")} value={ruleCount} />
            <Stat label={t("в плейлисте", "in playlist")} value={favs.length} />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" onClick={exportJson}><Download className="h-3.5 w-3.5" />{t("Выгрузить JSON", "Export JSON")}</Button>
            <label className="inline-flex h-8 cursor-pointer items-center gap-2 rounded-lg border border-line bg-panel px-3 text-xs font-medium hover:bg-panel-2">
              <Upload className="h-3.5 w-3.5" />
              {t("Загрузить JSON", "Import JSON")}
              <input type="file" accept="application/json" className="hidden" onChange={(e) => void importJson(e)} />
            </label>
          </div>
          <p className="mt-3 text-xs text-muted">{t("Всё хранится только в этом браузере (localStorage). Файл копии удобно переносить между компьютером и телефоном.", "Everything is stored only in this browser (localStorage). The backup file makes it easy to move between computer and phone.")}</p>
        </Card>
      </div>
      <p className="text-center font-mono text-[10px] uppercase tracking-widest text-faint">{lang === "en" ? "monitor refreshes every second" : "монитор обновляется каждую секунду"}</p>
    </div>
  );
}

const KIND_STYLE: Record<LogKind, string> = { tx: "text-signal", rx: "text-ink-2", sys: "text-muted", err: "text-flare" };
const KIND_MARK: Record<LogKind, string> = { tx: "→", rx: "←", sys: "i", err: "!" };

export function JournalTab() {
  const lang = useLang();
  const t = useT();
  const logs1 = useFurby((s) => s.logs);
  const logs2 = useFurby2((s) => s.logs);
  const logs = useMemo(
    () =>
      [...logs1.map((e) => ({ ...e, key: `1-${e.id}` })), ...logs2.map((e) => ({ ...e, key: `2-${e.id}` }))].sort((a, b) =>
        a.time < b.time ? -1 : a.time > b.time ? 1 : 0,
      ),
    [logs1, logs2],
  );
  const stats1 = useFurby((s) => s.stats);
  const stats2 = useFurby2((s) => s.stats);
  const tx = stats1.tx + stats2.tx;
  const rx = stats1.rx + stats2.rx;
  const verbose = useSettings((s) => s.verboseLog);
  const autoscroll = useSettings((s) => s.autoscroll);
  const [filter, setFilter] = useState<"all" | "tx" | "rx" | "sys">("all");
  const box = useRef<HTMLDivElement>(null);
  const shown = logs.filter((l) => filter === "all" || l.kind === filter || (filter === "sys" && l.kind === "err"));
  useEffect(() => {
    if (autoscroll && box.current) box.current.scrollTop = box.current.scrollHeight;
  }, [shown.length, autoscroll]);
  const count = (k: "tx" | "rx" | "sys") => logs.filter((l) => l.kind === k || (k === "sys" && l.kind === "err")).length;
  return (
    <Card title={t("Журнал обмена", "Exchange log")} hint={`${tx} ${t("пакетов отправлено", "packets sent")} · ${rx} ${t("получено", "received")}`} icon={ScrollText} action={<Button size="sm" variant="ghost" onClick={() => { furby.clearLogs(); furby2.clearLogs(); }}><Trash2 className="h-3.5 w-3.5" />{t("Очистить", "Clear")}</Button>}>
      <div className="flex flex-wrap items-center gap-1.5">
        {([["all", t("Всё", "All"), logs.length], ["tx", t("Отправлено", "Sent"), count("tx")], ["rx", t("Получено", "Received"), count("rx")], ["sys", t("Система", "System"), count("sys")]] as const).map(([k, label, n]) => (
          <button key={k} type="button" onClick={() => setFilter(k)} className={cn("flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium", filter === k ? "border-invert bg-invert text-on-invert" : "border-line text-ink-2 hover:bg-panel-2")}>
            {label} <span className="font-mono opacity-60">{n}</span>
          </button>
        ))}
      </div>
      <div className="mt-2 grid gap-x-6 sm:grid-cols-2">
        <Toggle checked={verbose} onChange={(v) => settings.set({ verboseLog: v })} label={t("подробный лог", "verbose log")} hint={t("показывать keep-alive и пакеты датчиков", "show keep-alive and sensor packets")} />
        <Toggle checked={autoscroll} onChange={(v) => settings.set({ autoscroll: v })} label={t("автопрокрутка", "autoscroll")} />
      </div>
      <div ref={box} className="scroll-thin mt-3 h-[28rem] overflow-y-auto rounded-xl border border-line bg-panel-2 p-3 font-mono text-xs leading-relaxed">
        {shown.length === 0 && <p className="text-muted">{t("Пока пусто", "Empty for now")}</p>}
        {shown.map((e) => (
          <div key={e.key ?? e.id} className={cn("flex gap-2", KIND_STYLE[e.kind])}>
            <span className="shrink-0 text-faint">{e.time}</span>
            <span className="w-3 shrink-0 text-center">{KIND_MARK[e.kind]}</span>
            <span className="min-w-0 break-all">{pick([e.text, e.en ?? e.text], lang)}</span>
          </div>
        ))}
      </div>
      <p className="mt-2 text-xs text-muted">{t("Keep-alive 20 06 уходит раз в 3 секунды, чтобы Ферби не начинал болтать сам по себе. В обычном режиме эти пакеты скрыты — включи «подробный лог».", "Keep-alive 20 06 goes every 3 seconds so Furby doesn't start chattering on its own. These packets are hidden unless the verbose log is on.")}</p>
    </Card>
  );
}
