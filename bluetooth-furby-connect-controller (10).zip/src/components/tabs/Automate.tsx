import { useEffect, useMemo, useState } from "react";
import type { LucideIcon } from "lucide-react";
import { Activity, AlarmClock, ArrowDown, ArrowUp, Bug, Copy, EyeOff, Lightbulb, MessageCircle, Moon, Music, Palette, Piano, Play, Plus, Repeat, RotateCcw, Smile, Square, Sun, Timer, Trash2, Workflow, Zap, PowerOff } from "lucide-react";
import { Button, Card, Chip, Empty, Label, Stat, Switch, inputCls } from "@/components/ui";
import { LIBRARY } from "@/lib/actions/library";
import { RULE_EVENTS, TIMER_PRESETS, automation, rules, runTimer, type TimerKind } from "@/lib/automation";
import { furby, rowLabel } from "@/lib/furby/controller";
import { LIGHT_SPECIALS, LIGHT_PATTERNS } from "@/lib/furby/lighting";
import { MOODS, type MoodType } from "@/lib/furby/protocol";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT } from "@/lib/i18n";
import { MELODIES, NOTE_KEYS, NOTE_NAMES, macroDuration, macroName, macroOps, macros, mk, playMelody, playNote, runMacro, runner, stepLabel, stopMacro, type StepKind } from "@/lib/macros";
import { settings, useSettings } from "@/lib/settings";
import { cn } from "@/utils/cn";

const STEP_ICONS: Record<StepKind, LucideIcon> = { action: MessageCircle, random: MessageCircle, color: Palette, effect: Lightbulb, mood: Smile, wake: Sun, sleep: Moon, lcdOff: EyeOff, debug: Bug, lightOff: PowerOff, note: Music };

function StudioEditor() {
  const t = useT();
  const lang = useLang();
  const list = macros.use((m) => m.list);
  const selected = macros.use((m) => m.selected);
  const running = runner.use((r) => r.running);
  const step = runner.use((r) => r.step);
  const m = list.find((x) => x.id === selected) ?? list[0];
  const [find, setFind] = useState("");
  const [hex, setHex] = useState("#cf8a12");
  const found = useMemo(() => {
    const q = find.trim().toLowerCase();
    return q ? LIBRARY.filter((r) => `${r[4]} ${r[5]} ${r.slice(0, 4).join("/")}`.toLowerCase().includes(q)).slice(0, 6) : [];
  }, [find]);
  if (!m) return <Empty icon={Workflow} title={t("Макросов нет", "No macros")}><Button size="sm" onClick={() => macroOps.create()}>{t("Создать", "Create")}</Button></Empty>;
  const isRunning = running === m.id;
  return (
    <div className="grid gap-4 md:grid-cols-[220px_minmax(0,1fr)]">
      <div className="space-y-1.5">
        {list.map((x) => (
          <button key={x.id} type="button" onClick={() => macroOps.select(x.id)} className={cn("w-full rounded-xl border px-3 py-2.5 text-left transition-colors", x.id === m.id ? "border-invert bg-invert text-on-invert" : "border-line bg-panel-2 hover:bg-panel")}>
            <span className="block truncate text-sm font-medium">{macroName(x)}</span>
            <span className="block font-mono text-[11px] opacity-60">{x.steps.length} {t("шагов", "steps")} · {macroDuration(x).toFixed(1)}{t("с", "s")}</span>
          </button>
        ))}
        <Button size="sm" variant="ghost" className="w-full" onClick={macroOps.restorePresets}>
          <RotateCcw className="h-3.5 w-3.5" />
          {t("Вернуть пресеты", "Restore presets")}
        </Button>
      </div>
      <div className="min-w-0 space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <input value={macroName(m)} onChange={(e) => macroOps.update(m.id, { name: e.target.value, nameEn: undefined })} className={cn(inputCls, "min-w-0 flex-1 font-display text-base font-bold")} />
          <Button size="sm" variant={m.loop ? "soft" : "secondary"} onClick={() => macroOps.update(m.id, { loop: !m.loop })}>
            <Repeat className="h-3.5 w-3.5" />
            {t("Цикл", "Loop")}
          </Button>
          {isRunning ? (
            <Button size="sm" variant="primary" onClick={stopMacro}><Square className="h-3.5 w-3.5" />{t("Стоп", "Stop")}</Button>
          ) : (
            <Button size="sm" variant="signal" disabled={!m.steps.length} onClick={() => void runMacro(m)}><Play className="h-3.5 w-3.5" />{t("Запустить", "Run")}</Button>
          )}
          <Button size="icon" variant="ghost" onClick={() => macroOps.duplicate(m.id)} aria-label={t("Копия", "Duplicate")}><Copy className="h-4 w-4" /></Button>
          <Button size="icon" variant="ghost" onClick={() => window.confirm(t("Удалить макрос?", "Delete the macro?")) && macroOps.remove(m.id)} aria-label={t("Удалить", "Delete")}><Trash2 className="h-4 w-4" /></Button>
        </div>
        <div className="space-y-1.5">
          {m.steps.map((s, i) => {
            const Icon = STEP_ICONS[s.kind];
            return (
              <div key={s.id} className={cn("flex items-center gap-2 rounded-lg border px-2.5 py-1.5", isRunning && step === i ? "border-signal bg-signal-dim" : "border-line bg-panel-2")}>
                <span className="w-6 font-mono text-[11px] text-muted">{String(i + 1).padStart(2, "0")}</span>
                <Icon className="h-3.5 w-3.5 shrink-0 text-signal" />
                <span className="min-w-0 flex-1 truncate text-sm">{stepLabel(s)}</span>
                <input type="number" min={50} max={20000} step={50} value={s.wait} onChange={(e) => macroOps.updateStep(m.id, s.id, { wait: Math.max(50, Number(e.target.value) || 50) })} className="h-8 w-20 rounded-lg border border-line bg-panel px-2 text-right font-mono text-xs" />
                <span className="text-[11px] text-muted">{t("мс", "ms")}</span>
                <button type="button" onClick={() => macroOps.moveStep(m.id, s.id, -1)} className="p-1 text-faint hover:text-ink"><ArrowUp className="h-3.5 w-3.5" /></button>
                <button type="button" onClick={() => macroOps.moveStep(m.id, s.id, 1)} className="p-1 text-faint hover:text-ink"><ArrowDown className="h-3.5 w-3.5" /></button>
                <button type="button" onClick={() => macroOps.removeStep(m.id, s.id)} className="p-1 text-faint hover:text-flare"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            );
          })}
          {!m.steps.length && <p className="rounded-lg border border-dashed border-line-strong px-3 py-4 text-center text-sm text-muted">{t("Добавь первый шаг ниже", "Add the first step below")}</p>}
        </div>
        <div className="space-y-2.5 rounded-xl border border-line p-3">
          <Label>{t("добавить шаг", "add a step")}</Label>
          <input value={find} onChange={(e) => setFind(e.target.value)} placeholder={t("Найти экшен: «смех», «нота», 55/2/14…", "Find an action: “laugh”, “note”, 55/2/14…")} className={inputCls} />
          {found.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {found.map((r) => (
                <Button key={r.slice(0, 4).join("/")} size="sm" onClick={() => { macroOps.addStep(m.id, mk.action([r[0], r[1], r[2], r[3]])); setFind(""); }}>
                  <Plus className="h-3 w-3" />
                  {rowLabel(r)}
                </Button>
              ))}
            </div>
          )}
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-lg border border-line px-2 py-1">
              <input type="color" value={hex} onChange={(e) => setHex(e.target.value)} className="h-6 w-7 cursor-pointer rounded border-0 bg-transparent" />
              <Button size="sm" variant="ghost" onClick={() => macroOps.addStep(m.id, mk.color(hex))}>{t("цвет", "colour")}</Button>
            </span>
            <select value="" onChange={(e) => e.target.value && macroOps.addStep(m.id, mk.effect(e.target.value, 3000))} className="h-9 rounded-lg border border-line bg-panel px-2 text-sm">
              <option value="">{t("+ световой эффект…", "+ light effect…")}</option>
              {[...LIGHT_SPECIALS.map((x) => [x.id, pick(x.name, lang)]), ...LIGHT_PATTERNS.map((p) => [`${p.id}-rainbow`, `${pick(p.name, lang)} · ${t("радуга", "rainbow")}`])].map(([id, name]) => (
                <option key={id} value={id}>{name}</option>
              ))}
            </select>
            <select value="" onChange={(e) => { if (e.target.value === "") return; const [ty, v] = e.target.value.split(":").map(Number); macroOps.addStep(m.id, mk.mood(ty as MoodType, v)); }} className="h-9 rounded-lg border border-line bg-panel px-2 text-sm">
              <option value="">{t("+ настроение…", "+ mood…")}</option>
              {MOODS.flatMap((x) => [80, 20].map((v) => <option key={`${x.type}:${v}`} value={`${x.type}:${v}`}>{pick(x.label, lang)} → {v}</option>))}
            </select>
            <select value="" onChange={(e) => e.target.value !== "" && macroOps.addStep(m.id, mk.note(Number(e.target.value)))} className="h-9 rounded-lg border border-line bg-panel px-2 text-sm">
              <option value="">{t("+ нота…", "+ note…")}</option>
              {NOTE_NAMES.map((n, i) => <option key={i} value={i}>{pick(n, lang)}</option>)}
            </select>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {([["wake", Sun, t("Подъём", "Wake")], ["sleep", Moon, t("Отбой", "Sleep")], ["lcdOff", EyeOff, "LCD off"], ["debug", Bug, t("Дебаг", "Debug")], ["lightOff", PowerOff, t("Свет выкл", "Light off")]] as Array<[StepKind, LucideIcon, string]>).map(([k, I, label]) => (
              <Button key={k} size="sm" onClick={() => macroOps.addStep(m.id, mk.simple(k))}><I className="h-3.5 w-3.5" />{label}</Button>
            ))}
            <Button size="sm" onClick={() => macroOps.addStep(m.id, mk.random(8))}><MessageCircle className="h-3.5 w-3.5" />{t("Случайная реплика", "Random phrase")}</Button>
          </div>
          <p className="font-mono text-[10px] uppercase leading-relaxed tracking-wider text-muted">{t("Шаг выполняется, затем выдерживается пауза. Для реплик ставь 1800–2600 мс, для нот 400–900 мс, для света — сколько он должен играть.", "A step runs, then the pause is held. Use 1800–2600 ms for phrases, 400–900 ms for notes, and as long as needed for light.")}</p>
        </div>
      </div>
    </div>
  );
}

function PianoCard() {
  const t = useT();
  const lang = useLang();
  const octave = useSettings((s) => s.octaveInput);
  const running = runner.use((r) => r.running);
  const [lit, setLit] = useState(-1);
  const hit = (i: number) => {
    playNote(i);
    setLit(i);
    window.setTimeout(() => setLit((x) => (x === i ? -1 : x)), 220);
  };
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      if (e.repeat || (el && /INPUT|TEXTAREA|SELECT/.test(el.tagName))) return;
      const i = NOTE_KEYS.indexOf(e.key.toUpperCase());
      if (i >= 0) hit(i);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, []);
  return (
    <Card
      title={t("Пианино", "Piano")}
      hint={`${t("Октава Ферби", "Furby's octave")} · input ${octave} · ${t("клавиши", "keys")} A S D F G H J K`}
      icon={Piano}
      action={
        <select value={octave} onChange={(e) => settings.set({ octaveInput: Number(e.target.value) })} className="h-8 rounded-lg border border-line bg-panel px-2 font-mono text-xs">
          <option value={70}>input 70</option>
          <option value={71}>input 71</option>
        </select>
      }
    >
      <div className="grid grid-cols-8 gap-1.5">
        {NOTE_NAMES.map((n, i) => (
          <button key={i} type="button" onPointerDown={() => hit(i)} className={cn("flex h-28 touch-none flex-col items-center justify-end gap-1 rounded-b-xl rounded-t-md border pb-2 transition-colors sm:h-32", lit === i ? "border-signal bg-signal-dim" : "border-line bg-panel hover:bg-panel-2")}>
            <span className="text-xs font-semibold sm:text-sm">{pick(n, lang)}</span>
            <span className="font-mono text-[10px] text-muted">{NOTE_KEYS[i]}</span>
          </button>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <Label className="mr-1">{t("мелодии", "melodies")}</Label>
        {MELODIES.map((mel) => (
          <Button key={mel.name[1]} size="sm" onClick={() => void playMelody(mel.notes)}>
            <Play className="h-3 w-3" />
            {pick(mel.name, lang)}
          </Button>
        ))}
        {running === "melody" && <Button size="sm" variant="ghost" onClick={stopMacro}><Square className="h-3 w-3" />{t("Стоп", "Stop")}</Button>}
      </div>
    </Card>
  );
}

export function StudioTab() {
  const t = useT();
  return (
    <div className="space-y-4">
      <Card title={t("Студия макросов", "Macro studio")} hint={t("Сценарии из экшенов, света, настроения и пауз", "Scenarios of actions, light, mood and pauses")} icon={Workflow} action={<Button size="sm" onClick={() => macroOps.create()}><Plus className="h-3.5 w-3.5" />{t("Новый", "New")}</Button>}>
        <StudioEditor />
      </Card>
      <PianoCard />
    </div>
  );
}

function MotionCard() {
  const t = useT();
  const motion = useFurby((s) => s.motion);
  const demo = useFurby((s) => s.demo);
  const threshold = useSettings((s) => s.motionThreshold);
  const label = motion.label === "shake" ? t("тряска", "shaking") : motion.label === "move" ? t("движение", "moving") : t("покой", "calm");
  return (
    <Card title={t("Датчик движения", "Motion sensor")} hint={label} icon={Activity} action={<span className="font-display text-3xl font-bold tabular-nums">{motion.intensity}</span>}>
      <div className="relative h-2 rounded-full bg-line-2">
        <div className={cn("h-full rounded-full transition-[width]", motion.label === "shake" ? "bg-flare" : "bg-signal")} style={{ width: `${motion.intensity}%` }} />
        <span className="absolute -top-1 h-4 w-0.5 bg-ink" style={{ left: `${threshold}%` }} title={t("порог", "threshold")} />
      </div>
      <div className="mt-3 flex h-12 items-end gap-[2px]">
        {Array.from({ length: 60 }, (_, i) => motion.history[motion.history.length - 60 + i] ?? 0).map((v, i) => (
          <span key={i} className={cn("flex-1 rounded-sm", v >= threshold ? "bg-flare/70" : "bg-signal/50")} style={{ height: `${Math.max(4, v)}%` }} />
        ))}
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <Stat label={t("трясок", "shakes")} value={motion.shakes} />
        <Stat label={t("пик", "peak")} value={motion.peak} />
        <Stat label={t("покой", "still")} value={`${motion.stillFor}${t("с", "s")}`} />
      </div>
      <p className="mt-3 text-xs text-muted">{t("Интенсивность считается по смене положения, рывкам антенны и разбросу акселерометра за последние 1,4 секунды. Пока Ферби сам двигается, датчик не слушает.", "Intensity comes from position changes, antenna jerks and accelerometer spread over 1.4 seconds. It ignores Furby's own movements.")}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {demo && <Button size="sm" onClick={() => furby.demoShake(false)}>{t("Тряхнуть (демо)", "Shake (demo)")}</Button>}
        {demo && <Button size="sm" onClick={() => furby.demoShake(true)}>{t("Сильно тряхнуть", "Hard shake")}</Button>}
        <Button size="sm" variant="ghost" onClick={() => furby.resetMotion()}>{t("Сбросить счётчик", "Reset counter")}</Button>
      </div>
    </Card>
  );
}

function RulesCard() {
  const t = useT();
  const lang = useLang();
  const list = automation.use((a) => a.rules);
  const groups = [...new Set(RULE_EVENTS.map((e) => e.group[1]))];
  return (
    <Card
      title={t("Реакции на датчики", "Sensor reactions")}
      hint={t("Правило: событие игрушки → команда пульта", "Rule: toy event → remote command")}
      icon={Zap}
      action={
        <div className="flex items-center gap-2">
          <Chip tone={list.some((r) => r.on) ? "signal" : "neutral"}>{list.filter((r) => r.on).length} {t("активных", "active")}</Chip>
          <Button size="sm" onClick={rules.add}><Plus className="h-3.5 w-3.5" />{t("Правило", "Rule")}</Button>
        </div>
      }
    >
      <div className="space-y-2">
        {list.map((r) => (
          <div key={r.id} className={cn("flex flex-wrap items-center gap-2 rounded-xl border p-2.5", r.on ? "border-signal/40 bg-signal-dim" : "border-line bg-panel-2")}>
            <Switch checked={r.on} onChange={(v) => rules.update(r.id, { on: v })} />
            <Zap className="h-3.5 w-3.5 text-amber" />
            <select value={r.event} onChange={(e) => rules.update(r.id, { event: e.target.value })} className="h-9 min-w-0 flex-1 rounded-lg border border-line bg-panel px-2 text-sm sm:max-w-[220px]">
              {groups.map((g) => (
                <optgroup key={g} label={pick(RULE_EVENTS.find((e) => e.group[1] === g)!.group, lang)}>
                  {RULE_EVENTS.filter((e) => e.group[1] === g).map((e) => <option key={e.key} value={e.key}>{pick(e.name, lang)}</option>)}
                </optgroup>
              ))}
            </select>
            <span className="text-muted">→</span>
            <select value={r.code} onChange={(e) => rules.update(r.id, { code: e.target.value })} className="h-9 min-w-0 flex-[2] rounded-lg border border-line bg-panel px-2 text-sm">
              {LIBRARY.map((x) => <option key={x.slice(0, 4).join("/")} value={x.slice(0, 4).join("/")}>{x.slice(0, 4).join("/")} · {rowLabel(x)}</option>)}
              {!LIBRARY.some((x) => x.slice(0, 4).join("/") === r.code) && <option value={r.code}>{r.code}</option>}
            </select>
            <span className="flex items-center gap-1">
              <Timer className="h-3.5 w-3.5 text-muted" />
              <input type="number" min={1} max={600} value={r.cooldown} onChange={(e) => rules.update(r.id, { cooldown: Math.max(1, Number(e.target.value) || 1) })} className="h-9 w-14 rounded-lg border border-line bg-panel px-2 text-center font-mono text-xs" />
              <span className="text-[11px] text-muted">{t("с", "s")}</span>
            </span>
            <span className="font-mono text-[11px] text-muted">×{r.fired}</span>
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => rules.test(r)} aria-label={t("Проверить", "Test")}><Play className="h-3.5 w-3.5" /></Button>
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => rules.remove(r.id)} aria-label={t("Удалить", "Delete")}><Trash2 className="h-3.5 w-3.5" /></Button>
          </div>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <Button size="sm" variant="ghost" onClick={() => window.confirm(t("Вернуть стандартные правила?", "Restore the default rules?")) && rules.reset()}>{t("Вернуть стандартные", "Restore defaults")}</Button>
        <span className="text-xs text-muted">{t("Срабатывает по фронту события и не чаще кулдауна. В играх и сценариях правила молчат.", "Fires on the event edge, no more often than the cooldown. Silent during games and scenarios.")}</span>
      </div>
    </Card>
  );
}

function ScheduleCard() {
  const t = useT();
  const lang = useLang();
  const timers = automation.use((a) => a.timers);
  const [choice, setChoice] = useState("random:8");
  const [minutes, setMinutes] = useState(10);
  const [, tick] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => tick((x) => x + 1), 1000);
    return () => window.clearInterval(id);
  }, []);
  const OPTIONS: Array<[string, string]> = [
    ["random:8", t("Случайная реплика", "Random phrase")],
    ["action:56/3/0/0", t("Покормить", "Feed")],
    ["action:40/0/0/0", t("Поздороваться", "Say hello")],
    ["random:17", t("Спеть", "Sing")],
    ["wake", t("Разбудить", "Wake up")],
    ["sleep", t("Уложить спать", "Put to sleep")],
  ];
  const add = (value: string, mins: number) => {
    const [kind, arg] = value.split(":");
    rules.addTimer((kind === "random" ? "random" : kind) as TimerKind, mins, kind === "action" ? arg : undefined, kind === "random" ? Number(arg) : undefined);
  };
  const label = (k: TimerKind, code?: string, input?: number) => OPTIONS.find(([v]) => v === (k === "action" ? `action:${code}` : k === "random" ? `random:${input}` : k))?.[1] ?? code ?? k;
  return (
    <Card title={t("Расписание", "Schedule")} hint={t("Отложенные команды и напоминания", "Delayed commands and reminders")} icon={AlarmClock} action={<Chip>{timers.length} {t("в очереди", "queued")}</Chip>}>
      <div className="flex flex-wrap items-end gap-2 rounded-xl border border-line p-3">
        <label className="min-w-0 flex-1 space-y-1">
          <Label>{t("действие", "action")}</Label>
          <select value={choice} onChange={(e) => setChoice(e.target.value)} className={inputCls}>
            {OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </label>
        <label className="w-24 space-y-1">
          <Label>{t("через, мин", "in, min")}</Label>
          <input type="number" min={1} max={600} value={minutes} onChange={(e) => setMinutes(Math.max(1, Number(e.target.value) || 1))} className={cn(inputCls, "font-mono")} />
        </label>
        <Button variant="signal" onClick={() => add(choice, minutes)}><Plus className="h-4 w-4" />{t("Поставить таймер", "Set timer")}</Button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {TIMER_PRESETS.map((p) => (
          <Button key={p.name[1]} size="sm" onClick={() => rules.addTimer(p.kind, p.minutes, p.code, p.input)}>
            <AlarmClock className="h-3.5 w-3.5" />
            {pick(p.name, lang)} · {p.minutes}{t("м", "m")}
          </Button>
        ))}
      </div>
      <div className="mt-3">
        {timers.length === 0 ? (
          <Empty icon={AlarmClock} title={t("Таймеров нет", "No timers")} text={t("Например, покормить через 15 минут или уложить спать через полчаса.", "For example, feed in 15 minutes or put to sleep in half an hour.")} />
        ) : (
          <ul className="divide-y divide-line">
            {timers.map((tm) => {
              const left = Math.max(0, Math.round((tm.at - Date.now()) / 1000));
              return (
                <li key={tm.id} className="flex items-center gap-3 py-2">
                  <AlarmClock className="h-4 w-4 text-signal" />
                  <span className="flex-1 text-sm">{label(tm.kind, tm.code, tm.input)}</span>
                  <span className="font-mono text-xs text-muted">{Math.floor(left / 60)}:{String(left % 60).padStart(2, "0")}</span>
                  <Button size="sm" variant="ghost" onClick={() => runTimer(tm)}><Play className="h-3.5 w-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => rules.removeTimer(tm.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </Card>
  );
}

export function AutomationTab() {
  return (
    <div className="space-y-4">
      <MotionCard />
      <RulesCard />
      <ScheduleCard />
    </div>
  );
}
