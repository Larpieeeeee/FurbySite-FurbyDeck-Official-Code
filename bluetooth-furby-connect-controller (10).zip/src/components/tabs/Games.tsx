import { useEffect, useMemo, useState } from "react";
import { Bot, Camera, ChevronLeft, Dices, Gamepad2, Music, PartyPopper, Play, Plus, Search, Sparkles, Trash2, Trophy, Wand2 } from "lucide-react";
import { GameHost } from "@/components/GameHost";
import { FunkEditor } from "@/components/tabs/FunkEditor";
import { Button, Card, Chip, Empty, Label, Modal, Notice, Segmented, Slider, goTab, inputCls } from "@/components/ui";
import { bar, text } from "@/games/kit";
import { FUNK_CHARS, customFunkDef } from "@/games/funk";
import { CATEGORIES, CTL_LABELS, FEATURED, GAMES } from "@/games/registry";
import type { Cat, Ctl, GameDef } from "@/games/types";
import { LIBRARY } from "@/lib/actions/library";
import { furby, rowLabel, type InputType } from "@/lib/furby/controller";
import { startLight, stopLight } from "@/lib/furby/lighting";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { useFurby } from "@/lib/furby/useFurby";
import { funkLevels, levelOps, newLevel, type CustomLevel } from "@/lib/funkLevels";
import { progressStore } from "@/lib/progress";
import { useSettings } from "@/lib/settings";
import { askAI } from "@/lib/smart";
import { createStore } from "@/lib/store";
import { cn } from "@/utils/cn";

const COLORS = ["#2f7de1", "#e8386a", "#3b5bdb", "#12a37a", "#e0479e", "#0f9b8e", "#cf8a12", "#7c4dff", "#5b8c5a", "#0a6c8f", "#f2711c", "#8e44ad"];

// ---- custom games (workshop) -----------------------------------------------------
interface CustomCfg {
  id: string;
  name: string;
  desc: string;
  time: number;
  rounds: number;
  lives: number;
  orders: InputType[];
}
const ORDER_TEXT: Partial<Record<InputType, Text>> = {
  antL: ["Антенну влево", "Antenna left"], antR: ["Антенну вправо", "Antenna right"], antF: ["Антенну вперёд", "Antenna forward"], antB: ["Антенну назад", "Antenna back"],
  tongue: ["Нажми на язык", "Press the tongue"], tail: ["Дёрни хвост", "Pull the tail"], head: ["Погладь голову", "Pet the head"], tummy: ["Погладь живот", "Rub the tummy"],
  sideL: ["Нажми левый бок", "Press the left side"], sideR: ["Нажми правый бок", "Press the right side"], tiltL: ["Наклони влево", "Tilt left"], tiltR: ["Наклони вправо", "Tilt right"],
  shake: ["Потряси Ферби", "Shake Furby"], flip: ["Переверни вверх ногами", "Flip upside down"],
};
const ORDER_KEYS = Object.keys(ORDER_TEXT) as InputType[];
const CTL_OF: Partial<Record<InputType, Ctl>> = { antL: "antennaLR", antR: "antennaLR", antF: "antennaFB", antB: "antennaFB", tongue: "tongue", tail: "tail", head: "head", tummy: "tummy", sideL: "sides", sideR: "sides", tiltL: "tilt", tiltR: "tilt", shake: "shake", flip: "flip" };
export const customGames = createStore<{ list: CustomCfg[] }>({ list: [] }, "furby.customgames.v1");

function customDef(c: CustomCfg): GameDef {
  return {
    id: `custom-${c.id}`,
    name: [c.name, c.name],
    desc: [c.desc, c.desc],
    icon: Wand2,
    cat: "party",
    controls: [...new Set(c.orders.map((o) => CTL_OF[o]).filter((x): x is Ctl => !!x))],
    lives: c.lives,
    tap: null,
    create: (api) => {
      let order = c.orders[0];
      let phase: "wait" | "go" = "wait";
      let timer = 1;
      let elapsed = 0;
      let done = 0;
      let wrong = 0;
      const next = () => {
        const pool = c.orders.length > 1 ? c.orders.filter((o) => o !== order) : c.orders;
        order = pool[Math.floor(Math.random() * pool.length)];
        phase = "go";
        elapsed = 0;
        api.speak(api.t(...(ORDER_TEXT[order] ?? ["?", "?"])));
        api.sfx("tick");
      };
      return {
        update(dt, inp) {
          wrong = Math.max(0, wrong - dt);
          if (phase === "wait") {
            timer -= dt;
            if (timer <= 0) next();
            return;
          }
          elapsed += dt;
          for (const e of inp.events) {
            if (e.type === order) {
              api.add(Math.round(100 + 400 * Math.max(0, 1 - elapsed / c.time)), api.w / 2, api.h * 0.62);
              api.sfx("good");
              done++;
              if (done >= c.rounds) return api.over(true);
              phase = "wait";
              timer = 0.6;
              return;
            }
            if (ORDER_KEYS.includes(e.type)) wrong = 0.3;
          }
          if (elapsed >= c.time) {
            phase = "wait";
            timer = 0.8;
            api.hurt();
          }
        },
        draw() {
          const { ctx, w, h, pal } = api;
          ctx.fillStyle = wrong > 0 ? pal.surface2 : pal.bg;
          ctx.fillRect(-20, -20, w + 40, h + 40);
          if (phase === "go") {
            text(ctx, api.t(...(ORDER_TEXT[order] ?? ["?", "?"])), w / 2, h * 0.42, Math.min(44, w / 13), pal.fg, "center", 800);
            bar(ctx, w * 0.2, h * 0.56, w * 0.6, 12, 1 - elapsed / c.time, pal.fg, pal.surface2);
          } else text(ctx, api.t("Приготовься…", "Get ready…"), w / 2, h * 0.45, 22, pal.muted, "center", 700);
          text(ctx, `${done}/${c.rounds}`, w / 2, h - 22, 13, pal.muted, "center", 600);
        },
      };
    },
  };
}

function Workshop({ open, onClose }: { open: boolean; onClose(): void }) {
  const t = useT();
  const lang = useLang();
  const hasKey = useSettings((s) => !!s.aiKey);
  const blank = (): CustomCfg => ({ id: Math.random().toString(36).slice(2, 9), name: t("Моя игра", "My game"), desc: "", time: 2.5, rounds: 15, lives: 3, orders: ["antL", "antR", "tongue", "tail"] });
  const [cfg, setCfg] = useState<CustomCfg>(blank);
  const [idea, setIdea] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const generate = async () => {
    setBusy(true);
    setErr(null);
    try {
      const reply = await askAI(
        `You design Furby Connect reflex games. Reply ONLY with JSON: {"name":string,"desc":string,"time":number(1-5),"rounds":number(5-40),"lives":number(1-5),"orders":string[]} using only these orders: ${ORDER_KEYS.join(", ")}. Write name and desc in ${lang === "en" ? "English" : "Russian"}.`,
        idea || "a fun game",
      );
      const j = JSON.parse(reply.match(/\{[\s\S]*\}/)?.[0] ?? "{}");
      const orders = (Array.isArray(j.orders) ? j.orders : []).filter((o: string): o is InputType => ORDER_KEYS.includes(o as InputType));
      setCfg((c) => ({ ...c, name: String(j.name ?? c.name).slice(0, 40), desc: String(j.desc ?? "").slice(0, 200), time: Math.min(5, Math.max(1, Number(j.time) || c.time)), rounds: Math.min(40, Math.max(5, Number(j.rounds) || c.rounds)), lives: Math.min(5, Math.max(1, Number(j.lives) || c.lives)), orders: orders.length ? orders : c.orders }));
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };
  const save = () => {
    customGames.set((s) => ({ list: [...s.list.filter((x) => x.id !== cfg.id), cfg] }));
    setCfg(blank());
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} wide icon={Wand2} title={t("Мастерская игр", "Game workshop")} subtitle={t("Собери свою игру-реакцию руками или с помощью ИИ", "Build your own reflex game by hand or with AI")} footer={<><Button variant="ghost" className="ml-auto" onClick={onClose}>{t("Отмена", "Cancel")}</Button><Button variant="signal" disabled={!cfg.orders.length || !cfg.name.trim()} onClick={save}>{t("Сохранить игру", "Save game")}</Button></>}>
      <div className="space-y-4">
        <div className="rounded-xl border border-line bg-panel-2 p-3">
          <Label>{t("сгенерировать с ИИ", "generate with AI")}</Label>
          {hasKey ? (
            <div className="mt-2 flex gap-2">
              <input value={idea} onChange={(e) => setIdea(e.target.value)} placeholder={t("например: быстрая игра про ниндзя, только антенна", "e.g. a fast ninja game, antenna only")} className={inputCls} />
              <Button variant="primary" disabled={busy} onClick={() => void generate()}><Bot className="h-4 w-4" />{busy ? "…" : t("Создать", "Create")}</Button>
            </div>
          ) : (
            <p className="mt-1 text-xs text-muted">{t("Добавь свой ключ ИИ в настройках — или собери игру руками ниже.", "Add your AI key in Settings — or build the game by hand below.")} <button type="button" className="text-signal hover:underline" onClick={() => { onClose(); goTab("settings"); }}>{t("Настройки", "Settings")}</button></p>
          )}
          {err && <p className="mt-2 text-xs text-flare">{err}</p>}
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <input value={cfg.name} onChange={(e) => setCfg({ ...cfg, name: e.target.value })} placeholder={t("Название", "Name")} className={inputCls} />
          <input value={cfg.desc} onChange={(e) => setCfg({ ...cfg, desc: e.target.value })} placeholder={t("Описание", "Description")} className={inputCls} />
        </div>
        <div>
          <Label className="mb-2">{t("какие действия просить", "which actions to ask for")}</Label>
          <div className="flex flex-wrap gap-1.5">
            {ORDER_KEYS.map((o) => {
              const on = cfg.orders.includes(o);
              return (
                <button key={o} type="button" onClick={() => setCfg({ ...cfg, orders: on ? cfg.orders.filter((x) => x !== o) : [...cfg.orders, o] })} className={cn("rounded-full border px-3 py-1 text-xs font-medium", on ? "border-signal/40 bg-signal-dim text-signal" : "border-line text-ink-2")}>
                  {pick(ORDER_TEXT[o]!, lang)}
                </button>
              );
            })}
          </div>
        </div>
        <div className="grid gap-x-6 sm:grid-cols-3">
          <Slider label={t("Время на приказ", "Time per order")} value={cfg.time} min={1} max={5} step={0.5} onChange={(v) => setCfg({ ...cfg, time: v })} format={(v) => `${v} ${t("с", "s")}`} />
          <Slider label={t("Раундов", "Rounds")} value={cfg.rounds} min={5} max={40} onChange={(v) => setCfg({ ...cfg, rounds: v })} />
          <Slider label={t("Жизней", "Lives")} value={cfg.lives} min={1} max={5} onChange={(v) => setCfg({ ...cfg, lives: v })} />
        </div>
      </div>
    </Modal>
  );
}

// ---- featured artwork ---------------------------------------------------------------
function DashArt() {
  return (
    <svg viewBox="0 0 400 150" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="150" fill="#0b3b38" />
      {Array.from({ length: 20 }, (_, i) => <line key={i} x1={i * 22} y1="0" x2={i * 22} y2="150" stroke="#ffffff10" />)}
      <rect x="0" y="118" width="400" height="32" fill="#0f5a52" />
      {[60, 82, 200, 222, 244, 330].map((x) => <polygon key={x} points={`${x},118 ${x + 10},96 ${x + 20},118`} fill="#e6fffb" />)}
      <rect x="120" y="86" width="32" height="32" rx="4" fill="#22c55e" stroke="#e6fffb" strokeWidth="3" />
      <ellipse cx="290" cy="70" rx="9" ry="26" fill="none" stroke="#facc15" strokeWidth="4" />
      <ellipse cx="360" cy="60" rx="9" ry="26" fill="none" stroke="#38bdf8" strokeWidth="4" />
    </svg>
  );
}
function FunkArt() {
  return (
    <svg viewBox="0 0 400 150" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="150" fill="#3a1d8c" />
      <polygon points="240,30 252,52 228,52" fill="#ffd166" />
      <rect x="300" y="28" width="16" height="16" rx="3" fill="#7ff2d8" />
      <circle cx="350" cy="44" r="8" fill="#ff5c85" />
      <circle cx="120" cy="88" r="38" fill="#7ff2d8" />
      <circle cx="108" cy="80" r="8" fill="#fff" /><circle cx="134" cy="80" r="8" fill="#fff" />
      <circle cx="110" cy="81" r="3.5" fill="#0c1013" /><circle cx="136" cy="81" r="3.5" fill="#0c1013" />
      <circle cx="270" cy="96" r="34" fill="#ff5c85" />
      <circle cx="259" cy="89" r="7" fill="#fff" /><circle cx="281" cy="89" r="7" fill="#fff" />
      <circle cx="257" cy="90" r="3" fill="#0c1013" /><circle cx="279" cy="90" r="3" fill="#0c1013" />
    </svg>
  );
}

function LevelPicker({ def, onPick, onBack, onCreate }: { def: GameDef; onPick(level: number): void; onBack(): void; onCreate?: () => void }) {
  const t = useT();
  const lang = useLang();
  const levels = progressStore.use((p) => p.levels);
  return (
    <Card title={pick(def.name, lang)} hint={pick(def.desc, lang)} icon={def.icon} action={<Button size="sm" variant="ghost" onClick={onBack}><ChevronLeft className="h-4 w-4" />{t("Все игры", "All games")}</Button>}>
      {onCreate && (
        <Button variant="signal" onClick={onCreate}>
          <Plus className="h-4 w-4" />
          {t("Создать свой уровень", "Create your own level")}
        </Button>
      )}
      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {def.levels!.map((lv, i) => {
          const best = levels[`${def.id}:${i}`] ?? 0;
          const cleared = def.id === "dash" ? best >= 100 : def.id === "funk" ? (levels[`funkclear:${i}`] ?? 0) > 0 : best > 0;
          return (
            <button key={i} type="button" onClick={() => onPick(i)} className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 p-3 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-signal/50 hover:shadow-md">
              <span className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg font-display text-sm font-bold", cleared ? "bg-signal text-white" : "border border-line bg-panel text-muted")}>{i + 1}</span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium">{pick(lv.name, lang)}</span>
                {lv.sub && <span className="block truncate text-xs text-muted">{pick(lv.sub, lang)}</span>}
              </span>
              {best > 0 && <span className="font-mono text-xs text-muted">{best}{def.levelUnit ?? ""}</span>}
            </button>
          );
        })}
      </div>
    </Card>
  );
}

function Fun() {
  const t = useT();
  const ready = useFurby((st) => st.status === "ready");
  const [phrase, setPhrase] = useState<string | null>(null);
  const [count, setCount] = useState(0);
  const [party, setParty] = useState(false);
  const roulette = () => {
    const r = LIBRARY[Math.floor(Math.random() * LIBRARY.length)];
    setPhrase(rowLabel(r));
    furby.phrase(r, false);
  };
  const photo = () => {
    setCount(3);
    [2, 1, 0].forEach((n, i) => window.setTimeout(() => {
      setCount(n);
      if (n === 0) {
        const r = LIBRARY.find((x) => x[0] === 57);
        if (r) furby.phrase(r, false);
        else furby.randomInput(57);
        furby.setLedFrame([255, 255, 255], true);
      }
    }, (i + 1) * 1000));
  };
  const togglParty = () => {
    if (party) {
      furby.stopDance();
      stopLight();
      setParty(false);
      return;
    }
    setParty(true);
    startLight("rainbow-fast");
    furby.startDance();
    window.setTimeout(() => {
      furby.stopDance();
      setParty(false);
    }, 60000);
  };
  return (
    <Card title={t("Приколы", "Fun stuff")} hint={t("Быстрые сценки на один тап", "Quick one-tap skits")} icon={PartyPopper}>
      <div className="grid gap-2.5 sm:grid-cols-3">
        <div className="rounded-xl border border-line bg-panel-2 p-3">
          <p className="flex items-center gap-2 text-sm font-semibold"><Dices className="h-4 w-4 text-signal" />{t("Рулетка реплик", "Phrase roulette")}</p>
          <p className="mt-1 min-h-8 text-xs text-muted">{phrase ? `«${phrase}»` : t("Нажми «Крутить»", "Press “Spin”")}</p>
          <Button size="sm" variant="signal" className="mt-2" disabled={!ready} onClick={roulette}>{t("Крутить", "Spin")}</Button>
        </div>
        <div className="rounded-xl border border-line bg-panel-2 p-3">
          <p className="flex items-center gap-2 text-sm font-semibold"><Camera className="h-4 w-4 text-signal" />{t("Фото-таймер", "Photo timer")}</p>
          <p className="mt-1 min-h-8 text-xs text-muted">{count > 0 ? `${count}…` : t("Три вспышки и «скажи сыр»", "Three flashes and “say cheese”")}</p>
          <Button size="sm" className="mt-2" disabled={!ready || count > 0} onClick={photo}>{t("Снять", "Shoot")}</Button>
        </div>
        <div className="rounded-xl border border-line bg-panel-2 p-3">
          <p className="flex items-center gap-2 text-sm font-semibold"><Sparkles className="h-4 w-4 text-signal" />{t("Вечеринка", "Party")}</p>
          <p className="mt-1 min-h-8 text-xs text-muted">{t("Радуга, танец и реплики целую минуту", "Rainbow, dancing and phrases for a minute")}</p>
          <Button size="sm" variant={party ? "soft" : "secondary"} className="mt-2" disabled={!ready} onClick={togglParty}>{party ? t("Хватит", "Enough") : t("Погнали", "Let's go")}</Button>
        </div>
      </div>
    </Card>
  );
}

const SCENE_NAMES: Record<string, Text> = {
  theater: ["Театральная", "Theatre"],
  club: ["Клуб", "Club"],
  street: ["Ночная улица", "Night street"],
};

export function GamesTab() {
  const t = useT();
  const lang = useLang();
  const bests = progressStore.use((p) => p.bests);
  const custom = customGames.use((s) => s.list);
  const [active, setActive] = useState<{ def: GameDef; level: number } | null>(null);
  const [levelsFor, setLevelsFor] = useState<GameDef | null>(null);
  const [cat, setCat] = useState<Cat | "all">("all");
  const [query, setQuery] = useState("");
  const [shop, setShop] = useState(false);
  const [editing, setEditing] = useState<CustomLevel | null>(null);
  const customList = funkLevels.use((s) => s.list);
  // selecting a game or level always brings you back to the top of the tab
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [active, levelsFor, editing]);
  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return GAMES.filter((g) => !g.featured && (cat === "all" || g.cat === cat) && (!q || `${g.name[0]} ${g.name[1]} ${g.desc[0]} ${g.desc[1]}`.toLowerCase().includes(q)));
  }, [cat, query]);

  if (editing) return <FunkEditor level={editing} onClose={() => setEditing(null)} />;
  if (active) {
    const exit = () => setActive(null);
    if (active.def.component) return <active.def.component onExit={exit} />;
    return <GameHost key={`${active.def.id}-${active.level}`} def={active.def} level={active.level} onExit={exit} />;
  }
  if (levelsFor)
    return (
      <LevelPicker
        def={levelsFor}
        onPick={(level) => setActive({ def: levelsFor, level })}
        onBack={() => setLevelsFor(null)}
        onCreate={levelsFor.id === "funk" ? () => setEditing(newLevel()) : undefined}
      />
    );
  const open = (def: GameDef) => (def.levels ? setLevelsFor(def) : setActive({ def, level: 0 }));
  const unlocked = Object.keys(progressStore.get().unlocked).length;

  return (
    <div className="space-y-4">
      <Workshop open={shop} onClose={() => setShop(false)} />
      <Card
        title={t("Игровой зал", "Game hall")}
        hint={t(`${GAMES.length} игр на антенне, наклонах, датчиках и чувстве ритма`, `${GAMES.length} games on the antenna, tilt, sensors and rhythm`)}
        icon={Gamepad2}
        action={
          <div className="flex items-center gap-2">
            <Chip><Trophy className="h-3 w-3" />{unlocked}</Chip>
            <Button size="sm" variant="signal" onClick={() => setShop(true)}><Wand2 className="h-3.5 w-3.5" />{t("Мастерская", "Workshop")}</Button>
          </div>
        }
      >
        <p className="text-sm text-muted">{t("Подключи Ферби или включи демо — в демо всё играется кнопками, мышью и пальцем.", "Connect Furby or turn on the demo — in demo everything plays with keys, mouse and touch.")}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {FEATURED.map((g, i) => (
            <button key={g.id} type="button" onClick={() => open(g)} className="group overflow-hidden rounded-2xl border border-line text-left transition-all duration-200 hover:-translate-y-1 hover:shadow-xl">
              <div className="relative h-36">
                {i === 0 ? <DashArt /> : <FunkArt />}
                <span className="absolute right-3 top-3"><Chip tone="ink">{t("большая игра", "big game")}</Chip></span>
              </div>
              <div className={cn("p-4 text-white", i === 0 ? "bg-[#0b3b38]" : "bg-[#3a1d8c]")}>
                <p className="flex items-center gap-2 font-display text-xl font-bold"><g.icon className="h-5 w-5" />{pick(g.name, lang)}</p>
                <p className="mt-0.5 font-mono text-[11px] uppercase tracking-wider opacity-80">{i === 0 ? t("12 уровней · 8 режимов · прыжок языком", "12 levels · 8 modes · jump with the tongue") : t("15 песен · 5 соперников · живой BPM", "15 songs · 5 rivals · live BPM")}</p>
                <p className="mt-2 line-clamp-2 text-sm opacity-85">{pick(g.desc, lang)}</p>
                <span className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-[#15181c]"><Play className="h-3.5 w-3.5" />{t("Играть", "Play")}</span>
              </div>
            </button>
          ))}
        </div>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("Найти игру", "Find a game")} className={cn(inputCls, "pl-9")} />
          </div>
          <Segmented<Cat | "all"> value={cat} onChange={setCat} options={CATEGORIES.map((c) => ({ value: c.id, label: pick(c.name, lang) }))} />
        </div>
        <div className="mt-3 grid gap-2.5 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((g) => {
            const color = COLORS[GAMES.indexOf(g) % COLORS.length];
            return (
              <div key={g.id} className="flex flex-col rounded-xl border border-line bg-panel-2 p-3.5 transition-all duration-200 hover:-translate-y-0.5 hover:border-signal/40 hover:shadow-lg">
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white" style={{ backgroundColor: color }}>
                    <g.icon className="h-5 w-5" />
                  </span>
                  <div className="min-w-0">
                    <p className="font-display text-base font-bold leading-tight">{pick(g.name, lang)}</p>
                    <p className="text-xs font-medium" style={{ color }}>{pick(CATEGORIES.find((c) => c.id === g.cat)!.name, lang)}{(bests[g.id] ?? 0) > 0 ? ` · ${t("рекорд", "best")} ${bests[g.id]}` : ""}</p>
                  </div>
                </div>
                <p className="mt-2 line-clamp-3 flex-1 text-xs leading-relaxed text-muted">{pick(g.desc, lang)}</p>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <span className="truncate text-[11px] text-muted">{g.controls.slice(0, 3).map((c) => pick(CTL_LABELS[c], lang)).join(" · ")}</span>
                  <Button size="sm" onClick={() => open(g)}><Play className="h-3.5 w-3.5" />{t("играть", "play")}</Button>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <Card
        title={t("Мои уровни FNF", "My FNF levels")}
        hint={t("Сцена, персонажи, песня и чарт — сохраняются в браузере", "Scene, characters, song and chart — saved in the browser")}
        icon={Music}
        action={
          <Button size="sm" variant="signal" onClick={() => setEditing(newLevel())}>
            <Plus className="h-3.5 w-3.5" />
            {t("Создать", "Create")}
          </Button>
        }
        flush
      >
        {customList.length === 0 ? (
          <div className="p-4">
            <Empty icon={Music} title={t("Своих уровней пока нет", "No custom levels yet")} text={t("Собери уровень: сцену, персонажей, песню и чарт нот.", "Build a level: scene, characters, song and the note chart.")} />
          </div>
        ) : (
          <ul className="divide-y divide-line">
            {customList.map((lv) => (
              <li key={lv.id} className="flex items-center gap-2 px-4 py-2.5">
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{lv.name}</span>
                  <span className="block truncate text-xs text-muted">
                    {pick(SCENE_NAMES[lv.scene] ?? ["Сцена", "Scene"], lang)} · {lv.spec.bpm} BPM ·{" "}
                    {pick(FUNK_CHARS[lv.opponent]?.name ?? ["Соперник", "Rival"], lang)} · {lv.chart.opp.filter((v) => v >= 0).length + lv.chart.player.filter((v) => v >= 0).length} {t("нот", "notes")}
                  </span>
                </span>
                <Button size="sm" variant="signal" onClick={() => setActive({ def: customFunkDef(lv), level: 0 })}>
                  <Play className="h-3.5 w-3.5" />
                </Button>
                <Button size="sm" onClick={() => setEditing(lv)}>{t("Редактировать", "Edit")}</Button>
                <Button size="sm" variant="ghost" onClick={() => window.confirm(t("Удалить уровень?", "Delete the level?")) && levelOps.remove(lv.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title={t("Мои игры", "My games")} hint={t("Собраны в мастерской — руками или с помощью ИИ", "Built in the workshop — by hand or with AI")} icon={Wand2} action={<Button size="sm" onClick={() => setShop(true)}><Plus className="h-3.5 w-3.5" />{t("Создать", "Create")}</Button>}>
        {custom.length === 0 ? (
          <Empty icon={Wand2} title={t("Своих игр пока нет", "No games of your own yet")} text={t("Открой мастерскую: выбери действия, время и раунды — или опиши игру словами для ИИ.", "Open the workshop: pick actions, time and rounds — or describe a game for the AI.")} />
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {custom.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 p-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-invert text-on-invert"><Wand2 className="h-4 w-4" /></span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{c.name}</span>
                  <span className="block truncate text-xs text-muted">{c.desc || `${c.rounds} ${t("раундов", "rounds")} · ${c.time} ${t("с", "s")}`}</span>
                </span>
                <Button size="sm" onClick={() => setActive({ def: customDef(c), level: 0 })}><Play className="h-3.5 w-3.5" /></Button>
                <Button size="sm" variant="ghost" onClick={() => customGames.set((s) => ({ list: s.list.filter((x) => x.id !== c.id) }))}><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            ))}
          </div>
        )}
        <Notice tone="info" className="mt-3">{t("Своя игра — это «приказы» из выбранных действий: успей выполнить за отведённое время. Ошибаться можно, жизнь снимается только по таймеру.", "A custom game is “orders” from the chosen actions: do it in time. Mistakes are fine, a life is lost only on timeout.")}</Notice>
      </Card>

      <Fun />
    </div>
  );
}
