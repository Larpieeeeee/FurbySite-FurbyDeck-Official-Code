import { useState } from "react";
import { ArrowLeft, Save, Shuffle, Trash2 } from "lucide-react";
import { Button, Card, Chip, Label, Slider, inputCls } from "@/components/ui";
import { FUNK_CHARS, LOOKS } from "@/games/funk";
import { LANE_COLORS } from "@/games/kit";
import type { ScaleName } from "@/lib/audio/synth";
import { emptyChart, levelOps, type CustomLevel } from "@/lib/funkLevels";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { cn } from "@/utils/cn";

const SCENES: Array<{ id: string; name: Text }> = [
  { id: "theater", name: ["Театральная", "Theatre"] },
  { id: "club", name: ["Клуб", "Club"] },
  { id: "street", name: ["Ночная улица", "Night street"] },
];
const PLAYER_LOOKS: Text[] = [
  ["Игрок", "Player"], ["Робот", "Robot"], ["Росток", "Sprout"], ["Панк", "Punk"], ["Неон", "Neon"], ["Корона", "Crown"],
];
const SCALES: Array<{ id: ScaleName; name: Text }> = [
  { id: "major", name: ["Мажор", "Major"] }, { id: "minor", name: ["Минор", "Minor"] },
  { id: "dorian", name: ["Дориан", "Dorian"] }, { id: "mixo", name: ["Миксолидиан", "Mixolydian"] },
  { id: "penta", name: ["Пентатоника", "Pentatonic"] },
];
const ROOTS: Array<[number, string]> = [[53, "F"], [55, "G"], [57, "A"], [58, "B♭"], [60, "C"], [62, "D"], [65, "F↑"]];
const STYLES = ["A", "B", "C", "D"];
const DEG_NAMES = ["До", "Ре", "Ми", "Фа", "Соль", "Ля", "Си", "До↑", "Ре↑", "Ми↑", "Фа↑"];
const ARROWS = ["←", "↓", "↑", "→"];
const CELL_W = 16;

function ChartRow({ label, row, deg, onCell, onFill }: { label: string; row: number[]; deg: number; onCell(i: number): void; onFill(mode: "clear" | "random"): void }) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <Label>{label}</Label>
        <div className="flex gap-1">
          <Button size="sm" variant="ghost" title="Случайно" onClick={() => onFill("random")}>
            <Shuffle className="h-3.5 w-3.5" />
          </Button>
          <Button size="sm" variant="ghost" title="Очистить" onClick={() => onFill("clear")}>
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
      <div className="no-scrollbar overflow-x-auto pb-1">
        <div className="flex gap-[2px]">
          {row.map((v, i) => (
            <button
              key={i}
              type="button"
              onClick={() => onCell(i)}
              title={`Шаг ${i + 1}${v >= 0 ? ` · ${DEG_NAMES[v] ?? v}` : ""}`}
              className={cn(
                "flex h-9 shrink-0 items-center justify-center rounded-[3px] border text-[10px] font-bold transition-colors",
                v < 0 ? "border-line bg-panel-2 text-faint hover:border-signal/60" : "border-transparent text-white",
              )}
              style={v >= 0 ? { backgroundColor: LANE_COLORS[v % 4] } : undefined}
            >
              {v >= 0 ? ARROWS[v % 4] : ""}
            </button>
          ))}
        </div>
        <div className="mt-1 flex gap-[2px]">
          {Array.from({ length: 8 }, (_, b) => (
            <span key={b} className="shrink-0 text-center font-mono text-[8px] text-faint" style={{ width: CELL_W * 4 + 6 }}>
              {b + 1}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function FunkEditor({ level, onClose }: { level: CustomLevel; onClose(): void }) {
  const t = useT();
  const lang = useLang();
  const [draft, setDraft] = useState<CustomLevel>(() => ({ ...level, chart: { opp: [...level.chart.opp], player: [...level.chart.player] } }));
  const [deg, setDeg] = useState(0);
  const set = (patch: Partial<CustomLevel>) => setDraft((d) => ({ ...d, ...patch }));

  const cell = (who: "opp" | "player", i: number) =>
    setDraft((d) => {
      const row = [...d.chart[who]];
      row[i] = row[i] === deg ? -1 : deg;
      return { ...d, chart: { ...d.chart, [who]: row } };
    });

  const fill = (who: "opp" | "player", mode: "clear" | "random") =>
    setDraft((d) => {
      const row =
        mode === "clear"
          ? emptyChart()[who]
          : Array.from({ length: 32 }, (_, i) => {
              if (i % 4 === 0) return Math.floor(Math.random() * 11);
              if (i % 2 === 0 && Math.random() < 0.5) return Math.floor(Math.random() * 11);
              return -1;
            });
      return { ...d, chart: { ...d.chart, [who]: row } };
    });

  const notes = draft.chart.opp.filter((v) => v >= 0).length + draft.chart.player.filter((v) => v >= 0).length;

  const save = () => {
    levelOps.upsert({ ...draft, name: draft.name.trim() || "Мой уровень", updated: Date.now() });
    onClose();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <Button variant="ghost" size="sm" onClick={onClose}>
          <ArrowLeft className="h-4 w-4" />
          {t("Отмена", "Cancel")}
        </Button>
        <span className="text-sm text-muted">{t("Уровень сохраняется в браузере", "The level is saved in this browser")}</span>
      </div>

      <Card title={t("Название", "Name")} hint={t("Появится в списке уровней", "Shown in the level list")}>
        <input value={draft.name} onChange={(e) => set({ name: e.target.value.slice(0, 40) })} className={inputCls} maxLength={40} />
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title={t("Сцена", "Scene")} hint={t("Где поют персонажи", "Where the characters sing")}>
          <div className="grid grid-cols-3 gap-2">
            {SCENES.map((s) => (
              <button key={s.id} type="button" onClick={() => set({ scene: s.id })} className={cn("rounded-xl border px-2 py-3 text-sm font-medium transition-colors", draft.scene === s.id ? "border-signal bg-signal-dim text-signal" : "border-line bg-panel-2 text-ink-2 hover:border-signal/50")}>
                {pick(s.name, lang)}
              </button>
            ))}
          </div>
        </Card>

        <Card title={t("Персонажи", "Characters")} hint={t("Соперник поёт слева, твой образ — справа", "The rival sings left, your look is on the right")}>
          <div className="mb-2 flex flex-wrap gap-1.5">
            {FUNK_CHARS.map((c, i) => (
              <button key={c.name[1]} type="button" onClick={() => set({ opponent: i })} className={cn("flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium", draft.opponent === i ? "border-signal bg-signal-dim text-signal" : "border-line text-ink-2 hover:border-signal/50")}>
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: c.color }} />
                {pick(c.name, lang)}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {PLAYER_LOOKS.map((name, i) => (
              <button key={i} type="button" onClick={() => set({ playerKind: i })} className={cn("flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium", draft.playerKind === i ? "border-signal bg-signal-dim text-signal" : "border-line text-ink-2 hover:border-signal/50")}>
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: LOOKS[i].jacket }} />
                {pick(name, lang)}
              </button>
            ))}
          </div>
        </Card>
      </div>

      <Card title={t("Песня", "Song")} hint={t("Звук и аккомпанемент генерируются из этих параметров", "Sound and accompaniment are generated from these parameters")}>
        <div className="grid gap-x-8 sm:grid-cols-2">
          <Slider label={t("Темп", "Tempo")} value={draft.spec.bpm} min={80} max={180} step={2} onChange={(v) => set({ spec: { ...draft.spec, bpm: v } })} format={(v) => `${v} BPM`} />
          <Slider label={t("Плотность нот", "Note density")} value={draft.spec.density} min={0.2} max={0.9} step={0.05} onChange={(v) => set({ spec: { ...draft.spec, density: v } })} format={(v) => `${Math.round(v * 100)}%`} />
          <div className="space-y-1.5 py-2">
            <Label>{t("Тональность", "Key")}</Label>
            <select value={draft.spec.scale} onChange={(e) => set({ spec: { ...draft.spec, scale: e.target.value as ScaleName } })} className={inputCls}>
              {SCALES.map((s) => (
                <option key={s.id} value={s.id}>{pick(s.name, lang)}</option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5 py-2">
            <Label>{t("Тоника", "Root")}</Label>
            <div className="flex flex-wrap gap-1.5">
              {ROOTS.map(([v, name]) => (
                <button key={v} type="button" onClick={() => set({ spec: { ...draft.spec, root: v } })} className={cn("h-9 w-9 rounded-lg border text-sm font-medium", draft.spec.root === v ? "border-signal bg-signal-dim text-signal" : "border-line text-ink-2")}>
                  {name}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5 py-2">
            <Label>{t("Ритм-стиль", "Rhythm style")}</Label>
            <div className="flex gap-1.5">
              {STYLES.map((s, i) => (
                <button key={s} type="button" onClick={() => set({ spec: { ...draft.spec, style: i } })} className={cn("h-9 w-9 rounded-lg border text-sm font-medium", draft.spec.style === i ? "border-signal bg-signal-dim text-signal" : "border-line text-ink-2")}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5 py-2">
            <Label>{t("Зерно мелодии", "Melody seed")}</Label>
            <div className="flex gap-2">
              <input type="number" value={draft.spec.seed} onChange={(e) => set({ spec: { ...draft.spec, seed: Number(e.target.value) || 0 } })} className={cn(inputCls, "font-mono")} />
              <Button size="icon" variant="secondary" title={t("Случайное", "Random")} onClick={() => set({ spec: { ...draft.spec, seed: Math.floor(Math.random() * 99999) } })}>
                <Shuffle className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <Card
        title={t("Чарт", "Chart")}
        hint={t("32 шага = 2 такта. Направление стрелки — остаток степени при делении на 4.", "32 steps = 2 bars. The arrow direction is the degree modulo 4.")}
        action={<Chip tone="signal">{notes} {t("нот", "notes")}</Chip>}
      >
        <div className="mb-3 flex flex-wrap items-center gap-1.5">
          <Label className="mr-1">{t("Ставить степень", "Place degree")}</Label>
          {DEG_NAMES.map((name, i) => (
            <button key={i} type="button" onClick={() => setDeg(i)} className={cn("flex h-8 w-8 items-center justify-center rounded-lg border text-[11px] font-bold", deg === i ? "border-ink text-fg" : "border-line text-ink-2")} style={deg === i ? { backgroundColor: LANE_COLORS[i % 4], color: "#fff", borderColor: "transparent" } : undefined}>
              {i}
            </button>
          ))}
        </div>
        <div className="space-y-4">
          <ChartRow label={t("Соперник", "Rival")} row={draft.chart.opp} deg={deg} onCell={(i) => cell("opp", i)} onFill={(m) => fill("opp", m)} />
          <ChartRow label={t("Игрок", "Player")} row={draft.chart.player} deg={deg} onCell={(i) => cell("player", i)} onFill={(m) => fill("player", m)} />
        </div>
        <p className="mt-3 text-xs text-muted">{t("Соперник поёт первую половину цикла, игрок повторяет — как в оригинале. Пустые клетки — паузы.", "The rival sings the first half of the cycle, the player answers — like the original. Empty cells are rests.")}</p>
      </Card>

      <div className="sticky bottom-2 flex justify-end gap-2 pb-safe">
        <Button variant="secondary" onClick={onClose}>
          {t("Отмена", "Cancel")}
        </Button>
        <Button variant="signal" onClick={save}>
          <Save className="h-4 w-4" />
          {t("Сохранить уровень", "Save level")}
        </Button>
      </div>
    </div>
  );
}
