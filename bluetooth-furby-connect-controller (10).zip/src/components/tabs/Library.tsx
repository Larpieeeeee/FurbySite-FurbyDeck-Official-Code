import {useMemo, useState, type FormEvent} from "react";
import { Bot, BookOpen, ChevronDown, Download, Lightbulb, Play, Search, Shuffle, Sparkles, Star, Trash2 } from "lucide-react";
import { Button, Card, Chip, Empty, Notice, Progress, Segmented, goTab, inputCls } from "@/components/ui";
import { FULL_COUNT_APPROX, GZIP_BYTES, RAW_BYTES, catalog, fullCount, installFull, removeFull } from "@/lib/actions/catalog";
import { CATEGORIES, LIBRARY } from "@/lib/actions/library";
import { useFurby } from "@/lib/furby/useFurby";
import { commandTarget, furby } from "@/lib/furby/controller";
import { pick, useLang, useT } from "@/lib/i18n";
import { MessageCircle } from "lucide-react";
import { progress } from "@/lib/progress";
import { settings, useSettings } from "@/lib/settings";
import { aiSearch, smartSearch, type Hit } from "@/lib/smart";
import { cn } from "@/utils/cn";

type Code = [number, number, number, number];
export const parseFav = (f: string) => {
  const [nums, text] = f.split("|");
  return { code: nums.split(".").map(Number) as Code, text: text ?? "" };
};
export function toggleFav(code: number[], text: string) {
  const favs = settings.get().favorites;
  const prefix = `${code.join(".")}|`;
  settings.set({ favorites: favs.some((f) => f.startsWith(prefix)) ? favs.filter((f) => !f.startsWith(prefix)) : [...favs, `${prefix}${text}`] });
}

function CmdRow({ code, ru, en }: { code: Code; ru: string; en: string }) {
  const t = useT();
  const lang = useLang();
  const favs = useSettings((s) => s.favorites);
  const fav = favs.some((f) => f.startsWith(`${code.join(".")}|`));
  const title = lang === "en" || !ru ? en : ru;
  return (
    <li className="flex items-center gap-2 px-3 py-2.5 sm:px-4">
      <div className="min-w-0 flex-1">
        <p className="break-words text-sm text-ink">{title || <span className="text-faint">{t("без описания", "no description")}</span>}</p>
        <p className="mt-0.5 truncate text-[11px] text-muted">
          <span className="font-mono">{code.join("/")}</span>
          {lang !== "en" && ru && en ? <span> · {en}</span> : null}
        </p>
      </div>
      <button type="button" onClick={() => toggleFav(code, title)} aria-label={t("В плейлист", "To playlist")} className="rounded-lg p-2 text-faint hover:bg-panel-2 hover:text-ink">
        <Star className={cn("h-4 w-4", fav && "fill-current text-amber")} />
      </button>
      <Button size="sm" variant="secondary" onClick={() => furby.action(...code)} aria-label={t("Запустить", "Run")}>
        <Play className="h-3.5 w-3.5" />
      </Button>
    </li>
  );
}

const kb = (b: number) => (b / 1024).toFixed(b < 10240 ? 1 : 0);
const EXAMPLES: Array<[string, string]> = [
  ["чтобы уснул", "to fall asleep"],
  ["что-нибудь весёлое", "something funny"],
  ["поёт песню", "sings a song"],
  ["пукнуть смешно", "funny fart"],
  ["признание в любви", "declaration of love"],
  ["удивление и восторг", "surprise and joy"],
];

export function SearchTab() {
  const t = useT();
  const lang = useLang();
  const hasKey = useSettings((s) => !!s.aiKey);
  const [mode, setMode] = useState<"smart" | "ai">("smart");
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Hit[] | null>(null);
  const [intents, setIntents] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async (q = query) => {
    if (!q.trim()) return;
    setQuery(q);
    setError(null);
    progress.bump("searches");
    if (mode === "ai" && hasKey) {
      setBusy(true);
      try {
        setHits(await aiSearch(q));
        setIntents([]);
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      } finally {
        setBusy(false);
      }
      return;
    }
    const r = smartSearch(q);
    setHits(r.hits);
    setIntents(r.intents.map((i) => pick(i.name, lang)));
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    void run();
  };

  return (
    <div className="space-y-4">
      <Card
        title={t("Поиск по смыслу", "Search by meaning")}
        hint={t("Опиши словами, что должен сделать Ферби — пульт подберёт команды", "Describe what Furby should do — the remote picks the commands")}
        icon={Search}
        action={<Segmented<"smart" | "ai"> value={mode} onChange={setMode} options={[{ value: "smart", label: t("Умный", "Smart") }, { value: "ai", label: t("ИИ · ключ", "AI · key") }]} />}
      >
        <form onSubmit={submit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("например: чтобы уснул", "e.g. to fall asleep")} className={cn(inputCls, "h-11 pl-9")} />
          </div>
          <Button type="submit" variant="primary" className="h-11" disabled={busy}>
            {mode === "ai" ? <Bot className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
            {busy ? t("Думаю…", "Thinking…") : t("Найти", "Find")}
          </Button>
        </form>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {EXAMPLES.map(([ru, en]) => (
            <Chip key={ru} onClick={() => void run(lang === "en" ? en : ru)}>{lang === "en" ? en : ru}</Chip>
          ))}
        </div>
        <p className="mt-3 text-xs leading-relaxed text-muted">
          {mode === "ai"
            ? hasKey
              ? t("ИИ-режим использует твой ключ: запрос и список команд уходят напрямую провайдеру.", "AI mode uses your key: the query and command list go straight to the provider.")
              : t("Для ИИ-режима добавь свой ключ в настройках. Без ключа работает умный поиск.", "Add your own key in Settings for AI mode. Smart search works without a key.")
            : t("Локальный поиск по смыслу: понимает намерения, русскую морфологию и опечатки. Работает без интернета.", "Local search by meaning: understands intents, word forms and typos. Works offline.")}
          {mode === "ai" && !hasKey && (
            <button type="button" className="ml-1 text-signal hover:underline" onClick={() => goTab("settings")}>{t("Открыть настройки", "Open settings")}</button>
          )}
        </p>
        {error && <Notice tone="flare" className="mt-3">{error}</Notice>}
      </Card>

      {hits && (
        <Card title={t("Результаты", "Results")} hint={intents.length ? `${t("понял", "understood")}: ${intents.join(", ")}` : undefined} icon={Sparkles} flush action={<Chip>{hits.length}</Chip>}>
          {hits.length === 0 ? (
            <div className="p-4">
              <Empty icon={Search} title={t("Ничего не нашлось", "Nothing found")} text={t("Попробуй другие слова или установи полный список команд.", "Try other words or install the full command list.")} />
            </div>
          ) : (
            <ul className="divide-y divide-line">
              {hits.map((h) => (
                <CmdRow key={h.code.join("/")} code={h.code} ru={h.ru} en={h.en} />
              ))}
            </ul>
          )}
        </Card>
      )}

      <Card title={t("Как искать", "How to search")} icon={Lightbulb}>
        <div className="grid gap-2 sm:grid-cols-2">
          {[
            [t("«чтобы уснул»", "“to fall asleep”"), t("колыбельные, зевота, укладывание", "lullabies, yawning, bedtime")],
            [t("«что-нибудь весёлое»", "“something funny”"), t("смех, щекотка, хихиканье", "laughter, tickling, giggles")],
            [t("«признание в любви»", "“declaration of love”"), t("нежности, объятия, сердечки", "affection, hugs, hearts")],
            [t("«просит есть»", "“asks for food”"), t("голод, кормление, чавканье", "hunger, feeding, munching")],
            [t("«поёт песню»", "“sings a song”"), t("пение, музыка, ноты", "singing, music, notes")],
            ["«55/2/14»", t("точный код экшена из таблицы", "an exact action code")],
          ].map(([a, b]) => (
            <div key={a} className="rounded-xl border border-line bg-panel-2 px-3 py-2.5">
              <p className="text-sm font-medium text-ink">{a}</p>
              <p className="text-xs text-muted">{b}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

export function CommandsTab() {
  const t = useT();
  const lang = useLang();
  const { installing, phase, received, total, error, full } = catalog.use((c) => c);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState(0);
  const [custom, setCustom] = useState(["1", "0", "0", "0"]);
  const [openFull, setOpenFull] = useState<Set<number>>(() => new Set());

  const target = commandTarget.use((x) => x.target);
  const secondLinked = useFurby((s) => s.status === "ready" || s.status === "confirming");
  const q = query.trim().toLowerCase();
  const groups = useMemo(() => {
    const rows = LIBRARY.filter((r) => (!cat || r[0] === cat) && (!q || `${r[4]} ${r[5]} ${r.slice(0, 4).join("/")}`.toLowerCase().includes(q)));
    const map = new Map<number, typeof rows>();
    rows.forEach((r) => map.set(r[0], [...(map.get(r[0]) ?? []), r]));
    return [...map.entries()].sort((a, b) => a[0] - b[0]);
  }, [q, cat]);
  const shown = groups.reduce((n, [, r]) => n + r.length, 0);
  const cats = useMemo(() => [...new Set(LIBRARY.map((r) => r[0]))].sort((a, b) => a - b), []);

  return (
    <div className="space-y-4">
      {!full && (
        <Card
          title={t("Установить полный список?", "Install the full list?")}
          hint={`~${FULL_COUNT_APPROX} ${t("экшенов из bluefluff", "actions from bluefluff")}`}
          icon={Download}
        >
          <p className="text-sm text-muted">
            {t(
              "Сейчас доступна встроенная библиотека из 152 команд с русскими названиями. Полный список добавит все экшены из таблицы bluefluff.",
              "The built-in library has 152 commands with Russian names. The full list adds every action from the bluefluff table.",
            )}
          </p>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            {[
              [t("загрузка", "download"), `≈${kb(GZIP_BYTES)} ${t("КБ", "KB")}`],
              [t("данные", "data"), `≈${kb(RAW_BYTES)} ${t("КБ", "KB")}`],
              [t("в браузере", "stored"), `≈70 ${t("КБ", "KB")}`],
            ].map(([a, b]) => (
              <div key={a} className="rounded-xl border border-line bg-panel-2 px-2 py-2.5">
                <p className="font-display text-base font-bold text-ink">{b}</p>
                <p className="font-mono text-[10px] uppercase tracking-widest text-muted">{a}</p>
              </div>
            ))}
          </div>
          {(installing || phase === "done") && (
            <div className="mt-3 space-y-2">
              <Progress value={phase === "download" ? received / total : 1} />
              <p className="font-mono text-xs text-muted">
                {phase === "download" && `${t("загружено", "loaded")} ${kb(received)} / ~${kb(total)} ${t("КБ", "KB")} · ${t("осталось", "left")} ~${kb(Math.max(0, total - received))} ${t("КБ", "KB")} · ${Math.floor((received / total) * 100)}%`}
                {phase === "parse" && t("обработка списка…", "processing…")}
                {phase === "save" && t("сохранение…", "saving…")}
                {phase === "done" && t(`установлено: ${fullCount(full)} команд`, `installed: ${fullCount(full)} commands`)}
              </p>
            </div>
          )}
          {error && (
            <Notice tone="flare" className="mt-3">
              {t("Не удалось скачать: ", "Download failed: ")}
              {error}
            </Notice>
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button variant="signal" disabled={installing || phase === "done"} onClick={() => void installFull()}>
              <Download className="h-4 w-4" />
              {installing ? t("Загружаем…", "Downloading…") : error ? t("Повторить", "Retry") : t("Установить", "Install")}
            </Button>
            {phase === "done" && (
              <Chip tone="signal">
                {t("Готово", "Done")} · {fullCount(full)}
              </Chip>
            )}
          </div>
        </Card>
      )}
      <Card
        title={t("Кому говорить", "Who speaks")}
        hint={t("Куда уходят команды и реплики из этого сайта", "Where commands and phrases from this site go")}
        icon={MessageCircle}
      >
        <Segmented<"all" | "1" | "2">
          value={target}
          onChange={(v) => commandTarget.set({ target: v })}
          options={[
            { value: "all", label: t("Все", "All") },
            { value: "1", label: t("Фёрби 1", "Furby 1") },
            { value: "2", label: secondLinked ? t("Фёрби 2", "Furby 2") : t("Фёрби 2 (не подключён)", "Furby 2 (offline)") },
          ]}
        />
        <p className="mt-2 text-xs text-muted">
          {target === "all"
            ? t("Команды уходят на обе подключённые игрушки.", "Commands go to both connected toys.")
            : target === "2" && !secondLinked
              ? t("Фёрби 2 не подключён — подключи его во вкладке «Пульт».", "Furby 2 is not connected — connect it on the Remote tab.")
              : t(`Команды уходят только на Фёрби ${target}.`, `Commands go only to Furby ${target}.`)}
        </p>
      </Card>
      <Card
        title={t("Библиотека экшенов", "Action library")}
        hint={`${shown} ${t("из", "of")} ${LIBRARY.length} ${t("команд", "commands")} · input / index / subindex / specific`}
        icon={BookOpen}
        action={
          full ? <Chip tone="signal">{t("полный список", "full list")} · {fullCount(full)}</Chip> : undefined
        }
      >
        <div className="grid gap-2 sm:grid-cols-[1fr_240px]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("Фильтр по названию или коду", "Filter by name or code")} className={cn(inputCls, "pl-9")} />
          </div>
          <select value={cat} onChange={(e) => setCat(Number(e.target.value))} className={inputCls}>
            <option value={0}>{t("Все категории", "All categories")}</option>
            {cats.map((c) => (
              <option key={c} value={c}>
                {c} · {pick([CATEGORIES[c]?.[0] ?? String(c), CATEGORIES[c]?.[1] ?? String(c)], lang)}
              </option>
            ))}
          </select>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const [a, b, c, d] = custom.map(Number);
            furby.action(a, b, c, d);
          }}
          className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-[repeat(4,minmax(0,1fr))_auto]"
        >
          {["input", "index", "sub", "spec"].map((l, k) => (
            <input key={l} type="number" min={0} max={255} value={custom[k]} aria-label={l} onChange={(e) => setCustom((c) => c.map((v, j) => (j === k ? e.target.value : v)))} className={cn(inputCls, "font-mono")} />
          ))}
          <Button type="submit" variant="signal" className="col-span-4 sm:col-span-1">
            <Play className="h-4 w-4" />
            {t("Запустить", "Run")}
          </Button>
        </form>
      </Card>

      {groups.map(([input, rows]) => (
        <Card
          key={input}
          title={`${input} · ${pick([CATEGORIES[input]?.[0] ?? "", CATEGORIES[input]?.[1] ?? ""], lang)}`}
          flush
          action={
            <div className="flex items-center gap-1">
              <Chip>{rows.length}</Chip>
              <Button size="sm" variant="ghost" title={t("Случайная из категории", "Random from category")} onClick={() => furby.randomInput(input)}>
                <Shuffle className="h-3.5 w-3.5" />
              </Button>
            </div>
          }
        >
          <ul className="divide-y divide-line">
            {rows.map((r) => (
              <CmdRow key={r.slice(0, 4).join("/")} code={[r[0], r[1], r[2], r[3]]} ru={r[4]} en={r[5]} />
            ))}
          </ul>
        </Card>
      ))}

      {full && (
        <Card title={t("Полный список bluefluff", "Full bluefluff list")} hint={t("Описания — фразы английского Ферби", "Descriptions are English Furby phrases")} icon={BookOpen} flush action={<Button size="sm" variant="ghost" onClick={removeFull}><Trash2 className="h-3.5 w-3.5" />{t("Удалить", "Remove")}</Button>}>
          <div className="divide-y divide-line">
            {full.map((s, i) => {
              const rows = q ? s.rows.filter((r) => `${r[4]} ${r.slice(0, 4).join("/")}`.toLowerCase().includes(q)) : s.rows;
              if (!rows.length) return null;
              const open = !!q || openFull.has(i);
              return (
                <div key={i}>
                  <button type="button" onClick={() => setOpenFull((p) => { const n = new Set(p); if (n.has(i)) n.delete(i); else n.add(i); return n; })} className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-panel-2">
                    <ChevronDown className={cn("h-4 w-4 text-faint transition-transform", open && "rotate-180")} />
                    <span className="flex-1 text-sm font-medium">{pick(s.title, lang)}</span>
                    <span className="font-mono text-xs text-muted">{s.range} · {rows.length}</span>
                  </button>
                  {open && (
                    <ul className="divide-y divide-line border-t border-line bg-panel-2/40">
                      {rows.map((r, k) => (
                        <CmdRow key={k} code={[r[0], r[1], r[2], r[3]]} ru="" en={r[4]} />
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}
