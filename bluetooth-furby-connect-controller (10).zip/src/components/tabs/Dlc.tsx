import { useEffect, useState } from "react";
import { Check, Disc, Download, ExternalLink, Play, RotateCcw, Search, Trash2, Upload, X, Zap } from "lucide-react";
import { Button, Card, Chip, Label, Notice, Progress, Segmented, inputCls } from "@/components/ui";
import { furby } from "@/lib/furby/controller";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT } from "@/lib/i18n";
import { parseDlc, SECTION_NAMES, type DlcInfo } from "@/lib/dlc";
import { useSettings } from "@/lib/settings";
import { toast } from "@/lib/toast";
import { cn } from "@/utils/cn";

type Slot = { slot: number; name: string; size: number; checksum: string; raw: string } | null;

const SLOTS = Array.from({ length: 14 }, (_, i) => i);

const REPO_PRESETS = ["Mame26Git/furbya18", "pdjstone/furby-web-bluetooth", "ollieisnumber09-netizen/furby-web-bluetooth"];
const repoFileCache = new Map<string, { at: number; list: Array<{ path: string; branch: string }> }>();


export function DlcCard() {
  const t = useT();
  const ready = useFurby((s) => s.status === "ready");
  const active = useFurby((s) => s.activeSlot);
  const safe = useSettings((s) => s.safeMode);
  const [slots, setSlots] = useState<Slot[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [sel, setSel] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [checked, setChecked] = useState(0);
  const [catMode, setCatMode] = useState<"repo" | "url">("repo");
  const [repo, setRepo] = useState(REPO_PRESETS[0]);
  const [files, setFiles] = useState<Array<{ name: string; url: string; size: number }> | null>(null);
  const [listing, setListing] = useState(false);
  const [catErr, setCatErr] = useState<string | null>(null);
  const [dl, setDl] = useState<{ name: string; pct: number } | null>(null);
  const [saved, setSaved] = useState<{ name: string; size: number; sum: string; url: string } | null>(null);
  const [urlInput, setUrlInput] = useState("");
  const [structure, setStructure] = useState<{ info: DlcInfo; sum: string } | null>(null);
  const [extracting, setExtracting] = useState(false);
  const [extractGot, setExtractGot] = useState(0);
  const [extractErr, setExtractErr] = useState<string | null>(null);
  const [extractLog, setExtractLog] = useState<string[]>([]);
  const lang = useLang();

  const [allEmpty, setAllEmpty] = useState(false);

  const fetchJson = async (url: string): Promise<Record<string, any>> => {
    const ac = new AbortController();
    const timer = window.setTimeout(() => ac.abort(), 15000);
    try {
      const res = await fetch(url, { signal: ac.signal, headers: { Accept: "application/vnd.github+json" } });
      if (!res.ok) throw new Error(res.status === 403 ? t("GitHub ограничил запросы — попробуй позже", "GitHub rate-limited the requests — try later") : `HTTP ${res.status}`);
      return await res.json();
    } finally {
      window.clearTimeout(timer);
    }
  };

  const listRepo = async () => {
    setListing(true);
    setCatErr(null);
    setFiles(null);
    try {
      const info = await fetchJson(`https://api.github.com/repos/${repo}`);
      const branch = info.default_branch || "master";
      const tree = await fetchJson(`https://api.github.com/repos/${repo}/git/trees/${branch}?recursive=1`);
      const list = (Array.isArray(tree.tree) ? tree.tree : [])
        .filter((n: Record<string, any>) => n.type === "blob" && /\.dlc$/i.test(String(n.path)))
        .map((n: Record<string, any>) => ({
          name: String(n.path).split("/").pop() as string,
          size: Number(n.size) || 0,
          url: `https://raw.githubusercontent.com/${repo}/${branch}/${n.path}`,
        }));
      setFiles(list);
      if (!list.length) setCatErr(t("В репозитории нет .dlc файлов", "No .dlc files in this repository"));
    } catch (e) {
      setCatErr(e instanceof Error ? e.message : String(e));
    } finally {
      setListing(false);
    }
  };

  const download = async (url: string, name: string, expectSum?: string) => {
    setDl({ name, pct: 0 });
    setCatErr(null);
    setDone(null);
    setErr(null);
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const total = Number(res.headers.get("content-length")) || 0;
      const chunks: Uint8Array[] = [];
      let received = 0;
      if (res.body) {
        const reader = res.body.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
          received += value.length;
          setDl({ name, pct: total ? Math.min(1, received / total) : 0 });
        }
      } else {
        const buf = new Uint8Array(await res.arrayBuffer());
        chunks.push(buf);
        received = buf.length;
      }
      const all = new Uint8Array(received);
      let offset = 0;
      for (const c of chunks) {
        all.set(c, offset);
        offset += c.length;
      }
      let a = 1;
      let b = 0;
      for (let i = 0; i < all.length; i++) {
        a = (a + all[i]) % 65521;
        b = (b + a) % 65521;
      }
      const file = new File([all], name, { type: "application/octet-stream" });
      const sum = "0x" + (((b << 16) | a) >>> 0).toString(16);
      setFile(file);
      setSaved({ name, size: all.length, sum, url: URL.createObjectURL(file) });
      setDl(null);
      if (expectSum) {
        if (expectSum.toLowerCase() === sum.toLowerCase()) {
          setDone(t("Точная копия: контрольная сумма совпала с игрушкой", "Exact copy: the checksum matches the toy"));
          toast(t("Файл совпал с игрушкой", "The file matches the toy"), name);
        } else {
          setCatErr(t(`Скачано, но сумма ${sum} не совпала с суммой игрушки ${expectSum} — файл может отличаться`, `Downloaded, but checksum ${sum} doesn't match the toy's ${expectSum} — the file may differ`));
          toast(t("Сумма не совпала", "Checksum mismatch"), name, undefined, "warn");
        }
      } else {
        toast(t("Файл скачан", "File downloaded"), name);
      }
    } catch (e) {
      setDl(null);
      setCatErr(
        e instanceof Error && e.name === "AbortError"
          ? t("Сайт не ответил вовремя — попробуй другой источник", "The site didn't answer in time — try another source")
          : e instanceof Error
            ? e.message
            : String(e),
      );
    }
  };

  useEffect(() => {
    let alive = true;
    setStructure(null);
    if (!file) return;
    (async () => {
      try {
        const all = new Uint8Array(await file.arrayBuffer());
        let a = 1;
        let b = 0;
        for (let i = 0; i < all.length; i++) {
          a = (a + all[i]) % 65521;
          b = (b + a) % 65521;
        }
        const info = parseDlc(all);
        if (alive) setStructure({ info, sum: "0x" + (((b << 16) | a) >>> 0).toString(16) });
      } catch {
        /* ignore unreadable files */
      }
    })();
    return () => {
      alive = false;
    };
  }, [file]);

  /** Tries to pull the exact file for a slot out of the community catalogues
   *  and verifies the adler32 against the toy's own checksum (0x73). */
  const fetchBySlot = async () => {
    const info = slots?.[sel];
    if (!info) return;
    setBusy(true);
    setCatErr(null);
    setDone(null);
    setErr(null);
    try {
      const low = info.name.toLowerCase();
      const tu = low.match(/tu\d{6}/);
      const base = tu ? tu[0] : low.replace(/\.dlc$/i, "").replace(/[^a-z0-9]+/g, "");
      const target = `${base}.dlc`;
      let found: { url: string; repo: string } | null = null;
      const failures: string[] = [];
      for (const repo of REPO_PRESETS) {
        try {
          let files = repoFileCache.get(repo);
          if (!files || Date.now() - files.at < 5 * 60 * 1000) {
            const meta = await fetchJson(`https://api.github.com/repos/${repo}`);
            const branch = meta.default_branch || "master";
            const tree = await fetchJson(`https://api.github.com/repos/${repo}/git/trees/${branch}?recursive=1`);
            files = {
              at: Date.now(),
              list: (Array.isArray(tree.tree) ? tree.tree : [])
                .filter((n: Record<string, any>) => n.type === "blob")
                .map((n: Record<string, any>) => ({ path: String(n.path), branch })),
            };
            repoFileCache.set(repo, files);
          }
          const hit = files.list.find((f) => f.path.toLowerCase().endsWith(`/${target}`));
          if (hit) {
            found = { url: `https://raw.githubusercontent.com/${repo}/${hit.branch}/${hit.path}`, repo };
            break;
          }
        } catch (e) {
          failures.push(`${repo}: ${e instanceof Error ? e.message : String(e)}`);
        }
      }
      if (!found && failures.length) throw new Error(failures.join(" · "));
      if (!found) {
        throw new Error(
          t(
            `Файл ${target} не найден в репозиториях (${REPO_PRESETS.join(", ")}). Пришли строку «rx 73 …» из журнала — подгоню разбор под твою прошивку.`,
            `File ${target} was not found in the repositories (${REPO_PRESETS.join(", ")}). Send me the "rx 73 …" line from the log and I'll adapt the parser to your firmware.`,
          ),
        );
      }
      await download(found.url, target, info.checksum);
    } catch (e) {
      setCatErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  /** Best-effort direct extraction of the slot's bytes from the toy. */
  const extract = async () => {
    setExtracting(true);
    setExtractErr(null);
    setExtractLog([]);
    setExtractGot(0);
    setDone(null);
    setErr(null);
    try {
      const res = await furby.dlcReadFromToy(sel, (got) => setExtractGot(got));
      setExtractLog(res.log);
      if (!res.ok || !res.file) {
        setExtractErr(res.error ?? t("Неизвестная ошибка", "Unknown error"));
        return;
      }
      const all = new Uint8Array(await res.file.arrayBuffer());
      let a = 1;
      let b = 0;
      for (let i = 0; i < all.length; i++) {
        a = (a + all[i]) % 65521;
        b = (b + a) % 65521;
      }
      setFile(res.file);
      setSaved({ name: res.file.name, size: all.length, sum: "0x" + (((b << 16) | a) >>> 0).toString(16), url: URL.createObjectURL(res.file) });
      setDone(t(`Выгружено из слота ${sel}`, `Extracted from slot ${sel}`));
      toast(t("DLC выгружен на устройство", "DLC extracted to the device"), res.file.name);
    } catch (e) {
      setExtractErr(e instanceof Error ? e.message : String(e));
    } finally {
      setExtracting(false);
    }
  };

  const refresh = async () => {
    setBusy(true);
    setErr(null);
    setAllEmpty(false);
    setChecked(0);
    try {
      const res = await furby.dlcSlots((n) => setChecked(n));
      setSlots(res);
      setAllEmpty(res.every((s) => s === null));
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    }
    setBusy(false);
  };

  useEffect(() => {
    if (ready) void refresh();
    else setSlots(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  const act = async (label: string, fn: () => void | Promise<void>) => {
    setErr(null);
    setDone(null);
    setBusy(true);
    try {
      await fn();
      await refresh();
      setDone(label);
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const upload = async () => {
    if (!file) return;
    setErr(null);
    setDone(null);
    setProgress(0);
    try {
      await furby.dlcUpload(file, sel, (f) => setProgress(f));
      setDone(t(`Файл загружен в слот ${sel}`, `File loaded into slot ${sel}`));
      setFile(null);
      await refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setProgress(null);
    }
  };

  const remove = () => {
    if (!window.confirm(t(`Удалить содержимое слота ${sel}? Это необратимо.`, `Delete slot ${sel} contents? This cannot be undone.`))) return;
    void act(t(`Слот ${sel} очищен`, `Slot ${sel} cleared`), () => furby.dlcDelete(sel));
  };

  const slot = slots?.[sel] ?? null;
  const sizeMb = (n: number) => `${(n / 1048576).toFixed(2)} MB`;
  const eta = file ? Math.max(1, Math.round(file.size / 4000)) : 0;

  return (
    <Card
      title={t("Слоты DLC", "DLC slots")}
      hint={t("Просмотр, загрузка и управление обновлениями игрушки", "View, upload and manage the toy's updates")}
      icon={Disc}
      action={
        <Button size="sm" variant="ghost" disabled={!ready || busy} onClick={() => void refresh()}>
          <RotateCcw className={cn("h-3.5 w-3.5", busy && "animate-spin")} />
          {t("Обновить", "Refresh")}
        </Button>
      }
    >
      {!ready ? (
        <p className="text-sm text-muted">{t("Подключи Фёрби во вкладке «Пульт», чтобы увидеть слоты.", "Connect Furby on the Remote tab to see the slots.")}</p>
      ) : (
        <>
          {busy && slots === null && (
            <div className="mb-3 space-y-1.5">
              <Progress value={checked / 14} />
              <p className="font-mono text-xs text-muted">
                {t("Опрашиваем слоты", "Querying slots")} {checked}/14…
              </p>
            </div>
          )}
          {allEmpty && !busy && (
            <Notice tone="amber" className="mb-3">
              {t(
                "Игрушка не ответила ни на один слот. Проверь подключение и нажми «Обновить»; если ответов нет — включи «подробный лог» во вкладке «Журнал» и посмотри, приходят ли пакеты 0x73.",
                "The toy didn't answer for any slot. Check the connection and press Refresh; if there are no replies, enable the verbose log on the Log tab and look for incoming 0x73 packets.",
              )}
            </Notice>
          )}
          <div className="grid grid-cols-7 gap-1.5">
            {SLOTS.map((i) => {
              const s = slots?.[i] ?? null;
              const isActive = active === i;
              return (
                <button
                  key={i}
                  type="button"
                  disabled={!slots}
                  onClick={() => setSel(i)}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center rounded-lg border text-center transition-colors",
                    sel === i ? "border-signal bg-signal-dim" : isActive ? "border-signal/50 bg-signal-dim/60" : s ? "border-line bg-panel-2" : "border-line bg-panel",
                    !slots && "opacity-50",
                  )}
                >
                  <span className="font-mono text-[11px] text-muted">{i}</span>
                  <span className={cn("text-[10px] leading-tight", s ? "text-signal" : "text-faint")}>
                    {slots === null ? "…" : s ? (isActive ? t("активен", "active") : t("есть", "has")) : t("пусто", "empty")}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-3 rounded-xl border border-line bg-panel-2 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-medium">
                {t("Слот", "Slot")} {sel} — {slot ? slot.name || t("не распознан", "unrecognized") : slots === null ? "…" : t("пусто", "empty")}
              </p>
              <div className="flex gap-1.5">
                {active === sel && <Chip tone="signal"><Zap className="h-3 w-3" />{t("активен", "active")}</Chip>}
                {slot && <Chip>{sizeMb(slot.size)}</Chip>}
              </div>
            </div>
            {slot && (
              <p className="mt-1 break-all font-mono text-[11px] text-muted">
                {slot.checksum ? `adler32 ${slot.checksum} · ` : ""}
                {t("слот", "slot")} {slot.slot}
                {slot.size > 0 ? ` · ${(slot.size / 1048576).toFixed(2)} MB` : ""}
              </p>
            )}
            {slot && slot.raw && (
              <p className="mt-0.5 break-all font-mono text-[10px] text-faint">{slot.raw}</p>
            )}
            <div className="mt-2.5 flex flex-wrap gap-2">
              <Button size="sm" variant="signal" disabled={busy || !slot} onClick={() => void act(t("Слот активирован", "Slot activated"), () => furby.dlcActivate(sel))}>
                <Zap className="h-3.5 w-3.5" />
                {t("Активировать", "Activate")}
              </Button>
              <Button size="sm" disabled={busy || active !== sel} onClick={() => void act(t("Слот деактивирован", "Slot deactivated"), () => furby.dlcDeactivate(sel))}>
                <X className="h-3.5 w-3.5" />
                {t("Деактивировать", "Deactivate")}
              </Button>
              <Button size="sm" variant="danger" disabled={busy || !slot || safe} onClick={remove}>
                <Trash2 className="h-3.5 w-3.5" />
                {t("Удалить", "Delete")}
              </Button>
              <Button size="sm" variant="secondary" disabled={busy || !slot || extracting || dl !== null} onClick={() => void extract()}>
                <Download className="h-3.5 w-3.5" />
                {extracting ? (extractGot > 0 ? `${(extractGot / 1024).toFixed(0)} ${t("КБ", "KB")}` : t("Читаем…", "Reading…")) : t("Выгрузить на устройство", "Extract to device")}
              </Button>
            </div>
            {slot && (
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <Button size="sm" variant="ghost" disabled={busy || listing || dl !== null || !slot?.name} onClick={() => void fetchBySlot()}>
                  <Download className="h-3.5 w-3.5" />
                  {t("Получить файл из репозиториев", "Get the file from repositories")}
                </Button>
                <span className="text-[11px] text-faint">
                  {t(
                    "Стандартный файл (tu003410 и подобные) найдётся в каталогах, и его adler32 сверится с суммой игрушки — это точная копия.",
                    "A stock file (tu003410 etc.) will be found in the catalogues and its adler32 checked against the toy — an exact copy.",
                  )}
                </span>
              </div>
            )}
            {(extractErr || extractLog.length > 0) && (
              <div className="mt-2 space-y-2">
                {extractErr && (
                  <Notice tone="flare">{extractErr}</Notice>
                )}
                {extractLog.length > 0 && (
                  <details className="rounded-xl border border-line bg-panel-2 p-2.5">
                    <summary className="cursor-pointer text-xs font-medium">{t("Лог выгрузки", "Extraction log")}</summary>
                    <pre className="mt-1 overflow-x-auto whitespace-pre-wrap font-mono text-[11px] text-muted">{extractLog.join("\n")}</pre>
                  </details>
                )}
              </div>
            )}
            {safe && (
              <p className="mt-2 text-xs text-amber">
                {t("Безопасный режим блокирует удаление и загрузку — отключи его в настройках.", "Safe mode blocks deleting and uploading — turn it off in Settings.")}
              </p>
            )}
          </div>

          <div className="mt-3 rounded-xl border border-line p-3">
            <Label>{t("Загрузить DLC-файл", "Upload a DLC file")}</Label>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <label className="inline-flex h-10 cursor-pointer items-center gap-2 rounded-lg border border-line bg-panel px-3 text-sm font-medium hover:bg-panel-2">
                <Upload className="h-4 w-4" />
                {file ? file.name : t("Выбрать .dlc", "Choose .dlc")}
                <input
                  type="file"
                  accept=".dlc"
                  className="hidden"
                  onChange={(e) => {
                    setFile(e.target.files?.[0] ?? null);
                    setDone(null);
                    setErr(null);
                  }}
                />
              </label>
              <select value={sel} onChange={(e) => setSel(Number(e.target.value))} className={cn(inputCls, "h-10 w-auto")}>
                {SLOTS.map((i) => (
                  <option key={i} value={i}>
                    {t("Слот", "Slot")} {i}
                    {slots?.[i] ? ` · ${slots[i].name}` : ""}
                  </option>
                ))}
              </select>
              <Button variant="primary" disabled={!file || progress !== null || busy || safe} onClick={() => void upload()}>
                <Play className="h-4 w-4" />
                {t("Загрузить", "Upload")}
              </Button>
            </div>
            {file && (
              <p className="mt-2 text-xs text-muted">
                {t(
                  `→ слот ${sel}. Передача идёт по BLE со скоростью ~1–4 КБ/с и может занять несколько минут — держи вкладку открытой.`,
                  `→ slot ${sel}. BLE transfer runs at ~1–4 KB/s and may take several minutes — keep the tab open.`,
                )}{" "}
                ≈ {eta} {t("с", "s")}
              </p>
            )}
            {progress !== null && (
              <div className="mt-2 space-y-1.5">
                <Progress value={progress} />
                <p className="font-mono text-xs text-muted">{Math.floor(progress * 100)}%</p>
              </div>
            )}
            {err && (
              <Notice tone="flare" className="mt-2">
                {err}
              </Notice>
            )}
            {done && (
              <Notice tone="info" className="mt-2" icon={Check}>
                {done}
              </Notice>
            )}
          </div>

          {file && structure && (
            <div className="mt-3 rounded-xl border border-line p-3">
              <Label>{t("Содержимое файла", "File contents")}</Label>
              <p className="mt-1 break-all text-sm text-ink">
                {file.name} · {(structure.info.total / 1048576).toFixed(2)} MB · adler32 {structure.sum}
              </p>
              {structure.info.ok ? (
                <ul className="mt-2 divide-y divide-line rounded-xl border border-line">
                  {structure.info.sections.map((sec) => (
                    <li key={sec.tag} className="flex items-center gap-2 px-3 py-1.5 text-sm">
                      <span className="font-mono font-semibold text-signal">{sec.tag}</span>
                      <span className="min-w-0 flex-1 truncate">{pick(SECTION_NAMES[sec.tag] ?? [sec.tag, sec.tag], lang)}</span>
                      {sec.count !== undefined && sec.countLabel && (
                        <span className="text-xs text-muted">
                          {sec.count} {pick(sec.countLabel, lang)}
                        </span>
                      )}
                      <span className="font-mono text-[11px] text-muted">
                        0x{sec.offset.toString(16)} · {(sec.size / 1024).toFixed(1)} {pick(["КБ", "KB"], lang)}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <Notice tone="flare" className="mt-2">
                  {structure.info.error} · {t("заголовок", "header")}: {structure.info.head.slice(0, 47)}…
                </Notice>
              )}
            </div>
          )}

          {/* DLC catalogue: download a file, then flash it below */}
          <div className="mt-3 rounded-xl border border-line p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Label>{t("Скачать DLC с сайта", "Download DLC from the web")}</Label>
              <Segmented<"repo" | "url">
                value={catMode}
                onChange={setCatMode}
                options={[
                  { value: "repo", label: t("Репозиторий", "Repository") },
                  { value: "url", label: t("Ссылка", "Link") },
                ]}
              />
            </div>

            {catMode === "repo" ? (
              <div className="mt-2 flex flex-wrap gap-2">
                <input
                  list="dlc-repos"
                  value={repo}
                  onChange={(e) => setRepo(e.target.value.trim())}
                  placeholder="owner/repository"
                  className={cn(inputCls, "h-10 min-w-0 flex-1 font-mono")}
                />
                <datalist id="dlc-repos">
                  {REPO_PRESETS.map((r) => (
                    <option key={r} value={r} />
                  ))}
                </datalist>
                <Button variant="signal" disabled={listing} onClick={() => void listRepo()}>
                  <Search className="h-4 w-4" />
                  {listing ? t("Ищем…", "Listing…") : t("Показать файлы", "List files")}
                </Button>
              </div>
            ) : (
              <div className="mt-2 flex flex-wrap gap-2">
                <input
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value.trim())}
                  placeholder="https://…/tu003410.dlc"
                  className={cn(inputCls, "h-10 min-w-0 flex-1 font-mono")}
                />
                <Button
                  variant="signal"
                  disabled={!/^https?:\/\//.test(urlInput) || dl !== null}
                  onClick={() => void download(urlInput, urlInput.split("/").pop() || "file.dlc")}
                >
                  <Download className="h-4 w-4" />
                  {t("Скачать", "Download")}
                </Button>
              </div>
            )}

            {catErr && (
              <Notice tone="flare" className="mt-2">
                {catErr}
              </Notice>
            )}

            {files && files.length > 0 && (
              <div className="mt-2 max-h-56 overflow-y-auto rounded-xl border border-line">
                <ul className="divide-y divide-line">
                  {files.map((f) => (
                    <li key={f.url} className="flex items-center gap-2 px-3 py-2">
                      <button
                        type="button"
                        className="min-w-0 flex-1 truncate text-left text-sm hover:text-signal"
                        disabled={dl !== null}
                        onClick={() => void download(f.url, f.name)}
                      >
                        {f.name}
                      </button>
                      <span className="font-mono text-[11px] text-muted">{f.size ? `${Math.round(f.size / 1024)} KB` : ""}</span>
                      <a href={f.url} target="_blank" rel="noreferrer" className="rounded p-1 text-faint hover:text-ink" aria-label={t("Открыть", "Open")}>
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {dl !== null && (
              <div className="mt-2 space-y-1.5">
                <Progress value={dl.pct} />
                <p className="font-mono text-xs text-muted">
                  {t("Скачиваем", "Downloading")} {dl.name} · {Math.floor(dl.pct * 100)}%
                </p>
              </div>
            )}

            {saved && (
              <div className="mt-2 rounded-xl border border-signal/40 bg-signal-dim p-3">
                <p className="text-sm font-medium text-signal">{saved.name}</p>
                <p className="mt-0.5 font-mono text-[11px] text-muted">
                  {(saved.size / 1048576).toFixed(2)} MB · adler32 {saved.sum}
                </p>
                <p className="mt-1 text-xs text-muted">
                  {t(
                    "Файл подставлен в поле загрузки ниже — выбери слот и нажми «Загрузить». Кнопка сохраняет копию на диск.",
                    "The file is placed in the upload field below — pick a slot and press “Upload”. The button saves a copy to disk.",
                  )}
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <a
                    href={saved.url}
                    download={saved.name}
                    className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-line bg-panel px-3 text-xs font-medium text-ink hover:bg-surface-2"
                  >
                    <Download className="h-3.5 w-3.5" />
                    {t("Сохранить на диск", "Save to disk")}
                  </a>
                  <Button size="sm" variant="ghost" onClick={() => setSaved(null)}>
                    {t("Сбросить", "Clear")}
                  </Button>
                </div>
              </div>
            )}

            <p className="mt-2 text-[11px] leading-relaxed text-faint">
              {t(
                "Официальный сервер обновлений Hasbro (S3) закрыт — отвечает 403, поэтому каталог берёт файлы из публичных репозиториев сообщества. Файлы DLC — собственность Hasbro, используй на свой риск и только с своей игрушкой.",
                "Hasbro's official update server (S3) is closed — it answers 403, so the catalogue takes files from public community repositories. DLC files are Hasbro's property; use at your own risk and only with your own toy.",
              )}
            </p>
          </div>

          <p className="mt-3 text-xs leading-relaxed text-faint">
            {t(
              "Выгрузить содержимое слота обратно в файл нельзя: в протоколе нет команды чтения файла. «Выгружать» — значит деактивировать или удалить слот.",
              "You can't export a slot back to a file: the protocol has no file-read command. “Unloading” means deactivating or deleting the slot.",
            )}
          </p>
          <p className="mt-1 text-xs leading-relaxed text-faint">
            <a href="https://github.com/Jeija/bluefluff/blob/master/doc/generalplus.md" target="_blank" rel="noreferrer" className="underline underline-offset-2">
              bluefluff · GeneralPlus
            </a>{" "}
            {t(
              "— команды 0x50, 0x60, 0x61, 0x62, 0x73, 0x74. Слоты помечаются как активные по данным пульта: спросить об этом у игрушки нельзя.",
              "— commands 0x50, 0x60, 0x61, 0x62, 0x73, 0x74. Active slots are tracked by the remote: the toy has no query for it.",
            )}
          </p>
          <p className="mt-1 text-xs text-faint">
            {t("Работает только на подключённом Фёрби (в демо-режиме слот 2 показан для примера).", "Works only with a connected Furby (demo shows slot 2 as an example).")}
          </p>
        </>
      )}
    </Card>
  );
}
