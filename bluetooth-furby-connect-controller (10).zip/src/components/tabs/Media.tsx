import { useEffect, useRef, useState, type DragEvent } from "react";
import type { LucideIcon } from "lucide-react";
import {
  ArrowDown, ArrowUp, Binary, CircleDot, CloudLightning, Disc3, Dices, Droplets, Eye, Flame, Ghost, Gift, Hand, Hash, HeartPulse, Lightbulb,
  ListMusic, Mic, Move, Music2, Palette, Pause, Play, Plus, Radio, Rainbow, Rows3, Shuffle, Siren, Smile, Sparkles, Square, Sun, Sunrise,
  Tornado, TrafficCone, Trash2, Upload, Waves, Wind, Zap,
} from "lucide-react";
import { Button, Card, Chip, Empty, Label, Notice, Slider, Toggle, inputCls } from "@/components/ui";
import { BUILTIN, addFiles, music, playBuiltin, playFile, removeFile, seek, setDance, stopMusic } from "@/lib/audio/music";
import { audio } from "@/lib/audio/synth";
import { furby } from "@/lib/furby/controller";
import { LIGHT_MODES, LIGHT_PALETTES, LIGHT_PATTERNS, LIGHT_SPECIALS, lighting, sequencer, setMoodValue, startLight, stopLight, type LightCat } from "@/lib/furby/lighting";
import { rgbToHex } from "@/lib/furby/protocol";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { settings, useSettings } from "@/lib/settings";
import { cn } from "@/utils/cn";

const SPECIAL_ICONS: Record<string, LucideIcon> = {
  rainbow: Rainbow, aurora: Sparkles, sunrise: Sunrise, "rainbow-fast": Tornado, siren: Siren, storm: CloudLightning, matrix: Binary, holiday: Gift, halloween: Ghost,
  music: Disc3, mic: Mic, sensors: Hand, tilt: Move, link: Radio, mood: Smile, white: Sun, traffic: TrafficCone, sos: CircleDot, morse: Hash, sequencer: Rows3, rgbtest: Palette, shuffle: Shuffle,
};
const PATTERN_ICONS: Record<string, LucideIcon> = { smooth: Waves, breathe: Wind, fade: Droplets, wave: Waves, candle: Flame, pulse: HeartPulse, strobe: Zap, blink: Eye, jump: Dices, sparkle: Sparkles };
const CATS: Array<{ id: LightCat | "all"; name: Text }> = [
  { id: "all", name: ["Все", "All"] },
  { id: "smooth", name: ["Плавные", "Smooth"] },
  { id: "rhythm", name: ["Ритмичные", "Rhythmic"] },
  { id: "react", name: ["Реактивные", "Reactive"] },
  { id: "special", name: ["Особые", "Special"] },
];

export function LightTab() {
  const t = useT();
  const lang = useLang();
  const mode = lighting.use((l) => l.mode);
  const color = lighting.use((l) => l.color);
  const micError = lighting.use((l) => l.micError);
  const speed = useSettings((s) => s.ledSpeed);
  const brightness = useSettings((s) => s.ledBrightness);
  const morse = useSettings((s) => s.morseText);
  const frames = sequencer.use((s) => s.frames);
  const [cat, setCat] = useState<LightCat | "all">("all");
  const current = LIGHT_MODES.find((m) => m.id === mode);
  const count = (c: LightCat | "all") => LIGHT_MODES.filter((m) => c === "all" || m.cat === c).length;
  const specials = LIGHT_SPECIALS.filter((m) => cat === "all" || m.cat === cat);
  const patterns = LIGHT_PATTERNS.filter((p) => cat === "all" || p.cat === cat);
  const setFrames = (f: typeof frames) => sequencer.set({ frames: f });
  const total = frames.reduce((n, f) => n + f.ms, 0);

  return (
    <div className="space-y-4">
      <Card
        title={t("Лаборатория света", "Light lab")}
        hint={t(`${LIGHT_MODES.length} эффектов · гамма-коррекция под светодиод`, `${LIGHT_MODES.length} effects · gamma-corrected for the LED`)}
        icon={Lightbulb}
        action={
          <div className="flex items-center gap-1.5">
            <Button size="icon" variant="ghost" title={t("Случайный", "Random")} onClick={() => startLight(LIGHT_MODES[Math.floor(Math.random() * LIGHT_MODES.length)].id)}>
              <Shuffle className="h-4 w-4" />
            </Button>
            <Chip tone={mode ? "signal" : "neutral"} onClick={mode ? () => stopLight() : undefined}>{current ? pick(current.name, lang) : t("выключено", "off")}</Chip>
          </div>
        }
      >
        <div className="flex flex-col gap-4 rounded-xl border border-line bg-panel-2 p-3 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <span className="h-11 w-11 shrink-0 rounded-xl border border-line transition-colors duration-100" style={{ backgroundColor: rgbToHex(color) }} />
            <div>
              <p className="text-sm font-semibold">{t("Сейчас на антенне", "On the antenna now")}</p>
              <p className="font-mono text-xs text-muted">{rgbToHex(color)}</p>
            </div>
          </div>
          <div className="grid flex-1 gap-x-6 sm:grid-cols-2">
            <Slider label={t("скорость", "speed")} value={speed} min={0.25} max={3} step={0.25} onChange={(v) => settings.set({ ledSpeed: v })} format={(v) => `×${v}`} />
            <Slider label={t("яркость", "brightness")} value={brightness} min={10} max={100} onChange={(v) => settings.set({ ledBrightness: v })} format={(v) => `${v}`} />
          </div>
        </div>
        <div className="no-scrollbar mt-4 flex gap-1.5 overflow-x-auto">
          {CATS.map((c) => (
            <button key={c.id} type="button" onClick={() => setCat(c.id)} className={cn("flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium", cat === c.id ? "border-invert bg-invert text-on-invert" : "border-line text-ink-2 hover:bg-panel-2")}>
              {pick(c.name, lang)} <span className="font-mono opacity-60">{count(c.id)}</span>
            </button>
          ))}
        </div>
        {micError && mode === "mic" && <Notice tone="flare" className="mt-3">{t("Нет доступа к микрофону: ", "No microphone access: ")}{micError}</Notice>}
        <div className="mt-3 grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-4">
          {specials.map((m) => {
            const Icon = SPECIAL_ICONS[m.id] ?? Sparkles;
            return (
              <button key={m.id} type="button" onClick={() => startLight(m.id)} className={cn("flex flex-col gap-2 rounded-xl border p-3 text-left transition-colors", mode === m.id ? "border-signal bg-signal-dim" : "border-line bg-panel-2 hover:border-signal/50")}>
                <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-line bg-panel text-signal">
                  <Icon className="h-4 w-4" />
                </span>
                <span className="text-sm font-medium text-ink">{pick(m.name, lang)}</span>
                <span className="text-[11px] leading-snug text-muted">{pick(m.desc, lang)}</span>
                {m.danger && <Chip tone="amber" className="self-start">{t("осторожно", "caution")}</Chip>}
              </button>
            );
          })}
          {patterns.map((p) => {
            const Icon = PATTERN_ICONS[p.id] ?? Sparkles;
            const active = mode?.startsWith(`${p.id}-`);
            return (
              <div key={p.id} className={cn("flex flex-col gap-2 rounded-xl border p-3", active ? "border-signal bg-signal-dim" : "border-line bg-panel-2")}>
                <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-line bg-panel text-signal">
                  <Icon className="h-4 w-4" />
                </span>
                <span className="text-sm font-medium text-ink">{pick(p.name, lang)}</span>
                <span className="text-[11px] leading-snug text-muted">{pick(p.desc, lang)} · {t("10 палитр", "10 palettes")}</span>
                <div className="flex flex-wrap gap-1">
                  {LIGHT_PALETTES.map((pal) => {
                    const id = `${p.id}-${pal.id}`;
                    return (
                      <button key={pal.id} type="button" title={pick(pal.name, lang)} onClick={() => startLight(id)} className={cn("h-5 w-5 rounded-full border-2 transition-transform hover:scale-110", mode === id ? "border-ink" : "border-panel")} style={{ background: pal.colors ? `conic-gradient(${pal.colors.map((c) => rgbToHex(c)).join(",")})` : "conic-gradient(red,yellow,lime,cyan,blue,magenta,red)" }} />
                    );
                  })}
                </div>
                {p.danger && <Chip tone="amber" className="self-start">{t("осторожно", "caution")}</Chip>}
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card title={t("Морзянка", "Morse code")} hint={t("Антенна выстукивает твой текст", "The antenna taps out your text")} icon={Hash}>
          <div className="flex gap-2">
            <input value={morse} onChange={(e) => settings.set({ morseText: e.target.value.slice(0, 40) })} className={cn(inputCls, "font-mono uppercase")} placeholder="SOS" />
            <Button variant="signal" onClick={() => startLight("morse")}>
              <Play className="h-4 w-4" />
              {t("Стучать", "Tap")}
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted">{t("Латиница, кириллица и цифры. Точка — короткая вспышка, тире — длинная.", "Latin, Cyrillic and digits. A dot is a short flash, a dash is a long one.")}</p>
        </Card>
        <Card title={t("Секвенсор света", "Light sequencer")} hint={`${frames.length} ${t("кадров", "frames")} · ${t("круг", "loop")} ${(total / 1000).toFixed(2)} ${t("с", "s")} · ${t("сохраняется в браузере", "saved in the browser")}`} icon={Rows3} action={<Button size="sm" variant="signal" onClick={() => startLight("sequencer")}><Play className="h-3.5 w-3.5" />{t("Крутить", "Run")}</Button>}>
          <div className="space-y-1.5">
            {frames.map((f, i) => (
              <div key={i} className="flex items-center gap-2 rounded-lg border border-line bg-panel-2 px-2 py-1.5">
                <span className="w-6 font-mono text-xs text-muted">{String(i + 1).padStart(2, "0")}</span>
                <input type="color" value={f.hex} onChange={(e) => setFrames(frames.map((x, j) => (j === i ? { ...x, hex: e.target.value } : x)))} className="h-7 w-9 cursor-pointer rounded border border-line bg-panel" />
                <span className="flex-1 font-mono text-xs uppercase">{f.hex}</span>
                <input type="number" min={40} max={5000} step={20} value={f.ms} onChange={(e) => setFrames(frames.map((x, j) => (j === i ? { ...x, ms: Math.max(40, Number(e.target.value) || 40) } : x)))} className="h-8 w-20 rounded-lg border border-line bg-panel px-2 font-mono text-xs" />
                <span className="text-[11px] text-muted">{t("мс", "ms")}</span>
                <button type="button" disabled={i === 0} onClick={() => { const n = [...frames]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; setFrames(n); }} className="p-1 text-faint hover:text-ink disabled:opacity-30"><ArrowUp className="h-3.5 w-3.5" /></button>
                <button type="button" disabled={i === frames.length - 1} onClick={() => { const n = [...frames]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; setFrames(n); }} className="p-1 text-faint hover:text-ink disabled:opacity-30"><ArrowDown className="h-3.5 w-3.5" /></button>
                <button type="button" disabled={frames.length <= 1} onClick={() => setFrames(frames.filter((_, j) => j !== i))} className="p-1 text-faint hover:text-flare disabled:opacity-30"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            ))}
          </div>
          <Button size="sm" className="mt-2" disabled={frames.length >= 16} onClick={() => setFrames([...frames, { hex: "#ffffff", ms: 300 }])}>
            <Plus className="h-3.5 w-3.5" />
            {t("Кадр", "Frame")}
          </Button>
        </Card>
      </div>
    </div>
  );
}

const GENRES: Record<string, Text> = {
  disco: ["ну-диско", "nu-disco"], city: ["синтвейв", "synthwave"], lofi: ["лоу-фай", "lo-fi"], quest: ["чиптюн", "chiptune"], cosmo: ["хаус", "house"], beach: ["регги-поп", "reggae pop"],
  rock: ["рок", "rock"], robots: ["электро", "electro"], garden: ["инди-поп", "indie pop"], neon: ["техно", "techno"], lullaby: ["колыбельная", "lullaby"], party: ["дэнс", "dance"],
};

function Visualizer({ active }: { active: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!active) return;
    const { analyser } = audio();
    const data = new Uint8Array(analyser.frequencyBinCount);
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const c = ref.current;
      if (!c) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      if (c.width !== c.clientWidth * dpr) {
        c.width = c.clientWidth * dpr;
        c.height = c.clientHeight * dpr;
      }
      const ctx = c.getContext("2d")!;
      analyser.getByteFrequencyData(data);
      ctx.clearRect(0, 0, c.width, c.height);
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--signal").trim() || "#0f9b8e";
      const n = 48;
      const bw = c.width / n;
      for (let i = 0; i < n; i++) {
        const v = data[Math.floor((i * data.length) / n / 1.6)] / 255;
        const bh = Math.max(2 * dpr, v * c.height);
        ctx.fillRect(i * bw + dpr, c.height - bh, bw - 2 * dpr, bh);
      }
    };
    draw();
    return () => cancelAnimationFrame(raf);
  }, [active]);
  return <canvas ref={ref} className="h-16 w-full" />;
}

const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

export function MusicTab() {
  const t = useT();
  const lang = useLang();
  const current = music.use((m) => m.current);
  const playing = music.use((m) => m.playing);
  const files = music.use((m) => m.files);
  const position = music.use((m) => m.position);
  const duration = music.use((m) => m.duration);
  const beat = music.use((m) => m.beat);
  const dance = useSettings((s) => s.dance);
  const danceEvery = useSettings((s) => s.danceEvery);
  const volume = useSettings((s) => s.musicVolume);
  const loop = useSettings((s) => s.musicLoop);
  const beatLight = useSettings((s) => s.beatLight);
  const dancing = useFurby((s) => s.dancing);
  const ready = useFurby((s) => s.status === "ready");
  const [drag, setDrag] = useState(false);
  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDrag(false);
    if (e.dataTransfer.files.length) void addFiles(e.dataTransfer.files);
  };
  return (
    <div className="space-y-4">
      <Card title={t("Музыкальная дека", "Music deck")} icon={Disc3} action={<Chip tone={dancing ? "signal" : "neutral"}><span className={cn("h-1.5 w-1.5 rounded-full", beat > 0.5 ? "bg-signal" : "bg-line-strong")} />{dancing ? t("Ферби танцует", "Furby is dancing") : t("бит", "beat")}</Chip>}>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="min-w-0 flex-1">
            <p className="font-display text-2xl font-bold">{current ? pick(current.name, lang) : t("Включи музыку", "Turn on the music")}</p>
            <p className="mt-1 text-sm text-muted">{t("Встроенные треки или свой файл. Ферби танцует по input 18 без остановки, пока играет музыка.", "Built-in tracks or your own file. Furby dances on input 18 non-stop while the music plays.")}</p>
          </div>
          {playing ? (
            <Button variant="primary" size="lg" onClick={() => stopMusic()}>
              <Square className="h-4 w-4" />
              {t("Стоп", "Stop")}
            </Button>
          ) : (
            <Button variant="signal" size="lg" onClick={() => playBuiltin(BUILTIN[0].id)}>
              <Play className="h-4 w-4" />
              {t("Играть", "Play")}
            </Button>
          )}
        </div>
        <div className="mt-4 rounded-xl border border-line bg-panel-2 p-2">
          <Visualizer active={playing} />
        </div>
        {current?.kind === "file" && duration > 0 && (
          <div className="mt-2 flex items-center gap-2 font-mono text-xs text-muted">
            {fmt(position)}
            <input type="range" min={0} max={duration} step={0.5} value={position} onChange={(e) => seek(Number(e.target.value))} className="flex-1" />
            {fmt(duration)}
          </div>
        )}
        <div className="mt-2 grid gap-x-6 sm:grid-cols-2">
          <Toggle checked={dance} onChange={setDance} label={t("Танец включён", "Dance is on")} hint={t("Ферби слушает музыку без остановки", "Furby listens to the music non-stop")} />
          <Slider label={t("Громкость", "Volume")} value={Math.round(volume * 100)} min={0} max={100} onChange={(v) => settings.set({ musicVolume: v / 100 })} format={(v) => `${v}`} />
        </div>
        {!ready && <p className="mt-1 text-xs text-muted">{t("Музыка играет и без игрушки, но чтобы Ферби танцевал — подключи его или включи демо-режим.", "Music plays without the toy, but for Furby to dance connect it or turn on demo mode.")}</p>}
      </Card>

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <Card title={t("Плейлист", "Playlist")} hint={t("Синтезируются прямо в браузере — никаких файлов", "Synthesised right in the browser — no files")} icon={ListMusic} flush>
          <ul className="divide-y divide-line">
            {BUILTIN.map((tr, i) => {
              const on = playing && current?.id === tr.id;
              return (
                <li key={tr.id}>
                  <button type="button" onClick={() => (on ? stopMusic() : playBuiltin(tr.id))} className={cn("flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-panel-2", on && "bg-signal-dim")}>
                    <span className="w-6 font-mono text-xs text-muted">{String(i + 1).padStart(2, "0")}</span>
                    {on ? <Pause className="h-4 w-4 text-signal" /> : <Play className="h-4 w-4 text-faint" />}
                    <span className="min-w-0 flex-1">
                      <span className={cn("block truncate text-sm font-medium", on && "text-signal")}>{pick(tr.name, lang)}</span>
                      <span className="block text-xs text-muted">{pick(GENRES[tr.id] ?? ["", ""], lang)}</span>
                    </span>
                    <span className="font-mono text-xs text-muted">{tr.spec.bpm}</span>
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="border-t border-line p-4">
            <label
              onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
              onDragLeave={() => setDrag(false)}
              onDrop={onDrop}
              className={cn("flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed px-4 py-5 text-center transition-colors", drag ? "border-signal bg-signal-dim" : "border-line-strong hover:bg-panel-2")}
            >
              <Upload className="h-5 w-5 text-muted" />
              <span className="text-sm text-ink">{t("Перетащи свой mp3 / wav — или выбери файл", "Drop your mp3 / wav — or pick a file")}</span>
              <span className="text-xs text-muted">{t("Файлы сохраняются в браузере и остаются после перезагрузки", "Files are stored in the browser and stay after reloading")}</span>
              <input type="file" accept="audio/*" multiple className="hidden" onChange={(e) => { if (e.target.files?.length) void addFiles(e.target.files); e.target.value = ""; }} />
            </label>
            {files.length > 0 && (
              <ul className="mt-3 divide-y divide-line">
                {files.map((f) => {
                  const on = playing && current?.id === f.id;
                  return (
                    <li key={f.id} className="flex items-center gap-2 py-2">
                      <Button size="sm" variant={on ? "soft" : "secondary"} onClick={() => (on ? stopMusic() : void playFile(f.id))}>
                        {on ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                      </Button>
                      <span className="min-w-0 flex-1 truncate text-sm">{f.name}</span>
                      <span className="font-mono text-[11px] text-muted">{(f.size / 1048576).toFixed(1)} MB</span>
                      <button type="button" onClick={() => void removeFile(f.id)} className="p-1.5 text-faint hover:text-flare" aria-label={t("Удалить", "Delete")}>
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
            <Toggle checked={loop} onChange={(v) => settings.set({ musicLoop: v })} label={t("Повторять свой трек", "Loop your track")} />
          </div>
        </Card>

        <div className="space-y-4">
          <Card title={t("Танец по input 18", "Dance on input 18")} hint={t("Ферби слушает музыку и реагирует без остановки", "Furby hears the music and reacts non-stop")} icon={Music2}>
            <p className="text-xs leading-relaxed text-muted">{t("Всегда уходит точный экшен 18/0/0/1. Следующая команда отправляется сразу, как игрушка договорила, поэтому танец не прерывается, пока играет трек. После «Стоп» танец гасится.", "The exact action 18/0/0/1 is always sent. The next one goes as soon as the toy finishes, so the dance never stops while a track plays. “Stop” ends it.")}</p>
            <p className="mt-2 rounded-lg bg-panel-2 px-3 py-2 font-mono text-xs text-ink">13 00 12 00 00 01</p>
            <Slider label={t("Повтор не реже чем", "Repeat at least every")} value={danceEvery} min={2} max={10} onChange={(v) => settings.set({ danceEvery: v })} format={(v) => `${v} ${t("с", "s")}`} />
            <div className="flex flex-wrap gap-2">
              <Button size="sm" disabled={!ready} onClick={() => setMoodValue(0, 100)}>{t("Настроение на максимум", "Max excitement")}</Button>
              <Button size="sm" disabled={!ready} onClick={() => furby.action(18, 0, 0, 1)}>{t("Ещё танца", "More dance")}</Button>
            </div>
          </Card>
          <Card title={t("Свет в такт", "Light to the beat")} hint={t("Антенна мигает с битом трека", "The antenna flashes with the beat")} icon={Lightbulb}>
            <Toggle checked={beatLight} onChange={(v) => settings.set({ beatLight: v })} label={t("Вспышка акцентным цветом на каждый бит", "Accent flash on every beat")} />
            <div className="mt-2 flex flex-wrap gap-2">
              <Button size="sm" onClick={() => startLight("music")}>
                <Disc3 className="h-3.5 w-3.5" />
                {t("Свет под музыку", "Music light")}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => stopLight()}>{t("Погасить", "Turn off")}</Button>
            </div>
          </Card>
          {files.length === 0 && !playing && <Empty icon={Music2} title={t("Своих треков пока нет", "No tracks of your own yet")} text={t("Загрузи файл — он сохранится в этом браузере.", "Upload a file — it'll be saved in this browser.")} />}
          <Label>{t("громкость звуков и вибрация — в настройках", "sound volume and vibration are in Settings")}</Label>
        </div>
      </div>
    </div>
  );
}
