import { useEffect, useState } from "react";
import { Activity, Check, Circle, Play, Timer, X } from "lucide-react";
import { Button, Card, Empty, Label, Notice, Stat } from "@/components/ui";
import { commandTarget, furby } from "@/lib/furby/controller";
import { decodeSensors, type Touch } from "@/lib/furby/protocol";
import { useFurby } from "@/lib/furby/useFurby";
import { pick, useLang, useT, type Text } from "@/lib/i18n";
import { progress } from "@/lib/progress";
import { cn } from "@/utils/cn";

type Status = "idle" | "run" | "pass" | "fail" | "sent";
interface Result {
  ok: boolean;
  detail: string;
  manual?: boolean;
}
interface TestRow {
  id: string;
  name: Text;
  run: () => Promise<Result>;
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

const sensorTouch = async (kind: Touch | "antenna-press"): Promise<Result> => {
  const p = furby.waitForPacket((d) => {
    const s = decodeSensors(d);
    if (!s) return false;
    return kind === "antenna-press" ? s.pressed : s.touches.includes(kind as Touch);
  }, 10000);
  const d = await p;
  return d ? { ok: true, detail: "датчик сработал" } : { ok: false, detail: "за 10 с не сработал" };
};

const TESTS: TestRow[] = [
  {
    id: "keepalive",
    name: ["Отклик ImHere (20 06 → 0x22)", "ImHere reply (20 06 → 0x22)"],
    run: async () => {
      const t0 = performance.now();
      const p = furby.waitForPacket((d) => d[0] === 0x22, 2000);
      furby.sendRaw([0x20, 0x06]);
      const d = await p;
      return d ? { ok: true, detail: `${Math.round(performance.now() - t0)} мс` } : { ok: false, detail: "нет ответа за 2 с" };
    },
  },
  {
    id: "action",
    name: ["Экшен 0x13 → SequencePlaying", "Action 0x13 → SequencePlaying"],
    run: async () => {
      const p = furby.waitForPacket((d) => d[0] === 0x20 && d[1] === 0x0c, 3000);
      furby.action(55, 2, 14, 0);
      const d = await p;
      return d ? { ok: true, detail: "0x20:0x0c получен, игрушка засмеялась" } : { ok: false, detail: "нет 0x20:0x0c за 3 с" };
    },
  },
  {
    id: "lcd",
    name: ["Подсветка глаз 0xCD", "LCD backlight 0xCD"],
    run: async () => {
      const prev = furby.getState().eyes;
      const p = furby.waitForPacket((d) => d[0] === 0x20 && d[1] === 0x17, 2000);
      furby.setEyes(true);
      const d = await p;
      if (!prev) furby.setEyes(false);
      return d ? { ok: true, detail: "0x20:0x17 получен" } : { ok: false, detail: "нет подтверждения" };
    },
  },
  {
    id: "telemetry",
    name: ["Поток датчиков 0x21", "Sensor stream 0x21"],
    run: async () => {
      furby.setSensorStream(true, true);
      await wait(300);
      const n = await furby.countPackets((d) => d[0] === 0x21, 2000);
      furby.setSensorStream(false, true);
      return n >= 3 ? { ok: true, detail: `${n} пакетов за 2 с` } : { ok: false, detail: `только ${n} пакетов за 2 с` };
    },
  },
  {
    id: "firmware",
    name: ["Версия прошивки 0xFE", "Firmware version 0xFE"],
    run: async () => {
      const p = furby.waitForPacket((d) => d[0] === 0xfe, 2000);
      furby.readFirmware();
      const d = await p;
      return d ? { ok: true, detail: `GP 0x${d[1].toString(16)}` } : { ok: false, detail: "нет ответа" };
    },
  },
  {
    id: "antenna",
    name: ["Антенна RGB 0x14", "Antenna RGB 0x14"],
    run: async () => {
      furby.setLedFrame([255, 0, 0], true);
      await wait(550);
      furby.setLedFrame([0, 0, 0], true);
      return { ok: true, detail: "красная вспышка — подтверди глазами", manual: true };
    },
  },
  {
    id: "mood",
    name: ["Настроение 0x23", "Mood meter 0x23"],
    run: async () => {
      furby.setMood(4, 90);
      return { ok: true, detail: "проверь дебаг-экран «Настроение»", manual: true };
    },
  },
  {
    id: "debug",
    name: ["Дебаг-меню 0xDB", "Debug menu 0xDB"],
    run: async () => {
      furby.debugOpen();
      await wait(500);
      furby.debugClose(7);
      return { ok: true, detail: "глаза мигнули меню и вернулись", manual: true };
    },
  },
  {
    id: "sensors",
    name: ["Датчики в реальном времени", "Live sensors"],
    run: async () => {
      furby.setSensorStream(true, true);
      await wait(400);
      const s = furby.getState().sensors;
      furby.setSensorStream(false, true);
      return s ? { ok: true, detail: `пакет ${s.raw}` } : { ok: false, detail: "нет пакета 0x21" };
    },
  },
  {
    id: "motor",
    name: ["Моторы — Фёрби пошевелится", "Motors — Furby will move"],
    run: async () => {
      const p = furby.waitForPacket((d) => d[0] === 0x20 && d[1] === 0x0c, 3000);
      furby.action(9, 0, 0, 3);
      const d = await p;
      return d ? { ok: true, detail: "SequencePlaying — смотри, шевелится ли", manual: true } : { ok: false, detail: "нет отклика за 3 с" };
    },
  },
  {
    id: "speaker",
    name: ["Динамик — Фёрби пропоёт", "Speaker — Furby sings"],
    run: async () => {
      const p = furby.waitForPacket((d) => d[0] === 0x20 && d[1] === 0x07, 6000);
      furby.action(17, 0, 0, 0);
      const d = await p;
      return d ? { ok: true, detail: "SpeechPlaying — слышишь голос?", manual: true } : { ok: false, detail: "нет SpeechPlaying за 6 с" };
    },
  },
  {
    id: "colors",
    name: ["Антенна: красный → зелёный → синий → белый", "Antenna: red → green → blue → white"],
    run: async () => {
      const seq: Array<[number, number, number]> = [[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 255]];
      for (const c of seq) {
        furby.setLedFrame(c, true);
        await wait(700);
      }
      furby.setLedFrame([0, 0, 0], true);
      return { ok: true, detail: "4 цвета по 0.7 с — подтверди глазами", manual: true };
    },
  },
  {
    id: "tongue",
    name: ["Клюв: нажми язык", "Beak: press the tongue"],
    run: () => sensorTouch("tongue"),
  },
  {
    id: "tail",
    name: ["Хвост: дёрни за хвост", "Tail: pull it"],
    run: () => sensorTouch("tail"),
  },
  {
    id: "head",
    name: ["Голова: погладь затылок", "Head: pet the back of the head"],
    run: () => sensorTouch("head"),
  },
  {
    id: "antpress",
    name: ["Антенна: надави вниз", "Antenna: press it down"],
    run: () => sensorTouch("antenna-press"),
  },
  {
    id: "tilt",
    name: ["Акселерометр: наклони Фёрби", "Accelerometer: tilt Furby"],
    run: async () => {
      const p = furby.waitForPacket((d) => {
        const s = decodeSensors(d);
        return !!s && s.orientation !== "upright" && s.orientation !== "unknown";
      }, 10000);
      const d = await p;
      return d ? { ok: true, detail: "наклон зарегистрирован" } : { ok: false, detail: "за 10 с наклонов не было" };
    },
  },
  {
    id: "beak",
    name: ["Клюв: потрогай клюв сбоку", "Beak: touch the beak"],
    run: () => sensorTouch("sideL"),
  },
];

const STATUS_STYLE: Record<Status, string> = {
  idle: "text-faint",
  run: "text-amber animate-pulse",
  pass: "text-signal",
  fail: "text-flare",
  sent: "text-amber",
};

function StatusIcon({ status }: { status: Status }) {
  if (status === "pass") return <Check className="h-4 w-4 text-signal" />;
  if (status === "fail") return <X className="h-4 w-4 text-flare" />;
  if (status === "sent") return <Circle className="h-4 w-4 text-amber" />;
  if (status === "run") return <Circle className="h-4 w-4 animate-pulse text-amber" />;
  return <Circle className="h-3 w-3 text-faint" />;
}

export function DiagnosticsTab() {
  const t = useT();
  // tests always talk to the primary toy, whatever the command target is
  useEffect(() => {
    const prev = commandTarget.get().target;
    commandTarget.set({ target: "all" });
    return () => commandTarget.set({ target: prev });
  }, []);
  const lang = useLang();
  const ready = useFurby((s) => s.status === "ready");
  const [rows, setRows] = useState<Record<string, { status: Status; detail: string }>>({});
  const [busy, setBusy] = useState(false);
  const [pings, setPings] = useState<number[]>([]);
  const [pingBusy, setPingBusy] = useState(false);

  const runOne = async (test: TestRow) => {
    setRows((r) => ({ ...r, [test.id]: { status: "run", detail: "" } }));
    try {
      const res = await test.run();
      setRows((r) => ({ ...r, [test.id]: { status: res.manual ? "sent" : res.ok ? "pass" : "fail", detail: res.detail } }));
    } catch (e) {
      setRows((r) => ({ ...r, [test.id]: { status: "fail", detail: e instanceof Error ? e.message : String(e) } }));
    }
  };

  const runAll = async () => {
    if (busy) return;
    setBusy(true);
    const wasTelemetry = furby.getState().telemetry;
    for (const test of TESTS) await runOne(test);
    if (wasTelemetry) furby.setSensorStream(true, true);
    setBusy(false);
  };

  const runPings = async () => {
    if (pingBusy) return;
    setPingBusy(true);
    const out: number[] = [];
    for (let i = 0; i < 5; i++) {
      const ms = await furby.ping();
      if (ms !== null) out.push(ms);
      await wait(160);
    }
    setPings(out);
    progress.bump("pings");
    setPingBusy(false);
  };

  const avg = pings.length ? Math.round(pings.reduce((a, b) => a + b, 0) / pings.length) : null;
  const verdict =
    avg === null ? null : avg <= 100 ? { text: t("отлично", "excellent"), tone: "text-signal" } : avg <= 250 ? { text: t("норма", "fine"), tone: "text-signal" } : avg <= 500 ? { text: t("слабый сигнал", "weak signal"), tone: "text-amber" } : { text: t("плохо", "poor"), tone: "text-flare" };

  return (
    <div className="space-y-4">
      <Card title={t("Задержка игрушка → сайт", "Latency toy → site")} hint={t("ImHere ping: 20 06 → 0x22, норма BLE 30–200 мс", "ImHere ping: 20 06 → 0x22, BLE norm is 30–200 ms")} icon={Timer}>
        <div className="flex flex-wrap items-center gap-4">
          <div className="text-center">
            <p className={cn("font-display text-5xl font-bold tabular-nums", verdict?.tone ?? "text-faint")}>{avg === null ? "—" : avg}</p>
            <Label>{t("средняя, мс", "average, ms")}</Label>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Stat label={t("лучший", "best")} value={pings.length ? Math.min(...pings) : "—"} />
            <Stat label={t("худший", "worst")} value={pings.length ? Math.max(...pings) : "—"} />
            <Stat label={t("ответов", "replies")} value={`${pings.length}/5`} />
            <Stat label={t("оценка", "verdict")} value={verdict ? verdict.text : "—"} />
          </div>
          <Button variant="signal" disabled={!ready || pingBusy} onClick={() => void runPings()}>
            <Timer className="h-4 w-4" />
            {pingBusy ? t("Меряем…", "Measuring…") : t("Замерить (5 пингов)", "Measure (5 pings)")}
          </Button>
        </div>
        {pings.length > 0 && <p className="mt-3 font-mono text-xs text-muted">{pings.join(" · ")} {t("мс", "ms")}</p>}
      </Card>

      <Card
        title={t("Тесты функций", "Function tests")}
        hint={t("Каждая функция проверяется по подтверждению от игрушки", "Every function is checked by the toy's reply")}
        icon={Activity}
        action={
          <Button variant="primary" size="sm" disabled={!ready || busy} onClick={() => void runAll()}>
            <Play className="h-3.5 w-3.5" />
            {busy ? t("Идёт…", "Running…") : t("Запустить все", "Run all")}
          </Button>
        }
      >
        <Notice tone="amber">
          {t("Тесты издают звуки и двигают Фёрби. Датчики (клюв, хвост, голова, антенна, наклон) ждут твоего действия до 10 с — в демо их нажимают в панели с датчиками. Ручные пункты подтверждаешь глазами; поток датчиков включится обратно, если был включён.", "The tests make sounds and move Furby. Sensor tests (beak, tail, head, antenna, tilt) wait up to 10 s for your action — in demo mode use the sensor panel. Manual items are confirmed by eye; the sensor stream is re-enabled if it was on.")}
        </Notice>
        <ul className="mt-3 divide-y divide-line">
          {TESTS.map((test) => {
            const r = rows[test.id];
            return (
              <li key={test.id} className="flex items-center gap-3 py-2.5">
                <StatusIcon status={r?.status ?? "idle"} />
                <span className="min-w-0 flex-1">
                  <span className="block text-sm text-fg">{pick(test.name, lang)}</span>
                  {r?.detail && <span className="block truncate text-xs text-muted">{r.detail}</span>}
                </span>
                <span className={cn("font-mono text-[11px] uppercase", STATUS_STYLE[r?.status ?? "idle"])}>
                  {r?.status === "run" ? t("…", "…") : r?.status === "pass" ? t("ок", "ok") : r?.status === "fail" ? t("ошибка", "fail") : r?.status === "sent" ? t("ручной", "manual") : ""}
                </span>
                <Button size="sm" variant="ghost" disabled={!ready || busy} onClick={() => void runOne(test)}>
                  <Play className="h-3.5 w-3.5" />
                </Button>
              </li>
            );
          })}
        </ul>
      </Card>

      {!ready && <Empty icon={Activity} title={t("Игрушка не подключена", "Furby is not connected")} text={t("Подключись во вкладке «Пульт», чтобы прогнать тесты.", "Connect on the Remote tab to run the tests.")} />}
    </div>
  );
}

