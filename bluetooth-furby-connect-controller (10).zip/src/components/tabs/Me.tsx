import type { ChangeEvent, ReactNode } from "react";
import { Bot, ChartColumn, CircleHelp, Code, ExternalLink, Gamepad2, ListChecks, Lock, RotateCcw, Send, Sparkles, Trophy, Users, Languages } from "lucide-react";
import { Button, Card, Chip, Empty, Label, Notice, Progress, Segmented, Slider, Stat, Toggle, inputCls } from "@/components/ui";
import { TELEGRAM_URL, TIKTOK_URL, TestedNotice } from "@/components/Modals";
import { GAMES } from "@/games/registry";
import { removeFull } from "@/lib/actions/catalog";
import { clearFiles } from "@/lib/audio/music";
import { sfx } from "@/lib/audio/synth";
import { idbClear } from "@/lib/idb";
import { furby } from "@/lib/furby/controller";
import { LIGHT_MODES } from "@/lib/furby/lighting";
import { LANGS, pick, useLang, useT, type Lang } from "@/lib/i18n";
import { ACHIEVEMENTS, RANKS, levelOf, progress, progressStore, rankOf, todayQuests, xpFor } from "@/lib/progress";
import { askAI } from "@/lib/smart";
import { ACCENTS, DEFAULT_SETTINGS, settings, useSettings, type AiProvider, type Density, type Settings, type Theme, type TouchControls } from "@/lib/settings";
import { toast } from "@/lib/toast";
import { cn } from "@/utils/cn";

export function ProgressTab() {
  const t = useT();
  const lang = useLang();
  const p = progressStore.use((s) => s);
  const level = levelOf(p.xp);
  const rank = rankOf(level);
  const nextXp = xpFor(level + 1);
  const curXp = xpFor(level);
  const quests = todayQuests();
  const days = Array.from({ length: 7 }, (_, i) => new Date(Date.now() - (6 - i) * 864e5));
  const dayXp = days.map((d) => p.xpDays[d.toISOString().slice(0, 10)] ?? 0);
  const maxDay = Math.max(1, ...dayXp);
  const fav = GAMES.filter((g) => (p.plays[g.id] ?? 0) > 0).sort((a, b) => (p.plays[b.id] ?? 0) - (p.plays[a.id] ?? 0)).slice(0, 6);
  const unlocked = ACHIEVEMENTS.filter((a) => p.unlocked[a.id]).length;
  return (
    <div className="space-y-4">
      <Card title={t("Твой ранг", "Your rank")} hint={t("Опыт капает за команды, игры, реплики и ачивки", "XP comes from commands, games, phrases and achievements")} icon={Trophy} action={<Chip tone="amber">{t("серия", "streak")} {p.streak} {t("дн.", "d")}</Chip>}>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-4">
            <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full border-4 border-signal font-display text-3xl font-bold">{level}</span>
            <div>
              <p className="flex items-center gap-2 font-display text-2xl font-bold"><rank.icon className="h-6 w-6 text-signal" />{pick(rank.name, lang)}</p>
              <p className="text-sm text-muted">{p.xp} XP {t("всего", "total")} · {t("до уровня", "to level")} {level + 1} {t("осталось", "left")} {nextXp - p.xp} XP</p>
            </div>
          </div>
          <div className="flex-1">
            <Progress value={(p.xp - curXp) / (nextXp - curXp)} />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {RANKS.map((r) => (
            <Chip key={r.min} tone={level >= r.min ? "signal" : "neutral"}>
              <r.icon className="h-3 w-3" />
              {pick(r.name, lang)} <span className="font-mono opacity-60">{r.min}</span>
            </Chip>
          ))}
        </div>
      </Card>
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title={t("Задания дня", "Daily quests")} hint={t("Обновляются каждый день, награда — опыт", "Refreshed daily, rewarded with XP")} icon={ListChecks} action={<Chip>{p.daily.done.length}/3</Chip>}>
          <div className="space-y-2.5">
            {quests.map((q) => {
              const v = Math.min(q.goal, p.daily.counts[q.counter] ?? 0);
              const done = p.daily.done.includes(q.id);
              return (
                <div key={q.id} className={cn("rounded-xl border p-3", done ? "border-signal/40 bg-signal-dim" : "border-line bg-panel-2")}>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium">{pick(q.text, lang)}</p>
                    <Chip tone={done ? "signal" : "amber"}>+{q.reward} XP</Chip>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Progress value={v / q.goal} className="flex-1" />
                    <span className="font-mono text-[11px] text-muted">{v}/{q.goal}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
        <Card title={t("Активность за неделю", "Weekly activity")} hint={t("Опыт по дням", "XP per day")} icon={ChartColumn}>
          <div className="flex h-40 items-end gap-2">
            {dayXp.map((v, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1">
                <span className="font-mono text-[10px] text-muted">{v || ""}</span>
                <div className="w-full rounded-t-md bg-signal/80" style={{ height: `${(v / maxDay) * 100}%`, minHeight: v ? 4 : 2, opacity: v ? 1 : 0.25 }} />
                <span className="text-[10px] text-muted">{days[i].toLocaleDateString(lang === "en" ? "en-GB" : "ru-RU", { weekday: "short" })}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            <Chip>{t("дней в истории", "days in history")}: {Object.keys(p.xpDays).length}</Chip>
            <Chip>{t("ачивок", "achievements")} {unlocked}/{ACHIEVEMENTS.length}</Chip>
          </div>
        </Card>
      </div>
      <Card title={t("Любимые игры", "Favourite games")} hint={t("По числу партий и рекордам", "By rounds played and records")} icon={Gamepad2}>
        {fav.length === 0 ? (
          <Empty icon={Gamepad2} title={t("Сыграй первую партию", "Play your first round")} text={t("Здесь появится твоя статистика.", "Your stats will show up here.")} />
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {fav.map((g) => (
              <div key={g.id} className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 p-3">
                <g.icon className="h-5 w-5 text-signal" />
                <span className="min-w-0 flex-1 truncate text-sm font-medium">{pick(g.name, lang)}</span>
                <span className="font-mono text-[11px] text-muted">×{p.plays[g.id]} · {p.bests[g.id] ?? 0}</span>
              </div>
            ))}
          </div>
        )}
      </Card>
      <Card title={`${t("Достижения", "Achievements")} · ${unlocked}/${ACHIEVEMENTS.length}`} icon={Sparkles}>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-4">
          {ACHIEVEMENTS.map((a) => {
            const done = !!p.unlocked[a.id];
            return (
              <div key={a.id} className={cn("flex flex-col items-center gap-1.5 rounded-xl border p-3 text-center", done ? "border-signal/40 bg-signal-dim" : "border-dashed border-line opacity-60")}>
                <span className={cn("flex h-9 w-9 items-center justify-center rounded-full border", done ? "border-signal text-signal" : "border-line text-faint")}>{done ? <a.icon className="h-4 w-4" /> : <Lock className="h-4 w-4" />}</span>
                <span className="text-xs font-semibold">{pick(a.name, lang)}</span>
                <span className="text-[11px] leading-snug text-muted">{pick(a.desc, lang)}</span>
              </div>
            );
          })}
        </div>
      </Card>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label={t("команд", "commands")} value={p.stats.commands} />
        <Stat label={t("партий", "rounds")} value={p.stats.gamesPlayed} />
        <Stat label={t("реплик", "phrases")} value={p.stats.phrases} />
        <Stat label={t("минут игр", "game minutes")} value={Math.floor(p.stats.playSeconds / 60)} />
      </div>
      <Button variant="danger" onClick={() => window.confirm(t("Сбросить весь прогресс, рекорды и кликер?", "Reset all progress, records and the clicker?")) && progress.reset()}>
        <RotateCcw className="h-4 w-4" />
        {t("Сбросить прогресс", "Reset progress")}
      </Button>
    </div>
  );
}

function Group({ title, hint, icon, children }: { title: string; hint?: string; icon?: typeof Trophy; children: ReactNode }) {
  return (
    <Card title={title} hint={hint} icon={icon}>
      <div className="divide-y divide-line">{children}</div>
    </Card>
  );
}
function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="space-y-2 py-2.5">
      <div>
        <p className="text-sm text-ink">{label}</p>
        {hint && <p className="text-xs text-muted">{hint}</p>}
      </div>
      {children}
    </div>
  );
}

export function SettingsTab() {
  const t = useT();
  const lang = useLang();
  const s = useSettings((x) => x);
  const set = (patch: Partial<Settings>) => settings.set(patch);
  const testAI = async () => {
    try {
      const r = await askAI("Reply with one word.", "Say OK");
      toast(t("ИИ отвечает", "AI responds"), r.slice(0, 60));
    } catch (e) {
      toast(t("Ошибка ИИ", "AI error"), e instanceof Error ? e.message : String(e), undefined, "err");
    }
  };
  const exportSettings = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify({ ...s, aiKey: "" }, null, 2)], { type: "application/json" }));
    a.download = "furby-deck-settings.json";
    a.click();
  };
  const importSettings = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    try {
      settings.set(JSON.parse(await f.text()));
      toast(t("Настройки загружены", "Settings loaded"));
    } catch {
      toast(t("Не удалось прочитать файл", "Couldn't read the file"), undefined, undefined, "err");
    }
  };
  const wipe = async () => {
    if (!window.confirm(t("Стереть все данные пульта: настройки, прогресс, макросы, музыку?", "Erase all data: settings, progress, macros, music?"))) return;
    Object.keys(localStorage).filter((k) => k.startsWith("furby.")).forEach((k) => localStorage.removeItem(k));
    try {
      await idbClear();
    } catch {
      /* ignore */
    }
    location.reload();
  };
  return (
    <div className="space-y-4">
      <TestedNotice />
      <div className="grid items-start gap-4 xl:grid-cols-2">
        <Group title={t("Внешний вид", "Appearance")} hint={t("Тема, акцент и плотность интерфейса", "Theme, accent and density")} icon={Sparkles}>
          <Row label={t("Тема оформления", "Theme")} hint={t("Тёмная тема бережёт глаза ночью и экран телефона", "Dark theme is easier on the eyes at night")}>
            <Segmented<Theme> value={s.theme} onChange={(v) => set({ theme: v })} options={[{ value: "light", label: t("Светлая", "Light") }, { value: "dark", label: t("Тёмная", "Dark") }, { value: "system", label: t("Системная", "System") }]} />
          </Row>
          <Row label={t("Акцентный цвет", "Accent colour")} hint={t("Красит кнопки, графики и подсветку активных элементов", "Colours buttons, charts and active elements")}>
            <div className="flex flex-wrap gap-2">
              {ACCENTS.map((a) => (
                <button key={a.id} type="button" title={lang === "en" ? a.en : a.ru} onClick={() => set({ accent: a.hex })} className={cn("h-8 w-8 rounded-full border-2 transition-transform hover:scale-110", s.accent === a.hex ? "border-ink" : "border-panel")} style={{ backgroundColor: a.hex }} />
              ))}
            </div>
          </Row>
          <Row label={t("Плотность", "Density")} hint={t("Компактный режим уменьшает шрифт и отступы", "Compact mode shrinks text and spacing")}>
            <Segmented<Density> value={s.density} onChange={(v) => set({ density: v })} options={[{ value: "normal", label: t("Обычная", "Normal") }, { value: "compact", label: t("Компактная", "Compact") }]} />
          </Row>
          <Row
            label={t("Язык сайта", "Site language")}
            hint={
              s.langPicked
                ? t("Выбор закреплён вручную", "Pinned manually")
                : t("Определяется по браузеру автоматически — переключите вручную, чтобы закрепить", "Auto-detected from the browser — switch manually to pin it")
            }
          >
            <Segmented<Lang> value={s.lang} onChange={(v) => set({ lang: v, langPicked: true })} options={LANGS.map((l) => ({ value: l.id, label: l.name }))} />
          </Row>
          <Toggle checked={!s.reduceMotion} onChange={(v) => set({ reduceMotion: !v })} label={t("Анимации", "Animations")} hint={t("Выключи, если интерфейс должен быть максимально спокойным", "Turn off for a calmer interface")} />
          <Toggle checked={s.grid} onChange={(v) => set({ grid: v })} label={t("Фоновая сетка", "Background grid")} hint={t("Точечный паттерн на подложке", "Dotted pattern behind the content")} />
          <Row label={t("Экранные кнопки в играх", "On-screen game buttons")}>
            <Segmented<TouchControls> value={s.touchControls} onChange={(v) => set({ touchControls: v })} options={[{ value: "auto", label: t("Без Ферби", "Without Furby") }, { value: "always", label: t("Всегда", "Always") }, { value: "never", label: t("Никогда", "Never") }]} />
          </Row>
          <Slider label={t("Отступ снизу (значок хостинга)", "Bottom inset (hosting badge)")} value={s.bottomInset} min={0} max={160} step={8} onChange={(v) => set({ bottomInset: v })} format={(v) => `${v}px`} />
        </Group>

        <Group title={t("Голос Ферби", "Furby's voice")} hint={t("Пульт сам разговаривает с игрушкой, чтобы она не молчала", "The remote talks to the toy so it isn't silent")} icon={Users}>
          <div className="flex flex-wrap gap-2 py-2.5">
            <Button size="sm" disabled={!furby.connected} onClick={() => furby.sayRandom()}>{t("Проверить голос", "Test the voice")}</Button>
            <Button size="sm" variant={s.quietUntil > Date.now() ? "soft" : "secondary"} onClick={() => set({ quietUntil: s.quietUntil > Date.now() ? 0 : Date.now() + 300000 })}>{s.quietUntil > Date.now() ? t("Отменить тишину", "Cancel quiet") : t("Тихий час на 5 минут", "Quiet for 5 minutes")}</Button>
          </div>
          <Toggle checked={s.chatter} onChange={(v) => set({ chatter: v })} label={t("Болтовня при простое", "Idle chatter")} hint={t("Ферби сам подаёт голос, пока ты ничего не делаешь", "Furby speaks up while you're idle")} />
          <Slider label={t("Пауза между репликами", "Pause between phrases")} value={s.chatterEvery} min={10} max={120} step={5} onChange={(v) => set({ chatterEvery: v })} format={(v) => `${v} ${t("с", "s")}`} />
          <Toggle checked={s.reactions} onChange={(v) => set({ reactions: v })} label={t("Реакции на прикосновения", "Reactions to touch")} hint={t("Смеётся на щекотку, мурчит на поглаживание, охает на тряску", "Laughs at tickles, purrs at petting, yelps when shaken")} />
          <Toggle checked={s.reactTummy} onChange={(v) => set({ reactTummy: v })} label={t("Смеяться от щекотки живота", "Laugh at tummy tickles")} disabled={!s.reactions} />
          <Toggle checked={s.reactTongue} onChange={(v) => set({ reactTongue: v })} label={t("Реагировать на язык", "React to the tongue")} disabled={!s.reactions} />
          <Toggle checked={s.gameTalk} onChange={(v) => set({ gameTalk: v })} label={t("Комментарии в играх", "Game comments")} hint={t("Реплики на старт, попадание и победу — без болтовни по таймеру", "Lines on start, hits and wins — no timed chatter")} />
          <Toggle checked={s.talkOnEvents} onChange={(v) => set({ talkOnEvents: v })} label={t("Реплики на события сайта", "Lines on site events")} />
          <Toggle checked={s.chatterSilly} onChange={(v) => set({ chatterSilly: v })} label={t("Разрешить пуки и отрыжку", "Allow farts and burps")} />
          <Slider label={t("Касание засчитывается через", "Touch counts after")} value={s.touchHoldMs} min={100} max={1000} step={50} onChange={(v) => set({ touchHoldMs: v })} format={(v) => `${v} ${t("мс", "ms")}`} hint={t("Защищает от ложной «щекотки»", "Protects from false “tickles”")} />
          <Toggle checked={s.gateWhileMoving} onChange={(v) => set({ gateWhileMoving: v })} label={t("Не слушать датчики, пока Ферби двигается", "Ignore sensors while Furby moves")} />
        </Group>

        <Group title={t("Подключение", "Connection")} icon={Send}>
          <Toggle checked={s.telemetryOnConnect} onChange={(v) => set({ telemetryOnConnect: v })} label={t("Телеметрия сразу после коннекта", "Telemetry right after connecting")} hint={t("Включает поток 0x20:0x0D — нужен для правил и детектора тряски", "Turns on 0x20:0x0D — needed for rules and shake detection")} />
          <Toggle checked={s.antennaOffOnDisconnect} onChange={(v) => set({ antennaOffOnDisconnect: v })} label={t("Гасить антенну при отключении", "Turn off the antenna on disconnect")} />
          <Row label={t("Эффект при подключении", "Effect on connect")}>
            <select value={s.connectEffect} onChange={(e) => set({ connectEffect: e.target.value })} className={inputCls}>
              <option value="">{t("не запускать", "don't start")}</option>
              {LIGHT_MODES.filter((m) => m.group === "special").map((m) => <option key={m.id} value={m.id}>{pick(m.name, lang)}</option>)}
            </select>
          </Row>
          <Toggle checked={s.restoreLight} onChange={(v) => set({ restoreLight: v })} label={t("Вернуть последний режим света", "Restore the last light mode")} />
        </Group>

        <Group title={t("ИИ-помощник", "AI helper")} hint={t("Необязательно: поиск по смыслу и генерация игр на твоём ключе", "Optional: smart search and game generation with your key")} icon={Bot}>
          <p className="py-2.5 text-xs leading-relaxed text-muted">{t("Пульт полностью работает без ИИ. Ключ хранится только в этом браузере и уходит напрямую провайдеру, минуя любые наши серверы (их нет).", "The remote works fully without AI. The key stays in this browser and goes straight to the provider — there are no servers of ours.")}</p>
          <Row label={t("Провайдер", "Provider")}>
            <Segmented<AiProvider> value={s.aiProvider} onChange={(v) => set({ aiProvider: v })} options={[{ value: "anthropic", label: "Anthropic Claude" }, { value: "openai", label: "OpenAI" }]} />
          </Row>
          <Row label={t("Ключ API", "API key")}>
            <input type="password" value={s.aiKey} onChange={(e) => set({ aiKey: e.target.value.trim() })} placeholder={s.aiProvider === "openai" ? "sk-…" : "sk-ant-…"} className={cn(inputCls, "font-mono")} />
          </Row>
          <Row label={t("Модель (пусто = по умолчанию)", "Model (empty = default)")}>
            <input value={s.aiModel} onChange={(e) => set({ aiModel: e.target.value.trim() })} placeholder={s.aiProvider === "openai" ? "gpt-4o-mini" : "claude-haiku-4-5"} className={cn(inputCls, "font-mono")} />
          </Row>
          <div className="flex flex-wrap gap-2 py-2.5">
            <Button size="sm" disabled={!s.aiKey} onClick={() => void testAI()}>{t("Проверить связь", "Test connection")}</Button>
            <Button size="sm" variant="ghost" disabled={!s.aiKey} onClick={() => set({ aiKey: "" })}>{t("Стереть ключ", "Erase key")}</Button>
          </div>
        </Group>

        <Group title={t("Датчики и калибровка", "Sensors and calibration")} icon={Code}>
          <Slider label={t("Чувствительность тряски", "Shake sensitivity")} value={s.motionSensitivity} min={10} max={100} onChange={(v) => set({ motionSensitivity: v })} hint={t("Выше — легче поймать слабое покачивание", "Higher catches gentler shaking")} />
          <Slider label={t("Порог срабатывания", "Trigger threshold")} value={s.motionThreshold} min={10} max={95} onChange={(v) => set({ motionThreshold: v })} />
          <Slider label={t("Пауза между срабатываниями", "Pause between triggers")} value={s.motionCooldown} min={1} max={15} onChange={(v) => set({ motionCooldown: v })} format={(v) => `${v} ${t("с", "s")}`} />
          <Toggle checked={s.invertY} onChange={(v) => set({ invertY: v })} label={t("Инверсия вертикали антенны", "Invert antenna vertical")} hint={t("Если тянешь вперёд, а пульт показывает «назад ↓»", "If you push forward but it shows “back ↓”")} />
          <Toggle checked={s.invertX} onChange={(v) => set({ invertX: v })} label={t("Инверсия горизонтали антенны", "Invert antenna horizontal")} />
          <Toggle checked={s.tiltInvertX} onChange={(v) => set({ tiltInvertX: v })} label={t("Инверсия наклона для «Космоса»", "Invert tilt for Space")} />
          <Slider label={t("Чувствительность наклона в играх", "Tilt sensitivity in games")} value={s.tiltSensitivity} min={1} max={5} onChange={(v) => set({ tiltSensitivity: v })} />
          <Row label={t("Input октавы", "Octave input")} hint={t("На живых игрушках ноты в input 70, в доке bluefluff — 71", "On real toys notes are input 70, bluefluff docs say 71")}>
            <Segmented<number> value={s.octaveInput} onChange={(v) => set({ octaveInput: v })} options={[{ value: 70, label: "70" }, { value: 71, label: "71" }]} />
          </Row>
        </Group>

        <Group title={t("Отклик, свет и безопасность", "Feedback, light and safety")} icon={Lock}>
          <Toggle checked={s.toasts} onChange={(v) => set({ toasts: v })} label={t("Всплывающие уведомления", "Pop-up notifications")} />
          <Toggle checked={s.sfx} onChange={(v) => set({ sfx: v })} label={t("Звуковой отклик", "Sound feedback")} />
          <Slider label={t("Громкость звуков", "Sound volume")} value={Math.round(s.sfxVolume * 100)} min={0} max={100} onChange={(v) => set({ sfxVolume: v / 100 })} format={(v) => `${v}%`} />
          <div className="py-2"><Button size="sm" onClick={() => sfx("win")}>{t("Проверить звук", "Test sound")}</Button></div>
          <Toggle checked={s.vibrate} onChange={(v) => set({ vibrate: v })} label={t("Вибрация на телефоне", "Vibration on phones")} />
          <Toggle checked={s.voice} onChange={(v) => set({ voice: v })} label={t("Голос сайта", "Site voice")} hint={t("Озвучивает приказы в играх", "Reads game orders aloud")} />
          <Toggle checked={s.ledGamma} onChange={(v) => set({ ledGamma: v })} label={t("Коррекция цвета светодиода", "LED colour correction")} />
          <Toggle checked={s.gameLights} onChange={(v) => set({ gameLights: v })} label={t("Подсветка в играх", "Lights in games")} />
          <Toggle checked={s.safeMode} onChange={(v) => set({ safeMode: v })} label={t("Безопасный режим", "Safe mode")} hint={t("Блокирует запись и удаление DLC — самое опасное для прошивки", "Blocks writing and deleting DLC — the riskiest for firmware")} />
          <Toggle checked={s.confirmDanger} onChange={(v) => set({ confirmDanger: v })} label={t("Подтверждать опасные действия", "Confirm risky actions")} />
        </Group>

        <Group title={t("Рукопожатие антенной", "Antenna handshake")} hint={t("Обязательная проверка — отключить её нельзя", "Mandatory check — can't be turned off")} icon={Lock}>
          <div className="grid grid-cols-3 gap-2 py-2.5">
            <Stat label={t("поворотов", "turns")} value="6" />
            <Stat label={t("на попытку", "per try")} value={t("20 с", "20 s")} />
            <Stat label={t("при ошибке", "on error")} value={t("с нуля", "restart")} />
          </div>
          <p className="py-2.5 text-xs leading-relaxed text-muted">{t("Пульт генерирует случайную комбинацию из шести поворотов — влево, вправо, вперёд, назад. Нажатия вниз в комбинации нет и они игнорируются. Ошибся — комбинация начинается заново, таймер сбрасывается.", "The remote makes a random combination of six turns — left, right, forward, back. Presses aren't part of it and are ignored. A mistake restarts the combination and the timer.")}</p>
        </Group>

        <Group title={t("Данные", "Data")} hint={t("Всё хранится локально в браузере", "Everything is stored locally in the browser")} icon={RotateCcw}>
          <div className="flex flex-wrap gap-2 py-3">
            <Button size="sm" onClick={exportSettings}>{t("Выгрузить настройки", "Export settings")}</Button>
            <label className="inline-flex h-8 cursor-pointer items-center rounded-lg border border-line bg-panel px-3 text-xs font-medium hover:bg-panel-2">
              {t("Загрузить настройки", "Import settings")}
              <input type="file" accept="application/json" className="hidden" onChange={(e) => void importSettings(e)} />
            </label>
            <Button size="sm" onClick={() => removeFull()}>{t("Удалить полный список команд", "Remove the full command list")}</Button>
            <Button size="sm" onClick={() => void clearFiles()}>{t("Удалить загруженную музыку", "Delete uploaded music")}</Button>
            <Button size="sm" variant="danger" onClick={() => window.confirm(t("Сбросить настройки?", "Reset settings?")) && settings.set({ ...DEFAULT_SETTINGS, warningAccepted: true })}>{t("Сбросить настройки", "Reset settings")}</Button>
            <Button size="sm" variant="danger" onClick={() => void wipe()}>{t("Стереть все данные", "Erase all data")}</Button>
          </div>
        </Group>
      </div>
    </div>
  );
}

export function AboutTab() {
  const t = useT();
  const team = [
    { name: "@larpieeeeee", where: "TikTok", role: t("Идея, живые тесты на русском Ферби, постановка задач", "Idea, live tests on a Russian Furby, requirements"), url: TIKTOK_URL },
    { name: "@furbydeck", where: "Telegram", role: t("Канал проекта и сбор результатов тестов — сюда писать про английский Connect", "Project channel and test reports — write here about the English Connect"), url: TELEGRAM_URL },
    { name: "Claude", where: "Anthropic", role: t("ИИ-инженер пульта: протокол, интерфейс, игры, свет", "AI engineer of the remote: protocol, interface, games, light"), url: "https://www.anthropic.com/claude" },
  ];
  return (
    <div className="space-y-4">
      <Card title={t("О проекте", "About")} icon={CircleHelp}>
        <p className="font-display text-3xl font-bold">FURBY<span className="text-signal">·</span>DECK</p>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-2">{t("Открытый пульт для Furby Connect, который пережил своё приложение. Работает прямо в браузере по Bluetooth LE, ничего не устанавливается и никуда не отправляется: настройки, макросы, правила, прогресс и музыка живут в твоём браузере.", "An open remote for Furby Connect that outlived its app. It works right in the browser over Bluetooth LE, installs nothing and sends nothing anywhere: settings, macros, rules, progress and music live in your browser.")}</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Chip tone="signal">{t("версия 3.0", "version 3.0")}</Chip>
          <Chip tone="amber"><Languages className="h-3 w-3" />{t("тесты: только RU", "tested: RU only")}</Chip>
          <Chip>{t("без сервера", "no server")}</Chip>
          <Chip>{t("не аффилировано с Hasbro", "not affiliated with Hasbro")}</Chip>
        </div>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {["React 19", "TypeScript", "Vite", "Tailwind 4", "Web Bluetooth", "Web Audio", "Canvas", "Lucide"].map((x) => <Chip key={x}>{x}</Chip>)}
        </div>
      </Card>
      <Card title={t("Совместимость по языкам", "Language compatibility")} hint={t("Что проверено на живом железе, а что ещё нет", "What's tested on real hardware and what isn't")} icon={Languages}>
        <div className="grid gap-2 sm:grid-cols-2">
          <div className="rounded-xl border border-signal/40 bg-signal-dim p-3">
            <p className="text-sm font-semibold text-signal">{t("Русский Connect — проверено", "Russian Connect — tested")}</p>
            <p className="mt-1 text-xs text-muted">{t("Все команды, свет, датчики и рукопожатие проверены на живой игрушке.", "All commands, light, sensors and the handshake are tested on a real toy.")}</p>
          </div>
          <div className="rounded-xl border border-amber/40 bg-amber-dim p-3">
            <p className="text-sm font-semibold text-amber">{t("Английский Connect — не проверено", "English Connect — not tested")}</p>
            <p className="mt-1 text-xs text-muted">{t("Коды экшенов могут отличаться, часть реплик другая.", "Action codes may differ and some phrases are different.")}</p>
          </div>
        </div>
        <Notice icon={Languages} className="mt-3">{t("Furby Connect выпускался только на русском и английском — других языковых версий не существует. Есть английский Connect? Прогони пару команд, посмотри журнал и напиши, что сработало, с версией прошивки и кодами экшенов.", "Furby Connect only exists in Russian and English — there are no other language versions. Have an English Connect? Try a few commands, check the log and tell us what worked, with the firmware version and action codes.")}</Notice>
        <a href={TELEGRAM_URL} target="_blank" rel="noreferrer" className="mt-3 inline-flex h-10 items-center gap-2 rounded-lg bg-signal px-4 text-sm font-medium text-white hover:opacity-90">
          <Send className="h-4 w-4" />
          {t("Написать в @furbydeck", "Write to @furbydeck")}
        </a>
      </Card>
      <Card title={t("Команда", "Team")} hint={t("Кто это всё придумал и собрал", "Who came up with all this and built it")} icon={Users}>
        <div className="grid gap-2 md:grid-cols-3">
          {team.map((m) => (
            <a key={m.name} href={m.url} target="_blank" rel="noreferrer" className="flex flex-col gap-2 rounded-xl border border-line bg-panel-2 p-4 transition-colors hover:border-signal/50">
              <span className="flex items-center justify-between">
                <span className="font-display text-base font-bold">{m.name}</span>
                <ExternalLink className="h-3.5 w-3.5 text-faint" />
              </span>
              <Label>{m.where}</Label>
              <span className="text-sm text-ink-2">{m.role}</span>
            </a>
          ))}
        </div>
      </Card>
      <Card title={t("Что нового", "What's new")} icon={Sparkles}>
        <ul className="space-y-2 text-sm text-ink-2">
          <li><b className="text-ink">3.0</b> — {t("дизайн Furby Deck, демо-режим, автоматика и расписание, студия макросов и пианино, монитор канала, журнал с фильтрами, поиск по смыслу, опыт и задания дня", "Furby Deck design, demo mode, automation and schedule, macro studio and piano, channel monitor, filtered log, smart search, XP and daily quests")}</li>
          <li><b className="text-ink">2.x</b> — {t("58 игр, 122 режима подсветки, музыка с танцем 18/0/0/1, полный список команд", "58 games, 122 light modes, music with dance 18/0/0/1, the full command list")}</li>
          <li><b className="text-ink">1.0</b> — {t("BLE-подключение, библиотека экшенов, дебаг-глаза", "BLE connection, action library, debug eyes")}</li>
        </ul>
      </Card>
      <Card title={t("Благодарности", "Credits")} icon={Trophy}>
        <ul className="space-y-1.5 text-sm text-ink-2">
          <li><a className="font-medium text-ink underline-offset-2 hover:underline" href="https://github.com/Jeija/bluefluff" target="_blank" rel="noreferrer">Jeija / bluefluff</a> — {t("разбор протокола и таблица экшенов", "protocol research and the action table")}</li>
          <li><a className="font-medium text-ink underline-offset-2 hover:underline" href="https://github.com/pdjstone/furby-web-bluetooth" target="_blank" rel="noreferrer">pdjstone / FurBLE</a> — {t("расшифровка датчиков через Web Bluetooth", "sensor decoding over Web Bluetooth")}</li>
        </ul>
      </Card>
    </div>
  );
}
